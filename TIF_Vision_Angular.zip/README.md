# TIFVision — Angular 19 TIF Viewer with Claude OCR

A production-grade Angular 19 component for viewing multi-page TIFF files with
Click2Pick / Box Selection → Claude Vision OCR extraction.

## Features

- ✅ Multi-page TIF/TIFF rendering via `geotiff`
- ✅ Thumbnail strip with **lazy loading** (hover/intersection triggers)
- ✅ Zoom: slider, +/-, Ctrl+Scroll, Fit Width, Fit Page, 1:1
- ✅ **Box selection** — drag to draw selection rectangle
- ✅ **Click2Pick** — single click auto-selects 120×40px area
- ✅ Crop snippet → send to Claude Vision API → get text back
- ✅ OCR Results panel with preview image + copy button
- ✅ Paginated navigation (first/prev/next/last + input)
- ✅ Angular 19 Signals & Standalone components
- ✅ Zoneless change detection ready

## Angular 19 Compatibility Notes

> **Note**: This project targets Angular 19 (latest stable). If upgrading to
> Angular 21 when released, change version numbers in package.json accordingly —
> all APIs used (`signal`, `computed`, `afterNextRender`, standalone, `@for`)
> are forward-compatible.

## Quick Start

```bash
npm install
npm start
# Open http://localhost:4200
```

## Project Structure

```
src/app/tif-viewer/
├── tif-viewer.component.ts        # Main viewer component
├── tif-viewer.component.html      # Template with canvas, toolbar, pagination
├── tif-viewer.component.scss      # Dark cyberpunk theme
├── tif-viewer.service.ts          # GeoTIFF parsing + Claude OCR API calls
├── tif-viewer.models.ts           # PageInfo, OcrResult, SelectionRect types
├── thumbnail-strip/
│   ├── thumbnail-strip.component.ts   # Lazy-loading thumbnail strip
│   └── thumbnail-strip.component.scss
├── zoom-controls/
│   ├── zoom-controls.component.ts     # Zoom slider + buttons
│   └── zoom-controls.component.scss
└── ocr-result-panel/
    ├── ocr-result-panel.component.ts  # OCR results with preview + copy
    └── ocr-result-panel.component.scss
```

## Usage in Your App

```typescript
// app.component.ts
import { TifViewerComponent } from './tif-viewer/tif-viewer.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [TifViewerComponent],
  template: `<app-tif-viewer />`,
})
export class AppComponent {}
```

## API Key Setup

1. Click **API KEY** button in the toolbar
2. Paste your Anthropic API key (`sk-ant-...`)
3. Click **SAVE**
4. Key is stored in memory only — never persisted or logged

Get your key at: https://console.anthropic.com

## How Click2Pick / Box Select Works

```
User draws selection on canvas overlay
        ↓
Canvas crops the selected region via OffscreenCanvas
        ↓
Converts to base64 PNG
        ↓
POST to Anthropic /v1/messages with claude-opus-4-5
(image block + "extract all text" prompt)
        ↓
Text returned → displayed in OCR Results panel
```

## Lazy Thumbnail Loading

Thumbnails are loaded on demand:
- **First 5 pages**: loaded immediately on file open
- **Remaining pages**: loaded on hover over thumbnail strip item
- **Page switch**: full ImageData rendered on first navigation

## Keyboard / Mouse Shortcuts

| Action | Shortcut |
|---|---|
| Zoom in/out | `Ctrl + Scroll` |
| Box select | Drag on canvas |
| Click2Pick | Single click (in CLICK mode) |
| Prev/Next page | Toolbar buttons |

## Dependencies

```json
{
  "geotiff": "^2.1.3"    // TIF/GeoTIFF parser
}
```

Claude Vision API is called directly from the service (bring-your-own-key).
For production, **proxy the API call through your backend** to protect the key.

## Backend Proxy (Recommended for Production)

```typescript
// In tif-viewer.service.ts, replace the fetch URL:
const response = await fetch('/api/ocr', {   // Your backend endpoint
  method: 'POST',
  body: JSON.stringify({ image: base64Image })
});
```

```javascript
// Express backend
app.post('/api/ocr', async (req, res) => {
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    headers: { 'x-api-key': process.env.ANTHROPIC_API_KEY },
    body: JSON.stringify({ /* ... */ })
  });
  res.json(await response.json());
});
```
