// src/environments/environment.ts
// ⚠️  For production, proxy API calls through your backend to protect the key.
export const environment = {
  production: false,
  anthropicApiKey: 'YOUR_ANTHROPIC_API_KEY_HERE'
};
