export const environment = {
  production: true,
  anthropicApiKey: '' // Use backend proxy in production - never expose in frontend
};
