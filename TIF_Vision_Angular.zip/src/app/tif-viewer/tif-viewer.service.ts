import { Injectable } from '@angular/core';
import { PageInfo } from './tif-viewer.models';

@Injectable({ providedIn: 'root' })
export class TifViewerService {
  private tiffLib: any = null;

  private async loadGeoTiff(): Promise<any> {
    if (this.tiffLib) return this.tiffLib;
    // Dynamic import — add geotiff to package.json
    this.tiffLib = await import('geotiff');
    return this.tiffLib;
  }

  async loadTiff(file: File): Promise<PageInfo[]> {
    const GeoTIFF = await this.loadGeoTiff();
    const arrayBuffer = await file.arrayBuffer();
    const tiff = await GeoTIFF.fromArrayBuffer(arrayBuffer);
    const count = await tiff.getImageCount();
    const pages: PageInfo[] = [];

    for (let i = 0; i < count; i++) {
      const img = await tiff.getImage(i);
      pages.push({
        index: i,
        width: img.getWidth(),
        height: img.getHeight(),
        imageData: null,
        thumbnailUrl: null,
        loaded: false,
      });
    }

    // Immediately load first page full data
    if (pages.length > 0) {
      const img = await tiff.getImage(0);
      pages[0].imageData = await this.buildImageData(img);
      pages[0].thumbnailUrl = this.imageDataToThumbnail(pages[0].imageData, pages[0].width, pages[0].height, 120);
      pages[0].loaded = true;
    }

    // Store tiff handle for lazy loading
    (this as any)._tiff = tiff;
    return pages;
  }

  async renderPageImageData(page: PageInfo): Promise<void> {
    const tiff = (this as any)._tiff;
    if (!tiff) return;
    const img = await tiff.getImage(page.index);
    page.imageData = await this.buildImageData(img);
    page.thumbnailUrl = this.imageDataToThumbnail(page.imageData, page.width, page.height, 120);
    page.loaded = true;
  }

  private async buildImageData(img: any): Promise<ImageData> {
    const width = img.getWidth();
    const height = img.getHeight();
    const rasters = await img.readRasters({ interleave: true });
    const samplesPerPixel = img.getSamplesPerPixel();
    const data = new Uint8ClampedArray(width * height * 4);

    for (let i = 0; i < width * height; i++) {
      const base = i * samplesPerPixel;
      if (samplesPerPixel === 1) {
        // Grayscale
        const v = rasters[base];
        data[i * 4 + 0] = v;
        data[i * 4 + 1] = v;
        data[i * 4 + 2] = v;
        data[i * 4 + 3] = 255;
      } else if (samplesPerPixel >= 3) {
        data[i * 4 + 0] = rasters[base + 0];
        data[i * 4 + 1] = rasters[base + 1];
        data[i * 4 + 2] = rasters[base + 2];
        data[i * 4 + 3] = samplesPerPixel === 4 ? rasters[base + 3] : 255;
      }
    }
    return new ImageData(data, width, height);
  }

  private imageDataToThumbnail(imageData: ImageData, w: number, h: number, thumbW: number): string {
    const scale = thumbW / w;
    const thumbH = Math.round(h * scale);
    const offscreen = document.createElement('canvas');
    offscreen.width = thumbW;
    offscreen.height = thumbH;
    const src = document.createElement('canvas');
    src.width = w;
    src.height = h;
    src.getContext('2d')!.putImageData(imageData, 0, 0);
    const ctx = offscreen.getContext('2d')!;
    ctx.drawImage(src, 0, 0, thumbW, thumbH);
    return offscreen.toDataURL('image/jpeg', 0.7);
  }

  async getThumbnail(pageIndex: number, pages: PageInfo[]): Promise<string | null> {
    const page = pages[pageIndex];
    if (!page) return null;
    if (page.thumbnailUrl) return page.thumbnailUrl;
    await this.renderPageImageData(page);
    return page.thumbnailUrl;
  }

  async runOcr(base64Image: string, apiKey: string): Promise<string> {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-opus-4-5',
        max_tokens: 1024,
        messages: [{
          role: 'user',
          content: [
            {
              type: 'image',
              source: { type: 'base64', media_type: 'image/png', data: base64Image },
            },
            {
              type: 'text',
              text: 'Extract ALL text visible in this image snippet exactly as it appears. Preserve formatting, line breaks, and spacing. If no text is found, respond with "(no text detected)". Return only the extracted text, nothing else.',
            },
          ],
        }],
      }),
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error((err as any)?.error?.message || `API error ${response.status}`);
    }

    const data = await response.json();
    return data.content?.map((c: any) => c.text || '').join('') || '(empty response)';
  }
}
