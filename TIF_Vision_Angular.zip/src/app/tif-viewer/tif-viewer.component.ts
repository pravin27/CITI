import {
  Component, OnInit, OnDestroy, ViewChild, ElementRef,
  signal, computed, inject, NgZone, afterNextRender,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TifViewerService } from './tif-viewer.service';
import { ThumbnailStripComponent } from './thumbnail-strip/thumbnail-strip.component';
import { OcrResultPanelComponent } from './ocr-result-panel/ocr-result-panel.component';
import { ZoomControlsComponent } from './zoom-controls/zoom-controls.component';
import { PageInfo, OcrResult, SelectionRect } from './tif-viewer.models';

@Component({
  selector: 'app-tif-viewer',
  standalone: true,
  imports: [CommonModule, FormsModule, ThumbnailStripComponent, OcrResultPanelComponent, ZoomControlsComponent],
  templateUrl: './tif-viewer.component.html',
  styleUrls: ['./tif-viewer.component.scss'],
})
export class TifViewerComponent implements OnInit, OnDestroy {
  @ViewChild('mainCanvas', { static: false }) mainCanvasRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('overlayCanvas', { static: false }) overlayCanvasRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('viewerContainer', { static: false }) viewerContainerRef!: ElementRef<HTMLDivElement>;

  private tifService = inject(TifViewerService);
  private ngZone = inject(NgZone);

  pages = signal<PageInfo[]>([]);
  currentPageIndex = signal<number>(0);
  zoom = signal<number>(1.0);
  isLoading = signal<boolean>(false);
  isOcrLoading = signal<boolean>(false);
  ocrResults = signal<OcrResult[]>([]);
  selectionMode = signal<'box' | 'click'>('box');
  isDragging = signal<boolean>(false);
  selectionRect = signal<SelectionRect | null>(null);
  fileName = signal<string>('');
  apiKey = signal<string>('');
  showApiKeyInput = signal<boolean>(false);
  errorMessage = signal<string>('');

  currentPage = computed(() => this.pages()[this.currentPageIndex()]);
  totalPages = computed(() => this.pages().length);
  canGoPrev = computed(() => this.currentPageIndex() > 0);
  canGoNext = computed(() => this.currentPageIndex() < this.totalPages() - 1);

  private dragStart = { x: 0, y: 0 };
  private resizeObserver: ResizeObserver | null = null;

  readonly ZOOM_MIN = 0.25;
  readonly ZOOM_MAX = 4.0;
  readonly ZOOM_STEP = 0.25;

  constructor() {
    afterNextRender(() => { this.setupResizeObserver(); });
  }

  ngOnInit(): void {}
  ngOnDestroy(): void { this.resizeObserver?.disconnect(); }

  async onFileSelected(event: Event): Promise<void> {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;
    this.fileName.set(file.name);
    this.isLoading.set(true);
    this.errorMessage.set('');
    this.pages.set([]);
    this.currentPageIndex.set(0);
    this.ocrResults.set([]);
    try {
      const loadedPages = await this.tifService.loadTiff(file);
      this.pages.set(loadedPages);
      await this.renderCurrentPage();
    } catch (err: any) {
      this.errorMessage.set(err.message || 'Failed to load TIF file.');
    } finally {
      this.isLoading.set(false);
    }
  }

  async goToPage(index: number): Promise<void> {
    if (index < 0 || index >= this.totalPages()) return;
    this.currentPageIndex.set(index);
    await this.renderCurrentPage();
  }

  async prevPage(): Promise<void> { await this.goToPage(this.currentPageIndex() - 1); }
  async nextPage(): Promise<void> { await this.goToPage(this.currentPageIndex() + 1); }

  async zoomIn(): Promise<void> { this.zoom.set(Math.min(this.zoom() + this.ZOOM_STEP, this.ZOOM_MAX)); await this.renderCurrentPage(); }
  async zoomOut(): Promise<void> { this.zoom.set(Math.max(this.zoom() - this.ZOOM_STEP, this.ZOOM_MIN)); await this.renderCurrentPage(); }

  async setZoom(value: number): Promise<void> {
    this.zoom.set(Math.max(this.ZOOM_MIN, Math.min(this.ZOOM_MAX, value)));
    await this.renderCurrentPage();
  }

  async fitToWidth(): Promise<void> {
    const page = this.currentPage();
    const container = this.viewerContainerRef?.nativeElement;
    if (!page || !container) return;
    await this.setZoom((container.clientWidth - 40) / page.width);
  }

  async fitToPage(): Promise<void> {
    const page = this.currentPage();
    const container = this.viewerContainerRef?.nativeElement;
    if (!page || !container) return;
    await this.setZoom(Math.min((container.clientWidth - 40) / page.width, (container.clientHeight - 40) / page.height));
  }

  async renderCurrentPage(): Promise<void> {
    const page = this.currentPage();
    if (!page || !this.mainCanvasRef) return;
    const canvas = this.mainCanvasRef.nativeElement;
    const overlay = this.overlayCanvasRef.nativeElement;
    const z = this.zoom();
    canvas.width = page.width * z;
    canvas.height = page.height * z;
    overlay.width = canvas.width;
    overlay.height = canvas.height;
    const ctx = canvas.getContext('2d')!;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (!page.imageData) await this.tifService.renderPageImageData(page);
    if (page.imageData) {
      const offscreen = document.createElement('canvas');
      offscreen.width = page.width;
      offscreen.height = page.height;
      offscreen.getContext('2d')!.putImageData(page.imageData, 0, 0);
      ctx.drawImage(offscreen, 0, 0, page.width * z, page.height * z);
    }
    this.clearOverlay();
  }

  private clearOverlay(): void {
    const overlay = this.overlayCanvasRef?.nativeElement;
    if (!overlay) return;
    overlay.getContext('2d')!.clearRect(0, 0, overlay.width, overlay.height);
  }

  onMouseDown(event: MouseEvent): void {
    const pt = this.getCanvasOffset(event);
    this.dragStart = pt;
    this.isDragging.set(true);
    this.selectionRect.set(null);
  }

  onMouseMove(event: MouseEvent): void {
    if (!this.isDragging()) return;
    const current = this.getCanvasOffset(event);
    const sel: SelectionRect = {
      x: Math.min(this.dragStart.x, current.x),
      y: Math.min(this.dragStart.y, current.y),
      width: Math.abs(current.x - this.dragStart.x),
      height: Math.abs(current.y - this.dragStart.y),
    };
    this.selectionRect.set(sel);
    this.drawSelectionOverlay(sel);
  }

  async onMouseUp(event: MouseEvent): Promise<void> {
    if (!this.isDragging()) return;
    this.isDragging.set(false);
    const sel = this.selectionRect();
    if (sel && sel.width > 10 && sel.height > 10) {
      await this.processSelection(sel);
    } else {
      const pt = this.getCanvasOffset(event);
      await this.processSelection({ x: Math.max(0, pt.x - 60), y: Math.max(0, pt.y - 20), width: 120, height: 40 });
    }
  }

  onMouseLeave(): void { if (this.isDragging()) this.isDragging.set(false); }

  private getCanvasOffset(event: MouseEvent): { x: number; y: number } {
    const bounds = this.overlayCanvasRef.nativeElement.getBoundingClientRect();
    return { x: event.clientX - bounds.left, y: event.clientY - bounds.top };
  }

  private drawSelectionOverlay(sel: SelectionRect): void {
    const overlay = this.overlayCanvasRef?.nativeElement;
    if (!overlay) return;
    const ctx = overlay.getContext('2d')!;
    ctx.clearRect(0, 0, overlay.width, overlay.height);
    ctx.fillStyle = 'rgba(0,0,0,0.3)';
    ctx.fillRect(0, 0, overlay.width, overlay.height);
    ctx.clearRect(sel.x, sel.y, sel.width, sel.height);
    ctx.strokeStyle = '#00e5ff';
    ctx.lineWidth = 2;
    ctx.setLineDash([6, 3]);
    ctx.strokeRect(sel.x, sel.y, sel.width, sel.height);
    const hs = 8;
    ctx.fillStyle = '#00e5ff';
    ctx.setLineDash([]);
    [[sel.x, sel.y], [sel.x + sel.width, sel.y], [sel.x, sel.y + sel.height], [sel.x + sel.width, sel.y + sel.height]]
      .forEach(([cx, cy]) => ctx.fillRect(cx - hs / 2, cy - hs / 2, hs, hs));
    const z = this.zoom();
    ctx.fillStyle = '#00e5ff';
    ctx.font = '11px monospace';
    ctx.fillText(`${Math.round(sel.width / z)} × ${Math.round(sel.height / z)}px`, sel.x + 4, sel.y - 6);
  }

  async processSelection(sel: SelectionRect): Promise<void> {
    const key = this.apiKey();
    if (!key) { this.showApiKeyInput.set(true); this.errorMessage.set('Enter your Anthropic API key to use OCR.'); return; }
    const mainCanvas = this.mainCanvasRef.nativeElement;
    const offscreen = document.createElement('canvas');
    offscreen.width = sel.width;
    offscreen.height = sel.height;
    offscreen.getContext('2d')!.drawImage(mainCanvas, sel.x, sel.y, sel.width, sel.height, 0, 0, sel.width, sel.height);
    const base64 = offscreen.toDataURL('image/png').split(',')[1];
    const previewUrl = offscreen.toDataURL('image/png');
    this.isOcrLoading.set(true);
    this.clearOverlay();
    try {
      const text = await this.tifService.runOcr(base64, key);
      this.ocrResults.update(prev => [{
        id: Date.now(), text, imageDataUrl: previewUrl,
        pageIndex: this.currentPageIndex(), selection: { ...sel }, timestamp: new Date(),
      }, ...prev]);
      this.errorMessage.set('');
    } catch (err: any) {
      this.errorMessage.set(err.message || 'OCR failed.');
    } finally {
      this.isOcrLoading.set(false);
    }
  }

  clearOcrResults(): void { this.ocrResults.set([]); }
  removeOcrResult(id: number): void { this.ocrResults.update(prev => prev.filter(r => r.id !== id)); }

  private setupResizeObserver(): void {
    const container = this.viewerContainerRef?.nativeElement;
    if (!container) return;
    this.resizeObserver = new ResizeObserver(() => this.ngZone.run(() => this.renderCurrentPage()));
    this.resizeObserver.observe(container);
  }

  onWheelZoom(event: WheelEvent): void {
    if (!event.ctrlKey && !event.metaKey) return;
    event.preventDefault();
    this.setZoom(this.zoom() + (event.deltaY < 0 ? this.ZOOM_STEP : -this.ZOOM_STEP));
  }

  get zoomPercent(): number { return Math.round(this.zoom() * 100); }

  setApiKey(key: string): void { this.apiKey.set(key); if (key) { this.showApiKeyInput.set(false); this.errorMessage.set(''); } }
  dismissError(): void { this.errorMessage.set(''); }
}
