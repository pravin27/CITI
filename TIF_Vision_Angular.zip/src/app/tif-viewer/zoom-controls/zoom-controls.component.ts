import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-zoom-controls',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="zoom-bar">
      <button class="zoom-btn" (click)="zoomOut.emit()" [disabled]="zoom <= zoomMin" title="Zoom Out (Ctrl+Scroll)">
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
          <circle cx="6" cy="6" r="5" stroke="currentColor" stroke-width="1.5"/>
          <line x1="3.5" y1="6" x2="8.5" y2="6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          <line x1="10" y1="10" x2="13" y2="13" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
        </svg>
      </button>

      <div class="zoom-slider-wrap">
        <input
          type="range"
          class="zoom-slider"
          [min]="zoomMin * 100"
          [max]="zoomMax * 100"
          [step]="25"
          [value]="zoomPercent"
          (input)="onSliderChange($event)"
          title="Zoom"
        />
      </div>

      <button class="zoom-btn" (click)="zoomIn.emit()" [disabled]="zoom >= zoomMax" title="Zoom In">
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
          <circle cx="6" cy="6" r="5" stroke="currentColor" stroke-width="1.5"/>
          <line x1="6" y1="3.5" x2="6" y2="8.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          <line x1="3.5" y1="6" x2="8.5" y2="6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          <line x1="10" y1="10" x2="13" y2="13" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
        </svg>
      </button>

      <div class="zoom-value">{{ zoomPercent }}%</div>

      <div class="zoom-divider"></div>

      <button class="zoom-btn zoom-btn--text" (click)="fitWidth.emit()" title="Fit to Width">⇔</button>
      <button class="zoom-btn zoom-btn--text" (click)="fitPage.emit()" title="Fit to Page">⊡</button>
      <button class="zoom-btn zoom-btn--text" (click)="reset.emit()" title="Reset Zoom (100%)">1:1</button>
    </div>
  `,
  styleUrls: ['./zoom-controls.component.scss'],
})
export class ZoomControlsComponent {
  @Input() zoom: number = 1;
  @Input() zoomMin: number = 0.25;
  @Input() zoomMax: number = 4;
  @Output() zoomIn = new EventEmitter<void>();
  @Output() zoomOut = new EventEmitter<void>();
  @Output() zoomChange = new EventEmitter<number>();
  @Output() fitWidth = new EventEmitter<void>();
  @Output() fitPage = new EventEmitter<void>();
  @Output() reset = new EventEmitter<void>();

  get zoomPercent(): number { return Math.round(this.zoom * 100); }

  onSliderChange(event: Event): void {
    const val = +(event.target as HTMLInputElement).value;
    this.zoomChange.emit(val / 100);
  }
}
