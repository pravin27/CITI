import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class LlmService {
  private http = inject(HttpClient);

  /**
   * Sends a base64 PNG snippet to Claude Vision and returns extracted text.
   * Route through your backend to keep the API key secure in production.
   */
  async extractText(base64Image: string): Promise<string> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'x-api-key': environment.anthropicApiKey,
      'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true'
    });

    const body = {
      model: 'claude-opus-4-5',
      max_tokens: 2048,
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'image',
              source: {
                type: 'base64',
                media_type: 'image/png',
                data: base64Image
              }
            },
            {
              type: 'text',
              text: `You are an OCR assistant. Extract ALL text visible in this image snippet exactly as it appears.
- Preserve formatting, line breaks, and spacing as much as possible.
- If the image contains a table, preserve the tabular structure.
- If no readable text is found, respond with: [No text found in selection]
- Do not add explanations, just return the extracted text.`
            }
          ]
        }
      ]
    };

    const response = await firstValueFrom(
      this.http.post<any>('https://api.anthropic.com/v1/messages', body, { headers })
    );

    if (response?.content?.[0]?.text) {
      return response.content[0].text.trim();
    }
    throw new Error('No content returned from LLM');
  }
}
