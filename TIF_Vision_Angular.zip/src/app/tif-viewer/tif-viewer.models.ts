export interface PageInfo {
  index: number;
  width: number;
  height: number;
  imageData: ImageData | null;
  thumbnailUrl: string | null;
  loaded: boolean;
}

export interface OcrResult {
  id: number;
  text: string;
  imageDataUrl: string;
  pageIndex: number;
  selection: SelectionRect;
  timestamp: Date;
}

export interface SelectionRect {
  x: number;
  y: number;
  width: number;
  height: number;
}
