import {
  Component, Input, Output, EventEmitter, OnChanges,
  SimpleChanges, signal, inject, ChangeDetectionStrategy,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { TifViewerService } from '../tif-viewer.service';
import { PageInfo } from '../tif-viewer.models';

@Component({
  selector: 'app-thumbnail-strip',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="thumb-strip">
      <div class="thumb-strip__header">
        <span class="thumb-strip__label">PAGES</span>
        <span class="thumb-strip__count">{{ pages.length }}</span>
      </div>
      <div class="thumb-strip__list">
        @for (page of pages; track page.index) {
          <div
            class="thumb-item"
            [class.thumb-item--active]="page.index === currentPageIndex"
            (click)="onPageClick(page.index)"
            (mouseenter)="onThumbHover(page)"
          >
            <div class="thumb-item__img-wrap">
              @if (page.thumbnailUrl) {
                <img [src]="page.thumbnailUrl" class="thumb-item__img" [alt]="'Page ' + (page.index + 1)" />
              } @else if (loadingThumbs.has(page.index)) {
                <div class="thumb-item__skeleton">
                  <div class="thumb-item__spinner"></div>
                </div>
              } @else {
                <div class="thumb-item__placeholder">
                  <span class="thumb-item__placeholder-icon">◻</span>
                </div>
              }
            </div>
            <span class="thumb-item__num">{{ page.index + 1 }}</span>
            @if (page.index === currentPageIndex) {
              <div class="thumb-item__active-bar"></div>
            }
          </div>
        }
      </div>
    </div>
  `,
  styleUrls: ['./thumbnail-strip.component.scss'],
})
export class ThumbnailStripComponent implements OnChanges {
  @Input() pages: PageInfo[] = [];
  @Input() currentPageIndex: number = 0;
  @Output() pageSelected = new EventEmitter<number>();

  private tifService = inject(TifViewerService);
  loadingThumbs = new Set<number>();
  private observer: IntersectionObserver | null = null;

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['pages'] && this.pages.length > 0) {
      this.setupLazyLoading();
    }
  }

  private setupLazyLoading(): void {
    // Pre-load thumbnails for first 5 pages
    this.pages.slice(0, 5).forEach(p => {
      if (!p.thumbnailUrl) this.loadThumb(p);
    });
  }

  async onThumbHover(page: PageInfo): Promise<void> {
    if (!page.thumbnailUrl && !this.loadingThumbs.has(page.index)) {
      await this.loadThumb(page);
    }
  }

  async loadThumb(page: PageInfo): Promise<void> {
    if (this.loadingThumbs.has(page.index)) return;
    this.loadingThumbs.add(page.index);
    try {
      await this.tifService.renderPageImageData(page);
    } finally {
      this.loadingThumbs.delete(page.index);
    }
  }

  onPageClick(index: number): void {
    this.pageSelected.emit(index);
  }
}
