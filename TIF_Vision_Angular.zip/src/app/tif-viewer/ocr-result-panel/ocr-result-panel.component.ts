import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OcrResult } from '../tif-viewer.models';

@Component({
  selector: 'app-ocr-result-panel',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="ocr-panel">
      <div class="ocr-panel__header">
        <div class="ocr-panel__title">
          <span class="ocr-panel__icon">◈</span>
          <span>OCR RESULTS</span>
          <span class="ocr-panel__badge">{{ results.length }}</span>
        </div>
        <button class="ocr-panel__clear" (click)="clearAll.emit()" [disabled]="results.length === 0">
          CLEAR ALL
        </button>
      </div>

      @if (isLoading) {
        <div class="ocr-panel__loading">
          <div class="ocr-panel__loading-bar">
            <div class="ocr-panel__loading-fill"></div>
          </div>
          <span class="ocr-panel__loading-text">Sending to Claude Vision...</span>
        </div>
      }

      <div class="ocr-panel__list">
        @if (results.length === 0 && !isLoading) {
          <div class="ocr-panel__empty">
            <div class="ocr-panel__empty-icon">⬚</div>
            <p class="ocr-panel__empty-text">Draw a box or click on the document to extract text</p>
          </div>
        }

        @for (result of results; track result.id) {
          <div class="ocr-result" [@slideIn]>
            <div class="ocr-result__header">
              <span class="ocr-result__meta">Page {{ result.pageIndex + 1 }} · {{ result.timestamp | date:'HH:mm:ss' }}</span>
              <div class="ocr-result__actions">
                <button class="ocr-result__btn" (click)="copyText(result.text)" title="Copy text">⎘</button>
                <button class="ocr-result__btn ocr-result__btn--remove" (click)="removeResult.emit(result.id)" title="Remove">✕</button>
              </div>
            </div>

            <div class="ocr-result__preview-wrap">
              <img [src]="result.imageDataUrl" class="ocr-result__preview" alt="Cropped snippet" />
            </div>

            <div class="ocr-result__text-wrap">
              <pre class="ocr-result__text">{{ result.text }}</pre>
            </div>

            @if (copiedId === result.id) {
              <div class="ocr-result__copied">✓ Copied</div>
            }
          </div>
        }
      </div>
    </div>
  `,
  styleUrls: ['./ocr-result-panel.component.scss'],
})
export class OcrResultPanelComponent {
  @Input() results: OcrResult[] = [];
  @Input() isLoading: boolean = false;
  @Output() clearAll = new EventEmitter<void>();
  @Output() removeResult = new EventEmitter<number>();

  copiedId: number | null = null;

  async copyText(text: string): Promise<void> {
    await navigator.clipboard.writeText(text);
  }
}
