import {
  Directive, ElementRef, EventEmitter,
  Input, OnDestroy, OnInit, Output
} from '@angular/core';

@Directive({
  selector: '[appLazyThumb]',
  standalone: true
})
export class LazyThumbDirective implements OnInit, OnDestroy {
  @Input('appLazyThumb') pageIndex!: number;
  @Output() intersect = new EventEmitter<number>();

  private observer!: IntersectionObserver;

  constructor(private el: ElementRef<HTMLElement>) {}

  ngOnInit(): void {
    this.observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(e => {
          if (e.isIntersecting) {
            this.intersect.emit(this.pageIndex);
            this.observer.disconnect(); // only trigger once
          }
        });
      },
      { rootMargin: '120px', threshold: 0.01 }
    );
    this.observer.observe(this.el.nativeElement);
  }

  ngOnDestroy(): void {
    this.observer?.disconnect();
  }
}
