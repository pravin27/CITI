import { Component } from '@angular/core';
import { TifViewerComponent } from './tif-viewer/tif-viewer.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [TifViewerComponent],
  template: `<app-tif-viewer style="height:100vh;display:block;" />`,
})
export class AppComponent {}
