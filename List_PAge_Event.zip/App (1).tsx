import { navigatePdfPage } from './components/PDFViewer';
import React, { useRef, useState, useEffect, useCallback } from 'react';
import { useAppStore } from './store/appStore';
import { TopBar } from './components/TopBar';
import { ResizablePanes } from './components/ResizablePanes';
import { ViewerToolbar } from './components/ViewerToolbar';
import { ViewerPane } from './components/ViewerPane';
import { FieldsPanel } from './components/FieldsPanel';
import { ThumbnailSidebar } from './components/ThumbnailSidebar';
import { useSidecarLoader } from './hooks/useSidecarLoader';
import { useMultiDoc } from './hooks/useMultiDoc';
import { MultiDocSidebar } from './components/MultiDocSidebar';
import type { DocumentManifest } from './types/multiDoc';
import { categoryColor } from './adapters/types';
import { useEventBridge, isEmbedded, generateTempId } from './hooks/useEventBridge';
import { SPLIT_MERGE_URL } from './config';
import { preloadPdfResources } from './utils/pdfResourceCache';
import { parseHighlightPayload } from './utils/parseHighlightPayload';

function useGlobalShortcuts() {
  const setSearchOpen = useAppStore(s => s.setSearchOpen);
  const searchIsOpen  = useAppStore(s => s.search.isOpen);
  const file          = useAppStore(s => s.file);
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'f' && file) {
        e.preventDefault(); setSearchOpen(!searchIsOpen);
      }
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [setSearchOpen, searchIsOpen, file]);
}

// ── normaliseEntry — pure helper used by applyDocMeta ────────────────────────
// Takes a raw wordIndex entry in ANY supported coord format and returns it
// with normalised { x, y, width, height } (0-1 fractions) so rebuildCaches
// can read e.x, e.y, e.width, e.height directly without further conversion.
function normaliseEntry(
  e: Record<string, unknown>,
  pg: number,
  adapter: any,
  extractRawCoords: Function,
  normaliseCoords: Function,
  getExtractedPage?: Function,
): Record<string, unknown> {
  const raw = extractRawCoords(e) as [number,number,number,number] | null;
  if (!raw) return e;

  // FORMAT 10: page was embedded in bbox[0] — use extracted page for normalisation
  const effectivePage = getExtractedPage ? getExtractedPage(e, pg) : pg;

  const [rx, ry, rw, rh] = raw;
  const isNorm = rx <= 1 && ry <= 1 && rw <= 1 && rh <= 1;
  if (isNorm) {
    return {
      ...e, x: rx, y: ry, width: rw, height: rh, _rawUnit: 'norm',
      // Store extracted page so store knows the correct page for this item
      ...(effectivePage !== pg ? { page: effectivePage } : {}),
    };
  }
  const [x, y, w, h] =
    normaliseCoords(raw, e, effectivePage, adapter, null) as [number,number,number,number];

  // Store original bbox for FORMAT 10 round-trip reconstruction
  const isFmt10 = Array.isArray(e.bbox) && (e.bbox as unknown[]).length === 5;

  return {
    ...e, x, y, width: w, height: h,
    _rawX: rx, _rawY: ry, _rawWidth: rw, _rawHeight: rh, _rawUnit: 'px',
    // FORMAT 10: preserve original [page, x, y, w, h] for CAPTURE_PREVIEW
    ...(isFmt10 ? { _rawBbox: e.bbox } : {}),
    ...(effectivePage !== pg ? { page: effectivePage } : {}),
  };
}

export default function App() {
  const sidebarOpen    = useAppStore(s => s.sidebarOpen);
  const openFile       = useAppStore(s => s.openFile);
  const setCurrentPage = useAppStore(s => s.setCurrentPage);
  const closeFile      = useAppStore(s => s.closeFile);
  const adapter               = useAppStore(s => s.adapter);
  const setWordIndex          = useAppStore(s => s.setWordIndex);
  const setCategories         = useAppStore(s => s.setCategories);
  const addCaptureWithId      = useAppStore(s => s.addCaptureWithId);
  const navigateAndHighlight  = useAppStore(s => s.navigateAndHighlight);
  const openFileBuffer        = useAppStore(s => s.openFileBuffer);
  const enableCaptureDebug    = useAppStore(s => s.enableCaptureDebug);
  const enableAnnotation      = useAppStore(s => s.enableAnnotation);
  const enableThumbnailView   = useAppStore(s => s.enableThumbnailView);
  const setEnableCaptureDebug = useAppStore(s => s.setEnableCaptureDebug);
  const showSplitMerge    = useAppStore(s => s.showSplitMerge);
  // splitMergeUrl is internal — read from env (VITE_SPLIT_MERGE_URL), not from parent
  const splitMergeUrl     = SPLIT_MERGE_URL;
  const [smActive,    setSmActive]    = React.useState(false);
  const [showConfirm,      setShowConfirm]      = React.useState(false);
  const [showResetConfirm, setShowResetConfirm] = React.useState(false);
  const [retriggerMode,    setRetriggerMode]    = React.useState<'with_idp'|'without_idp'>('without_idp');
  const smIframeRef       = React.useRef<HTMLIFrameElement>(null);
  const smIframeLoaded    = React.useRef(false);  // tracks cross-origin load state

  // Expose confirm popup opener globally so ThumbnailSidebar/MultiDocSidebar
  // can trigger the full-viewer overlay without prop drilling
  React.useEffect(() => {
    (window as any).__doccapture_openRetriggerConfirm = (mode: 'with_idp'|'without_idp' = 'without_idp') => {
      setRetriggerMode(mode);
      setShowConfirm(true);
    };
    (window as any).__doccapture_openResetConfirm = () => setShowResetConfirm(true);
    return () => {
      delete (window as any).__doccapture_openRetriggerConfirm;
      delete (window as any).__doccapture_openResetConfirm;
    };
  }, []);

  useSidecarLoader();
  useGlobalShortcuts();

  // ── Split & Merge integration ───────────────────────────────────────────────

  // Register the global opener so ViewerToolbar can call it without prop-drilling
  React.useEffect(() => {
    (window as any).__doccapture_openSplitMerge = () => {
      if (!splitMergeUrl) { console.warn('[SplitMerge] splitMergeUrl not configured in .env'); return; }

      // Activate SM mode — viewer hides, event bridge pauses doc-load events
      (window as any).__doccapture_sm_active = true;
      setSmActive(true);

      const st = useAppStore.getState();

      // Retrieve the complete original message that the parent sent
      // (stored by useEventBridge on LOAD_SINGLEDOC / LOAD_MANIFEST)
      const originalMsg = (window as any).__doccapture_last_parent_msg ?? {};

      // ── Patch payload with CURRENT store state before sending to SM ──────
      // When SM has reclassified and sent SM_RECLASSIFY, the store holds
      // the updated categories/documents. We must send THOSE to SM on the
      // next open — not the stale original from the parent message.
      const storeCategories = useAppStore.getState().categories;
      const patchedPayload: Record<string, unknown> = { ...originalMsg };

      // LOAD_SINGLEDOC: patch categories[]
      if (storeCategories?.length) {
        patchedPayload.categories = storeCategories;
      }

      // LOAD_MANIFEST: patch manifest.documents with current state.
      // Convert internal `categoryId` field back to `category` string
      // so SM app receives the same format it originally sent.
      const mds = multiDocRef.current?.state;
      if (mds?.documents?.length && patchedPayload.manifest) {
        const docsForSM = mds.documents.map((d: any) => ({
          ...d,
          category:   d.categoryId,   // SM expects "category" not "categoryId"
          categoryId: undefined,       // remove internal field
        }));
        patchedPayload.manifest = {
          ...(patchedPayload.manifest as Record<string, unknown>),
          documents: docsForSM,
        };
      }

      // Build the SPLIT_MERGE_OPEN envelope
      const smMessage: Record<string, unknown> = {
        type:    'SPLIT_MERGE_OPEN',
        payload: patchedPayload,             // patched with current state
        viewerState: {
          pageCount:   st.pageCount,
          currentPage: st.currentPage,
          format:      st.format,             // 'pdf'|'image'|'document'|'spreadsheet'
        },
      };

      // Extract buffer from payload for Transferable zero-copy transfer
      // The buffer in the payload clone is the same reference — slice it for transfer
      const payloadBuf =
        (originalMsg.buffer instanceof ArrayBuffer && originalMsg.buffer.byteLength > 0)
          ? originalMsg.buffer
          : (originalMsg.activeBuffer instanceof ArrayBuffer && originalMsg.activeBuffer.byteLength > 0)
          ? originalMsg.activeBuffer
          : null;

        // postToSM: attempts to post smMessage to the iframe.
        // contentWindow is available even for cross-origin iframes.
        // We retry every 100ms for up to 5 seconds in case the iframe
        // is still loading — this handles both first open and subsequent opens.
        const postToSM = () => {
          const win = smIframeRef.current?.contentWindow;
          if (!win) return false;
          if (payloadBuf) {
            const buf = payloadBuf.slice(0);
            if (originalMsg.buffer instanceof ArrayBuffer)
              (smMessage.payload as any).buffer = buf;
            if (originalMsg.activeBuffer instanceof ArrayBuffer)
              (smMessage.payload as any).activeBuffer = buf;
            win.postMessage(smMessage, '*', [buf]);
          } else {
            win.postMessage(smMessage, '*');
          }
          return true;
        };

        // Try immediately (works when iframe already loaded from previous open)
        if (!postToSM()) {
          // Iframe not ready yet — retry every 100ms until it is (max 5s)
          let attempts = 0;
          const retry = setInterval(() => {
            attempts++;
            if (postToSM() || attempts >= 50) clearInterval(retry);
          }, 100);
        }

      // Notify parent Angular that SM mode is now active
      if (isEmbedded) window.parent.postMessage({ type: 'SPLIT_MERGE_OPENED', fileName: st.fileName }, '*');
    };

    // Register close handler — called by useEventBridge when a new doc load
    // arrives while SM is active (parent loaded a new document)
    (window as any).__doccapture_closeSplitMerge = () => {
      setSmActive(false);
      // Notify parent that SM exited due to new document load
      if (isEmbedded) window.parent.postMessage({ type: 'SPLIT_MERGE_EXITED', reason: 'new_doc' }, '*');
    };

    return () => {
      delete (window as any).__doccapture_openSplitMerge;
      delete (window as any).__doccapture_closeSplitMerge;
      delete (window as any).__doccapture_sm_doPost;
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [splitMergeUrl, smIframeRef]);

  // Listen for messages FROM the SM iframe (SAVE / EXIT)
  // ── multiDocRef: lets the message handler (registered once) always access
  // the latest multiDoc state without being stale from the [] closure ────────
  const multiDocRef = React.useRef<ReturnType<typeof useMultiDoc> | null>(null);

  React.useEffect(() => {
    const handler = (event: MessageEvent) => {
      const data = event.data as Record<string, unknown>;
      if (!data?.type) return;

      // SM_RECLASSIFY — SM iframe sends reclassified data back to viewer.
      // Supports all three load scenarios:
      //   LOAD_SINGLEDOC      → categories[] changed
      //   MultiDoc:SinglePage → documents[].category changed
      //   MultiDoc:MultiPage  → documents[].pageCategories changed
      if (data.type === 'SM_RECLASSIFY') {
        // Always close SM and show viewer regardless of whether data changed
        (window as any).__doccapture_sm_active = false;
        setSmActive(false);

        // Re-apply isSplitScreen from SM payload — ensures bar shows even if
        // the store value was false (e.g. store was reset by a new doc load)
        if (data.isSplitScreen === true) {
          useAppStore.getState().setIsSplitScreen(true);
          useAppStore.getState().setSidebarOpen(true);
        }

        const hasCategories = Array.isArray(data.categories) && data.categories.length > 0;
        const hasDocuments  = Array.isArray(data.documents)  && data.documents.length  > 0;

        if (!hasCategories && !hasDocuments) {
          // No data sent — treat same as SPLIT_MERGE_EXIT (no change in SM app)
          if (isEmbedded) window.parent.postMessage({ type: 'SPLIT_MERGE_EXITED', reason: 'no_change' }, '*');
          return;
        }

        // Option A: Viewer owns the original snapshot — SM sends updated data only.
        const st = useAppStore.getState();

        // ── LOAD_SINGLEDOC: updated flat categories from SM ───────────────
        if (hasCategories) {
          const updated = (data.categories as any[]).map((c: any) => ({
            ...c, color: c.color ?? categoryColor(c.label ?? c.id ?? ''),
          }));
          setTimeout(() => {
            st.setCategories(updated as any);
            st.setHasReclassification(true);
          }, 0);
        }

        // ── MultiDoc: updated documents from SM ───────────────────────────
        const md = multiDocRef.current;
        if (hasDocuments && md?.state) {
          md.updateDocuments?.(data.documents as any[]);
          st.setHasReclassification(true);
        }

        // Reset retrigger bar to 'idle' so it reappears with fresh data.
        // The sidebar keeps retriggerState in local component state — it persists
        // as 'done' from any prior Retrigger click since the component stays mounted.
        // Calling this reset makes the bar visible again after SM_RECLASSIFY.
        (window as any).__doccapture_resetRetriggerBar?.();

        // NOTE: st.originalCategories is intentionally NOT touched here.
        return;
      }

      if (data.type === 'SPLIT_MERGE_SAVE') {
        // Deactivate SM mode
        (window as any).__doccapture_sm_active = false;
        setSmActive(false);

        // If SM app sends back a new buffer, reload the document
        if (data.buffer instanceof ArrayBuffer && data.buffer.byteLength > 0) {
          const fileName = (data.fileName as string) || useAppStore.getState().fileName;
          useAppStore.getState().openFileBuffer(data.buffer, fileName);
          if (isEmbedded) window.parent.postMessage({ type: 'SPLIT_MERGE_SAVED', fileName }, '*');
        } else {
          if (isEmbedded) window.parent.postMessage({ type: 'SPLIT_MERGE_SAVED' }, '*');
        }
      }

      if (data.type === 'SPLIT_MERGE_EXIT') {
        (window as any).__doccapture_sm_active = false;
        setSmActive(false);
        if (isEmbedded) window.parent.postMessage({ type: 'SPLIT_MERGE_EXITED' }, '*');
      }
    };
    window.addEventListener('message', handler);
    return () => window.removeEventListener('message', handler);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── Multi-doc state ───────────────────────────────────────────────────────
  const multiDoc = useMultiDoc();
  // Keep ref in sync so message handler always has latest state
  multiDocRef.current = multiDoc;

  // Expose updateDocuments globally so MultiDocSidebar handleDiscard can call it
  React.useEffect(() => {
    (window as any).__doccapture_updateDocuments = (docs: any[]) => {
      multiDoc.updateDocuments?.(docs);
    };
    return () => { delete (window as any).__doccapture_updateDocuments; };
  }, [multiDoc]);

  // ── Event bridge (only active when running inside an iframe) ─────────────
  // ── waitForAdapter ────────────────────────────────────────────────────────
  // Returns a Promise that resolves when the adapter is loaded AND ready
  // (all page dimensions available). Safe to call any time — if already
  // ready it resolves on the next microtask.
  const waitForAdapterReady = useCallback((): Promise<void> => {
    return new Promise(resolve => {
      const tryBind = () => {
        const ad = useAppStore.getState().adapter;
        if (ad && typeof (ad as any).onReady === 'function') {
          (ad as any).onReady(resolve); // fires immediately if already ready
        } else {
          // Adapter not created yet — wait for it
          const unsub = useAppStore.subscribe((state, prev) => {
            if (state.adapter && state.adapter !== prev.adapter) {
              unsub();
              if (typeof (state.adapter as any).onReady === 'function') {
                (state.adapter as any).onReady(resolve);
              } else {
                resolve();
              }
            }
          });
        }
      };
      tryBind();
    });
  }, []);

  // ── applyDocMeta ───────────────────────────────────────────────────────────
  // Applies wordIndex / categories / captures received from parent.
  //
  // wordIndex format accepted (both detected automatically):
  //   ARRAY:  [{ x, y, width, height, page, text }, ...]   ← your format
  //   OBJECT: { "1": [{ x, y, width, height, text }], "2": [...] }
  //
  // In both cases each entry is normalised through extractRawCoords so any
  // supported coord format works (x/y, left/right, bbox, etc.).
  //
  // wordIndex + captures are deferred until adapter.onReady() so page
  // dimensions are available for coordinate normalisation. Categories
  // (no coords) apply immediately.
  const applyDocMeta = useCallback((
    meta?: import('./hooks/useEventBridge').SingleDocMeta | import('./hooks/useEventBridge').DocResponseMeta
  ) => {
    if (!meta) return;

    // Categories — no coords needed but page count must be known
    // so defer to adapter.onReady same as wordIndex/captures
    // (avoids useMemo running with pageCount=0 → wrong otherPages list)

    // wordIndex + captures need page dimensions → defer to adapter ready
    // Gate: skip waitForAdapterReady if there is genuinely nothing coord-related to apply.
    // Check captures.length explicitly — an empty array [] is falsy but shouldn't block.
    const hasCaptures  = Array.isArray(meta.captures) && meta.captures.length > 0;
    const hasCategories = Array.isArray(meta.categories) && meta.categories.length > 0;
    // Gate: skip if nothing to apply (but include categories in the check)
    const hasCoordMeta = !!( (meta as any).fullPageOCR || meta.wordIndex || hasCaptures || hasCategories );
    if (!hasCoordMeta) return;

    waitForAdapterReady().then(() => {
      const ad = useAppStore.getState().adapter;

      // ── Apply initialZoom ─────────────────────────────────────────────────
      // Accepted values (case-insensitive string or numeric):
      //   'page-fit' / 'fit' / 'fit-page'       → page-fit (pdfjs: page-fit)
      //   'page-width' / 'width' / 'fit-width'  → page-width
      //   'actual' / '100%' / 'actual-size'     → actual (100%)
      //   1.5 / '1.5'                            → explicit numeric zoom
      //   undefined / null / ''                  → keep format default (page-fit for PDF/image,
      //                                            actual for XLSX/CSV)
      // initialZoom only exists on SingleDocMeta (not DocResponseMeta) — cast safely
      const initialZoom = (meta as import('./hooks/useEventBridge').SingleDocMeta).initialZoom;
      if (initialZoom !== undefined && initialZoom !== null && initialZoom !== '') {
        const raw   = String(initialZoom).trim().toLowerCase();
        const isNum = !isNaN(Number(initialZoom));
        if (isNum) {
          useAppStore.getState().setZoom(Number(initialZoom));
        } else if (raw === 'page-fit' || raw === 'fit' || raw === 'fit-page' || raw === 'fit page') {
          useAppStore.getState().setZoomMode('page-fit');
        } else if (raw === 'page-width' || raw === 'width' || raw === 'fit-width' || raw === 'fit width') {
          useAppStore.getState().setZoomMode('page-width');
        } else if (raw === 'actual' || raw === '100%' || raw === 'actual-size' || raw === 'actual size') {
          useAppStore.getState().setZoomMode('actual');
        }
      }

      // Apply categories now that pageCount is known.
      // Use setTimeout(0) to yield the main thread AFTER pdfjs has processed
      // any pending navigation (currentPageNumber assignment) before the heavy
      // ThumbnailSidebar useMemo re-render for 20-30 categories fires.
      // Without this yield, a 400-page doc with 30 categories blocks the thread
      // and pdfjs cannot process navigation requests.
      if (meta.categories) {
        const withColors = (meta.categories as any[]).map((cat: any, i: number) => ({
          ...cat,
          color: cat.color ?? categoryColor(cat.label ?? cat.id ?? ''),
        }));
        setTimeout(() => {
          setCategories(withColors as any);
          useAppStore.getState().setOriginalCategories(withColors as any);
          useAppStore.getState().setHasReclassification(false);
          useAppStore.getState().setOriginalDocuments(null);
}, 0);
      }

      // After adapter is ready, force a redraw of all visible pages
      // so captured_fields grey boxes appear immediately on load.
      // We schedule after the current micro-task so state updates settle first.
      const triggerRedraw = () => {
        // Fire immediately (synchronous store subscribers will pick it up),
        // then retry at 100ms and 600ms to cover slow PDF initialisation.
        useAppStore.getState()._rebuildHighlightIndex();
        setTimeout(() => useAppStore.getState()._rebuildHighlightIndex(), 100);
        setTimeout(() => useAppStore.getState()._rebuildHighlightIndex(), 600);
      };

      // ── wordIndex ──────────────────────────────────────────────────────
      if (meta.wordIndex) {
        import('./utils/coords').then(async ({ extractRawCoords, normaliseCoords, getExtractedPage }) => {
          const normalised = new Map<number, import('./adapters/types').WordEntry[]>();
          const rawWi = meta.wordIndex as any;

          // Build page→entries map first (no processing yet)
          const byPage = new Map<number, any[]>();
          if (Array.isArray(rawWi)) {
            for (const e of rawWi) {
              const pg = Number(e.page ?? 1);
              if (!byPage.has(pg)) byPage.set(pg, []);
              byPage.get(pg)!.push(e);
            }
          } else {
            for (const [pageKey, entries] of Object.entries(rawWi)) {
              if (Array.isArray(entries)) byPage.set(Number(pageKey), entries as any[]);
            }
          }

          // ── Chunked normalisation — yields main thread every CHUNK_SIZE pages ──
          // For large documents (1000+ pages × 300 words = 300k operations),
          // processing all pages synchronously freezes the UI for seconds.
          // Processing in chunks of 50 pages yields between chunks so the browser
          // can handle scroll, paint, and input events — document stays responsive.
          const CHUNK_SIZE = 50; // pages per chunk before yielding
          const pageEntries = Array.from(byPage.entries());

          const processChunks = async () => {
            for (let i = 0; i < pageEntries.length; i += CHUNK_SIZE) {
              const chunk = pageEntries.slice(i, i + CHUNK_SIZE);
              for (const [pg, entries] of chunk) {
                normalised.set(pg, entries.map((e: any) =>
                  normaliseEntry(e, pg, ad, extractRawCoords, normaliseCoords, getExtractedPage)
                ) as any);
              }
              // Yield to browser between chunks — keeps UI responsive
              if (i + CHUNK_SIZE < pageEntries.length) {
                await new Promise<void>(r =>
                  typeof (scheduler as any)?.yield === 'function'
                    ? (scheduler as any).yield().then(r)
                    : setTimeout(r, 0)
                );
              }
            }

            console.log('[applyDocMeta] wordIndex ready. Pages:', normalised.size);
            setWordIndex(normalised);
          };

          await processChunks();

        });
      }

      // ── captures ───────────────────────────────────────────────────────
      // Normalise coordinates AND merge atomically in one store write.
      //
      // Parent may send captures in any supported format:
      //   { x, y, width, height }  as 0-1 fractions → stored as-is
      //   { x, y, width, height }  as pixel/pt values → normalised to 0-1
      //   { bbox, rectangle, coordinates }            → extracted + normalised
      //
      // After normalisation, captures + highlightIndex are written in ONE
      // setState call so PDFViewer subscription fires exactly once with
      // both already correct → all grey boxes appear immediately.
      if (meta.captures && meta.captures.length > 0) {
        import('./utils/coords').then(({ extractRawCoords, normaliseCoords, normaliseBatch }) => {
          // Use batch normalisation — detects unit ONCE from global max coordinate
          // across ALL captures, not per-item. This prevents the ambiguity where
          // coords below ~page_height_in_pts are misidentified as pts instead of px,
          // causing highlights to appear at wrong positions for absolute pixel coords.
          const rawCaps = meta.captures as any[];

          // Run batch normalisation: detects unit from max coord across all items
          const coordSpace2 = (meta as any)?.coordinateSpace as 'px'|'pt'|'norm'|undefined;
          const rawCapsHinted = coordSpace2
            ? rawCaps.map((c: any) => ({ ...c, _rawUnit: coordSpace2 }))
            : rawCaps;
          const batchResults = normaliseBatch(
            rawCaps,
            (item: any) => {
              const ep = (item as any).__extractedPage;
              return typeof ep === 'number' ? ep : (item.page ?? 1);
            },
            ad,
          );

          console.log('[FMT10 DEBUG] rawCaps count:', rawCaps.length);
          console.log('[FMT10 DEBUG] batchResults:', batchResults.map((r: any, i: number) => ({
            i, coords: r.coords, extractedPage: (rawCaps[i] as any).__extractedPage,
            capPage: (rawCaps[i] as any).page, bbox: (rawCaps[i] as any).bbox,
          })));

          const incoming = rawCaps.map((cap: any, i: number) => {
            const batchResult = batchResults[i];
            const batchCoord  = batchResult?.coords;
            const resolvedPage = (cap as any).__extractedPage ?? cap.page ?? 1;
            console.log('[FMT10 DEBUG] cap', i, 'bbox:', cap.bbox,
              '__extractedPage:', (cap as any).__extractedPage,
              'resolvedPage:', resolvedPage, 'coords:', batchCoord);
            const normed = batchCoord
              ? { ...cap,
                  page:   resolvedPage,
                  x:      batchCoord[0],
                  y:      batchCoord[1],
                  width:  batchCoord[2],
                  height: batchCoord[3] }
              : normaliseEntry(cap, resolvedPage, ad, extractRawCoords, normaliseCoords);
            return {
              label:       cap.label ?? cap.text ?? cap.value ?? '',
              value:       cap.value ?? cap.text ?? cap.label ?? '',
              fromJson:    true,
              sourceFormat: cap.sourceFormat ?? 'flat',
              ...normed,
              page: resolvedPage,
            } as import('./adapters/types').CaptureItem;
          });
          console.log('[FMT10 DEBUG] incoming captures:', incoming.map((c: any) =>
            ({ id: c.id, page: c.page, x: c.x?.toFixed(3), y: c.y?.toFixed(3), w: c.width?.toFixed(3), h: c.height?.toFixed(3) })));

          // Merge with existing captures (upsert by id)
          const current = useAppStore.getState().captures;
          const merged  = [...current];
          for (const cap of incoming) {
            const idx = merged.findIndex(c => c.id === (cap as any).id);
            if (idx >= 0) merged[idx] = cap;
            else          merged.push(cap);
          }

          // Build highlightIndex synchronously before setState
          type HRect = { x:number; y:number; width:number; height:number; id:string; color?:string; type?:'external' };
          const index = new Map<number, HRect[]>();
          for (const c of merged) {
            if (!index.has(c.page)) index.set(c.page, []);
            index.get(c.page)!.push({
              x: c.x, y: c.y, width: c.width, height: c.height,
              id: c.id, color: c.color, type: c.type,
            });
          }

          console.log('[FMT10 DEBUG] highlightIndex pages:', Array.from(index.keys()),
            'entries per page:', Array.from(index.entries()).map(([p, rects]) => `page${p}:${rects.length}rects`));
          // Only persist if persistHighlights=true
          if (useAppStore.getState().persistHighlights) {
            useAppStore.setState({ captures: merged, highlightIndex: index });
          }
          // If false: captures from LOAD are discarded — only HIGHLIGHT events show boxes

          // Trigger redraws at increasing intervals to cover all timing scenarios:
          //   T+0ms:   subscription fires from setState above — handles case where
          //            viewer is already ready (common: captures sent after doc opened)
          //   T+100ms: catches case where PDF is still initialising when captures arrive
          //   T+600ms: catches slow PDF loads or heavy documents
          // Each call touches highlightIndex to re-fire the subscription → drawAllVisible.
          // Safe to call multiple times — drawAllVisible is idempotent.
          [100, 600].forEach(delay => setTimeout(() => {
            useAppStore.getState()._rebuildHighlightIndex();
          }, delay));
        });
        return;
      }

      // Trigger one redraw pass to ensure any already-rendered pages pick up
      // the new highlightIndex (covers pages rendered before captures arrived).
      triggerRedraw();
    });
  }, [waitForAdapterReady, setWordIndex, setCategories, addCaptureWithId]);

  const bridge = useEventBridge({
    onReset: () => {
      // Called when parent sends RESET_VIEWER
      multiDoc.clearMultiDoc();
    },
    onLoadSingleDoc: (buffer, fileName, meta) => {
      // Fresh document — reset visit tracker and activeDocId to SingleDoc sentinel
      useAppStore.getState().clearPageVisits();
      (window as any).__doccapture_activeDocId = '_single';
      openFileBuffer(buffer, fileName);
      applyDocMeta(meta);
      // Click2Pick: enable box-capture mode immediately on load if requested
      if (meta?.Click2Pick) useAppStore.getState().setBoxMode(true);
      // debugArea (alias: showFieldsPanel) — show/hide right-side Fields panel.
      // debugArea takes priority; falls back to showFieldsPanel for backwards compat.
      const showPanel1 = meta?.debugArea ?? meta?.showFieldsPanel;
      if (showPanel1 !== undefined)
        useAppStore.getState().setEnableCaptureDebug(showPanel1);
      // showAnnotation: show annotation/draw button if parent requests it
      if ((meta as any)?.showAnnotation !== undefined)
        useAppStore.getState().setEnableAnnotation(!!(meta as any).showAnnotation);
      // showThumbnailView: show/hide thumbnail icon + section (default: true)
      if ((meta as any)?.showThumbnailView !== undefined)
        useAppStore.getState().setEnableThumbnailView(!!(meta as any).showThumbnailView);
      // showSplitMerge from LOAD_SINGLEDOC — enables icon if VITE_SPLIT_MERGE_URL is set
      if ((meta as any)?.showSplitMerge !== undefined)
        useAppStore.getState().setShowSplitMerge(!!(meta as any).showSplitMerge);
      // Default: false (transient). Only true when parent explicitly sends persistHighlights:true
      useAppStore.getState().setPersistHighlights(
        (meta as any)?.persistHighlights === true
      );
      if ((meta as any)?.isSplitScreen !== undefined) {
        const val = !!(meta as any).isSplitScreen;
        console.log('[App onLoadSingleDoc] isSplitScreen=', val, 'meta=', JSON.stringify(meta).slice(0,200));
        useAppStore.getState().setIsSplitScreen(val);
        if (val) useAppStore.getState().setSidebarOpen(true);
        console.log('[App] after set: isSplitScreen=', useAppStore.getState().isSplitScreen, 'sidebarOpen=', useAppStore.getState().sidebarOpen);
      } else {
        console.log('[App onLoadSingleDoc] isSplitScreen NOT in meta. meta keys=', Object.keys(meta ?? {}));
      }
      if ((meta as any)?.openThumbnail)
        useAppStore.getState().setSidebarOpen(true);
    },

    onLoadManifest: (manifest, activeDocId, activeBuffer, meta) => {
      // Fresh manifest — reset visit tracker. activeDocId will be set by
      // handleSelectDoc when the first doc is auto-selected.
      useAppStore.getState().clearPageVisits();
      if (activeDocId) (window as any).__doccapture_activeDocId = activeDocId;
      // Pre-seed the file cache with activeBuffer BEFORE loadManifest triggers
      // the auto-select (which calls selectDoc via setTimeout). Without this,
      // selectDoc sees no cache hit and fires DOC_REQUEST even though the buffer
      // is already available in the initial LOAD_MANIFEST payload.
      if (activeBuffer && activeBuffer.byteLength > 0 && activeDocId) {
        const doc = (manifest.documents ?? []).find((d: any) => d.id === activeDocId);
        const name = (doc as any)?.name ?? `${activeDocId}.pdf`;
        const mime = name.endsWith('.pdf') ? 'application/pdf'
          : name.endsWith('.tif') || name.endsWith('.tiff') ? 'image/tiff'
          : name.endsWith('.png') ? 'image/png'
          : name.endsWith('.jpg') || name.endsWith('.jpeg') ? 'image/jpeg'
          : 'application/octet-stream';
        const blob = new Blob([activeBuffer], { type: mime });
        const file = new File([blob], name, { type: mime });
        try {
          Object.defineProperty(file, '__docId',
            { value: activeDocId, enumerable: false, writable: false });
        } catch (_) {}
        // Inject directly into multiDoc file cache before loadManifest auto-select fires
        const blobUrl = URL.createObjectURL(blob);
        multiDoc.preSeedCache?.(activeDocId, file, blobUrl);
      }

      multiDoc.loadManifest(manifest);

      if (activeBuffer && activeBuffer.byteLength > 0 && activeDocId) {
        const doc = (manifest.documents ?? []).find((d: any) => d.id === activeDocId);
        const name = (doc as any)?.name ?? `${activeDocId}.pdf`;
        openFileBuffer(activeBuffer, name);
        applyDocMeta(meta);
      }
      // Click2Pick: enable box-capture mode if requested
      if (meta?.Click2Pick) useAppStore.getState().setBoxMode(true);
      // debugArea (alias: showFieldsPanel) — show/hide right-side Fields panel.
      const showPanel2 = (meta as any)?.debugArea ?? meta?.showFieldsPanel;
      if (showPanel2 !== undefined)
        useAppStore.getState().setEnableCaptureDebug(showPanel2);
      // showAnnotation: show annotation/draw button if parent requests it
      if ((meta as any)?.showAnnotation !== undefined)
        useAppStore.getState().setEnableAnnotation(!!(meta as any).showAnnotation);
      if ((meta as any)?.showThumbnailView !== undefined)
        useAppStore.getState().setEnableThumbnailView(!!(meta as any).showThumbnailView);
      // showSplitMerge from LOAD_MANIFEST
      if ((meta as any)?.showSplitMerge !== undefined)
        useAppStore.getState().setShowSplitMerge(!!(meta as any).showSplitMerge);
      // Default: false (transient). Only true when parent explicitly sends persistHighlights:true
      useAppStore.getState().setPersistHighlights(
        (meta as any)?.persistHighlights === true
      );
      if ((meta as any)?.isSplitScreen !== undefined) {
        const val = !!(meta as any).isSplitScreen;
        console.log('[App onLoadManifest] isSplitScreen=', val, 'meta=', JSON.stringify(meta).slice(0,200));
        useAppStore.getState().setIsSplitScreen(val);
        if (val) useAppStore.getState().setSidebarOpen(true);
        console.log('[App] after set: isSplitScreen=', useAppStore.getState().isSplitScreen, 'sidebarOpen=', useAppStore.getState().sidebarOpen);
      } else {
        console.log('[App onLoadManifest] isSplitScreen NOT in meta. meta keys=', Object.keys(meta ?? {}));
      }
      if ((meta as any)?.openThumbnail)
        useAppStore.getState().setSidebarOpen(true);

      // Snapshot manifest documents for MultiDoc Discard/Reset
      if (manifest.documents?.length) {
        const snap = (manifest.documents as any[]).map((d: any) => ({ ...d }));
        useAppStore.getState().setOriginalDocuments(snap);
        useAppStore.getState().setOriginalCategories(null);
        useAppStore.getState().setHasReclassification(false);
      }
    },

    // Called after DOC_RESPONSE resolves — apply per-doc meta
    onDocMeta: (_docId, meta) => {
      applyDocMeta(meta);
    },

    onHighlight: async (payload) => {
      if (!payload?.id || String(payload.id).trim() === '') {
        console.warn('[onHighlight] Ignored — missing id:', payload);
        return;
      }

      const persist = useAppStore.getState().persistHighlights;

      // Clear previous active highlight
      useAppStore.getState().setActiveField(null);
      useAppStore.getState().setPreviewRect(null);

      // MultiDoc — switch to target doc if needed
      if (payload.docId && multiDoc.state &&
          payload.docId !== multiDoc.state.activeDocId) {
        await multiDoc.selectDoc(payload.docId);
      }

      if (persist) {
        // ── PERSIST MODE (default) ───────────────────────────────────────────
        // Captures stay in store as grey boxes. Active = yellow.
        const found = navigateAndHighlight(payload.id);
        if (found) return;
        // Not in store yet — parse and add
        const result = parseHighlightPayload(payload, adapter);
        if ('error' in result) {
          console.warn('[onHighlight] No valid coords:', result.error);
          return;
        }
        addCaptureWithId(result.item);
      } else {
        // ── TRANSIENT MODE (persistHighlights:false) ────────────────────────
        // No grey boxes. No store persistence.
        // Current highlight = YELLOW. Duplicate coords = LIGHT PINK.
        // All previous highlights cleared on each new HIGHLIGHT event.
        const result = parseHighlightPayload(payload, adapter);
        if ('error' in result) {
          console.warn('[onHighlight] No valid coords:', result.error);
          return;
        }
        const item = result.item;

        // Navigate to the page
        const ad = useAppStore.getState().adapter;
        if (ad) navigatePdfPage(item.page);
        ad?.navigateToPage?.(item.page);

        // Find any captures with same coords (duplicates) → light pink
        const existing = useAppStore.getState().captures;
        const PINK = '#ffb3c1';
        const duplicates = existing.filter(c =>
          c.page === item.page &&
          Math.abs(c.x - item.x) < 0.002 &&
          Math.abs(c.y - item.y) < 0.002
        );

        // Build transient highlight set:
        // Active item → YELLOW (rect.id === activeFieldId in painter)
        // Duplicates  → LIGHT PINK (rect.color in painter)
        const transientCaptures = [
          item,
          ...duplicates.filter(d => d.id !== item.id).map(c => ({ ...c, color: PINK })),
        ];

        // highlightIndex: active item (no color = yellow path) + duplicates (pink)
        const index = new Map<number, { x:number; y:number; width:number; height:number; id:string; color?:string }[]>();
        const addRect = (page: number, entry: { x:number; y:number; width:number; height:number; id:string; color?:string }) => {
          if (!index.has(page)) index.set(page, []);
          index.get(page)!.push(entry);
        };
        // Active item — no color so painter uses yellow (isAct = true)
        addRect(item.page, { x: item.x, y: item.y, width: item.width, height: item.height, id: item.id });
        // Duplicates — pink color
        for (const d of duplicates.filter(d => d.id !== item.id)) {
          addRect(d.page, { x: d.x, y: d.y, width: d.width, height: d.height, id: d.id, color: PINK });
        }
        useAppStore.setState({
          captures:       transientCaptures,
          highlightIndex: index,
          activeFieldId:  item.id,
        });

        // Show yellow via previewRect
        useAppStore.getState().setPreviewRect({
          page: item.page, x: item.x, y: item.y,
          width: item.width, height: item.height,
        });
      }
    },

    onCaptureAck: (tempId, realId) => {
      bridge.resolveAck(tempId, realId);
    },

    onReadyConfig: (config) => {
      if (config.enableCaptureDebug !== undefined)
        setEnableCaptureDebug(config.enableCaptureDebug);
      // showSplitMerge via READY_CONFIG still supported (URL stays internal)
      if (config.showSplitMerge !== undefined)
        useAppStore.getState().setShowSplitMerge(config.showSplitMerge);
      // initialZoom from READY_CONFIG (applies before first doc loads)
      if (config.initialZoom !== undefined) {
        const raw = String(config.initialZoom).trim().toLowerCase();
        if (!isNaN(Number(config.initialZoom))) {
          useAppStore.getState().setZoom(Number(config.initialZoom));
        } else if (raw === 'page-fit' || raw === 'fit') {
          useAppStore.getState().setZoomMode('page-fit');
        } else if (raw === 'page-width' || raw === 'width') {
          useAppStore.getState().setZoomMode('page-width');
        } else if (raw === 'actual' || raw === '100%') {
          useAppStore.getState().setZoomMode('actual');
        }
      }
      if (config.Click2Pick)
        useAppStore.getState().setBoxMode(true);
    },

    onExportRequest: () => {
      // Parent sent EXPORT_CAPTURES — build JSON and respond via CAPTURES_DATA
      const { captures, fileName } = useAppStore.getState();
      const round = (n: number) => parseFloat(n.toFixed(6));

      const data = captures.map((c: import('./adapters/types').CaptureItem) => {
        const hasRaw = c._rawX !== undefined && c._rawWidth !== undefined;
        const base: import('./hooks/useEventBridge').ExportedCapture = {
          id: c.id, value: c.value, page: c.page,
        };

        if (hasRaw) {
          // Restore original raw coords — round-trip fidelity
          const rx = c._rawX!,  ry = c._rawY  ?? 0;
          const rw = c._rawWidth!, rh = c._rawHeight ?? 0;
          if      (c.sourceFormat === 'bbox')        base.bbox        = [rx, ry, rw, rh];
          else if (c.sourceFormat === 'rectangle')   base.rectangle   = [rx, ry, rw, rh];
          else if (c.sourceFormat === 'coordinates') base.coordinates = [ry, rx, ry + rh, rx + rw];
          else { base.x = rx; base.y = ry; base.width = rw; base.height = rh; }
        } else {
          // No raw values — send normalised 0-1
          if      (c.sourceFormat === 'bbox')        base.bbox        = [round(c.x), round(c.y), round(c.width), round(c.height)];
          else if (c.sourceFormat === 'rectangle')   base.rectangle   = [round(c.x), round(c.y), round(c.width), round(c.height)];
          else if (c.sourceFormat === 'coordinates') base.coordinates = [round(c.y), round(c.x), round(c.y + c.height), round(c.x + c.width)];
          else { base.x = round(c.x); base.y = round(c.y); base.width = round(c.width); base.height = round(c.height); }
        }

        if (c.color) base.color = c.color;
        return base;
      });

      bridge.respondCaptures(data);
    },

    onPageVisitsRequest: () => {
      // Parent sent GET_PAGE_VISITS — build per-doc visit summary and respond.
      // visitedPages is a Map<docId, Set<pageNumber>> maintained by:
      //   • PDFViewer's pagerendered handler (catches every fast-scroll page)
      //   • setCurrentPage calls for non-PDF formats (images, spreadsheets, docx)
      const { visitedPages, pageCount, fileName } = useAppStore.getState();
      const mds = multiDoc.state;

      let docs: import('./hooks/useEventBridge').PageVisitDoc[];

      if (mds && mds.documents.length > 0) {
        // MultiDoc — one entry per manifest document
        docs = mds.documents.map(doc => {
          const visited   = visitedPages.get(doc.id) ?? new Set<number>();
          const total     = doc.totalPages ?? pageCount ?? 0;
          const visitedArr = [...visited].sort((a, b) => a - b);
          const unvisited  = total > 0
            ? Array.from({ length: total }, (_, i) => i + 1).filter(p => !visited.has(p))
            : [];
          return {
            docId:          doc.id,
            docName:        doc.name,
            pageCount:      total,
            visitedPages:   visitedArr,
            unvisitedPages: unvisited,
            visitedCount:   visitedArr.length,
            unvisitedCount: unvisited.length,
            complete:       total > 0 && unvisited.length === 0,
          };
        });
      } else {
        // SingleDoc — single entry keyed '_single'
        const visited    = visitedPages.get('_single') ?? new Set<number>();
        const total      = pageCount ?? 0;
        const visitedArr = [...visited].sort((a, b) => a - b);
        const unvisited  = total > 0
          ? Array.from({ length: total }, (_, i) => i + 1).filter(p => !visited.has(p))
          : [];
        docs = [{
          docId:          '_single',
          docName:        fileName || undefined,
          pageCount:      total,
          visitedPages:   visitedArr,
          unvisitedPages: unvisited,
          visitedCount:   visitedArr.length,
          unvisitedCount: unvisited.length,
          complete:       total > 0 && unvisited.length === 0,
        }];
      }

      bridge.respondPageVisits(docs);
    },

    onCaptureDelete: (id) => {
      // Parent signalled delete (empty/zero coords in ACK) — remove from captures
      useAppStore.getState().removeCapture(id);
    },

    // SET_CAPTURES — load or merge captures at any point after doc load
    onSetCaptures: (incoming, mode, _docId) => {
      import('./utils/coords').then(({ extractRawCoords, normaliseCoords, normaliseBatch, getExtractedPage }) => {
        const ad = useAppStore.getState().adapter;

        // Batch normalisation — consistent unit detection across all captures
        const incomingArr = incoming as any[];
        console.log('[App onSetCaptures] normaliseBatch for', incomingArr.length, 'captures:',
          incomingArr.map((c: any) => JSON.stringify({bbox: c.bbox, page: c.page})).join(' | '));
        const batchRes = normaliseBatch(incomingArr, (item: any) => {
          const ep = (item as any).__extractedPage;
          return typeof ep === 'number' ? ep : (item.page ?? 1);
        }, ad);
        console.log('[App onSetCaptures] batchResults:',
          batchRes.map((r: any) => r.coords ? r.coords.map((v: number) => v.toFixed(3)).join(',') : 'null').join(' | '));

        const normalised = incomingArr.map((cap: any, i: number) => {
          const bc = batchRes[i]?.coords;
          const normed = bc
            ? { ...cap, x: bc[0], y: bc[1], width: bc[2], height: bc[3] }
            : normaliseEntry(cap, cap.page ?? 1, ad, extractRawCoords, normaliseCoords);
          return {
            label:       cap.label ?? cap.text ?? cap.value ?? '',
            value:       cap.value ?? cap.text ?? cap.label ?? '',
            fromJson:    true,
            sourceFormat: cap.sourceFormat ?? 'flat',
            ...normed,
          } as import('./adapters/types').CaptureItem;
        });

        const current = useAppStore.getState().captures;
        let merged: import('./adapters/types').CaptureItem[];

        if (mode === 'merge') {
          // Upsert by id — update existing, append new ones
          merged = [...current];
          for (const cap of normalised) {
            const idx = merged.findIndex(c => c.id === (cap as any).id);
            if (idx >= 0) merged[idx] = cap;
            else          merged.push(cap);
          }
        } else {
          // Replace — discard all existing captures, use incoming only
          merged = normalised;
        }

        // Rebuild highlightIndex atomically
        type HRect = { x:number;y:number;width:number;height:number;id:string;color?:string;type?:'external' };
        const index = new Map<number, HRect[]>();
        for (const c of merged) {
          if (!index.has(c.page)) index.set(c.page, []);
          index.get(c.page)!.push({ x:c.x, y:c.y, width:c.width, height:c.height,
                                    id:c.id, color:c.color, type:c.type });
        }
        useAppStore.setState({ captures: merged, highlightIndex: index });

        // Retry redraws to cover timing edge cases
        setTimeout(() => useAppStore.getState()._rebuildHighlightIndex(), 100);
        setTimeout(() => useAppStore.getState()._rebuildHighlightIndex(), 600);
      });
    },
  });

  // Standalone defaults: when NOT in iframe, right panel + annotation visible by default.
  // When embedded, both start hidden — parent controls via debugArea (or showFieldsPanel) / showAnnotation.
  useEffect(() => {
    if (!isEmbedded) {
      useAppStore.getState().setEnableCaptureDebug(true);
      useAppStore.getState().setEnableAnnotation(true);
      // standalone: thumbnail icon visible, sidebar collapsed (user can expand)
      useAppStore.getState().setEnableThumbnailView(true);
    }
  }, []); // eslint-disable-line

  // Expose bridge.emitDocLoaded on window so PDFViewer can call it without prop drilling
  useEffect(() => {
    if (!isEmbedded) return;
    // emitDocLoaded is the canonical name.
    // emitPdfLoaded is the alias PDFViewer uses — both point to the same function.
    (window as any).__doccapture_bridge = {
      emitDocLoaded:    bridge.emitDocLoaded,
      emitPdfLoaded:    bridge.emitDocLoaded,     // alias for PDFViewer
      emitDocLoadError: bridge.emitDocLoadError,  // for PDFViewer + adapter errors
    };
    return () => { delete (window as any).__doccapture_bridge; };
  }, [bridge.emitDocLoaded]);

  // ── Watch store loadError → emit DOC_LOAD_ERROR to parent ──────────────────
  // openFile() sets loadError for ALL non-PDF format failures:
  //   • ImageAdapter (TIFF/PNG/JPG) — loadFile() throws
  //   • SpreadsheetAdapter (XLSX/CSV) — loadFile() throws
  //   • DocAdapter (DOCX) — loadFile() throws
  //   • Unsupported format — explicit message
  //   • openFileBuffer with empty/null buffer — explicit message
  // PDFViewer emits its own error via __doccapture_bridge directly.
  // This effect covers everything else uniformly.
  useEffect(() => {
    if (!isEmbedded) return;
    const unsub = useAppStore.subscribe((n, p) => {
      if (!n.loadError || n.loadError === p.loadError) return;
      const code: import('./hooks/useEventBridge').DocLoadErrorCode =
        n.loadError.includes('Unsupported') || n.loadError.includes('unreadable')
          ? 'UNSUPPORTED_FORMAT'
        : n.loadError.includes('Empty') || n.loadError.includes('invalid file')
          ? 'INVALID_BUFFER'
        : n.loadError.includes('corrupt') || n.loadError.includes('Corrupt')
          ? 'CORRUPT_FILE'
        : 'UNKNOWN';
      bridge.emitDocLoadError({
        code,
        reason:   n.loadError,
        fileName: n.fileName ?? undefined,
        docId:    null,
      });
    });
    return unsub;
  }, [bridge.emitDocLoadError]);

  // Pass requestBuffer into multiDoc so selectDoc can fetch via postMessage
  useEffect(() => {
    if (!isEmbedded) return;
    multiDoc.setConfig({ requestBuffer: bridge.requestDocBuffer });
  }, [bridge.requestDocBuffer]); // eslint-disable-line

  // Register manifest handler in the store — synchronous, no timing race
  const handleManifest = useCallback((manifest: DocumentManifest) => {
    multiDoc.loadManifest(manifest);
  }, [multiDoc]);

  useEffect(() => {
    useAppStore.getState().registerManifestHandler(handleManifest);
    // Also set window bridge for ViewerPane drop zone (belt-and-suspenders)
    (window as any).__onManifest = handleManifest;
    return () => {
      (window as any).__onManifest = undefined;
    };
  }, [handleManifest]);

  // Exit multi-doc mode — clear state + reset viewer
  const handleClearMultiDoc = useCallback(() => {
    multiDoc.clearMultiDoc();
    closeFile();
  }, [multiDoc, closeFile]);

  // pendingPageRef: when selectDoc resolves a new file, navigate to requested page
  // after pdfjs adapter is ready (adapter.onReady fires after page dims loaded)
  const pendingPageRef = React.useRef<number>(1);

  const handleSelectDoc = useCallback(async (docId: string, page = 1) => {
    pendingPageRef.current = page;
    // Keep the window global in sync so PDFViewer's pagerendered handler
    // records visits under the correct docId key.
    (window as any).__doccapture_activeDocId = docId;
    await multiDoc.selectDoc(docId, page);
  }, [multiDoc]);

  // Track last loaded file name to skip re-opening on cache hits (same File object)
  const lastLoadedFileRef = React.useRef<string>('');

  // When a new activeFile is resolved → load it into the viewer
  useEffect(() => {
    if (!multiDoc.activeFile) return;
    const fileKey = multiDoc.activeFile.name + multiDoc.activeFile.size;
    if (fileKey === lastLoadedFileRef.current) {
      // Cache hit — same File object, pdfjs already loaded.
      // Just navigate to the requested page.
      // Use multiDoc state activePage as source of truth (covers handleSelectPage path).
      const pg = multiDoc.state?.activePage ?? pendingPageRef.current;
      if (pg >= 1) {
        setCurrentPage(pg);
        // Small timeout ensures pdfjs viewer is not mid-render from a previous event
        const fmt = useAppStore.getState().format;
        if (fmt === 'pdf') { navigatePdfPage(pg); }
        else { useAppStore.getState().adapter?.navigateToPage?.(pg); }
      }
      return;
    }
    lastLoadedFileRef.current = fileKey;
    // Immediately clear all PageThumbRow canvases on the new doc
    // so user sees blank + loading instead of stale previous-doc content
    (window as any).__doccapture_clearThumbs?.();
    // Preserve user zoom across multi-doc navigation.
    // If zoomMode is 'custom' (explicit %): restore immediately after the sync reset.
    // If zoomMode is 'page-fit'/'page-width': let ViewerToolbar auto-apply recalculate
    //   for the new document's dimensions — do not restore the old doc's pixel zoom.
    const { zoom: savedZoom, zoomMode: savedZoomMode } = useAppStore.getState();
    openFile(multiDoc.activeFile).then(() => {
      if (savedZoomMode === 'custom') {
        // Restore exact zoom — this also sets zoomMode='custom' which blocks auto-apply
        useAppStore.getState().setZoom(savedZoom);
      }
      // For page-fit/page-width: openFile already reset to zoomMode='page-fit',
      // and the ViewerToolbar useEffect fires when adapter+pageCount are ready,
      // recalculating the correct zoom for the new doc size automatically.
      const adapter = useAppStore.getState().adapter as any;
      if (adapter && typeof adapter.onReady === 'function') {
        adapter.onReady(() => {
          const pg = pendingPageRef.current;
          if (pg > 1) {
            setCurrentPage(pg);
            useAppStore.getState().adapter?.navigateToPage?.(pg);
          }

          // Emit DOC_LOADED for non-PDF formats (PDF emits this from PDFViewer
          // via __doccapture_bridge when the first page renders).
          // For image/spreadsheet/doc adapters: adapter.onReady fires once
          // when page 1 is fully decoded — exactly the right moment.
          const st  = useAppStore.getState();
          const fmt = st.format;
          if (fmt !== 'pdf') {
            const bridgeEmit = (window as any).__doccapture_bridge?.emitDocLoaded;
            if (bridgeEmit) {
              bridgeEmit({
                fileName:  st.fileName,
                pageCount: st.pageCount,
                docId:     (st.file as any)?.__docId ?? null,
              });
            }
          }
        });
      }
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [multiDoc.activeFile]);

  // Page selection within the current document
  const handleSelectPage = useCallback((page: number) => {
    pendingPageRef.current = page;
    multiDoc.selectPage(page);
    setCurrentPage(page);
    const ad = useAppStore.getState().adapter;
    if (useAppStore.getState().format === 'pdf') { navigatePdfPage(page); }
    else {
      ad?.navigateToPage?.(page);
      // Non-PDF formats don't go through pdfjs pagerendered — record visit here.
      const docId: string = (window as any).__doccapture_activeDocId ?? '_single';
      useAppStore.getState().recordPageVisit(docId, page);
    }
  }, [multiDoc, setCurrentPage]);

  // ── VIEWER_STATE_CHANGED — single unified event for parent ─────────────────
  // Fires whenever the user navigates to a different page OR switches document.
  // Covers: toolbar nav, thumbnail click, PDF scroll, keyboard, MultiDoc doc switch.
  // Parent subscribes to one event type for all navigation notifications.
  const prevStateRef = React.useRef<{ page: number; docId: string | null }>({
    page: 0, docId: null,
  });
  React.useEffect(() => {
    if (!isEmbedded) return;
    const unsub = useAppStore.subscribe((s) => {
      const page      = s.currentPage;
      const name      = s.fileName;
      const pageCount = s.pageCount;
      if (!name) return;
      const mds   = multiDoc.state;
      const docId = mds?.activeDocId ?? null;
      const prev  = prevStateRef.current;
      if (page === prev.page && docId === prev.docId) return;
      prevStateRef.current = { page, docId };
      const doc = mds?.documents?.find((d: any) => d.id === docId);
      window.parent.postMessage({
        type:      'VIEWER_STATE_CHANGED',
        page,
        pageCount,
        fileName:  name,
        docId:     docId    ?? undefined,
        docLabel:  (doc as any)?.label ?? (doc as any)?.name ?? docId ?? undefined,
        mode:      mds?.mode ?? undefined,
        totalDocs: mds?.documents?.length ?? undefined,
      }, '*');
    });
    return unsub;
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isEmbedded, multiDoc.state]);

  const showMultiSidebar   = enableThumbnailView && !!multiDoc.state && sidebarOpen;
  const showDefaultSidebar = enableThumbnailView && !multiDoc.state && sidebarOpen;

  const handleConfirmProceed = React.useCallback(() => {
    setShowConfirm(false);
    const st = useAppStore.getState();
    window.parent.postMessage({
      type:       'RETRIGGER_CLICKED',
      mode:       retriggerMode,
      fileName:   st.fileName,
      page:       st.currentPage,
      pageCount:  st.pageCount,
      categories: st.categories,
    }, '*');
    // Hide Split & Merge icon after Retrigger — re-enabled on next LOAD_SINGLEDOC
    // or LOAD_MANIFEST that explicitly passes showSplitMerge:true
    useAppStore.getState().setShowSplitMerge(false);
    (window as any).__doccapture_retriggerSuccess?.();
  }, [retriggerMode]);

  const handleConfirmCancel = React.useCallback(() => {
    setShowConfirm(false);
  }, []);

  // Reset (Discard) popup handlers
  const handleResetProceed = React.useCallback(() => {
    setShowResetConfirm(false);
    // Delegate to sidebar's handleDiscard — same function that was already working
    // when Reset was next to Retrigger. It handles both SingleDoc and MultiDoc restore,
    // fires DISCARD_CLICKED, and hides the bar via setRetriggerState('done').
    (window as any).__doccapture_doDiscard?.();
    // Additionally hide toolbar Reset button and Split/Merge icon
    useAppStore.getState().setIsSplitScreen(false);
  }, []);

  const handleResetCancel = React.useCallback(() => {
    setShowResetConfirm(false);
  }, []);

  return (
    <div className="flex flex-col h-full bg-[#060d1a] overflow-hidden">

      {/* ── Split & Merge iframe ─────────────────────────────────────────────
          Created once, shown when smActive=true. The viewer content below is
          hidden (display:none) while this iframe is visible. State is preserved.
          The iframe receives SPLIT_MERGE_OPEN with the current doc buffer.    */}
      {showSplitMerge && splitMergeUrl && (
        <iframe
          ref={smIframeRef}
          src={splitMergeUrl}
          title="Split & Merge"
          style={{ display: smActive ? 'flex' : 'none', flex: 1, border: 'none', width: '100%', height: '100%' }}
          allow="*"
          onLoad={() => {
            smIframeLoaded.current = true;
            // If SM is already active when load fires (first open), post now
            if ((window as any).__doccapture_sm_active) {
              (window as any).__doccapture_sm_doPost?.();
            }
          }}
        />
      )}

      {/* ── Viewer content — hidden (not unmounted) when SM is active ───── */}
      <div style={{ display: smActive ? 'none' : 'flex', flexDirection: 'column', flex: 1, overflow: 'hidden' }}>

      {/* When right panel hidden: viewer takes full width (no ResizablePanes overhead) */}
      {!enableCaptureDebug ? (
        <div className="flex flex-col flex-1 overflow-hidden">
          <div className="flex flex-col flex-1 overflow-hidden">
            <ViewerToolbar />
            <div className="flex flex-1 overflow-hidden relative">
              {showMultiSidebar && multiDoc.state && (
                <MultiDocSidebar
                  state={multiDoc.state}
                  isLoading={multiDoc.activeDocLoading}
                  loadError={multiDoc.activeDocError}
                  adapter={adapter}
                  onSelectDoc={handleSelectDoc}
                  onSelectPage={handleSelectPage}
                  onClose={handleClearMultiDoc}
                />
              )}
              {showDefaultSidebar && (
                <div style={{ position:'absolute', top:0, left:0, bottom:0, zIndex:30, display:'flex' }}>
                  <ThumbnailSidebar />
                </div>
              )}
              <ViewerPane multiDocLoading={multiDoc.activeDocLoading && !multiDoc.activeFile} bridge={bridge} />
            </div>
          </div>
        </div>
      ) : (
      <ResizablePanes
        left={
          <div className="flex flex-col flex-1 overflow-hidden">
            {/* Toolbar spans full width above viewer+sidebar */}
            <ViewerToolbar />
            {/* Below toolbar: sidebar overlays the viewer body only */}
            <div className="flex flex-1 overflow-hidden relative">
              {showMultiSidebar && multiDoc.state && (
                <MultiDocSidebar
                  state={multiDoc.state}
                  isLoading={multiDoc.activeDocLoading}
                  loadError={multiDoc.activeDocError}
                  adapter={adapter}
                  onSelectDoc={handleSelectDoc}
                  onSelectPage={handleSelectPage}
                  onClose={handleClearMultiDoc}
                />
              )}
              {/* ThumbnailSidebar overlays viewer body — sits below toolbar, does not push viewer */}
              {showDefaultSidebar && (
                <div style={{
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  bottom: 0,
                  zIndex: 30,
                  display: 'flex',
                }}>
                  <ThumbnailSidebar />
                </div>
              )}
              <ViewerPane multiDocLoading={multiDoc.activeDocLoading && !multiDoc.activeFile} bridge={bridge} />
            </div>
          </div>
        }
        right={<FieldsPanel bridge={bridge} />}
        defaultSplit={0.80}
        minLeft={320}
        minRight={200}
      />
      )}
      </div>{/* end viewer content wrapper */}
      {/* ── Retrigger confirmation popup — full viewer overlay ───────────── */}
      {showConfirm && (
        <div style={{
          position: 'fixed', inset: 0,
          background: 'rgba(0,0,0,0.45)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          zIndex: 9999,
        }}>
          <div style={{
            background: '#ffffff',
            border: '1px solid #d4dce8',
            borderRadius: '12px',
            padding: '24px 20px',
            width: '280px',
            boxShadow: '0 8px 32px rgba(0,0,0,0.22)',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '12px',
          }}>
            {/* Icon */}
            <div style={{
              width: 40, height: 40, borderRadius: '50%',
              background: '#185FA5',
              border: '1px solid #0c447c',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <span aria-hidden="true" style={{
                fontSize: 20, color: '#e8f2fb', lineHeight: 1,
                fontStyle: 'normal', fontWeight: 500,
              }}>⇅</span>
            </div>
            {/* Title */}
            <span style={{
              fontSize: '14px', fontWeight: 600,
              color: '#111827', textAlign: 'center',
            }}>
              Confirm Classification
            </span>
            {/* Body */}
            <span style={{
              fontSize: '12px', color: '#6b7280',
              textAlign: 'center', lineHeight: 1.6,
            }}>
              You are about to finalize the document classification.
              This action cannot be undone. Do you want to proceed?
            </span>
            {/* Buttons */}
            <div style={{ display: 'flex', gap: 8, width: '100%', marginTop: 4 }}>
              <button onClick={handleConfirmCancel} style={{
                flex: 1, padding: '7px 0', borderRadius: '7px',
                background: '#f0f2f4',
                border: '1px solid #d4dce8',
                fontSize: '12px', fontWeight: 500,
                color: '#374151', cursor: 'pointer',
              }}>
                Cancel
              </button>
              <button onClick={handleConfirmProceed} style={{
                flex: 1, padding: '7px 0', borderRadius: '7px',
                background: '#1e2d3d', border: 'none',
                fontSize: '12px', fontWeight: 500,
                color: '#e8ecf0', cursor: 'pointer',
                display: 'inline-flex', alignItems: 'center',
                justifyContent: 'center', gap: 6,
              }}>
                ⇅ Retrigger
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Reset (Discard) confirmation popup ──────────────────────────── */}
      {showResetConfirm && (
        <div style={{
          position: 'fixed', inset: 0,
          background: 'rgba(0,0,0,0.45)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          zIndex: 9999,
        }}>
          <div style={{
            background: '#ffffff',
            border: '1px solid #d4dce8',
            borderRadius: '12px',
            padding: '24px 20px',
            width: '280px',
            boxShadow: '0 8px 32px rgba(0,0,0,0.22)',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '12px',
          }}>
            {/* Icon — grey, neutral */}
            <div style={{
              width: 40, height: 40, borderRadius: '50%',
              background: '#f0f2f4',
              border: '1px solid #d4dce8',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <span aria-hidden="true" style={{
                fontSize: 18, color: '#374151', lineHeight: 1,
                fontStyle: 'normal', fontWeight: 500,
              }}>↺</span>
            </div>
            {/* Title */}
            <span style={{ fontSize: '14px', fontWeight: 600, color: '#111827', textAlign: 'center' }}>
              Undo changes?
            </span>
            {/* Body */}
            <span style={{ fontSize: '12px', color: '#6b7280', textAlign: 'center', lineHeight: 1.6 }}>
              This will revert to the original classification. Modified changes will be lost.
            </span>
            {/* Buttons */}
            <div style={{ display: 'flex', gap: 8, width: '100%', marginTop: 4 }}>
              <button onClick={handleResetCancel} style={{
                flex: 1, padding: '7px 0', borderRadius: '7px',
                background: '#f0f2f4', border: '1px solid #d4dce8',
                fontSize: '12px', fontWeight: 500, color: '#374151', cursor: 'pointer',
              }}>
                No, keep
              </button>
              <button onClick={handleResetProceed} style={{
                flex: 1, padding: '7px 0', borderRadius: '7px',
                background: '#1e2d3d', border: 'none',
                fontSize: '12px', fontWeight: 500, color: '#e8ecf0', cursor: 'pointer',
              }}>
                Yes, reset
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
