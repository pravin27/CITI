# DocCapture — Complete Technical Reference

---

## 1. Supported File Formats

### 1.1 Format Groups

| Format Group | Extensions | Adapter | Library |
|---|---|---|---|
| **PDF** | `.pdf` | `PDFAdapter` | pdfjs-dist 5.4 (native viewer) |
| **Image** | `.tif`, `.tiff` | `ImageAdapter` | UTIF 3.1 (all TIFF compressions) |
| **Image** | `.bmp`, `.jpg`, `.jpeg`, `.png` | `ImageAdapter` | Browser native `<img>` decode |
| **Spreadsheet** | `.xlsx`, `.xls` | `SpreadsheetAdapter` | SheetJS 0.18.5 |
| **Spreadsheet** | `.csv` | `SpreadsheetAdapter` | PapaParse |
| **Document** | `.docx`, `.doc` | `DocAdapter` | mammoth 1.12 |
| **Document** | `.txt` | `DocAdapter` | Native text |

**Total: 11 extensions across 4 viewer groups.**

### 1.2 Format Detection

Detection is by file extension only (no MIME-type sniffing):

```
.pdf               → PDFAdapter    → PDFViewer
.tif/.tiff         → ImageAdapter  → ImageViewer  (UTIF decoder)
.bmp/.jpg/.png     → ImageAdapter  → ImageViewer  (browser native)
.xlsx/.xls         → SpreadsheetAdapter → SpreadsheetViewer
.csv               → SpreadsheetAdapter → SpreadsheetViewer
.docx/.doc         → DocAdapter    → ImageViewer  (rendered to canvas)
.txt               → DocAdapter    → ImageViewer  (rendered to canvas)
```

### 1.3 TIF Compression Types Supported (via UTIF)

| Compression | Code | Notes |
|---|---|---|
| Uncompressed | 1 | Raw pixels |
| CCITT Group 3 Fax | 3 | Old fax format |
| **CCITT Group 4 Fax (G4)** | 4 | Most common for scanned docs |
| LZW | 5 | Standard lossless |
| JPEG (old style) | 6 | Legacy TIFF-JPEG |
| JPEG (new style) | 7 | Modern TIFF-JPEG |
| Deflate / ZIP | 8 | ZIP compression |
| PackBits | 32773 | Simple RLE |
| PixarLog | 32809 | HDR images |

### 1.4 DOCX Document Modes (auto-detected)

| Mode | Description | Click2Pick |
|---|---|---|
| **Digital** | Text paragraphs, headings, lists | Word-level from word index |
| **Image-based** | Scanned pages as embedded PNG/JPEG | Box capture only (no text) |
| **Mixed** | Text + inline images together | Word-level for text sections |

---

## 2. Viewer Layers — Box Mode ON vs OFF

### 2.1 PDF Viewer Layers

```
┌─────────────────────────────────────────────┐  z-index
│  Rubber-band canvas (body-level, fixed)     │  99999  ← mouse coords during drag
│  Pulse box (preview rect, CSS div)          │  20     ← animated preview after capture
│  Overlay canvas (per-page, highlight draw)  │  11     ← all highlight painting
│  pdfjs textLayer (.textLayer div)           │  2–10   ← transparent text spans
│  pdfjs annotationLayer                      │  3      ← links, form fields
│  pdfjs canvas (page render)                 │  1      ← actual page pixels
└─────────────────────────────────────────────┘
```

#### Box Mode OFF

| Layer | State | Role |
|---|---|---|
| pdfjs canvas | Rendered, normal | Displays page content |
| textLayer | `pointer-events: auto`, visible | Text selection, native search |
| Overlay canvas | `pointer-events: none` | Draws confirmed capture highlights |
| Rubber-band canvas | Invisible | Not used |
| Pulse box | Hidden | Not used |

**Performance impact (Box Mode OFF):**
- Overlay canvas redraws only on store changes (captures/search change)
- textLayer renders in background thread via pdfjs worker
- No event listeners for capture on the viewer container

#### Box Mode ON

| Layer | State | Role |
|---|---|---|
| pdfjs canvas | Rendered, normal | Displays page content |
| textLayer | `pointer-events: auto`, crosshair cursor | Hittable for `elementsFromPoint` |
| Overlay canvas | `pointer-events: none` | Draws confirmed + preview highlights |
| Rubber-band canvas | Active during drag | Visual rubber-band rectangle |
| Pulse box | Shows after capture | Animated cyan preview rect |

**Performance impact (Box Mode ON):**
- `pointerdown`/`pointerup`/`dblclick` listeners added to container (`capture: true`)
- `pointermove` RAF-throttled — max 1 draw call per animation frame (60fps)
- pdfjs text items fetched via `getTextContent()` once per page, cached 30 seconds
- No re-renders during drag — all refs, zero React state changes while dragging

#### Word_index Loaded (either Box Mode state)

| Layer | State |
|---|---|
| textLayer | `opacity: 0`, `pointer-events: none` — fully hidden |
| Overlay canvas | Draws word_index occurrence highlights instead |
| pdfjs find controller | Disabled — our `runSearch()` takes over |

---

### 2.2 Image/TIF Viewer Layers

```
┌─────────────────────────────────────────────┐  z-index
│  Rubber-band canvas (body-level, fixed)     │  99999
│  Highlight canvas (per-page, absolute)      │  11     ← capture/search highlights
│  Image canvas (per-page)                    │  1      ← decoded TIF/PNG pixels
└─────────────────────────────────────────────┘
```

#### Box Mode OFF

| Layer | State | Role |
|---|---|---|
| Image canvas | Rendered (virtual: ±2 pages only) | Page display |
| Highlight canvas | `pointer-events: none` | Draws highlights on visible pages only |

**Performance impact:**
- **Virtual scroll**: only pages within ±2 of viewport are mounted in DOM
- Single store subscription for entire viewer (not per-page)
- RAF-gated redraws — 1 repaint per animation frame max
- Shared `hlCache` (fwc/flc Maps) rebuilt once per captures change, reused by all pages

#### Box Mode ON

Same layers, plus rubber-band canvas active during drag. Hit-testing uses word_index fractional arithmetic if loaded, otherwise `getPdfTextItems` (not applicable — TIF has no digital text unless word_index provided).

---

### 2.3 Spreadsheet Viewer Layers

```
┌─────────────────────────────────────────────┐  z-index
│  Rubber-band canvas (body-level, fixed)     │  99999
│  Selection overlay div (blue drag box)      │  30     ← visible during cell drag
│  Highlight canvas (natural-size, absolute)  │  25     ← capture/search highlights
│  HTML table (cells, borders, fill colors)   │  1      ← the spreadsheet itself
└─────────────────────────────────────────────┘
```

#### Box Mode OFF → Cell click = capture, no rubber-band

#### Box Mode ON → Drag across cells = multi-cell range capture

**Performance impact:**
- Only the **active sheet** is mounted in the DOM (other sheets unmounted)
- All rows are rendered (no row virtualization — add `react-virtual` for 50k+ rows)
- `drawHighlights` subscribes to store, redraws only on relevant changes

---

### 2.4 Performance Summary by Layer

| Layer | Box OFF cost | Box ON cost |
|---|---|---|
| Highlight canvas redraw | O(captures/page) per store event | Same |
| RAF throttle | N/A | caps pointermove at 60fps |
| word_index hit-test (box drag) | N/A | O(entries/page) — pure arithmetic |
| PDF text items (no word_index) | N/A | Cached per page, O(1) after first access |
| ThumbnailSidebar re-renders | 0 — imperative DOM updates | 0 |
| Store subscribers | 1 per viewer | 1 per viewer |

---

## 3. Coordinate Formats

### 3.1 Internal Storage

All coordinates are stored internally as **0–1 fractions** of page dimensions:

```
x      = left edge   / page_width    (0 = left,  1 = right)
y      = top edge    / page_height   (0 = top,   1 = bottom)
width  = box_width   / page_width
height = box_height  / page_height
```

This means coordinates are **resolution-independent** — the same fractions work at any zoom level, on any screen, for any page size.

---

### 3.2 The 7 Supported Input Formats

#### FORMAT 1 — Flat `{x, y, width, height}`
Default format. Used by box draw, click2pick (no word_index), and all manual entry.
```json
{
  "id": "invoice_total",
  "text": "4250.00",
  "page": 3,
  "x": 0.623,
  "y": 0.812,
  "width": 0.142,
  "height": 0.021
}
```
Aliases: `w` for `width`, `h` for `height` both accepted.

---

#### FORMAT 2 — `{bbox: [x, y, w, h]}`
Common in OCR output pipelines (AWS Textract, Google Vision style).
```json
{
  "text": "Invoice No",
  "page": 1,
  "bbox": [0.423, 0.117, 0.089, 0.018]
}
```
Array order: `[left, top, width, height]` — all fractions or absolute pixels.

---

#### FORMAT 3 — `{rectangle: [x, y, w, h]}`
Rectangle in width/height form. Detected when 3rd/4th values are not corner points.
```json
{
  "text": "Total",
  "page": 2,
  "rectangle": [120, 450, 80, 20],
  "page_width": 595,
  "page_height": 842
}
```
Absolute pixels auto-normalised using `page_width`/`page_height`.

---

#### FORMAT 4 — `{rectangle: [x1, y1, x2, y2]}`
Rectangle as two corner points. Detected when 3rd value > 1st (corner, not width).
```json
{
  "text": "Amount",
  "page": 1,
  "rectangle": [0.42, 0.11, 0.56, 0.13]
}
```
Internally converted to `[x1, y1, x2-x1, y2-y1]`.

---

#### FORMAT 5 — `{coordinates: [ymin, xmin, ymax, xmax]}`
**Y-first order** — common in ML model outputs (TensorFlow Object Detection format).
```json
{
  "text": "Date",
  "page": 1,
  "coordinates": [0.108, 0.423, 0.128, 0.561]
}
```
Note the unusual order: `[ymin, xmin, ymax, xmax]`. Internally reordered to `[xmin, ymin, w, h]`.

---

#### FORMAT 6 — Flat min/max `{xmin, ymin, xmax, ymax}`
Named properties version of corner points.
```json
{
  "text": "Vendor",
  "page": 1,
  "xmin": 0.05,
  "ymin": 0.22,
  "xmax": 0.28,
  "ymax": 0.24
}
```

---

#### FORMAT 7 — `{bbox_relative: [[x,y],[x,y],[x,y],[x,y]]}`
**Polygon bounding box** — 4 corner points (top-left, top-right, bottom-right, bottom-left). Supports rotated/skewed regions. Internally converted to axis-aligned bounding box (AABB).
```json
{
  "text": "Signature",
  "page": 4,
  "bbox_relative": [
    [0.42, 0.78],
    [0.68, 0.78],
    [0.68, 0.83],
    [0.42, 0.83]
  ]
}
```
AABB computed as: `x=min(all_x), y=min(all_y), w=max_x-min_x, h=max_y-min_y`.

---

### 3.3 Coordinate Normalisation Pipeline

```
Input JSON item
       │
       ▼
extractRawCoords()          → raw [x, y, w, h]  (may be absolute pixels or fractions)
       │
       ▼
normaliseCoords()           → normalised [x, y, w, h]  (always 0-1 fractions)
  Priority for page dims:
  1. item.pageWidth / page_width    (per-item override)
  2. adapter.getPageDimensions()    (real rendered dimensions)
  3. Inferred from standard sizes   (A4, Letter, Legal, A3...)
       │
       ▼
CaptureItem / WordEntry     → stored internally with sourceFormat tag
       │
       ▼
buildCoordProps()           → output in ORIGINAL format (round-trip)
```

---

### 3.4 Normalisation Examples

**Example A — Absolute pixels with page dims:**
```json
Input:  { "x": 250, "y": 180, "width": 80, "height": 15, "page_width": 595, "page_height": 842 }
raw:    [250, 180, 80, 15]  (all > 1 → absolute)
norm:   [250/595, 180/842, 80/595, 15/842]
output: x=0.420168, y=0.213777, width=0.134454, height=0.017815
```

**Example B — Already fractional:**
```json
Input:  { "bbox": [0.42, 0.21, 0.13, 0.018] }
raw:    [0.42, 0.21, 0.13, 0.018]  (all ≤ 1 → already fractional)
norm:   [0.42, 0.21, 0.13, 0.018]  (no change, just clamp to [0,1])
```

**Example C — coordinates (Y-first) with absolute pixels:**
```json
Input:  { "coordinates": [180, 250, 195, 330], "page_width": 595, "page_height": 842 }
raw:    [ymin=180, xmin=250, ymax=195, xmax=330]
→ x=250, y=180, w=80, h=15
norm:   x=0.4202, y=0.2138, w=0.1345, h=0.0178
```

---

### 3.5 Export Round-Trip

The `sourceFormat` is preserved from input through to export:

| Input format | Stored sourceFormat | Export output |
|---|---|---|
| `{x, y, width, height}` | `flat` | `{x, y, width, height}` |
| `{bbox: [x,y,w,h]}` | `bbox` | `{bbox: [x, y, w, h]}` |
| `{rectangle: [x1,y1,x2,y2]}` | `rectangle` | `{rectangle: [x1, y1, x2, y2]}` |
| `{coordinates: [ymin,xmin,ymax,xmax]}` | `coordinates` | `{coordinates: [ymin, xmin, ymax, xmax]}` |
| `{xmin, ymin, xmax, ymax}` | `flat` (normalised) | `{x, y, width, height}` |
| `{bbox_relative: [[…]]}` | `bbox_relative` | `{bbox_relative: [[tl],[tr],[br],[bl]]}` |
| Box draw / click2pick (no JSON) | `flat` | `{x, y, width, height}` |

---

## 4. JSON Types for Sidecar Loading

All JSON files are loaded via the **Load Sidecar JSON** drop zone. The system auto-detects the JSON type by inspecting its structure.

---

### 4.1 `word_index` — Text Position Index

**Purpose:** Provides word-level positions for the entire document. Enables precise click2pick (single-word selection), accurate search, and word-level duplicate highlighting. When loaded, replaces the PDF library's text layer entirely.

**When to use:** When you have OCR output or text extraction results with per-word bounding boxes.

**Effect on viewers:**
- PDF: pdfjs textLayer hidden; our overlay handles all text interaction
- TIF/Image: click2pick uses word_index (no DOM needed)
- All viewers: search queries the word_index instead of DOM/pdfjs

#### Format A — Paginated object
```json
{
  "pages": {
    "1": [
      { "text": "Invoice",  "x": 0.05, "y": 0.08, "width": 0.12, "height": 0.02 },
      { "text": "No",       "x": 0.18, "y": 0.08, "width": 0.04, "height": 0.02 },
      { "text": "INV-2024", "x": 0.05, "y": 0.12, "width": 0.18, "height": 0.02 }
    ],
    "2": [
      { "text": "Total",    "x": 0.62, "y": 0.85, "width": 0.08, "height": 0.02 },
      { "text": "4250.00",  "x": 0.72, "y": 0.85, "width": 0.14, "height": 0.02 }
    ]
  }
}
```

#### Format B — Flat array
```json
[
  { "text": "Invoice",  "page": 1, "x": 0.05, "y": 0.08, "width": 0.12, "height": 0.02 },
  { "text": "No",       "page": 1, "x": 0.18, "y": 0.08, "width": 0.04, "height": 0.02 },
  { "text": "Total",    "page": 2, "x": 0.62, "y": 0.85, "width": 0.08, "height": 0.02 }
]
```

#### word_index with bbox format
```json
{
  "pages": {
    "1": [
      { "label": "Invoice", "bbox": [0.05, 0.08, 0.12, 0.02] },
      { "value": "INV-001", "bbox": [0.05, 0.12, 0.18, 0.02] }
    ]
  }
}
```

#### word_index with coordinates format (ML model output)
```json
[
  {
    "text": "Amount",
    "page": 1,
    "coordinates": [0.080, 0.620, 0.100, 0.760],
    "page_width": 1,
    "page_height": 1
  }
]
```

**Field aliases (all equivalent):**
- Text content: `text`, `label`, `value`, `t`
- `id` — optional for word_index
- `page` — required in Format B, derived from object key in Format A
- `page_width` / `pageWidth`, `page_height` / `pageHeight` — for absolute pixel coords

---

### 4.2 `captured_fields` — Pre-loaded Capture Results

**Purpose:** Pre-populates the capture panel with existing field extractions. Each item appears as a confirmed capture with id, label, value, and highlighted position.

**When to use:** When you already have extracted field data and want to review/verify positions, or when loading previously exported captures back into the viewer.

```json
[
  {
    "id": "invoice_number",
    "label": "Invoice Number",
    "value": "INV-2024-0891",
    "page": 1,
    "x": 0.623,
    "y": 0.118,
    "width": 0.183,
    "height": 0.021,
    "color": "#2563eb"
  },
  {
    "id": "vendor_name",
    "label": "Vendor",
    "value": "Acme Corporation",
    "page": 1,
    "bbox": [0.05, 0.22, 0.35, 0.025]
  },
  {
    "id": "invoice_date",
    "label": "Date",
    "value": "2024-01-15",
    "page": 1,
    "coordinates": [0.148, 0.62, 0.168, 0.78]
  },
  {
    "id": "total_amount",
    "label": "Total",
    "value": "4250.00",
    "page": 2,
    "rectangle": [0.62, 0.85, 0.88, 0.872]
  }
]
```

**Required fields:** `id` (auto-generated if missing), one of `text`/`label`/`value`, `page`, coordinates in any supported format.

**Optional fields:** `color` (hex string for highlight colour), `label` (display name separate from value).

---

### 4.3 `categories` — Page Classification

**Purpose:** Groups pages into named categories with colours, displayed as accordion sections in the thumbnail sidebar. Pages not assigned to any category are auto-grouped into "Others".

**When to use:** When your document contains multiple document types (e.g. "Invoice", "Form 15CA", "Cover Letter") mixed across pages.

```json
[
  {
    "label": "Invoice",
    "color": "blue",
    "pages": [1, 2, 3]
  },
  {
    "label": "Form 15CA",
    "color": "teal",
    "pages": [4, 5]
  },
  {
    "label": "Form 15CB",
    "color": "coral",
    "pages": [6]
  }
]
```

**Named palette colors:** `blue`, `teal`, `amber`, `gray`, `purple`, `coral`, `green`, `red`

**Custom hex color:**
```json
[
  {
    "label": "Contract",
    "color": "#7C3AED",
    "pages": [1, 2, 3, 4]
  }
]
```

**Pages missing from all categories → automatically placed in "Others" group.**

---

### 4.4 Combined Sidecar JSON

All three types can be combined in a single JSON file:

```json
{
  "word_index": {
    "pages": {
      "1": [
        { "text": "Invoice", "x": 0.05, "y": 0.08, "width": 0.12, "height": 0.02 },
        { "text": "No",      "x": 0.18, "y": 0.08, "width": 0.04, "height": 0.02 }
      ]
    }
  },
  "captured_fields": [
    {
      "id": "invoice_number",
      "label": "Invoice Number",
      "value": "INV-001",
      "page": 1,
      "x": 0.05, "y": 0.08, "width": 0.18, "height": 0.02
    }
  ],
  "categories": [
    { "label": "Invoice", "color": "blue", "pages": [1, 2] },
    { "label": "Receipt", "color": "teal", "pages": [3]    }
  ]
}
```

---

### 4.5 Export / Submit JSON

When you confirm a capture and submit, the output JSON preserves the original coordinate format:

#### Box draw / click2pick (no word_index) → flat format
```json
{
  "id": "vendor_name",
  "label": "Vendor Name",
  "value": "Acme Corp",
  "page": 1,
  "x": 0.052,
  "y": 0.218,
  "width": 0.312,
  "height": 0.022
}
```

#### Captured from word_index with bbox input → bbox output
```json
{
  "id": "invoice_total",
  "label": "Total",
  "value": "4250.00",
  "page": 2,
  "bbox": [0.623, 0.851, 0.142, 0.021]
}
```

#### Captured from word_index with coordinates input → coordinates output
```json
{
  "id": "date_field",
  "label": "Date",
  "value": "2024-01-15",
  "page": 1,
  "coordinates": [0.148, 0.423, 0.168, 0.561]
}
```

#### Captured from word_index with bbox_relative input → bbox_relative output
```json
{
  "id": "signature",
  "label": "Signature",
  "value": "",
  "page": 4,
  "bbox_relative": [
    [0.42, 0.78],
    [0.68, 0.78],
    [0.68, 0.83],
    [0.42, 0.83]
  ]
}
```

---

### 4.6 Text Field Key Preservation

The key used for text in the source JSON is preserved in the output:

| Source JSON used | Output key |
|---|---|
| `"text": "Invoice"` | `"text": "Invoice"` |
| `"label": "Invoice"` | `"label": "Invoice"` |
| `"value": "Invoice"` | `"value": "Invoice"` |
| Box draw / click2pick | `"value": "..."` (default) |

---

### 4.7 Submit JSON Manually (via Submit JSON panel)

You can also paste JSON directly into the Submit JSON textarea. Accepts single object or array. All coordinate formats supported:

```json
{
  "id": "my_field",
  "label": "My Field",
  "value": "captured text",
  "page": 1,
  "x": 0.42,
  "y": 0.18,
  "width": 0.15,
  "height": 0.02
}
```

Press **Ctrl+Enter** or click Confirm to add to the capture list.

