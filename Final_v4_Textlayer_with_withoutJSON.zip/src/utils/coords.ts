// ─────────────────────────────────────────────────────────────────────────────
// COORDINATE NORMALISATION
// All coordinates stored internally as 0–1 fractions of page dimensions.
// ─────────────────────────────────────────────────────────────────────────────

import type { ViewerAdapter } from '../adapters/types';

// Standard page sizes (width × height, points)
const PAGE_SIZES: [number, number][] = [
  [595, 842],   // A4 portrait
  [842, 595],   // A4 landscape
  [612, 792],   // Letter portrait
  [792, 612],   // Letter landscape
  [612, 1008],  // Legal portrait
  [1008, 612],  // Legal landscape
  [842, 1191],  // A3 portrait
  [1191, 842],  // A3 landscape
  [792, 1224],  // Tabloid portrait
  [1224, 792],  // Tabloid landscape
];

function inferPageSizeFromAbsCoords(
  maxX: number, maxY: number
): { width: number; height: number } | null {
  for (const [w, h] of PAGE_SIZES) {
    if (maxX <= w * 1.05 && maxY <= h * 1.05) {
      return { width: w, height: h };
    }
  }
  return null;
}

/**
 * Extract raw [x, y, w, h] from any supported coordinate format.
 * Returns raw values (may be absolute or fractional — caller normalises).
 *
 * NOTE: page_width, page_height, pageWidth, pageHeight are intentionally
 * NOT extracted here — they are metadata used by normaliseCoords() and
 * resolvePageDims() only, then discarded from the output object.
 *
 * Supported formats:
 *   FORMAT 1 — flat:          {x, y, width|w, height|h}
 *   FORMAT 2 — bbox:          {bbox: [x, y, w, h]}
 *   FORMAT 3 — rectangle w/h: {rectangle: [x, y, w, h]}
 *   FORMAT 4 — rectangle pts: {rectangle: [x1, y1, x2, y2]}
 *   FORMAT 5 — coordinates:   {coordinates: [ymin, xmin, ymax, xmax]}
 *   FORMAT 6 — flat min/max:  {xmin, ymin, xmax, ymax}
 *   FORMAT 7 — bbox_relative: {bbox_relative: [[x,y],[x,y],[x,y],[x,y]]}
 *              4 corner points (top-left, top-right, bottom-right, bottom-left).
 *              May be rotated — we compute the axis-aligned bounding box (AABB):
 *              x=min(all x), y=min(all y), w=max(x)-min(x), h=max(y)-min(y).
 */
export function extractRawCoords(
  item: Record<string, unknown>
): [number, number, number, number] | null {
  // FORMAT 1 — flat: x/y/width|w/height|h
  if (
    typeof item.x === 'number' &&
    typeof item.y === 'number' &&
    (typeof item.width === 'number' || typeof item.w === 'number') &&
    (typeof item.height === 'number' || typeof item.h === 'number')
  ) {
    const w = (item.width ?? item.w) as number;
    const h = (item.height ?? item.h) as number;
    return [item.x as number, item.y as number, w, h];
  }

  // FORMAT 6 — flat min/max points: {xmin, ymin, xmax, ymax}
  if (
    typeof item.xmin === 'number' && typeof item.ymin === 'number' &&
    typeof item.xmax === 'number' && typeof item.ymax === 'number'
  ) {
    const x = item.xmin as number, y = item.ymin as number;
    const x2 = item.xmax as number, y2 = item.ymax as number;
    return [x, y, x2 - x, y2 - y];
  }

  // FORMAT 2 — bbox array [x, y, w, h]
  if (Array.isArray(item.bbox) && item.bbox.length >= 4) {
    const [a, b, c, d] = item.bbox as number[];
    return [a, b, c, d];
  }

  // FORMAT 3 / 4 — rectangle [x, y, w, h] or [x1, y1, x2, y2]
  if (Array.isArray(item.rectangle) && item.rectangle.length >= 4) {
    const [a, b, c, d] = item.rectangle as number[];
    if (c > a && d > b && (a > 1 || b > 1 || c > 1 || d > 1)) {
      return [a, b, c - a, d - b]; // FORMAT 4: corner points → x,y,w,h
    }
    return [a, b, c, d];
  }

  // FORMAT 5 — coordinates [ymin, xmin, ymax, xmax]
  if (Array.isArray(item.coordinates) && item.coordinates.length >= 4) {
    const [ymin, xmin, ymax, xmax] = item.coordinates as number[];
    return [xmin, ymin, xmax - xmin, ymax - ymin];
  }

  // FORMAT 7 — bbox_relative: [[x,y],[x,y],[x,y],[x,y]] — 4 polygon corner points
  // Compute AABB: minX, minY, width, height across all corners.
  if (Array.isArray(item.bbox_relative) && item.bbox_relative.length >= 3) {
    const pts = item.bbox_relative as [number, number][];
    // Validate: each element must be a [number, number] pair
    if (pts.every(p => Array.isArray(p) && p.length >= 2 &&
        typeof p[0] === 'number' && typeof p[1] === 'number')) {
      const xs = pts.map(p => p[0]);
      const ys = pts.map(p => p[1]);
      const minX = Math.min(...xs), maxX = Math.max(...xs);
      const minY = Math.min(...ys), maxY = Math.max(...ys);
      return [minX, minY, maxX - minX, maxY - minY];
    }
  }

  return null;
}

/**
 * Normalise raw [x, y, w, h] to 0–1 fractions.
 * Uses per-item pageWidth/Height, then adapter dimensions, then inferred size.
 * Always clamps to [0, 1].
 */
export function normaliseCoords(
  raw: [number, number, number, number],
  item: Record<string, unknown>,
  page: number,
  adapter?: ViewerAdapter | null,
  inferredSize?: { width: number; height: number } | null
): [number, number, number, number] {
  const [x, y, w, h] = raw;

  // Already fractional?
  if (x <= 1 && y <= 1 && w <= 1 && h <= 1) {
    return clamp4([x, y, w, h]);
  }

  // Absolute — need page dimensions
  let pw: number | undefined;
  let ph: number | undefined;

  // Priority 1: per-item dimensions (pageWidth/page_width/pageHeight/page_height)
  if (typeof item.pageWidth  === 'number') pw = item.pageWidth  as number;
  if (typeof item.page_width  === 'number') pw = item.page_width  as number;
  if (typeof item.pageHeight === 'number') ph = item.pageHeight as number;
  if (typeof item.page_height === 'number') ph = item.page_height as number;

  // Priority 2: adapter real dimensions
  if ((!pw || !ph) && adapter) {
    const dims = adapter.getPageDimensions(page);
    if (dims) { pw = dims.width; ph = dims.height; }
  }

  // Priority 3: inferred from standard sizes
  if ((!pw || !ph) && inferredSize) {
    pw = inferredSize.width;
    ph = inferredSize.height;
  }

  if (!pw || !ph) return clamp4([x, y, w, h]); // fallback — already checked ≤1

  return clamp4([x / pw, y / ph, w / pw, h / ph]);
}

function clamp4([x, y, w, h]: [number,number,number,number]): [number,number,number,number] {
  const clamp = (v: number) => Math.max(0, Math.min(1, v));
  return [clamp(x), clamp(y), clamp(w), clamp(h)];
}

/**
 * Two-pass O(n) normalisation for an array of items.
 * Pass 1: compute per-page max extent for abs coord inference.
 * Pass 2: normalise every entry.
 */
export function normaliseBatch(
  items: Record<string, unknown>[],
  getPage: (item: Record<string, unknown>) => number,
  adapter?: ViewerAdapter | null
): Array<{ raw: Record<string, unknown>; coords: [number,number,number,number] | null }> {
  // Pass 1 – per-page max content extent
  const pageMaxExtent = new Map<number, { maxX: number; maxY: number }>();
  for (const item of items) {
    const raw = extractRawCoords(item);
    if (!raw) continue;
    const [x, y, w, h] = raw;
    if (x <= 1 && y <= 1 && w <= 1 && h <= 1) continue; // already fractional
    const pg = getPage(item);
    const cur = pageMaxExtent.get(pg) ?? { maxX: 0, maxY: 0 };
    pageMaxExtent.set(pg, {
      maxX: Math.max(cur.maxX, x + w),
      maxY: Math.max(cur.maxY, y + h),
    });
  }

  // Pre-compute inferred page sizes
  const inferredSizes = new Map<number, { width: number; height: number } | null>();
  for (const [pg, { maxX, maxY }] of pageMaxExtent) {
    inferredSizes.set(pg, inferPageSizeFromAbsCoords(maxX, maxY));
  }

  // Pass 2 – normalise
  return items.map(item => {
    const raw = extractRawCoords(item);
    if (!raw) return { raw: item, coords: null };
    const pg = getPage(item);
    return {
      raw: item,
      coords: normaliseCoords(raw, item, pg, adapter, inferredSizes.get(pg) ?? null),
    };
  });
}

export { inferPageSizeFromAbsCoords };
