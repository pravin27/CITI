import React, { useEffect, useCallback } from 'react';
import { useAppStore } from './store/appStore';
import { TopBar } from './components/TopBar';
import { ResizablePanes } from './components/ResizablePanes';
import { ViewerPane } from './components/ViewerPane';
import { FieldsPanel } from './components/FieldsPanel';
import { ThumbnailSidebar } from './components/ThumbnailSidebar';
import { useSidecarLoader } from './hooks/useSidecarLoader';
import { useMultiDoc } from './hooks/useMultiDoc';
import { MultiDocSidebar } from './components/MultiDocSidebar';
import type { DocumentManifest } from './types/multiDoc';

function useGlobalShortcuts() {
  const setSearchOpen = useAppStore(s => s.setSearchOpen);
  const searchIsOpen  = useAppStore(s => s.search.isOpen);
  const file          = useAppStore(s => s.file);
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'f' && file) {
        e.preventDefault(); setSearchOpen(!searchIsOpen);
      }
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [setSearchOpen, searchIsOpen, file]);
}

export default function App() {
  const sidebarOpen    = useAppStore(s => s.sidebarOpen);
  const openFile       = useAppStore(s => s.openFile);
  const setCurrentPage = useAppStore(s => s.setCurrentPage);
  const closeFile      = useAppStore(s => s.closeFile);
  const adapter        = useAppStore(s => s.adapter);

  useSidecarLoader();
  useGlobalShortcuts();

  // ── Multi-doc state ───────────────────────────────────────────────────────
  const multiDoc = useMultiDoc();

  // Register manifest handler in the store — synchronous, no timing race
  const handleManifest = useCallback((manifest: DocumentManifest) => {
    multiDoc.loadManifest(manifest);
  }, [multiDoc]);

  useEffect(() => {
    useAppStore.getState().registerManifestHandler(handleManifest);
    // Also set window bridge for ViewerPane drop zone (belt-and-suspenders)
    (window as any).__onManifest = handleManifest;
    return () => {
      (window as any).__onManifest = undefined;
    };
  }, [handleManifest]);

  // Exit multi-doc mode — clear state + reset viewer
  const handleClearMultiDoc = useCallback(() => {
    multiDoc.clearMultiDoc();
    closeFile();
  }, [multiDoc, closeFile]);

  // pendingPageRef: when selectDoc resolves a new file, navigate to requested page
  // after pdfjs adapter is ready (adapter.onReady fires after page dims loaded)
  const pendingPageRef = React.useRef<number>(1);

  const handleSelectDoc = useCallback(async (docId: string, page = 1) => {
    pendingPageRef.current = page;
    await multiDoc.selectDoc(docId, page);
  }, [multiDoc]);

  // Track last loaded file name to skip re-opening on cache hits (same File object)
  const lastLoadedFileRef = React.useRef<string>('');

  // When a new activeFile is resolved → load it into the viewer
  useEffect(() => {
    if (!multiDoc.activeFile) return;
    const fileKey = multiDoc.activeFile.name + multiDoc.activeFile.size;
    if (fileKey === lastLoadedFileRef.current) {
      // Cache hit — same File object, pdfjs already loaded.
      // Just navigate to the requested page.
      const pg = pendingPageRef.current;
      if (pg >= 1) {
        setCurrentPage(pg);
        useAppStore.getState().adapter?.navigateToPage?.(pg);
      }
      return;
    }
    lastLoadedFileRef.current = fileKey;
    openFile(multiDoc.activeFile).then(() => {
      const adapter = useAppStore.getState().adapter as any;
      if (adapter && typeof adapter.onReady === 'function') {
        adapter.onReady(() => {
          const pg = pendingPageRef.current;
          if (pg > 1) {
            setCurrentPage(pg);
            useAppStore.getState().adapter?.navigateToPage?.(pg);
          }
        });
      }
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [multiDoc.activeFile]);

  // Page selection within the current document
  const handleSelectPage = useCallback((page: number) => {
    multiDoc.selectPage(page);
    setCurrentPage(page);
    useAppStore.getState().adapter?.navigateToPage?.(page);
  }, [multiDoc, setCurrentPage]);

  const showMultiSidebar   = !!multiDoc.state && sidebarOpen;
  const showDefaultSidebar = !multiDoc.state && sidebarOpen;

  return (
    <div className="flex flex-col h-screen bg-[#060d1a] overflow-hidden">
      <TopBar />
      <ResizablePanes
        left={
          <div className="flex flex-1 overflow-hidden">
            {showMultiSidebar && multiDoc.state && (
              <MultiDocSidebar
                state={multiDoc.state}
                isLoading={multiDoc.activeDocLoading}
                loadError={multiDoc.activeDocError}
                adapter={adapter}
                onSelectDoc={handleSelectDoc}
                onSelectPage={handleSelectPage}
                onClose={handleClearMultiDoc}
              />
            )}
            {showDefaultSidebar && <ThumbnailSidebar />}
            <ViewerPane multiDocLoading={multiDoc.activeDocLoading && !multiDoc.activeFile} />
          </div>
        }
        right={<FieldsPanel />}
        defaultSplit={0.62}
        minLeft={320}
        minRight={280}
      />
    </div>
  );
}
