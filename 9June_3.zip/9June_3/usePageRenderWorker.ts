// usePageRenderWorker — manages the pageRenderWorker for off-thread rendering.
//
// Responsibilities:
//   • Start/restart the worker when the PDF document changes
//   • Maintain a priority queue: current page renders first, prefetch second
//   • Cache completed bitmaps keyed by "page:scale"
//   • Cancel stale renders when the user navigates quickly
//   • Expose a drawBitmap() function for PDFViewer to blit results onto pdfjs canvases
//
// The worker renders pages using pdfjs + OffscreenCanvas entirely off the main
// thread. The returned ImageBitmap is transfered (zero-copy) and blitted over
// pdfjs's own canvas — making the visible page appear in <50ms (blit) while pdfjs
// renders its own copy in the background for overlays/text-layer consistency.

import { useRef, useCallback, useEffect } from 'react';

// ── Types ─────────────────────────────────────────────────────────────────────

interface PendingRequest {
  reqId:    string;
  page:     number;
  scale:    number;
  priority: number; // lower = higher priority (0 = current page)
  resolve:  (bitmap: ImageBitmap) => void;
  reject:   (err: Error) => void;
}

interface RenderWorkerHook {
  /** Notify the worker that a new document has been loaded. */
  loadDoc(docKey: string, pdfData: ArrayBuffer): void;
  /** Request off-thread render. Returns a transferable ImageBitmap. */
  requestRender(page: number, scale: number, priority?: number): Promise<ImageBitmap>;
  /** Pre-warm adjacent pages — lower priority than requestRender. */
  prefetch(pages: number[], scale: number): void;
  /** Cancel all pending renders (e.g. on document unload). */
  cancelAll(): void;
  /** Get a cached bitmap if available (no re-render). */
  getCached(page: number, scale: number): ImageBitmap | undefined;
  /** Invalidate cache (on zoom change etc). */
  clearCache(): void;
}

const CACHE_MAX = 12; // max cached bitmaps — each is ~6-24MB for large-format

// ── Hook ──────────────────────────────────────────────────────────────────────

export function usePageRenderWorker(): RenderWorkerHook {
  const workerRef   = useRef<Worker | null>(null);
  const pendingRef  = useRef<Map<string, PendingRequest>>(new Map());
  const bitmapCache = useRef<Map<string, ImageBitmap>>(new Map());
  const reqCounter  = useRef(0);
  const docKeyRef   = useRef('');
  const pdfDataRef  = useRef<ArrayBuffer | null>(null);
  const activeCount = useRef(0); // concurrent renders in flight
  const MAX_CONCURRENT = 2; // pdfjs worker handles concurrency internally; limit IPC

  // Pending items not yet sent to worker (queue)
  const queueRef = useRef<PendingRequest[]>([]);

  function cacheKey(page: number, scale: number) {
    return `${page}:${scale.toFixed(3)}`;
  }

  function evictCache() {
    while (bitmapCache.current.size > CACHE_MAX) {
      const firstKey = bitmapCache.current.keys().next().value!;
      bitmapCache.current.get(firstKey)?.close();
      bitmapCache.current.delete(firstKey);
    }
  }

  // ── Worker lifecycle ───────────────────────────────────────────────────────

  const startWorker = useCallback(() => {
    if (workerRef.current) { workerRef.current.terminate(); }

    const worker = new Worker(
      new URL('../workers/pageRenderWorker.ts', import.meta.url),
      { type: 'module' }
    );

    worker.onmessage = (e: MessageEvent) => {
      const msg = e.data;

      if (msg.type === 'bitmap') {
        const req = pendingRef.current.get(msg.reqId);
        if (req) {
          pendingRef.current.delete(msg.reqId);
          activeCount.current = Math.max(0, activeCount.current - 1);
          const ck = cacheKey(msg.page, msg.scale);
          // Cache the bitmap before resolving so getCached() works immediately
          bitmapCache.current.get(ck)?.close();
          bitmapCache.current.set(ck, msg.bitmap);
          evictCache();
          req.resolve(msg.bitmap);
          drainQueue();
        } else {
          // Nobody waiting — still cache it (prefetch result)
          const ck = cacheKey(msg.page, msg.scale);
          bitmapCache.current.get(ck)?.close();
          bitmapCache.current.set(ck, msg.bitmap);
          evictCache();
          activeCount.current = Math.max(0, activeCount.current - 1);
          drainQueue();
        }
      }

      if (msg.type === 'error') {
        const req = pendingRef.current.get(msg.reqId);
        if (req) {
          pendingRef.current.delete(msg.reqId);
          activeCount.current = Math.max(0, activeCount.current - 1);
          req.reject(new Error(msg.message));
          drainQueue();
        }
      }

      if (msg.type === 'loaded') {
        // Document loaded in worker — drain queued renders
        drainQueue();
      }
    };

    worker.onerror = (err) => {
      console.error('[pageRenderWorker] worker error:', err);
    };

    workerRef.current = worker;
  }, []);

  // ── Queue management ───────────────────────────────────────────────────────

  function drainQueue() {
    if (!workerRef.current) return;
    // Sort: lower priority number = render first (0 = current page)
    queueRef.current.sort((a, b) => a.priority - b.priority);
    while (activeCount.current < MAX_CONCURRENT && queueRef.current.length > 0) {
      const req = queueRef.current.shift()!;
      // Skip if already cancelled (promise resolved via cache or navigation)
      if (!pendingRef.current.has(req.reqId) && req.priority > 0) continue;
      if (!pendingRef.current.has(req.reqId)) {
        // Was resolved from cache — skip
        continue;
      }
      activeCount.current++;
      workerRef.current.postMessage({
        type:    'render',
        reqId:   req.reqId,
        docKey:  docKeyRef.current,
        page:    req.page,
        scale:   req.scale,
        // Only send pdfData on first message — worker caches it
        pdfData: pdfDataRef.current ?? undefined,
      }, pdfDataRef.current ? [pdfDataRef.current] : []);
      // After transfer, pdfDataRef is detached — clear it so we don't re-transfer
      pdfDataRef.current = null;
    }
  }

  // ── Public API ─────────────────────────────────────────────────────────────

  const loadDoc = useCallback((docKey: string, pdfData: ArrayBuffer) => {
    if (!workerRef.current) startWorker();
    docKeyRef.current = docKey;
    // Keep a copy for the worker (transferred on first render message)
    pdfDataRef.current = pdfData.slice(0);
    // Pre-send a 'load' message so the worker can start parsing immediately
    // before the first render request arrives (hides parse latency)
    const transferCopy = pdfDataRef.current.slice(0);
    workerRef.current!.postMessage(
      { type: 'load', docKey, pdfData: transferCopy },
      [transferCopy]
    );
    // pdfDataRef still holds a copy for the first render message's fallback
  }, [startWorker]);

  const requestRender = useCallback((
    page: number, scale: number, priority = 0
  ): Promise<ImageBitmap> => {
    if (!workerRef.current) startWorker();

    // Return cached bitmap immediately if available
    const ck = cacheKey(page, scale);
    const cached = bitmapCache.current.get(ck);
    if (cached) return Promise.resolve(cached);

    // Check if already in flight
    for (const [, req] of pendingRef.current) {
      if (req.page === page && Math.abs(req.scale - scale) < 0.001) {
        // Upgrade priority if needed
        if (priority < req.priority) req.priority = priority;
        return new Promise((resolve, reject) => {
          const original = req.resolve;
          req.resolve = (bm) => { original(bm); resolve(bm); };
          const origRej = req.reject;
          req.reject = (e) => { origRej(e); reject(e); };
        });
      }
    }

    return new Promise((resolve, reject) => {
      const reqId = `r${++reqCounter.current}`;
      const req: PendingRequest = { reqId, page, scale, priority, resolve, reject };
      pendingRef.current.set(reqId, req);
      queueRef.current.push(req);
      drainQueue();
    });
  }, [startWorker]);

  const prefetch = useCallback((pages: number[], scale: number) => {
    pages.forEach((page, idx) => {
      const ck = cacheKey(page, scale);
      if (bitmapCache.current.has(ck)) return;
      // Fire-and-forget — lower priority than current page renders
      requestRender(page, scale, 10 + idx).catch(() => {});
    });
  }, [requestRender]);

  const cancelAll = useCallback(() => {
    queueRef.current.forEach(req => {
      workerRef.current?.postMessage({ type: 'cancel', reqId: req.reqId });
      req.reject(new Error('cancelled'));
    });
    queueRef.current = [];
    pendingRef.current.clear();
    activeCount.current = 0;
  }, []);

  const getCached = useCallback((page: number, scale: number) => {
    return bitmapCache.current.get(cacheKey(page, scale));
  }, []);

  const clearCache = useCallback(() => {
    bitmapCache.current.forEach(bm => bm.close());
    bitmapCache.current.clear();
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    startWorker();
    return () => {
      workerRef.current?.terminate();
      workerRef.current = null;
      bitmapCache.current.forEach(bm => bm.close());
      bitmapCache.current.clear();
    };
  }, [startWorker]);

  return { loadDoc, requestRender, prefetch, cancelAll, getCached, clearCache };
}
