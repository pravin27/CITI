// pageRenderWorker — full-page PDF rendering entirely off the main thread.
//
// WHY: pdfjs rendering on the main thread blocks UI for 3-10s on heavy PDFs
// (large-format pages, embedded JPEG/JPEG2000 images, complex font programs).
// This worker runs a complete pdfjs instance with OffscreenCanvas, keeping
// the main thread free for UI interactions during the entire render.
//
// PROTOCOL:
//   Main → Worker:
//     { type:'load',   docKey, pdfData: ArrayBuffer }   — load/replace document
//     { type:'render', docKey, page, scale, reqId }      — render one page
//     { type:'cancel', reqId }                           — cancel pending render
//     { type:'clear' }                                   — destroy doc + free memory
//
//   Worker → Main:
//     { type:'loaded',  docKey, numPages }               — document ready
//     { type:'bitmap',  reqId, page, scale, bitmap }     — rendered ImageBitmap (transferable)
//     { type:'error',   reqId, page, message }           — render failed

import * as pdfjsLib from 'pdfjs-dist';

// Disable pdfjs sub-worker inside this worker — we ARE the worker
(pdfjsLib.GlobalWorkerOptions as any).workerSrc = '';

let cachedDoc: any = null;
let cachedKey = '';
let loadPromise: Promise<any> | null = null;

// Cancelled request IDs — checked before postMessage to avoid wasted transfer
const cancelled = new Set<string>();

async function ensureDoc(docKey: string, pdfData?: ArrayBuffer): Promise<any> {
  if (cachedKey === docKey && cachedDoc) return cachedDoc;
  if (loadPromise) { try { await loadPromise; } catch (_) {} }
  if (cachedKey === docKey && cachedDoc) return cachedDoc;

  try { cachedDoc?.destroy?.(); } catch (_) {}
  cachedDoc = null;
  cachedKey = docKey;

  if (!pdfData) throw new Error('pdfData required for new docKey');

  loadPromise = pdfjsLib.getDocument({
    data: pdfData,
    // Same options as main thread — in-memory, no network, fast font JIT
    isEvalSupported:  true,
    useSystemFonts:   false,
    disableAutoFetch: true,
    disableStream:    true,
    disableRange:     true,
    stopAtErrors:     false,
    enableXfa:        false,
    verbosity:        0,
  }).promise;

  cachedDoc = await loadPromise;
  loadPromise = null;
  return cachedDoc;
}

self.onmessage = async (e: MessageEvent) => {
  const msg = e.data;

  if (msg.type === 'clear') {
    try { cachedDoc?.destroy?.(); } catch (_) {}
    cachedDoc = null; cachedKey = ''; loadPromise = null;
    cancelled.clear();
    return;
  }

  if (msg.type === 'cancel') {
    cancelled.add(msg.reqId);
    return;
  }

  if (msg.type === 'load') {
    try {
      const doc = await ensureDoc(msg.docKey, msg.pdfData);
      (self as any).postMessage({ type: 'loaded', docKey: msg.docKey, numPages: doc.numPages });
    } catch (err) {
      (self as any).postMessage({ type: 'error', reqId: msg.reqId, page: 0, message: String(err) });
    }
    return;
  }

  if (msg.type === 'render') {
    const { reqId, docKey, page, scale } = msg;
    try {
      const doc = await ensureDoc(docKey, msg.pdfData);
      if (cancelled.has(reqId)) { cancelled.delete(reqId); return; }

      const pdfPage = await doc.getPage(page);
      if (cancelled.has(reqId)) {
        pdfPage.cleanup();
        cancelled.delete(reqId);
        return;
      }

      const viewport = pdfPage.getViewport({ scale });
      const w = Math.ceil(viewport.width);
      const h = Math.ceil(viewport.height);

      const canvas = new OffscreenCanvas(w, h);
      const ctx = canvas.getContext('2d') as OffscreenCanvasRenderingContext2D;
      if (!ctx) throw new Error('OffscreenCanvas 2d context unavailable');

      await pdfPage.render({
        canvasContext: ctx,
        viewport,
        intent: 'display',
      }).promise;

      pdfPage.cleanup();

      if (cancelled.has(reqId)) { cancelled.delete(reqId); return; }

      // Transfer bitmap to main thread — zero-copy, no serialisation overhead
      const bitmap = canvas.transferToImageBitmap();
      (self as any).postMessage({ type: 'bitmap', reqId, page, scale, bitmap }, [bitmap]);

    } catch (err) {
      if (!cancelled.has(reqId)) {
        (self as any).postMessage({ type: 'error', reqId, page, message: String(err) });
      }
      cancelled.delete(reqId);
    }
  }
};
