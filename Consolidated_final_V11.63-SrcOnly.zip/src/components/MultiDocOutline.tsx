// MultiDocOutline — Option B tree UI
//
// Performance guarantees:
//   · DocRow, CategoryRow, PillGrid are all React.memo — skip re-render when props unchanged.
//   · NO inline arrow functions passed as props to memo'd components (they defeat memo).
//     All callbacks are useCallback-stable or come from stable refs.
//   · catById built with useMemo — only rebuilds when categories array changes.
//   · sortedPages built with useMemo inside CategoryRow — only rebuilds when pc.pages changes.
//   · buildPageCatMap() runs only for the active (selected) document.
//   · Category children (pills) are not mounted until that category row is expanded.
//   · Doc children are not mounted until that doc row is expanded.
//   · PillGrid renders max 20 pills; "+N more" expands inline on click.

import { useState, useCallback, useEffect, useRef, useMemo, memo } from 'react';
import type { MultiDocState, DocPageCategory, ResolvedCategory, DocSetItem } from '../types/multiDoc';
import { PALETTE_MAP } from '../adapters/types';
import type { PaletteColor } from '../adapters/types';
import { buildPageCatMap } from '../types/multiDoc';

function isSinglePage(mode: string): boolean { return mode === 'single' || mode === 'MultiDoc:SinglePage'; }
function isMultiPage(mode: string): boolean  { return mode === 'multi'  || mode === 'MultiDoc:MultiPage';  }


// ─────────────────────────────────────────────────────────────────────────────
// ── Color resolver ────────────────────────────────────────────────────────────
// Resolves a category color to concrete CSS values.
// Palette key ('blue','teal',...) → opacity bg from PALETTE_MAP, dark text, saturated accent.
// Raw hex/CSS from parent → used full-strength.
function resolveCatColors(color: string): {
  bg: string;        // header/badge background
  text: string;      // text on bg
  dot: string;       // dot/bullet full color
  chipBg: string;    // page count chip background
  chipText: string;  // page count chip text — always dark & readable
  activePill: string;  // active page pill bg
  activePillText: string;
} {
  if (color in PALETTE_MAP) {
    const p = PALETTE_MAP[color as PaletteColor];
    return {
      bg:             p.bg,       // rgba 30% opacity
      text:           p.text,     // '#111111' dark
      dot:            p.divText,  // full saturated hex
      chipBg:         p.divText,  // solid saturated for chip bg → always visible
      chipText:       '#ffffff',  // white on saturated
      activePill:     p.divText,  // full saturated for active page pill
      activePillText: '#ffffff',
    };
  }
  // Raw color from parent — full strength
  return {
    bg:             color,
    text:           '#ffffff',
    dot:            color,
    chipBg:         'rgba(255,255,255,0.22)',
    chipText:       '#ffffff',
    activePill:     color,
    activePillText: '#ffffff',
  };
}

// PillGrid — memo'd, lazy expand
// ─────────────────────────────────────────────────────────────────────────────
interface PillGridProps {
  pages: number[];      // pre-sorted by parent — no sort here
  activePage: number;
  isSel: boolean;
  catColor: string;
  onSelect: (pg: number) => void;
}

const PillGrid = memo(function PillGrid({ pages, activePage, isSel, catColor, onSelect }: PillGridProps) {
  const [showAll, setShowAll] = useState(false);
  const MAX     = 20;
  const visible = showAll ? pages : pages.slice(0, MAX);
  const hidden  = pages.length - MAX;
  const cc = resolveCatColors(catColor);

  return (
    <div style={{
      display: 'flex', flexWrap: 'wrap', gap: 3,
      padding: '5px 10px 7px 30px',
      borderBottom: '0.5px solid #e8edf2',
      background: '#fafbfc',
    }}>
      {visible.map(pg => {
        const isActive = isSel && pg === activePage;
        return (
          <span
            key={pg}
            onClick={e => { e.stopPropagation(); onSelect(pg); }}
            style={{
              fontSize: 10, borderRadius: 4, padding: '2px 6px',
              cursor: 'pointer', userSelect: 'none',
              background: isActive ? cc.activePill : '#dde3ea',
              color:      isActive ? cc.activePillText : '#2a3a4a',
              fontWeight: isActive ? 500 : 400,
              border: `1px solid ${isActive ? cc.activePill : '#c0c8d4'}`,
              transition: 'background 0.1s',
            }}
          >{pg}</span>
        );
      })}
      {!showAll && hidden > 0 && (
        <span
          onClick={e => { e.stopPropagation(); setShowAll(true); }}
          style={{
            fontSize: 10, borderRadius: 4, padding: '2px 6px',
            cursor: 'pointer', userSelect: 'none',
            background: '#c8d6e8', color: '#1a3050', border: '1px solid #a8bcce',
          }}
        >+{hidden} more</span>
      )}
    </div>
  );
});

// ─────────────────────────────────────────────────────────────────────────────
// CategoryRow — memo'd
// onToggle and onSelect must be stable (useCallback) at call site.
// ─────────────────────────────────────────────────────────────────────────────
interface CategoryRowProps {
  pc: DocPageCategory;
  cat: ResolvedCategory;
  catKey: string;
  isCatExp: boolean;
  isCatActive: boolean;
  isSel: boolean;
  activePage: number;
  onToggle: (key: string) => void;
  onSelect: (pg: number) => void;
}

const CategoryRow = memo(function CategoryRow({
  pc, cat, catKey, isCatExp, isCatActive, isSel,
  activePage, onToggle, onSelect,
}: CategoryRowProps) {
  // Memoised sort — only re-runs when pc.pages reference changes
  const sortedPages = useMemo(() => [...pc.pages].sort((a, b) => a - b), [pc.pages]);
  const firstPage   = sortedPages[0];

  return (
    <div>
      <div
        onClick={() => { onToggle(catKey); onSelect(firstPage); }}
        style={{
          display: 'flex', alignItems: 'center', gap: 6,
          padding: '5px 10px 5px 22px',
          cursor: 'pointer', userSelect: 'none',
          borderBottom: '0.5px solid #f0f2f4',
          background: isCatActive ? '#e8f2ff' : 'transparent',
          transition: 'background 0.1s',
        }}
      >
        <span style={{
          fontSize: 8, color: '#9aacba', display: 'inline-block', flexShrink: 0, width: 8,
          transform: isCatExp ? 'rotate(90deg)' : 'rotate(0deg)',
          transition: 'transform 0.15s',
        }}>›</span>

        {/* Dot always uses full saturated colour regardless of opacity */}
        <span style={{ width: 7, height: 7, borderRadius: '50%', background: resolveCatColors(cat.color).dot, flexShrink: 0 }} />

        <span style={{ fontSize: 10, fontWeight: 500, color: '#1a2a3a', flex: 1 }}>
          {cat.label}
        </span>

        {/* Page count chip — solid saturated bg so it's always visible */}
        <span style={{
          fontSize: 9,
          background: resolveCatColors(cat.color).chipBg,
          color: resolveCatColors(cat.color).chipText,
          borderRadius: 8, padding: '1px 5px', flexShrink: 0, fontWeight: 500,
        }}>{pc.pages.length} pg</span>
      </div>

      {isCatExp && (
        <PillGrid
          pages={sortedPages}
          activePage={activePage}
          isSel={isSel}
          catColor={cat.color}
          onSelect={onSelect}
        />
      )}
    </div>
  );
});

// ─────────────────────────────────────────────────────────────────────────────
// DocRow — memo'd
// Owns its own catExpanded state so sibling DocRows never re-render on cat toggle.
// All callbacks passed down are stable useCallback refs.
// ─────────────────────────────────────────────────────────────────────────────
interface DocRowProps {
  doc: DocSetItem;
  isSel: boolean;
  isOpen: boolean;
  activePage: number;
  activeCatId: string | undefined;
  catById: Record<string, ResolvedCategory>;
  onToggle: (id: string) => void;
  onSelectDoc: (id: string, page: number) => void;
  onSelectPage: (page: number) => void;
  activeRef: React.RefObject<HTMLDivElement | null>;
}

const DocRow = memo(function DocRow({
  doc, isSel, isOpen, activePage, activeCatId,
  catById, onToggle, onSelectDoc, onSelectPage, activeRef,
}: DocRowProps) {
  // Each DocRow owns its own category-expand state.
  // This means toggling a category in doc A never causes doc B to re-render.
  const [catExpanded, setCatExpanded] = useState<Set<string>>(new Set());

  const toggleCat = useCallback((key: string) => {
    setCatExpanded(s => { const n = new Set(s); n.has(key) ? n.delete(key) : n.add(key); return n; });
  }, []);

  // Stable per-doc select callbacks — created once, never recreated
  const handleDocClick = useCallback(() => {
    onToggle(doc.id);
    if (!isSel) {
      const firstPage = doc.pageCategories?.[0]?.pages?.[0] ?? 1;
      onSelectDoc(doc.id, firstPage);
    }
  }, [doc.id, doc.pageCategories, isSel, onToggle, onSelectDoc]);

  // Stable factory: returns a stable onSelect for each category.
  // Built with useMemo so it only rebuilds when doc.id / isSel / deps change.
  const catSelectHandlers = useMemo(() => {
    const map = new Map<string, (pg: number) => void>();
    // Key by category+index so duplicate category entries (e.g. two Invoice groups)
    // each get their own independent handler
    (doc.pageCategories ?? []).forEach((pc, idx) => {
      map.set(`${pc.category}:${idx}`, (pg: number) => {
        if (!isSel) onSelectDoc(doc.id, pg);
        else onSelectPage(pg);
      });
    });
    return map;
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [doc.id, doc.pageCategories, isSel, onSelectDoc, onSelectPage]);

  const totalPages = doc.totalPages ?? 1;

  return (
    <div style={{ borderTop: '1.5px solid #c4c9d0' }}>
      {/* File header row */}
      <div
        ref={isSel ? (activeRef as React.RefObject<HTMLDivElement>) : undefined}
        onClick={handleDocClick}
        style={{
          display: 'flex', alignItems: 'center', gap: 5,
          padding: '9px 10px',
          background: isSel ? '#e0ecf8' : '#dde3ea',
          cursor: 'pointer', userSelect: 'none',
          transition: 'background 0.1s',
        }}
      >
        <span style={{
          fontSize: 9, color: '#6a7a8a', display: 'inline-block', flexShrink: 0,
          transform: isOpen ? 'rotate(90deg)' : 'rotate(0deg)',
          transition: 'transform 0.15s',
        }}>›</span>

        {/* Mini category colour dots */}
        <span style={{ display: 'flex', gap: 2, flexShrink: 0 }}>
          {doc.pageCategories?.map((pc, idx) => (
            <span key={`${pc.category}__${idx}`} style={{
              width: 6, height: 6, borderRadius: '50%',
              background: resolveCatColors(catById[pc.category]?.color ?? '#888').dot,
            }} />
          ))}
        </span>

        <span style={{
          fontSize: 13, fontWeight: 500, color: '#1a2a3a',
          flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
        }}>{doc.name}</span>

        <span style={{ fontSize: 9, color: '#8a9aaa', flexShrink: 0 }}>{totalPages}p</span>
      </div>

      {/* Category sub-rows — only mounted when doc is expanded */}
      {isOpen && doc.pageCategories && (
        <div style={{ background: '#fff' }}>
          {doc.pageCategories.map((pc, _pcIdx) => {
            const cat = catById[pc.category];
            if (!cat) return null;
            const catKey      = `${doc.id}:${pc.category}:${_pcIdx}`;
            const isCatExp    = catExpanded.has(catKey);
            const isCatActive = isSel && activeCatId === pc.category;
            const onSelect    = catSelectHandlers.get(`${pc.category}:${_pcIdx}`) ?? (() => {});

            return (
              <CategoryRow
                key={`${pc.category}__${_pcIdx}`}
                pc={pc}
                cat={cat}
                catKey={catKey}
                isCatExp={isCatExp}
                isCatActive={isCatActive}
                isSel={isSel}
                activePage={activePage}
                onToggle={toggleCat}     // stable (useCallback in DocRow)
                onSelect={onSelect}       // stable (useMemo map in DocRow)
              />
            );
          })}
        </div>
      )}
    </div>
  );
});

// ─────────────────────────────────────────────────────────────────────────────
// MultiDocOutline — root
// ─────────────────────────────────────────────────────────────────────────────
export interface MultiDocOutlineProps {
  state: MultiDocState;
  onSelectDoc: (docId: string, page?: number) => void;
  onSelectPage: (page: number) => void;
}

export function MultiDocOutline({ state, onSelectDoc, onSelectPage }: MultiDocOutlineProps) {
  const { documents, categories, activeDocId, activePage } = state;

  const [expanded, setExpanded] = useState<Set<string>>(
    new Set(activeDocId ? [activeDocId] : [])
  );
  const activeRef = useRef<HTMLDivElement | null>(null);

  // Auto-expand active doc when it changes externally (e.g. prev/next nav)
  useEffect(() => {
    if (activeDocId) {
      setExpanded(s => { const n = new Set(s); n.add(activeDocId); return n; });
    }
  }, [activeDocId]);

  // Scroll active doc header into view
  useEffect(() => {
    activeRef.current?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  }, [activeDocId]);

  // Stable callbacks passed to DocRow — never recreated
  const toggleDoc = useCallback((id: string) => {
    setExpanded(s => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });
  }, []);

  const handleSelectDoc = useCallback((id: string, pg: number) => {
    onSelectDoc(id, pg);
  }, [onSelectDoc]);

  // catById: memoised — only rebuilds when categories array reference changes
  const catById = useMemo(
    () => Object.fromEntries(categories.map(c => [c.id, c])),
    [categories]
  );

  return (
    <div style={{ flex: 1, overflowY: 'auto', background: '#f2f4f6' }}>
      {documents.map(doc => {
        const isOpen = expanded.has(doc.id);
        const isSel  = doc.id === activeDocId;

        // buildPageCatMap is O(pages) — only run for the active document
        const pageCatMap  = isSel && doc.pageCategories
          ? buildPageCatMap(doc.pageCategories)
          : null;
        const activeCatId = pageCatMap?.get(activePage);

        return (
          <DocRow
            key={doc.id}
            doc={doc}
            isSel={isSel}
            isOpen={isOpen}
            activePage={activePage}
            activeCatId={activeCatId}
            catById={catById}
            onToggle={toggleDoc}
            onSelectDoc={handleSelectDoc}
            onSelectPage={onSelectPage}
            activeRef={activeRef as React.RefObject<HTMLDivElement | null>}
          />
        );
      })}
    </div>
  );
}
