// ─────────────────────────────────────────────────────────────────────────────
// SpreadsheetViewer
//
// PERFORMANCE:
//   Only the active sheet is mounted. Switching tabs unmounts the old sheet
//   and mounts the new one. Non-visible sheets are never in the DOM.
//   This eliminates the main lag source — large sheets were all rendered
//   simultaneously even when hidden.
//
// MULTI-CELL SELECTION (Click2Pick):
//   • Single click  → capture that cell
//   • Click + drag  → rubber-band selection across multiple cells
//     Shows a blue overlay while dragging. On mouseup, captures the
//     bounding box of all selected cells with text joined by " | "
//   • Double-click  → same as single click (immediate capture)
//   Selection state is tracked in refs (no React state during drag
//   = zero re-renders while the user moves the mouse).
// ─────────────────────────────────────────────────────────────────────────────

import React, { useEffect, useRef, useCallback, useMemo, useState } from 'react';
import { useAppStore } from '../store/appStore';
import type { SpreadsheetAdapter } from '../adapters/SpreadsheetAdapter';
import { colorToRgba } from '../utils/color';

const COL_WIDTH_DEFAULT  = 96;   // px — fallback when no col width info
const ROW_HEIGHT_DEFAULT = 22;   // px — fallback when no row height info
const ROW_NUM_W          = 44;   // px — row number gutter (always fixed)
const HEADER_H           = 26;   // px — column letter header row

interface SpreadsheetViewerProps { adapter: SpreadsheetAdapter; }

function colLetter(i: number): string {
  let r = '';
  while (i >= 0) { r = String.fromCharCode(65 + (i % 26)) + r; i = Math.floor(i / 26) - 1; }
  return r;
}
function cellAddr(row: number, col: number) { return `${colLetter(col)}${row + 1}`; }

// ── Main component ─────────────────────────────────────────────────────────────
export function SpreadsheetViewer({ adapter }: SpreadsheetViewerProps) {
  const currentPage    = useAppStore(s => s.currentPage);
  const setCurrentPage = useAppStore(s => s.setCurrentPage);
  const sheets = adapter.getAllSheets();

  // Clamp currentPage to valid range
  const activePage = Math.max(1, Math.min(currentPage, sheets.length));

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-[#f5f5f5]">
      {sheets.length > 1 && (
        <div className="flex items-end gap-0 px-2 bg-[#e8e8e8] border-b border-[#c8c8c8] overflow-x-auto shrink-0" style={{ paddingTop: 6 }}>
          {sheets.map((sheet, i) => (
            <button key={i} onClick={() => setCurrentPage(i + 1)}
              className="whitespace-nowrap text-xs font-medium transition-colors focus:outline-none"
              style={{
                padding: '5px 14px 4px',
                marginRight: 1,
                borderRadius: '4px 4px 0 0',
                border: '1px solid',
                ...(activePage === i + 1 ? {
                  background: '#ffffff',
                  color: '#0f6e56',
                  borderColor: '#c8c8c8',
                  borderBottom: '1px solid #ffffff',
                  fontWeight: 600,
                  zIndex: 1,
                  position: 'relative',
                } : {
                  background: '#d8d8d8',
                  color: '#666666',
                  borderColor: '#c0c0c0',
                  borderBottom: '1px solid #c8c8c8',
                }),
              }}>
              {sheet.name || `Sheet ${i + 1}`}
            </button>
          ))}
        </div>
      )}

      <div className="flex-1 overflow-hidden relative">
        {/* KEY FIX: only mount the active sheet — not all sheets simultaneously */}
        {sheets[activePage - 1] && (
          <SheetTable
            key={activePage}          // remount on sheet change (fresh DOM)
            pageNum={activePage}
            sheet={sheets[activePage - 1]}
            adapter={adapter}
          />
        )}
      </div>
    </div>
  );
}


// ── Style helpers ──────────────────────────────────────────────────────────────

function isLightColor(hex: string): boolean {
  if (hex.length === 8) hex = hex.slice(2); // strip alpha
  const r = parseInt(hex.slice(0, 2), 16);
  const g = parseInt(hex.slice(2, 4), 16);
  const b = parseInt(hex.slice(4, 6), 16);
  return (r * 299 + g * 587 + b * 114) / 1000 > 140;
}

// Decode border string "color|style" or just "style" into CSS border value
function decodeBorder(b: string | undefined): string | undefined {
  if (!b) return undefined;
  const sep = b.indexOf('|');
  if (sep === -1) return `1px ${b} #aaa`;
  const color = '#' + b.slice(0, sep);
  const style = b.slice(sep + 1);
  const w = style === 'thick' ? '2px' : style === 'medium' ? '1.5px' : '1px';
  const cs = style === 'dashed' ? 'dashed' : style === 'dotted' ? 'dotted' : style === 'double' ? 'double' : 'solid';
  return `${w} ${cs} ${color}`;
}

// Build full cell CSS style from CellStyle metadata
function buildCellStyle(
  cs: import('../adapters/SpreadsheetAdapter').CellStyle | null | undefined,
  colW: number,
  rowH: number,
  bgOverride?: string,
): React.CSSProperties {
  const base: React.CSSProperties = { width: colW, height: rowH, maxWidth: colW * 10 };
  if (!cs) return base;

  if (cs.fillRgb)   { base.background = '#' + cs.fillRgb; base.color = isLightColor(cs.fillRgb) ? '#111' : '#eee'; }
  if (cs.fontColor) base.color = '#' + cs.fontColor;
  if (cs.bold)      base.fontWeight = 'bold';
  if (cs.italic)    base.fontStyle  = 'italic';
  if (cs.fontSize)  base.fontSize   = cs.fontSize + 'pt';
  if (cs.fontName)  base.fontFamily = cs.fontName;
  if (cs.underline || cs.strike) {
    base.textDecoration = [cs.underline && 'underline', cs.strike && 'line-through'].filter(Boolean).join(' ');
  }
  if (cs.hAlign)  base.textAlign    = cs.hAlign as any;
  if (cs.vAlign)  base.verticalAlign = cs.vAlign === 'middle' ? 'middle' : cs.vAlign === 'top' ? 'top' : 'bottom';
  if (cs.wrap)    { base.whiteSpace = 'pre-wrap'; base.wordBreak = 'break-word'; }

  const bl = decodeBorder(cs.borderLeft);
  const br = decodeBorder(cs.borderRight);
  const bt = decodeBorder(cs.borderTop);
  const bb = decodeBorder(cs.borderBottom);
  if (bl) base.borderLeft   = bl;
  if (br) base.borderRight  = br;
  if (bt) base.borderTop    = bt;
  if (bb) base.borderBottom = bb;

  if (bgOverride) { base.background = bgOverride; base.color = '#111'; }
  return base;
}

// ── Sheet table ────────────────────────────────────────────────────────────────
interface SheetTableProps {
  pageNum: number;
  sheet: import('../adapters/SpreadsheetAdapter').SheetData;
  adapter: SpreadsheetAdapter;
}

function SheetTable({ pageNum, sheet, adapter }: SheetTableProps) {
  const boxMode          = useAppStore(s => s.boxMode);
  const zoom             = useAppStore(s => s.zoom);
  const setPendingCapture = useAppStore(s => s.setPendingCapture);
  const setPreviewRect   = useAppStore(s => s.setPreviewRect);
  const search           = useAppStore(s => s.search);

  const scrollRef  = useRef<HTMLDivElement>(null);
  const tableRef   = useRef<HTMLTableElement>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);

  const { rows, colCount, rowCount, styles, colInfos, rowInfos, merges, images } = sheet;

  // Lazy row accessor — for large xlsx files that store raw buffer instead of rows[][]
  const _lazyBuf     = (sheet as any)._lazyBuf     as Uint8Array  | undefined;
  const _lazyOffsets = (sheet as any)._lazyOffsets as Uint32Array | undefined;
  const _lazyDec     = (sheet as any)._lazyDec     as TextDecoder | undefined;
  const getRow = (ri: number): string[] => {
    if (_lazyBuf && _lazyOffsets && _lazyDec) {
      const start = _lazyOffsets[ri];
      const end   = _lazyOffsets[ri + 1] ?? _lazyBuf.byteLength;
      const line  = _lazyDec.decode(_lazyBuf.subarray(start, end > 0 ? end - 1 : end));
      return line ? line.split('\t') : [];
    }
    return rows[ri] ?? [];
  };

  // ── Simple virtual scroll ─────────────────────────────────────────────────
  // Only render VISIBLE_COUNT rows at a time. Spacer divs maintain scroll height.
  const VISIBLE_COUNT = 50;
  const [startRow, setStartRow] = useState(0);

  // ── Column / row resize state ──────────────────────────────────────────────
  // colWidthsOv / rowHeightsOv: user overrides layered on top of xlsx metadata defaults.
  // Stored as Maps so we only allocate entries for actually-resized cols/rows.
  const [colWidthsOv,  setColWidthsOv]  = useState<Map<number, number>>(() => new Map());
  const [rowHeightsOv, setRowHeightsOv] = useState<Map<number, number>>(() => new Map());
  const resizingCol = useRef<{ ci: number; startX: number; startW: number } | null>(null);
  const resizingRow = useRef<{ ri: number; startY: number; startH: number } | null>(null);



  // ── Derived sizing from sheet metadata + user overrides ───────────────────────
  // colWidthsOv / rowHeightsOv layer user drag-resizes on top of xlsx metadata.
  const colWidths = useMemo(() => Array.from({ length: colCount }, (_, ci) =>
    colWidthsOv.get(ci) ?? colInfos?.[ci]?.wpx ?? COL_WIDTH_DEFAULT
  ), [colCount, colInfos, colWidthsOv]);
  const rowHeights = useMemo(() => Array.from({ length: rowCount }, (_, ri) =>
    rowHeightsOv.get(ri) ?? (rowInfos?.[ri]?.hidden ? 0 : rowInfos?.[ri]?.hpx ?? ROW_HEIGHT_DEFAULT)
  ), [rowCount, rowInfos, rowHeightsOv]);
  const naturalW = ROW_NUM_W + colWidths.reduce((s, w) => s + w, 0);
  const naturalH = HEADER_H  + rowHeights.reduce((s, h) => s + h, 0);

  // ── Merge lookup: for each cell, is it spanned by another? ───────────────────
  // mergeMap[r][c] = {colSpan, rowSpan} if this cell is the TOP-LEFT of a merge
  //                = 'hidden' if this cell is covered by a merge (skip rendering)
  const mergeMap = useMemo(() => {
    const map = new Map<string, { colSpan: number; rowSpan: number } | 'hidden'>();
    for (const m of (merges ?? [])) {
      const rs = m.e.r - m.s.r + 1;
      const cs = m.e.c - m.s.c + 1;
      // Top-left cell gets span info
      map.set(`\${m.s.r},\${m.s.c}`, { colSpan: cs, rowSpan: rs });
      // All other cells in the merge are hidden
      for (let r = m.s.r; r <= m.e.r; r++) {
        for (let c_ = m.s.c; c_ <= m.e.c; c_++) {
          if (r === m.s.r && c_ === m.s.c) continue; // skip top-left
          map.set(`\${r},\${c_}`, 'hidden');
        }
      }
    }
    return map;
  }, [merges]);

  // ── Selection state (click-only, no drag) ─────────────────────────────────────
  // Spreadsheet capture uses click-to-capture only. Drag is reserved for column/row
  // resizing. This eliminates conflicts between box-mode drag and resize handles.
  const selBoxRef  = useRef<HTMLDivElement | null>(null); // unused, kept for compat

  // ── Column resize handlers ────────────────────────────────────────────────
  const onColResizeMouseDown = useCallback((e: React.MouseEvent, ci: number) => {
    e.preventDefault(); e.stopPropagation();
    resizingCol.current = { ci, startX: e.clientX, startW: colWidths[ci] };
    const onMove = (ev: MouseEvent) => {
      const r = resizingCol.current; if (!r) return;
      const newW = Math.max(20, r.startW + (ev.clientX - r.startX) / zoom);
      setColWidthsOv(prev => { const m = new Map(prev); m.set(r.ci, Math.round(newW)); return m; });
    };
    const onUp = () => {
      resizingCol.current = null;
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  }, [colWidths, zoom]);

  // ── Row resize handlers ───────────────────────────────────────────────────
  const onRowResizeMouseDown = useCallback((e: React.MouseEvent, ri: number) => {
    e.preventDefault(); e.stopPropagation();
    resizingRow.current = { ri, startY: e.clientY, startH: rowHeights[ri] };
    const onMove = (ev: MouseEvent) => {
      const r = resizingRow.current; if (!r) return;
      const newH = Math.max(8, r.startH + (ev.clientY - r.startY) / zoom);
      setRowHeightsOv(prev => { const m = new Map(prev); m.set(r.ri, Math.round(newH)); return m; });
    };
    const onUp = () => {
      resizingRow.current = null;
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  }, [rowHeights, zoom]);

  // Reset overrides when sheet changes
  useEffect(() => {
    setColWidthsOv(new Map());
    setRowHeightsOv(new Map());
  }, [sheet]);

  // Register with adapter + store offscreen thumbnail snapshot
  useEffect(() => {
    adapter.registerPageElement(pageNum, wrapperRef.current);
    adapter.notifyPageRendered(pageNum);
    // Capture offscreen snapshot for thumbnail rendering (works even when sheet unmounts)
    const canvas = wrapperRef.current?.querySelector('canvas');
    if (canvas && typeof (adapter as any).storeSheetSnapshot === 'function') {
      (adapter as any).storeSheetSnapshot(pageNum, canvas);
    }
    return () => adapter.registerPageElement(pageNum, null);
  }, [adapter, pageNum]);

  // ── Coordinate helper ─────────────────────────────────────────────────────────
  const getCellFrac = useCallback((cell: HTMLElement) => {
    const table = tableRef.current;
    if (!table) return null;
    const tR = table.getBoundingClientRect();
    const cR = cell.getBoundingClientRect();
    const nW = tR.width  / zoom;
    const nH = tR.height / zoom;
    const rL = (cR.left - tR.left) / zoom;
    const rT = (cR.top  - tR.top)  / zoom;
    const cW = cR.width  / zoom;
    const cH = cR.height / zoom;
    return { x: rL/nW, y: rT/nH, width: cW/nW, height: cH/nH };
  }, [zoom]);

  // ── Get cell element by row/col ───────────────────────────────────────────────
  const getCellEl = useCallback((row: number, col: number): HTMLTableCellElement | null => {
    return tableRef.current?.querySelector<HTMLTableCellElement>(
      `td[data-row="${row}"][data-col="${col}"]`
    ) ?? null;
  }, []);

  // ── Compute bounding frac of a range ─────────────────────────────────────────
  const getRangeFrac = useCallback((
    r1: number, c1: number, r2: number, c2: number
  ) => {
    const table = tableRef.current;
    if (!table) return null;
    const tR = table.getBoundingClientRect();
    const nW = tR.width  / zoom;
    const nH = tR.height / zoom;

    const minR = Math.min(r1, r2), maxR = Math.max(r1, r2);
    const minC = Math.min(c1, c2), maxC = Math.max(c1, c2);

    // Get top-left and bottom-right corner cells
    const tlEl = getCellEl(minR, minC);
    const brEl = getCellEl(maxR, maxC);
    if (!tlEl || !brEl) return null;

    const tlR = tlEl.getBoundingClientRect();
    const brR = brEl.getBoundingClientRect();

    const left   = (tlR.left   - tR.left) / zoom;
    const top    = (tlR.top    - tR.top)  / zoom;
    const right  = (brR.right  - tR.left) / zoom;
    const bottom = (brR.bottom - tR.top)  / zoom;

    return {
      x:      left / nW,
      y:      top  / nH,
      width:  (right  - left) / nW,
      height: (bottom - top)  / nH,
    };
  }, [zoom, getCellEl]);

  // ── Get all cell values in range ──────────────────────────────────────────────
  const getRangeText = useCallback((
    r1: number, c1: number, r2: number, c2: number
  ): string => {
    const minR = Math.min(r1, r2), maxR = Math.max(r1, r2);
    const minC = Math.min(c1, c2), maxC = Math.max(c1, c2);
    const parts: string[] = [];
    for (let r = minR; r <= maxR; r++) {
      // Use getRow() — works for both lazy (flatBuf) and eager (rows[][]) sheets
      const rowData = getRow(r);
      for (let c = minC; c <= maxC; c++) {
        const v = rowData[c]?.trim();
        if (v) parts.push(v);
      }
    }
    return parts.join(' | ');
  }, [getRow]);

  // ── Fire capture from single cell ────────────────────────────────────────────
  const fireCapture = useCallback((ri: number, ci: number, el: HTMLTableCellElement) => {
    const frac = getCellFrac(el);
    if (!frac) return;
    const text = getRow(ri)[ci]?.trim() ?? '';
    const label = text || cellAddr(ri, ci);
    setPendingCapture({ text: label, page: pageNum, ...frac, sourceFormat: 'flat' });
    setPreviewRect({ page: pageNum, ...frac });
  }, [getCellFrac, getRow, pageNum, setPendingCapture, setPreviewRect]);

  // ── Cell pointer events (click-only capture) ────────────────────────────────
  // Spreadsheets use click-to-capture, NOT drag-to-box.
  // This prevents conflicts with column/row resize handles which also use drag.
  // The resize handles (in header/gutter) call stopPropagation so they never
  // reach the cell's onClick handler.

  const onCellClick = useCallback((
    e: React.MouseEvent<HTMLTableCellElement>, row: number, col: number
  ) => {
    if (!boxMode) return;
    fireCapture(row, col, e.currentTarget);
  }, [boxMode, fireCapture]);

  // ── Search ────────────────────────────────────────────────────────────────────
  const searchHitCells = useMemo(() => {
    const set = new Set<string>();
    if (!search.query.trim()) return set;
    const q = search.matchCase ? search.query : search.query.toLowerCase();
    // Use getRow() — works for both lazy (flatBuf) and eager (rows[][]) sheets.
    // rows[] is always [] for lazy sheets loaded from the worker.
    for (let ri = 0; ri < rowCount; ri++) {
      const row = getRow(ri);
      for (let ci = 0; ci < row.length; ci++) {
        const cell = row[ci];
        if (!cell) continue;
        const t = search.matchCase ? cell : cell.toLowerCase();
        if (search.matchType === 'exact' ? t === q : t.includes(q)) set.add(`${ri},${ci}`);
      }
    }
    return set;
  }, [rowCount, getRow, search.query, search.matchCase, search.matchType]);

  const currentResultKey = useMemo(() => {
    const r = search.results[search.currentIndex];
    if (!r || r.page !== pageNum || !tableRef.current) return null;
    const tR = tableRef.current.getBoundingClientRect();
    const nW = tR.width / zoom;
    const nH = tR.height / zoom;
    const col = Math.round(r.x * nW / COL_WIDTH_DEFAULT) - 1;
    const row = Math.round(r.y * nH / ROW_HEIGHT_DEFAULT) - 1;
    return `${row},${col}`;
  }, [search.results, search.currentIndex, pageNum, zoom]);

  // ── Search: populate store results for this sheet ────────────────────────────
  useEffect(() => {
    if (!search.query.trim()) return;
    const q = search.matchCase ? search.query : search.query.toLowerCase();
    const results: Array<{ page: number; x: number; y: number; width: number; height: number; text: string }> = [];
    // Use row/col index to compute fractional coords directly (no DOM query needed)
    const nW = naturalW;
    const nH = naturalH;
    // Pre-compute cumulative column/row offsets for accurate search rect positions
    const colOffsets = colWidths.reduce<number[]>((acc, w) => {
      acc.push((acc[acc.length - 1] ?? ROW_NUM_W) + w); return acc;
    }, [ROW_NUM_W]);
    const rowOffsets = rowHeights.reduce<number[]>((acc, h) => {
      acc.push((acc[acc.length - 1] ?? HEADER_H) + h); return acc;
    }, [HEADER_H]);

    // Use getRow() — rows[] is empty for lazy/worker-loaded sheets
    for (let ri = 0; ri < rowCount; ri++) {
      const row = getRow(ri);
      for (let ci = 0; ci < row.length; ci++) {
        const cell = row[ci];
        if (!cell) continue;
        const t = search.matchCase ? cell : cell.toLowerCase();
        if (!(search.matchType === 'exact' ? t === q : t.includes(q))) continue;
        const left = colOffsets[ci] ?? (ROW_NUM_W + ci * COL_WIDTH_DEFAULT);
        const top  = rowOffsets[ri] ?? (HEADER_H  + ri * ROW_HEIGHT_DEFAULT);
        results.push({
          page: pageNum,
          x:      left / nW,
          y:      top  / nH,
          width:  (colWidths[ci] ?? COL_WIDTH_DEFAULT)  / nW,
          height: (rowHeights[ri] ?? ROW_HEIGHT_DEFAULT) / nH,
          text: cell,
        });
      }
    }
    if (results.length > 0) {
      useAppStore.setState(s => {
        const merged = [...s.search.results.filter(r => r.page !== pageNum), ...results]
          .sort((a, b) => a.page !== b.page ? a.page - b.page : a.y !== b.y ? a.y - b.y : a.x - b.x);
        return { search: { ...s.search, results: merged, currentIndex: merged.length > 0 ? 0 : -1 } };
      });
    }
  }, [search.query, search.matchCase, search.matchType, rowCount, getRow, colCount, pageNum, colWidths, rowHeights, naturalW, naturalH]);

  // ── Highlight canvas overlay ─────────────────────────────────────────────────
  // Draws capture boxes and preview pulse directly onto a canvas overlay.
  // IMPORTANT: For large sheets (10k+ rows), naturalH can exceed 200,000px.
  // A 4844×220026 canvas = ~1 billion pixels = 4 GB RGBA → instant browser crash.
  // Fix: cap canvas pixel dimensions at CANVAS_MAX. Since highlights use fractional
  // coords (0-1), we simply scale: canvasW = min(naturalW, CANVAS_MAX), and
  // the CSS width/height still stretches the canvas over the full natural area.
  // Fractional × canvasW/H = correct pixel position within the capped canvas.
  const CANVAS_MAX = 8192; // safe GPU texture limit on all browsers
  const hlCanvasRef = useRef<HTMLCanvasElement>(null);
  const hlCanvasW = Math.min(naturalW, CANVAS_MAX);
  const hlCanvasH = Math.min(naturalH, CANVAS_MAX);

  const drawHighlights = useCallback(() => {
    const canvas = hlCanvasRef.current;
    if (!canvas) return;
    const W = canvas.width;
    const H = canvas.height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, W, H);

    const state       = useAppStore.getState();
    const rects       = state.highlightIndex.get(pageNum) ?? [];
    const activeId    = state.activeFieldId;
    const previewRect = state.previewRect;

    const RADIUS = 2;
    const rr = (x: number, y: number, w: number, h: number) => {
      if (w < 1 || h < 1) return;
      const r = Math.min(RADIUS, w/2, h/2);
      ctx.beginPath();
      ctx.moveTo(x+r,y); ctx.lineTo(x+w-r,y); ctx.arcTo(x+w,y,x+w,y+r,r);
      ctx.lineTo(x+w,y+h-r); ctx.arcTo(x+w,y+h,x+w-r,y+h,r);
      ctx.lineTo(x+r,y+h); ctx.arcTo(x,y+h,x,y+h-r,r);
      ctx.lineTo(x,y+r); ctx.arcTo(x,y,x+r,y,r); ctx.closePath();
    };

    // Exact-lowercase value map — no stripPunct so "LEADTOOLS" ≠ "LEADTOOLS®"
    const fwc = new Map<string, string>();
    for (const cap of state.captures) fwc.set(cap.id, cap.value.toLowerCase().trim());
    const activeCapture = activeId ? state.captures.find(c => c.id === activeId) : null;
    const activeTxt     = activeCapture ? (fwc.get(activeId!) ?? '') : '';

    // Draw confirmed capture boxes — mirrors PDFViewer colour rules exactly:
    //   active field        = YELLOW  — the focused/selected capture
    //   duplicate text      = PINK (strong) — same value captured twice
    //   other while active  = PINK (light)  — all non-active captures when any field is focused
    //   no active field     = GREY    — neutral, nothing selected
    //   colored field       = field colour at low opacity
    const hasActive = !!activeId;
    for (const rect of rects) {
      const isActive = rect.id === activeId;
      const isDup    = !isActive && !!activeTxt && fwc.get(rect.id) === activeTxt;
      ctx.save();
      if (isActive) {
        ctx.shadowColor = 'rgba(220,180,0,.5)'; ctx.shadowBlur = 8;
        ctx.fillStyle   = 'rgba(255,230,0,.35)';
        ctx.strokeStyle = 'rgb(200,160,0)';
        ctx.lineWidth   = 2.5;
      } else if (isDup) {
        // Duplicate value — stronger pink to flag it clearly
        ctx.fillStyle   = 'rgba(255,182,193,.50)';
        ctx.strokeStyle = 'rgba(220,80,120,.95)';
        ctx.lineWidth   = 2.5;
      } else if (hasActive) {
        // Another capture while a field is focused — light pink
        ctx.fillStyle   = 'rgba(255,182,193,.22)';
        ctx.strokeStyle = 'rgba(220,80,120,.60)';
        ctx.lineWidth   = 1.5;
      } else if (rect.color) {
        ctx.fillStyle   = colorToRgba(rect.color, .07);
        ctx.strokeStyle = colorToRgba(rect.color, .95);
        ctx.lineWidth   = 2.5;
      } else {
        ctx.fillStyle   = 'rgba(150,150,150,.10)';
        ctx.strokeStyle = 'rgba(80,80,80,.90)';
        ctx.lineWidth   = 2.0;
      }
      rr(rect.x*W, rect.y*H, rect.width*W, rect.height*H);
      ctx.fill(); ctx.stroke(); ctx.restore();
    }

    // Preview pulse (cyan) — shows immediately after cell click, before dialog confirms
    if (previewRect && previewRect.page === pageNum) {
      ctx.save();
      ctx.fillStyle   = 'rgba(6,182,212,.18)';
      ctx.strokeStyle = 'rgba(6,182,212,.9)';
      ctx.lineWidth   = 2;
      ctx.shadowColor = 'rgba(6,182,212,.5)'; ctx.shadowBlur = 6;
      rr(previewRect.x*W, previewRect.y*H, previewRect.width*W, previewRect.height*H);
      ctx.fill(); ctx.stroke(); ctx.restore();
    }
  }, [pageNum]);

  // Re-draw when captures / activeField / previewRect change
  useEffect(() => {
    drawHighlights();
    const unsub = useAppStore.subscribe((n, p) => {
      if (n.highlightIndex !== p.highlightIndex ||
          n.activeFieldId  !== p.activeFieldId  ||
          n.previewRect    !== p.previewRect) {
        drawHighlights();
      }
    });
    return unsub;
  }, [drawHighlights]);



  // Cumulative row offsets for fast binary search
  const rowOffsetsCum = useMemo(() => {
    const offsets = new Float64Array(rowCount + 1);
    offsets[0] = HEADER_H;
    for (let r = 0; r < rowCount; r++) {
      offsets[r + 1] = offsets[r] + (rowInfos?.[r]?.hpx ?? ROW_HEIGHT_DEFAULT);
    }
    return offsets;
  }, [rowCount, rowInfos]);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const st = el.scrollTop;
        // Binary search for first visible row
        let lo = 0, hi = rowCount;
        while (lo < hi) {
          const mid = (lo + hi) >> 1;
          if (rowOffsetsCum[mid] < st) lo = mid + 1; else hi = mid;
        }
        const newStart = Math.max(0, lo - 5);
        setStartRow(prev => prev === newStart ? prev : newStart);
      });
    };
    el.addEventListener('scroll', onScroll, { passive: true });
    return () => { cancelAnimationFrame(raf); el.removeEventListener('scroll', onScroll); };
  }, [rowCount, rowOffsetsCum]);

  const endRow   = Math.min(rowCount, startRow + VISIBLE_COUNT);
  const topPx    = startRow > 0 ? rowOffsetsCum[startRow] - rowOffsetsCum[0] : 0;
  const bottomPx = rowOffsetsCum[rowCount] - rowOffsetsCum[endRow];

  return (
    <div
      ref={scrollRef}
      data-viewer-scroll="1"
      className="w-full h-full overflow-auto bg-white"
    >
      <div style={{ width: naturalW * zoom, height: naturalH * zoom, position: 'relative' }}>
        <div
          ref={wrapperRef}
          data-page-number={pageNum}
          style={{
            position: 'absolute', top: 0, left: 0,
            transform: `scale(${zoom})`, transformOrigin: 'top left',
            width: naturalW, height: naturalH,
          }}
        >
          <table
            ref={tableRef}
            className="border-collapse select-none"
            style={{ tableLayout: 'fixed', width: naturalW, fontSize: 12 }}
          >
            {/* Dynamic column widths from xlsx metadata */}
            <colgroup>
              <col style={{ width: ROW_NUM_W }} />
              {colWidths.map((w, ci) => <col key={ci} style={{ width: w }} />)}
            </colgroup>

            {/* Column letter header */}
            <thead>
              <tr style={{ height: HEADER_H }}>
                <th className="bg-[#f2f2f2] border border-[#d0d0d0] text-[#555] font-normal text-center sticky top-0 left-0 z-20"
                  style={{ width: ROW_NUM_W, height: HEADER_H }} />
                {colWidths.map((w, ci) => (
                  <th key={ci}
                    className="bg-[#f2f2f2] border border-[#d0d0d0] text-[#555] font-normal text-center px-1 select-none"
                    style={{ width: w, height: HEADER_H, position: 'relative' }}>
                    {colLetter(ci)}
                    {/* Column resize handle — drag right edge. data-resize-handle tells
                         useBoxCapture to ignore this target even in box mode. */}
                    <div
                      data-resize-handle="col"
                      style={{
                        position: 'absolute', right: -2, top: 0, bottom: 0, width: 5,
                        cursor: 'col-resize', zIndex: 50,
                        background: 'transparent',
                      }}
                      onMouseDown={e => onColResizeMouseDown(e, ci)}
                      title={`Drag to resize column ${colLetter(ci)}`}
                    />
                  </th>
                ))}
              </tr>
            </thead>

            <tbody>
              {/* Top spacer */}
              {topPx > 0 && <tr style={{ height: topPx }}><td colSpan={colCount + 1} style={{padding:0,border:'none'}}/></tr>}

              {Array.from({ length: endRow - startRow }, (_, idx) => {
                const ri  = startRow + idx;
                const row = getRow(ri);
                if (rowInfos?.[ri]?.hidden) return null;
                const rowH = rowHeights[ri];
                return (
                  <tr key={ri} style={{ height: rowH }}>
                    {/* Row number gutter */}
                    <td className="bg-[#f2f2f2] border border-[#d0d0d0] text-[#555] text-center text-xs sticky left-0 z-10 select-none"
                      style={{ width: ROW_NUM_W, height: rowH, fontSize: 11, position: 'relative' }}>
                      {ri + 1}
                      {/* Row resize handle — drag bottom edge. data-resize-handle tells
                           useBoxCapture to ignore this target even in box mode. */}
                      <div
                        data-resize-handle="row"
                        style={{
                          position: 'absolute', left: 0, right: 0, bottom: -2, height: 5,
                          cursor: 'row-resize', zIndex: 50,
                          background: 'transparent',
                        }}
                        onMouseDown={e => onRowResizeMouseDown(e, ri)}
                        title={`Drag to resize row ${ri + 1}`}
                      />
                    </td>

                    {Array.from({ length: colCount }, (_, ci) => {
                      const key = `\${ri},\${ci}`;
                      const mergeInfo = mergeMap.get(key);

                      // Cell covered by a merge — render nothing (the spanning cell covers it)
                      if (mergeInfo === 'hidden') return null;

                      const val     = row[ci] ?? '';
                      const cellSty = styles?.[ri]?.[ci];
                      const isHit   = searchHitCells.has(key);
                      const isCur   = currentResultKey === key;
                      const colW    = colWidths[ci];
                      const colSpan = mergeInfo ? mergeInfo.colSpan : 1;
                      const rowSpan = mergeInfo ? mergeInfo.rowSpan : 1;

                      // Build style: search overrides > xlsx cell style > default
                      let cellStyle = buildCellStyle(cellSty, colW, rowH);
                      // Search highlight overrides background
                      if (isCur)       cellStyle = { ...cellStyle, background: 'rgba(255,140,0,0.45)', color: '#fff' };
                      else if (isHit)  cellStyle = { ...cellStyle, background: 'rgba(255,220,50,0.35)' };
                      // Expand merged cell visual width
                      if (colSpan > 1) cellStyle.maxWidth = colWidths.slice(ci, ci + colSpan).reduce((a, b) => a + b, 0);

                      return (
                        <td
                          key={ci}
                          data-row={ri} data-col={ci} data-cell-text={val}
                          title={val}
                          colSpan={colSpan}
                          rowSpan={rowSpan}
                          onClick={e => onCellClick(e, ri, ci)}
                          className={`border border-[#d0d0d0] px-1.5 text-xs overflow-hidden
                            \${!cellSty?.wrap ? 'whitespace-nowrap' : ''}
                            \${boxMode ? 'cursor-pointer select-none' : 'cursor-default'}
                            \${!isCur && !isHit && !cellSty?.fillRgb ? 'bg-white text-[#111]' : ''}
                            \${boxMode && !isHit && !isCur ? 'hover:brightness-110' : ''}
                          `}
                          style={cellStyle}
                        >
                          {val}
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
              {/* Bottom spacer — maintains scroll height for rows below visible window */}
              {bottomPx > 0 && <tr style={{ height: bottomPx }}><td colSpan={colCount + 1} style={{padding:0,border:'none'}}/></tr>}

            </tbody>
          </table>
          {/* ── Image overlay layer ─────────────────────────────────────────────
               Images from xlsx are positioned using cumulative col/row offsets.
               Each image is an <img> tag absolutely positioned inside the wrapper. */}
          {(images ?? []).map((img, idx) => {
            // Anchor position — always from colStart/rowStart cumulative offsets
            const x = ROW_NUM_W + colWidths.slice(0, img.colStart).reduce((a, b) => a + b, 0);
            const y = HEADER_H  + rowHeights.slice(0, img.rowStart).reduce((a, b) => a + b, 0);
            // Size priority:
            //   1. widthPx/heightPx from EMU conversion (exact, set by worker) — preferred
            //   2. col/row span sum (fallback when EMU not available)
            //   3. Hardcoded minimum (120×80) as last resort
            const w = img.widthPx  > 0
              ? img.widthPx
              : (colWidths.slice(img.colStart, img.colEnd).reduce((a, b) => a + b, 0) || 120);
            const h = img.heightPx > 0
              ? img.heightPx
              : (rowHeights.slice(img.rowStart, img.rowEnd).reduce((a, b) => a + b, 0) || 80);
            return (
              <img
                key={idx}
                src={img.src}
                alt={`image-${idx}`}
                draggable={false}
                style={{
                  position: 'absolute',
                  left: x, top: y,
                  width: w, height: h,
                  // Use fill so the image fills the exact EMU-derived pixel box
                  // without letterboxing. The EMU dims already encode the correct aspect ratio.
                  objectFit: 'fill',
                  pointerEvents: 'none',
                  zIndex: 15,
                }}
              />
            );
          })}

          {/* Highlight canvas — pixel size capped at 8192 to prevent OOM on large sheets.
               CSS width/height spans the full natural table so highlights align correctly.
               Fractional coords × canvas pixel dims = correct draw position. */}
          <canvas
            ref={hlCanvasRef}
            width={hlCanvasW}
            height={hlCanvasH}
            style={{
              position: 'absolute',
              inset: 0,
              width: naturalW,
              height: naturalH,
              pointerEvents: 'none',
              zIndex: 25,
            }}
          />
        </div>
      </div>
    </div>
  );
}
