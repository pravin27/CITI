// Sidecar JSON loading hook + manual injection functions.
//
// FIELD NAME ALIASES (all treated identically):
//   text / label / value  →  the display text of a word or field
//   id                    →  field identifier (optional for word_index, required for captured)
//
// PAGE DIMENSIONS (used for coordinate normalisation):
//   pageWidth / page_width / pageHeight / page_height  → ignored if coords are fractional
//   When absolute coords received: pageWidth/pageHeight used for normalisation then discarded.
//
// COORDINATE FORMATS SUPPORTED (via extractRawCoords):
//   flat:        {x, y, width, height} or {x, y, w, h}
//   bbox:        {bbox: [x, y, w, h]}
//   rectangle:   {rectangle: [x1,y1,x2,y2]} or [x,y,w,h]
//   coordinates: {coordinates: [ymin,xmin,ymax,xmax]}

import { useEffect } from 'react';
import { useAppStore } from '../store/appStore';
import { extractRawCoords, normaliseBatch, normaliseCoords } from '../utils/coords';
import type { WordEntry, Category, CaptureItem } from '../adapters/types';
import { PALETTE_COLORS } from '../adapters/types';
import type { ViewerAdapter } from '../adapters/types';

// ── Text field resolution ──────────────────────────────────────────────────────
// "text", "label", "value", "t" are all accepted as the display text.
// Priority: text > label > value > t
function resolveText(item: Record<string, unknown>): string {
  return String(
    item.text  ??
    item.label ??
    item.value ??
    item.t     ??
    ''
  );
}

// ── ID resolution ──────────────────────────────────────────────────────────────
// id is optional for word_index entries, required for captured fields.
function resolveId(item: Record<string, unknown>, fallback = ''): string {
  return item.id ? String(item.id) : fallback;
}

// ── Page dimension extraction ─────────────────────────────────────────────────
// Accepts pageWidth, page_width, pageHeight, page_height — all normalised.
// These are only used for coordinate normalisation and then discarded from output.
function resolvePageDims(item: Record<string, unknown>): { pw?: number; ph?: number } {
  const pw = (item.pageWidth  ?? item.page_width  ?? undefined) as number | undefined;
  const ph = (item.pageHeight ?? item.page_height ?? undefined) as number | undefined;
  return { pw: typeof pw === 'number' ? pw : undefined,
           ph: typeof ph === 'number' ? ph : undefined };
}

// ── Color resolution ──────────────────────────────────────────────────────────
function resolveColor(raw: string): string {
  if (!raw) return '';
  if (/^[0-9a-fA-F]{6}$/.test(raw)) return '#' + raw;
  if (/^[0-9a-fA-F]{3}$/.test(raw)) return '#' + raw;
  return raw;
}

// ── Normalise one set of raw coords ───────────────────────────────────────────
function normaliseOne(
  raw: [number, number, number, number],
  item: Record<string, unknown>,
  page: number,
  adapter: ViewerAdapter | null
): [number, number, number, number] {
  const [x, y, w, h] = raw;
  if (x <= 1 && y <= 1 && w <= 1 && h <= 1) return [x, y, w, h];
  const { pw, ph } = resolvePageDims(item);
  if (pw && ph) {
    return [
      Math.max(0, Math.min(1, x / pw)),
      Math.max(0, Math.min(1, y / ph)),
      Math.max(0, Math.min(1, w / pw)),
      Math.max(0, Math.min(1, h / ph)),
    ];
  }
  const dims = adapter?.getPageDimensions(page) ?? null;
  if (dims) {
    return [
      Math.max(0, Math.min(1, x / dims.width)),
      Math.max(0, Math.min(1, y / dims.height)),
      Math.max(0, Math.min(1, w / dims.width)),
      Math.max(0, Math.min(1, h / dims.height)),
    ];
  }
  return [x, y, w, h];
}

// ── Word index parsing ─────────────────────────────────────────────────────────
// id is NOT required — word_index entries are drawn as text overlays only.
// text/label/value/t are all accepted as the word text.
// page_width/page_height ignored after coordinate normalisation.
function parseWordIndex(
  json: unknown,
  adapter: ViewerAdapter | null
): Map<number, WordEntry[]> {
  const result = new Map<number, WordEntry[]>();
  if (!json || typeof json !== 'object') return result;

  const processEntries = (entries: Record<string, unknown>[], page: number) => {
    const items: WordEntry[] = [];
    for (const e of entries) {
      const raw = extractRawCoords(e);
      if (!raw) continue;
      const coords = normaliseOne(raw, e, page, adapter);
      const text   = resolveText(e);
      if (!text) continue; // skip entries with no text
      items.push({ text, page, x: coords[0], y: coords[1], width: coords[2], height: coords[3] });
    }
    return items;
  };

  // Format A: { pages: { "1": [...], "2": [...] } }
  if ('pages' in (json as object)) {
    const pages = (json as Record<string, unknown>).pages as Record<string, unknown[]>;
    for (const [pageStr, entries] of Object.entries(pages)) {
      const page = parseInt(pageStr);
      if (isNaN(page)) continue;
      const items = processEntries(entries as Record<string, unknown>[], page);
      if (items.length) result.set(page, items);
    }
    return result;
  }

  // Format B: flat array [ { text, page, x, y, ... }, ... ]
  if (Array.isArray(json)) {
    const getPage = (item: Record<string, unknown>) =>
      typeof item.page === 'number' ? item.page : 1;

    const normalised = normaliseBatch(json as Record<string, unknown>[], getPage, adapter as any);
    for (const { raw, coords } of normalised) {
      if (!coords) continue;
      const text = resolveText(raw);
      if (!text) continue;
      const page = getPage(raw);
      if (!result.has(page)) result.set(page, []);
      result.get(page)!.push({ text, page, x: coords[0], y: coords[1], width: coords[2], height: coords[3] });
    }
    return result;
  }

  return result;
}

// ── Captured fields parsing ────────────────────────────────────────────────────
// Accepts any of: label, value, text as the field display text.
// id is required — auto-generated if missing.
// page_width/page_height/pageWidth/pageHeight used only for coord normalisation.
function parseCapturedFields(
  json: unknown,
  adapter: ViewerAdapter | null
): CaptureItem[] {
  if (!Array.isArray(json)) return [];

  const pageSizeCache = new Map<number, { width: number; height: number } | null>();
  const getPageDims = (page: number) => {
    if (!pageSizeCache.has(page)) {
      pageSizeCache.set(page, adapter ? adapter.getPageDimensions(page) : null);
    }
    return pageSizeCache.get(page) ?? null;
  };

  return (json as Record<string, unknown>[]).map(item => {
    const raw  = extractRawCoords(item);
    const page = typeof item.page === 'number' ? item.page : 1;
    let x = 0, y = 0, w = 0, h = 0;

    if (raw) {
      const [rx, ry, rw, rh] = raw;
      const isAbs = rx > 1 || ry > 1 || rw > 1 || rh > 1;
      if (isAbs) {
        // Try item-level page dims first (pageWidth/page_width/pageHeight/page_height)
        const { pw, ph } = resolvePageDims(item);
        const ew = pw ?? getPageDims(page)?.width;
        const eh = ph ?? getPageDims(page)?.height;
        if (ew && eh) {
          x = Math.max(0, Math.min(1, rx / ew));
          y = Math.max(0, Math.min(1, ry / eh));
          w = Math.max(0, Math.min(1, rw / ew));
          h = Math.max(0, Math.min(1, rh / eh));
        }
      } else {
        [x, y, w, h] = [rx, ry, rw, rh];
      }
    }

    let sourceFormat: CaptureItem['sourceFormat'] = 'flat';
    if ('bbox'        in item) sourceFormat = 'bbox';
    else if ('rectangle'  in item) sourceFormat = 'rectangle';
    else if ('coordinates' in item) sourceFormat = 'coordinates';

    // Resolve display text: text > label > value > t
    // Resolve label field for display: label > text > value > id
    const displayText  = resolveText(item);
    // Store which field name was originally used so we can round-trip it
    const usedField    = item.text  !== undefined ? 'text'
                       : item.label !== undefined ? 'label'
                       : item.value !== undefined ? 'value'
                       : 'value'; // default to 'value' for new captures

    return {
      id:       resolveId(item, Math.random().toString(36).slice(2)),
      label:    String(item.label ?? item.text ?? item.value ?? ''),
      value:    displayText,
      // Store the original field name key so submit can use the same key
      _textField: usedField,
      page,
      x, y, width: w, height: h,
      sourceFormat,
      fromJson: true,
      color: typeof item.color === 'string' ? resolveColor(item.color) : undefined,
    } as CaptureItem;
  });
}

// ── Categories ────────────────────────────────────────────────────────────────
function parseCategories(json: unknown): Category[] {
  if (!Array.isArray(json)) return [];
  let paletteIdx = 0;
  return (json as Record<string, unknown>[]).map(item => {
    const color = typeof item.color === 'string'
      ? item.color
      : PALETTE_COLORS[paletteIdx++ % PALETTE_COLORS.length];
    return {
      pages: Array.isArray(item.pages) ? (item.pages as number[]) : [],
      label: String(item.label ?? item.text ?? item.value ?? ''),
      color,
    };
  });
}

// ── Hook ──────────────────────────────────────────────────────────────────────
export function useSidecarLoader() {
  const file    = useAppStore(s => s.file);
  const adapter = useAppStore(s => s.adapter);

  useEffect(() => {
    if (!file || !adapter) return;
    let cancelled = false;
    adapter.onReady(() => { if (!cancelled) { /* auto-load reserved for future */ } });
    return () => { cancelled = true; };
  }, [file, adapter]);
}

// ── Manual injection (called from SidecarLoader UI) ────────────────────────────
export function injectWordIndex(json: unknown, adapter: ViewerAdapter | null) {
  return parseWordIndex(json, adapter);
}

export function injectCapturedFields(json: unknown, adapter: ViewerAdapter | null) {
  return parseCapturedFields(json, adapter);
}

export function injectCategories(json: unknown) {
  return parseCategories(json);
}
