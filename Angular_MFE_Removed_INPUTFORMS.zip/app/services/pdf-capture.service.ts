import { Injectable, signal, computed } from '@angular/core';
import { WordCoordinate, HighlightRect } from '../models/pdf-capture.models';

/** A single word capture — may or may not have id/label yet */
export interface CaptureItem {
  id:     string;   // empty until user provides it
  label:  string;   // empty until user provides it
  value:  string;   // the captured word text
  page:   number;
  x:      number;
  y:      number;
  width:  number;
  height: number;
  sourceFormat?: string;
  fromJson?: boolean;
}

@Injectable({ providedIn: 'root' })
export class PdfCaptureService {

  // ── Signals ────────────────────────────────────────────────────────────────
  /** All confirmed captures (id+label present) — drive green/grey highlights */
  readonly fields = signal<CaptureItem[]>([]);

  /** Last raw click/box capture — shown in JSON log, awaiting id+label submission */
  readonly lastRawCapture = signal<CaptureItem | null>(null);

  readonly externalCoords = signal<WordCoordinate[]>([]);
  readonly click2pickMode = signal<boolean>(false);
  readonly activeFieldId  = signal<string | null>(null);

  // ── Computed highlights ────────────────────────────────────────────────────
  readonly highlightIndex = computed<Map<number, HighlightRect[]>>(() => {
    const index = new Map<number, HighlightRect[]>();
    const add = (page: number, rect: HighlightRect) => {
      let arr = index.get(page);
      if (!arr) { arr = []; index.set(page, arr); }
      arr.push(rect);
    };
    for (const c of this.externalCoords()) {
      add(c.page, { page:c.page, x:c.x, y:c.y, width:c.width, height:c.height,
                    type:'external', label:c.text });
    }
    for (const f of this.fields()) {
      add(f.page, { page:f.page, x:f.x, y:f.y, width:f.width, height:f.height,
                    type:'primary', fieldId:f.id, label:f.label });
    }
    return index;
  });

  readonly fieldTextIndex = computed<Map<string, string>>(() => {
    const m = new Map<string, string>();
    for (const f of this.fields()) {
      m.set(f.id, f.value.toLowerCase());
    }
    return m;
  });

  readonly activeWordText = computed<string | null>(() => {
    const id = this.activeFieldId();
    if (!id) return null;
    return this.fields().find(f => f.id === id)?.value?.toLowerCase() ?? null;
  });

  readonly allHighlights = computed<HighlightRect[]>(() => {
    const all: HighlightRect[] = [];
    this.highlightIndex().forEach(rects => all.push(...rects));
    return all;
  });

  getHighlightsForPage(page: number): HighlightRect[] {
    return this.highlightIndex().get(page) ?? [];
  }

  // ── Raw capture (click / dblclick / box) ──────────────────────────────────
  /**
   * Called on every click2pick / dblclick / box-select.
   * Stores the raw capture (id='', label='') for display in the JSON log.
   * Does NOT create a highlight — user must submit id+label first.
   */
  storeRawCapture(word: {
    text: string; page: number;
    x: number; y: number; width: number; height: number;
  }): void {
    const item: CaptureItem = {
      id: '', label: '', value: word.text,
      page: word.page, x: word.x, y: word.y,
      width: word.width, height: word.height,
    };
    this.lastRawCapture.set(item);

    console.group('%c[RAW CAPTURE] storeRawCapture()', 'color:#06b6d4;font-weight:bold;font-size:13px');
    console.log('Function:  storeRawCapture(word)');
    console.log('Param:', JSON.stringify(item, null, 2));
    console.log('Status: pending — no id/label yet, not highlighted');
    console.groupEnd();
  }

  /**
   * Submit a capture with id+label from the right panel form.
   * If id already exists in fields → replaces it.
   * If id is empty or label is empty → rejected (no highlight).
   */
  submitCapture(id: string, label: string): boolean {
    if (!id.trim() || !label.trim()) {
      console.warn('[SUBMIT] Rejected — id and label are both required');
      return false;
    }
    const raw = this.lastRawCapture();
    if (!raw) {
      console.warn('[SUBMIT] Rejected — no raw capture available to assign');
      return false;
    }

    const item: CaptureItem = {
      ...raw, id: id.trim(), label: label.trim(), fromJson: false,
    };

    const existing = this.fields().find(f => f.id === id.trim());
    const op = existing ? 'UPDATE' : 'ADD';

    this.fields.update(items => {
      const filtered = items.filter(f => f.id !== id.trim());
      return [...filtered, item];
    });
    this.activeFieldId.set(item.id);
    this.lastRawCapture.set(null);

    this.logCapturedState(op,
      `id="${item.id}" label="${item.label}" value="${item.value}"`);
    return true;
  }

  /** Remove one confirmed capture by id */
  deleteCapture(id: string): void {
    const existing = this.fields().find(f => f.id === id);
    console.group('%c[DELETE CAPTURE] deleteCapture()', 'color:#f87171;font-weight:bold;font-size:13px');
    console.log('Function:  deleteCapture(id)');
    console.log('Param — id:', id);
    console.log('Removed:', existing ? JSON.stringify(existing, null, 2) : '(not found)');
    console.groupEnd();

    this.fields.update(items => items.filter(f => f.id !== id));
    if (this.activeFieldId() === id) this.activeFieldId.set(null);

    Promise.resolve().then(() =>
      this.logCapturedState('DELETE', `id="${id}" removed`)
    );
  }

  /** Load pre-captured fields from _captured_fields.json */
  loadCapturedFieldsFromJson(jsonFields: Array<{
    id: string; label: string; value: string;
    page: number; x: number; y: number; width: number; height: number;
    sourceFormat?: string;
  }>): void {
    const items: CaptureItem[] = jsonFields
      .filter(f => f.value && f.id && f.label)
      .map(f => ({ ...f, fromJson: true }));

    // Merge: keep existing items not present in JSON, add/replace JSON items
    this.fields.update(existing => {
      const jsonIds = new Set(items.map(i => i.id));
      return [...existing.filter(e => !jsonIds.has(e.id)), ...items];
    });

    console.log('[LOAD] loadCapturedFieldsFromJson — loaded', items.length, 'items from JSON');
  }

  /** Export all confirmed captures as JSON */
  getCapturedFieldsJson(): Array<CaptureItem & { fromJson: boolean; sourceFormat: string }> {
    return this.fields().map(f => ({
      ...f,
      fromJson:     !!f.fromJson,
      sourceFormat: f.sourceFormat || 'flat',
    }));
  }

  // ── Legacy compat (viewer uses these) ──────────────────────────────────────
  initFields(_f: any[]) { /* no-op — fields now managed by storeRawCapture/submitCapture */ }
  setActiveField(id: string | null) { this.activeFieldId.set(id); }
  getActiveField() { return this.fields().find(f => f.id === this.activeFieldId()) ?? null; }
  clearField(id: string) { this.deleteCapture(id); }
  captureWordToActiveField(_w: any) { /* no-op */ }
  setPendingCapture(word: any) { this.storeRawCapture(word); }
  confirmCapture() { /* handled by submitCapture now */ }
  discardPendingCapture() { this.lastRawCapture.set(null); }
  pendingCapture = signal<any>(null);

  loadExternalCoordinates(coords: WordCoordinate[]) { this.externalCoords.set(coords); }
  toggleClick2PickMode() { this.click2pickMode.update(v => !v); }
  setClick2PickMode(on: boolean) { this.click2pickMode.set(on); }

  // ── Private helpers ────────────────────────────────────────────────────────
  private logCapturedState(op: 'ADD'|'UPDATE'|'DELETE', context: string): void {
    const snap = this.fields().map(f => ({
      id: f.id, label: f.label, value: f.value, page: f.page,
      x: parseFloat(f.x.toFixed(6)), y: parseFloat(f.y.toFixed(6)),
      width: parseFloat(f.width.toFixed(6)), height: parseFloat(f.height.toFixed(6)),
    }));
    const color = op === 'DELETE' ? 'color:#f87171' : 'color:#00c864';
    console.group(`%c[CAPTURED JSON] ${op}: ${context}`, `${color};font-weight:bold;font-size:13px`);
    console.log('Total confirmed captures:', snap.length);
    console.table(snap);
    console.log('Full JSON:', JSON.stringify(snap, null, 2));
    console.groupEnd();
  }
}