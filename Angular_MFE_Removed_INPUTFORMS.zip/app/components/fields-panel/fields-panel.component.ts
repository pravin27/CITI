import {
  Component, Output, EventEmitter, ChangeDetectionStrategy,
  signal, computed,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PdfCaptureService, CaptureItem } from '../../services/pdf-capture.service';

@Component({
  selector: 'app-fields-panel',
  standalone: true,
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="capture-panel">

      <!-- ── Header ── -->
      <div class="panel-header">
        <div class="header-title">
          <span class="header-icon">⬡</span>
          <h2>Field Capture</h2>
        </div>
        <div class="header-actions">
          <button
            class="btn-pick"
            [class.active]="svc.click2pickMode()"
            (click)="svc.toggleClick2PickMode()"
            [title]="svc.click2pickMode() ? 'Click2Pick ON' : 'Click2Pick OFF'"
          >
            <span class="pick-dot" [class.on]="svc.click2pickMode()"></span>
            Click2Pick
          </button>
        </div>
      </div>

      <!-- ── Status bar ── -->
      <div class="status-bar" [class.has-raw]="svc.lastRawCapture()">
        <ng-container *ngIf="svc.lastRawCapture(); else noCapture">
          <span class="status-dot pulse"></span>
          Captured: <strong>"{{ svc.lastRawCapture()!.value }}"</strong>
          — pg {{ svc.lastRawCapture()!.page }}
          &nbsp;({{ (svc.lastRawCapture()!.x * 100) | number:'1.0-0' }}%,{{ (svc.lastRawCapture()!.y * 100) | number:'1.0-0' }}%)
        </ng-container>
        <ng-template #noCapture>
          <span class="status-dot idle"></span>
          Click2Pick or draw a box to capture a word
        </ng-template>
      </div>

      <!-- ── Raw JSON preview ── -->
      <div class="json-preview" *ngIf="svc.lastRawCapture()">
        <div class="json-label">Raw capture (id &amp; label not yet assigned)</div>
        <pre class="json-block">{{ rawJson() }}</pre>
      </div>

      <!-- ── Submit form: assign id + label ── -->
      <div class="submit-form" [class.active]="!!svc.lastRawCapture()">
        <div class="form-title">
          <span class="form-icon">{{ svc.lastRawCapture() ? '✦' : '○' }}</span>
          Assign ID &amp; Label to capture
        </div>
        <div class="form-row">
          <input
            class="form-input"
            type="text"
            placeholder="ID (required)"
            [(ngModel)]="inputId"
            [disabled]="!svc.lastRawCapture()"
          />
          <input
            class="form-input"
            type="text"
            placeholder="Label (required)"
            [(ngModel)]="inputLabel"
            [disabled]="!svc.lastRawCapture()"
          />
          <button
            class="btn-submit"
            [disabled]="!svc.lastRawCapture() || !inputId.trim() || !inputLabel.trim()"
            (click)="onSubmit()"
            title="Assign ID + Label → creates green highlight and adds to captured JSON"
          >
            Submit
          </button>
        </div>
        <div class="form-hint" *ngIf="submitError" style="color:#f87171;font-size:11px;margin-top:4px">
          {{ submitError }}
        </div>
        <div class="form-hint" *ngIf="!svc.lastRawCapture()">
          ID and Label are required to highlight and track a capture
        </div>
      </div>

      <!-- ── Confirmed captures list ── -->
      <div class="captures-header" *ngIf="svc.fields().length">
        <span>Confirmed Captures ({{ svc.fields().length }})</span>
        <button class="btn-clear-all" (click)="onClearAll()">Clear All</button>
      </div>

      <div class="captures-scroll">
        <div
          class="capture-card"
          *ngFor="let item of svc.fields()"
          [class.active]="svc.activeFieldId() === item.id"
          (click)="onCardClick(item)"
        >
          <div class="card-top">
            <span class="card-label">{{ item.label }}</span>
            <div class="card-badges">
              <span class="badge-page">⌖ pg {{ item.page }}</span>
              <button class="btn-delete" (click)="onDelete(item.id, $event)" title="Remove">✕</button>
            </div>
          </div>
          <div class="card-value">"{{ item.value }}"</div>
          <div class="card-coords">
            {{ (item.x * 100) | number:'1.0-0' }}%,{{ (item.y * 100) | number:'1.0-0' }}%
            · w={{ (item.width * 100) | number:'1.1-1' }}%
            · {{ item.fromJson ? '📂 from JSON' : '✎ captured' }}
          </div>
        </div>

        <div class="empty-state" *ngIf="!svc.fields().length">
          <div class="empty-icon">◎</div>
          <p>No confirmed captures yet.<br>Click a word, then assign ID &amp; Label.</p>
        </div>
      </div>

      <!-- ── Legend ── -->
      <div class="legend">
        <div class="legend-title">Highlight Legend</div>
        <div class="legend-items">
          <div class="legend-item"><span class="swatch active"></span> Active / Confirmed</div>
          <div class="legend-item"><span class="swatch previous"></span> Previously Captured</div>
          <div class="legend-item"><span class="swatch duplicate"></span> Duplicate Word</div>
          <div class="legend-item"><span class="swatch external"></span> External Coords</div>
        </div>
      </div>

    </div>
  `,
  styles: [`
    :host { display:flex; flex-direction:column; height:100%; }

    .capture-panel {
      display: flex;
      flex-direction: column;
      height: 100%;
      background: #080f1a;
      color: #e2e8f0;
      font-family: 'JetBrains Mono', monospace;
      overflow: hidden;
    }

    /* ── Header ── */
    .panel-header {
      display: flex; align-items: center; justify-content: space-between;
      padding: 14px 18px 12px;
      border-bottom: 1px solid rgba(255,255,255,0.06);
      flex-shrink: 0;
    }
    .header-title { display:flex; align-items:center; gap:8px; }
    .header-icon { font-size:18px; color:#00d4aa; }
    h2 { margin:0; font-size:14px; font-weight:700; letter-spacing:.5px; color:#f1f5f9; }
    .btn-pick {
      display:flex; align-items:center; gap:6px; padding:5px 12px;
      background:rgba(255,255,255,0.04); border:1.5px solid #1e293b;
      border-radius:20px; color:#94a3b8; font-size:12px; font-weight:600;
      cursor:pointer; transition:all .15s; font-family:inherit;
      &.active { border-color:#00d4aa; color:#00d4aa; background:rgba(0,212,170,.08); }
    }
    .pick-dot {
      width:7px; height:7px; border-radius:50%; background:#475569; transition:background .15s;
      &.on { background:#00d4aa; box-shadow:0 0 6px #00d4aa; }
    }

    /* ── Status bar ── */
    .status-bar {
      padding:8px 16px; font-size:12px; color:#64748b;
      background:rgba(255,255,255,0.02); border-bottom:1px solid rgba(255,255,255,0.04);
      display:flex; align-items:center; gap:7px; flex-shrink:0;
      &.has-raw { color:#e2e8f0; background:rgba(6,182,212,0.06); border-color:rgba(6,182,212,.2); }
      strong { color:#06b6d4; }
    }
    .status-dot {
      width:7px; height:7px; border-radius:50%; flex-shrink:0;
      &.idle { background:#334155; }
      &.pulse { background:#06b6d4; animation:dot-pulse 1s ease-in-out infinite; }
    }
    @keyframes dot-pulse {
      0%,100% { box-shadow:0 0 0 0 rgba(6,182,212,0); }
      50% { box-shadow:0 0 0 4px rgba(6,182,212,.3); }
    }

    /* ── JSON preview ── */
    .json-preview {
      margin:10px 14px 0; border-radius:8px;
      border:1px solid rgba(6,182,212,.25); background:rgba(6,182,212,.04);
      overflow:hidden; flex-shrink:0;
    }
    .json-label {
      font-size:10px; color:#06b6d4; padding:5px 10px;
      border-bottom:1px solid rgba(6,182,212,.12);
      font-weight:700; letter-spacing:.4px; text-transform:uppercase;
    }
    .json-block {
      margin:0; padding:8px 10px; font-size:11px; color:#94a3b8;
      line-height:1.6; overflow:auto; max-height:140px;
      white-space:pre; background:transparent;
    }

    /* ── Submit form ── */
    .submit-form {
      margin:10px 14px; padding:12px 14px; border-radius:8px;
      border:1.5px solid rgba(255,255,255,0.06);
      background:rgba(255,255,255,.02); flex-shrink:0; transition:border-color .2s;
      &.active { border-color:rgba(0,212,170,.35); background:rgba(0,212,170,.03); }
    }
    .form-title {
      font-size:11px; color:#64748b; font-weight:700; letter-spacing:.4px;
      text-transform:uppercase; margin-bottom:8px; display:flex; align-items:center; gap:6px;
      .form-icon { font-size:13px; }
    }
    .submit-form.active .form-title { color:#00d4aa; }
    .form-row { display:flex; gap:6px; align-items:center; }
    .form-input {
      flex:1; background:#0d1b2a; border:1.5px solid #1e293b; border-radius:6px;
      padding:7px 10px; color:#f1f5f9; font-family:inherit; font-size:12px;
      outline:none; transition:border-color .2s; min-width:0;
      &::placeholder { color:#334155; }
      &:focus { border-color:#00d4aa; }
      &:disabled { opacity:.4; cursor:not-allowed; }
    }
    .btn-submit {
      padding:7px 14px; background:rgba(0,212,170,.12); border:1.5px solid rgba(0,212,170,.4);
      color:#00d4aa; border-radius:6px; font-size:12px; font-weight:700;
      cursor:pointer; font-family:inherit; white-space:nowrap; transition:all .15s; flex-shrink:0;
      &:hover:not(:disabled) { background:rgba(0,212,170,.25); box-shadow:0 0 8px rgba(0,212,170,.3); }
      &:disabled { opacity:.35; cursor:not-allowed; }
    }
    .form-hint { font-size:11px; color:#475569; margin-top:5px; }

    /* ── Confirmed captures ── */
    .captures-header {
      display:flex; align-items:center; justify-content:space-between;
      padding:8px 16px 4px; font-size:11px; color:#475569;
      font-weight:700; letter-spacing:.4px; text-transform:uppercase; flex-shrink:0;
    }
    .btn-clear-all {
      font-size:10px; color:#f87171; background:none; border:none;
      cursor:pointer; font-family:inherit; opacity:.7;
      &:hover { opacity:1; }
    }
    .captures-scroll { flex:1; overflow-y:auto; padding:4px 10px 8px; }
    .capture-card {
      border:1.5px solid #1e293b; border-radius:8px; padding:9px 11px;
      margin-bottom:7px; background:rgba(255,255,255,.02); cursor:pointer;
      transition:all .15s;
      &:hover { border-color:#334155; background:rgba(255,255,255,.04); }
      &.active { border-color:#00c864; background:rgba(0,200,100,.06); }
    }
    .card-top { display:flex; align-items:center; justify-content:space-between; }
    .card-label { font-size:11px; font-weight:700; color:#94a3b8; text-transform:uppercase; letter-spacing:.3px; }
    .card-badges { display:flex; align-items:center; gap:5px; }
    .badge-page {
      font-size:10px; color:#60a5fa; background:rgba(59,130,246,.12);
      border:1px solid rgba(59,130,246,.25); border-radius:4px; padding:1px 6px;
    }
    .btn-delete {
      width:18px; height:18px; border:none; background:rgba(239,68,68,.1);
      color:#f87171; border-radius:50%; font-size:9px; cursor:pointer;
      display:flex; align-items:center; justify-content:center;
      &:hover { background:rgba(239,68,68,.25); }
    }
    .card-value { font-size:13px; color:#00d4aa; margin:3px 0 2px; }
    .card-coords { font-size:10px; color:#475569; }

    /* ── Empty state ── */
    .empty-state { text-align:center; padding:28px 16px; color:#334155; }
    .empty-icon { font-size:28px; margin-bottom:8px; opacity:.5; }
    .empty-state p { font-size:12px; line-height:1.6; margin:0; }

    /* ── Legend ── */
    .legend {
      padding:10px 16px; border-top:1px solid rgba(255,255,255,0.06);
      background:#060d18; flex-shrink:0;
    }
    .legend-title {
      font-size:10px; font-weight:700; text-transform:uppercase;
      letter-spacing:1px; color:#475569; margin-bottom:6px;
    }
    .legend-items { display:grid; grid-template-columns:1fr 1fr; gap:5px; }
    .legend-item { display:flex; align-items:center; gap:6px; font-size:11px; color:#64748b; }
    .swatch {
      width:13px; height:13px; border-radius:3px; flex-shrink:0;
      &.active   { background:rgba(0,200,100,.25); border:2px solid rgb(0,200,100); }
      &.previous { background:rgba(150,150,150,.18); border:2px solid rgba(120,120,120,.7); }
      &.duplicate{ background:rgba(250,204,21,.30); border:2px solid rgb(234,179,8); }
      &.external { background:rgba(139,92,246,.25); border:2px solid #8b5cf6; }
    }
  `],
})
export class FieldsPanelComponent {
  @Output() goToWord    = new EventEmitter<CaptureItem>();
  @Output() captureConfirmed = new EventEmitter<void>();

  inputId    = '';
  inputLabel = '';
  submitError = '';

  constructor(public svc: PdfCaptureService) {}

  rawJson(): string {
    const raw = this.svc.lastRawCapture();
    if (!raw) return '';
    return JSON.stringify({
      id: '', label: '', value: raw.value, page: raw.page,
      x: parseFloat(raw.x.toFixed(6)), y: parseFloat(raw.y.toFixed(6)),
      width: parseFloat(raw.width.toFixed(6)), height: parseFloat(raw.height.toFixed(6)),
    }, null, 2);
  }

  onSubmit(): void {
    this.submitError = '';
    if (!this.inputId.trim() || !this.inputLabel.trim()) {
      this.submitError = 'Both ID and Label are required.';
      return;
    }
    const ok = this.svc.submitCapture(this.inputId, this.inputLabel);
    if (ok) {
      this.inputId    = '';
      this.inputLabel = '';
      this.captureConfirmed.emit();
    }
  }

  onDelete(id: string, e: MouseEvent): void {
    e.stopPropagation();
    this.svc.deleteCapture(id);
  }

  onCardClick(item: CaptureItem): void {
    this.svc.setActiveField(item.id);
    this.goToWord.emit(item);
  }

  onClearAll(): void {
    this.svc.fields().slice().forEach(f => this.svc.deleteCapture(f.id));
  }
}