import { useState, useRef, useCallback, useEffect } from "react";
// react-pdf Document/Page replaced by direct pdfjs canvas rendering
import { pdfjs } from "react-pdf";

// ─── Worker (Vite native — resolves from node_modules) ────────────────────────
pdfjs.GlobalWorkerOptions.workerSrc = new URL(
  "pdfjs-dist/build/pdf.worker.min.mjs",
  import.meta.url
).toString();

// ─── Colour palette ───────────────────────────────────────────────────────────
const C = {
  bg:           "#0d1117",
  surface:      "#161b27",
  surface2:     "#1c2233",
  border:       "#232b3e",
  accent:       "#4f8ef7",
  accentDim:    "rgba(79,142,247,0.14)",
  accentGlow:   "rgba(79,142,247,0.28)",
  // ── Highlight colours ──
  //  active      = green (current selection being edited)
  //  activeDup   = yellow (same word on other pages when active field selected)
  //  captured    = grey (words captured in other non-active fields)
  //  capturedDup = grey border only (duplicate of a captured non-active word)
  //  ext         = teal (externally injected highlights)
  active:       "rgba(74,222,128,0.35)",
  activeBdr:    "rgba(74,222,128,0.95)",
  activeGlow:   "rgba(74,222,128,0.4)",
  activeDup:    "rgba(250,204,21,0.32)",
  activeDupBdr: "rgba(250,204,21,0.9)",
  captured:     "rgba(160,160,180,0.18)",
  capturedBdr:  "rgba(160,160,180,0.55)",
  capturedDup:  "rgba(160,160,180,0.10)",
  capturedDupBdr:"rgba(160,160,180,0.4)",
  ext:          "rgba(80,220,120,0.28)",
  extBdr:       "rgba(80,220,120,0.75)",
  srch:         "rgba(250,196,0,0.26)",
  srchBdr:      "rgba(250,196,0,0.68)",
  activeField:  "rgba(79,142,247,0.16)",
  lasso:        "rgba(79,142,247,0.18)",
  lassoBdr:     "#4f8ef7",
  text:         "#dde4f4",
  muted:        "#7a8aaa",
  dim:          "#505d7a",
  ok:           "#4ade80",
  warn:         "#facc15",
  danger:       "#f87171",
};

// ─── External highlights (inject words-with-coords here) ─────────────────────
// Each entry: { page, x, y, width, height, text }  — coords are page-fractions 0–1
const EXTERNAL_HIGHLIGHTS = [];

// ─── Field definitions ────────────────────────────────────────────────────────
const INITIAL_FIELDS = [
  "Entity Name", "Invoice Number", "Date", "Amount",
  "PAN / Tax ID", "Address", "Reference", "Description",
].map((label, i) => ({
  id: `f${i + 1}`, label,
  value: "", captures: [],   // captures: [{word, page, x,y,width,height}]
}));

// ─── Utilities ────────────────────────────────────────────────────────────────
const debounce = (fn, ms) => {
  let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
};
const norm = (s = "") => s.toLowerCase().replace(/[^a-z0-9]/g, "");

// Rectangle overlap — both rects are in page-fraction coords
const overlaps = (a, b) =>
  a.x < b.x + b.w && a.x + a.w > b.x &&
  a.y < b.y + b.h && a.y + a.h > b.y;

const navBtn = {
  background: "rgba(255,255,255,0.04)", border: `1px solid ${C.border}`,
  color: C.muted, borderRadius: 4, padding: "3px 10px",
  cursor: "pointer", fontSize: 12, fontFamily: "inherit",
};
const btn = (extra = {}) => ({
  background: "rgba(255,255,255,0.04)", border: `1px solid ${C.border}`,
  color: C.muted, borderRadius: 4, padding: "4px 10px",
  cursor: "pointer", fontSize: 13, fontFamily: "inherit",
  transition: "all .15s", ...extra,
});

// ─── Word-item cache per page ────────────────────────────────────────────────
// Shape: Map<pageNum, Array<{word, x, y, w, h}>>  coords are page-fractions 0–1
//
// Strategy: pdf.js getTextContent() returns one item per text run (often a full
// line). We split each run into individual words and measure each word's width
// using a hidden <canvas> + the item's own font metrics — far more accurate than
// naive character-count proportioning.
const wordCache = new Map();

// Offscreen canvas for font measurement
const _mCanvas  = document.createElement("canvas");
const _mCtx     = _mCanvas.getContext("2d");

function measureWords(str, fontName, fontSize) {
  // Build a CSS font string that mirrors what pdf.js uses
  const family = fontName?.toLowerCase().includes("bold")
    ? `bold ${fontSize}px serif`
    : fontName?.toLowerCase().includes("italic")
      ? `italic ${fontSize}px serif`
      : `${fontSize}px serif`;
  _mCtx.font = family;

  const tokens   = str.split(/(\s+)/);
  const results  = [];  // [{text, width}]
  for (const tok of tokens) {
    results.push({ text: tok, width: _mCtx.measureText(tok).width });
  }
  return results;
}

async function getPageWords(pdfDoc, pageNum) {
  if (wordCache.has(pageNum)) return wordCache.get(pageNum);

  const page    = await pdfDoc.getPage(pageNum);
  const content = await page.getTextContent({ includeMarkedContent: false });
  const vp      = page.getViewport({ scale: 1 });

  const words = [];

  for (const item of content.items) {
    const raw = item.str;
    if (!raw?.trim()) continue;

    const [scaleX,, , scaleY, tx, ty] = item.transform;
    // scaleY is the rendered font size in PDF user-space units
    const fontSize = Math.abs(scaleY);

    // Measure each token with canvas so word widths are accurate
    const tokens     = measureWords(raw, item.fontName, fontSize);
    const totalMeasW = tokens.reduce((s, t) => s + t.width, 0);
    // Scale factor: map canvas-pixel widths → PDF user-space widths
    // Use item.width as ground-truth total; fall back to measured total
    const totalW     = item.width > 0 ? item.width : totalMeasW;
    const ratio      = totalMeasW > 0 ? totalW / totalMeasW : 1;

    let cursorX = tx;
    for (const tok of tokens) {
      const tokW = tok.width * ratio;
      if (tok.text.trim()) {
        // PDF y is bottom-up; convert to top-down fraction
        const yFrac = Math.max(0, 1 - (ty + Math.abs(scaleY)) / vp.height);
        words.push({
          word: tok.text.trim(),
          x:    Math.max(0, Math.min(cursorX / vp.width,  0.999)),
          y:    Math.max(0, Math.min(yFrac,               0.999)),
          w:    Math.max(0.002, Math.min(tokW / vp.width, 0.999)),
          h:    Math.max(0.005, Math.min(Math.abs(scaleY) / vp.height, 0.1)),
          // Keep raw pdf data for DOM rewriting
          _tx: cursorX, _ty: ty, _fontSize: fontSize,
          _fontName: item.fontName,
          _pageW: vp.width, _pageH: vp.height,
        });
      }
      cursorX += tokW;
    }
  }

  wordCache.set(pageNum, words);
  return words;
}

// ─── Lasso / drag-box overlay ─────────────────────────────────────────────────
// Two capture modes:
//   1. Drag     → draws a selection box; captures all words whose rects overlap it
//   2. DblClick → instantly captures the single nearest word at the click point
function LassoOverlay({ active, onSelect, onDblClickWord, pageRef }) {
  const [box, setBox]         = useState(null);
  const [drawing, setDrawing] = useState(false);
  const startRef              = useRef(null);
  const overlayRef            = useRef(null);
  // Used to distinguish a double-click from starting a drag
  const pendingDragRef        = useRef(null);
  const isDblPendingRef       = useRef(false);
  const pendingStartCoordRef  = useRef(null);   // coords at mousedown, for early drag detection

  const getRect = () =>
    // pageRef now points directly to the canvas element (not a react-pdf wrapper)
    pageRef.current?.getBoundingClientRect() ?? null;

  const toCoords = (e) => {
    const rect = getRect();
    if (!rect) return null;
    return {
      x:  Math.max(0, Math.min(e.clientX - rect.left, rect.width)),
      y:  Math.max(0, Math.min(e.clientY - rect.top,  rect.height)),
      pw: rect.width,
      ph: rect.height,
    };
  };

  // mousedown: schedule drag start after 220ms — dblclick will cancel it
  const onMouseDown = useCallback(e => {
    if (!active) return;
    e.preventDefault();
    e.stopPropagation();
    isDblPendingRef.current = false;

    const c = toCoords(e);
    if (!c) return;
    pendingStartCoordRef.current = c;   // store for early drag detection in mousemove

    // Delay drag start so double-click can cancel it cleanly
    pendingDragRef.current = setTimeout(() => {
      if (isDblPendingRef.current) return;   // dblclick fired — skip drag
      startRef.current = c;
      setBox({ x: c.x, y: c.y, w: 0, h: 0, pw: c.pw, ph: c.ph });
      setDrawing(true);
    }, 180);   // short enough to feel instant, long enough for dblclick detection
  }, [active]);

  const onMouseMove = useCallback(e => {
    // If mouse moves while pending-drag timer is running, start drag immediately
    // (user is clearly dragging, not double-clicking)
    // Early drag detection — if mouse moves >4px during the dblclick wait window
    if (!drawing && pendingDragRef.current && !isDblPendingRef.current) {
      const c = toCoords(e);
      if (!c) return;
      if (pendingStartCoordRef.current) {
        const dx = Math.abs(c.x - pendingStartCoordRef.current.x);
        const dy = Math.abs(c.y - pendingStartCoordRef.current.y);
        if (dx > 4 || dy > 4) {
          clearTimeout(pendingDragRef.current);
          pendingDragRef.current = null;
          startRef.current = pendingStartCoordRef.current;
          const s0 = pendingStartCoordRef.current;
          setBox({
            x: Math.min(s0.x, c.x), y: Math.min(s0.y, c.y),
            w: Math.abs(c.x - s0.x), h: Math.abs(c.y - s0.y),
            pw: c.pw, ph: c.ph,
          });
          setDrawing(true);
        }
      }
      return;
    }
    if (!drawing || !startRef.current) return;
    const c = toCoords(e);
    if (!c) return;
    const s = startRef.current;
    setBox({
      x: Math.min(s.x, c.x), y: Math.min(s.y, c.y),
      w: Math.abs(c.x - s.x), h: Math.abs(c.y - s.y),
      pw: c.pw, ph: c.ph,
    });
  }, [drawing]);

  const onMouseUp = useCallback(e => {
    if (!drawing || !box || !startRef.current) return;
    setDrawing(false);
    const { x, y, w, h, pw, ph } = box;
    if (w > 6 && h > 6 && pw && ph) {
      onSelect({ x: x / pw, y: y / ph, w: w / pw, h: h / ph });
    }
    setBox(null);
    startRef.current = null;
  }, [drawing, box, onSelect]);

  // dblclick: cancel any pending drag, then find + capture nearest word
  const onDblClick = useCallback(e => {
    if (!active) return;
    e.preventDefault();
    e.stopPropagation();
    // Cancel the drag that mousedown may have scheduled
    clearTimeout(pendingDragRef.current);
    pendingDragRef.current = null;
    isDblPendingRef.current = true;
    pendingStartCoordRef.current = null;
    setDrawing(false);
    setBox(null);
    startRef.current = null;

    const rect = getRect();
    if (!rect) return;
    const fx = Math.max(0, Math.min((e.clientX - rect.left) / rect.width,  1));
    const fy = Math.max(0, Math.min((e.clientY - rect.top)  / rect.height, 1));
    onDblClickWord({ fx, fy });

    // Reset flag after a tick so next single-click drag works normally
    setTimeout(() => { isDblPendingRef.current = false; }, 50);
  }, [active, onDblClickWord]);

  useEffect(() => {
    const el = overlayRef.current;
    if (!el) return;
    el.addEventListener("mousedown", onMouseDown);
    el.addEventListener("dblclick",  onDblClick);
    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseup",   onMouseUp);
    return () => {
      el.removeEventListener("mousedown", onMouseDown);
      el.removeEventListener("dblclick",  onDblClick);
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseup",   onMouseUp);
    };
  }, [onMouseDown, onMouseMove, onMouseUp, onDblClick]);

  return (
    <div
      ref={overlayRef}
      style={{
        position: "absolute", inset: 0, zIndex: 10,
        cursor: active ? "crosshair" : "default",
        userSelect: "none",
        pointerEvents: active ? "all" : "none",
      }}
    >
      {/* Live rubber-band rectangle */}
      {box && box.w > 4 && box.h > 4 && (
        <div style={{
          position: "absolute",
          left: box.x, top: box.y, width: box.w, height: box.h,
          background: C.lasso,
          border: `1.5px dashed ${C.lassoBdr}`,
          borderRadius: 3, pointerEvents: "none", zIndex: 11,
        }} />
      )}
    </div>
  );
}

// ─── Highlight overlay ────────────────────────────────────────────────────────
// Colour rules:
//   GREEN  — word captured by the currently active field (this page)
//   YELLOW — same word as the active capture, appearing on OTHER pages / fields (duplicate of active)
//   GREY   — word captured by a non-active field (previously captured, just stored)
//   GREY lighter — duplicate of a captured non-active word
//   TEAL   — externally injected highlights
//   AMBER  — search matches
function HLOverlay({ pageNum, allCaptured, activeFieldId, searches, external }) {
  const pageExt  = external.filter(h => h.page === pageNum);
  const pageSrch = searches.filter(m => m.page === pageNum);

  // Active capture = the one belonging to the currently selected field
  const activeCap = allCaptured.find(c => c.fieldId === activeFieldId);
  const activeNorm = activeCap ? norm(activeCap.word) : null;

  // All captures on THIS page
  const pageCaps = allCaptured.filter(c => c.page === pageNum);

  // Captures on OTHER pages (for cross-page duplicate highlights)
  const otherPageCaps = allCaptured.filter(c => c.page !== pageNum);

  // Words of non-active captured fields (normalised) — for grey duplicate detection
  const capturedNorms = allCaptured
    .filter(c => c.fieldId !== activeFieldId)
    .map(c => norm(c.word));

  const renderBox = (key, x, y, width, height, bg, bdr, z, glow = false) => (
    <div key={key} style={{
      position: "absolute",
      left: `${x * 100}%`, top: `${y * 100}%`,
      width: `${width * 100}%`, height: `${height * 100}%`,
      background: bg, border: `2px solid ${bdr}`,
      borderRadius: 2, zIndex: z, pointerEvents: "none",
      boxShadow: glow ? `0 0 10px ${bdr}` : "none",
      transition: "background .18s, box-shadow .18s",
    }} />
  );

  return (
    <div style={{ position: "absolute", inset: 0, pointerEvents: "none", zIndex: 6 }}>

      {/* Search matches — amber, lowest priority */}
      {pageSrch.map((m, i) => renderBox(
        `s${i}`, m.x, m.y, m.width, m.height,
        C.srch, C.srchBdr, 1
      ))}

      {/* External highlights — teal */}
      {pageExt.map((h, i) => renderBox(
        `e${i}`, h.x, h.y, h.width, h.height,
        C.ext, C.extBdr, 2
      ))}

      {/* Cross-page duplicates of active word — YELLOW (other pages show these) */}
      {activeNorm && otherPageCaps
        .filter(c => norm(c.word) === activeNorm)
        .map((c, i) => renderBox(
          `xd${i}`, c.x, c.y, c.width, c.height,
          C.activeDup, C.activeDupBdr, 3
        ))
      }

      {/* THIS page captures — render by priority */}
      {pageCaps.map((c, i) => {
        const isActive     = c.fieldId === activeFieldId;
        const isActiveDup  = !isActive && activeNorm && norm(c.word) === activeNorm;
        const isCapturedDup = !isActive && !isActiveDup &&
          capturedNorms.filter(n => n === norm(c.word)).length > 1;

        if (isActive) {
          // GREEN — current active capture
          return renderBox(
            `c${i}`, c.x, c.y, c.width, c.height,
            C.active, C.activeBdr, 5, true   // glow
          );
        }
        if (isActiveDup) {
          // YELLOW — same word as active, on this page for a different field
          return renderBox(
            `c${i}`, c.x, c.y, c.width, c.height,
            C.activeDup, C.activeDupBdr, 4
          );
        }
        if (isCapturedDup) {
          // GREY lighter — duplicate among non-active captures
          return renderBox(
            `c${i}`, c.x, c.y, c.width, c.height,
            C.capturedDup, C.capturedDupBdr, 3
          );
        }
        // GREY — regular captured (non-active) field
        return renderBox(
          `c${i}`, c.x, c.y, c.width, c.height,
          C.captured, C.capturedBdr, 3
        );
      })}
    </div>
  );
}

// ─── Build text layer DOM from pdfjs textContent ─────────────────────────────
// Positions each text item as an absolutely-placed <span> matching the canvas.
// Uses the same transform matrix math as pdf.js's own renderTextLayer.
function buildTextLayer(container, textContent, viewport) {
  container.innerHTML = "";
  const vw = viewport.width;
  const vh = viewport.height;

  for (const item of textContent.items) {
    if (!item.str) continue;

    const [a, b, c, d, e, f] = item.transform;
    // Apply viewport transform
    const tx = viewport.transform;
    // Map PDF coordinates → CSS coordinates
    // PDF y is bottom-up; CSS is top-down
    const x = tx[0] * e + tx[2] * f + tx[4];
    const y = tx[1] * e + tx[3] * f + tx[5];

    // Font size from the scale factor in the transform matrix
    const fontSize = Math.sqrt(a * a + b * b) * Math.abs(tx[0]);
    // Rotation angle
    const angle    = Math.atan2(b, a);

    const span = document.createElement("span");
    span.textContent = item.str;
    span.style.cssText = [
      "position:absolute",
      `left:${x}px`,
      `top:${y - fontSize}px`,
      `font-size:${fontSize}px`,
      `font-family:sans-serif`,
      "white-space:pre",
      "transform-origin:0 100%",
      angle ? `transform:rotate(${angle}rad)` : "",
      "color:transparent",
      "cursor:text",
    ].filter(Boolean).join(";");

    container.appendChild(span);
  }
}

// ─── Text-layer DOM rewriter ─────────────────────────────────────────────────
// After react-pdf renders the text layer it contains one <span> per text run
// (typically a full line). This function replaces each span with N word-spans
// positioned absolutely so every word is individually selectable and has an
// accurate bounding box. Called via onGetTextSuccess on <Page>.
function splitTextLayerSpans(containerEl) {
  if (!containerEl) return;
  const spans = Array.from(containerEl.querySelectorAll("span[role='presentation'], span"));
  for (const span of spans) {
    const text = span.textContent;
    if (!text?.trim() || span.dataset.split === "1") continue;

    const words = text.split(/\b/);  // split on word boundaries
    if (words.length <= 1) continue;

    // Grab the span's own style so we can reproduce it per-word
    const cs         = window.getComputedStyle(span);
    const fontSize   = parseFloat(cs.fontSize) || 12;
    const fontFamily = cs.fontFamily || "serif";
    const fontWeight = cs.fontWeight || "normal";
    const fontStyle  = cs.fontStyle  || "normal";
    const color      = cs.color;
    const transform  = span.style.transform || "";

    // Measure each token width in a canvas
    _mCtx.font = `${fontStyle} ${fontWeight} ${fontSize}px ${fontFamily}`;
    const totalMeasured = _mCtx.measureText(text).width;
    const spanWidth     = span.getBoundingClientRect().width;
    const scale         = totalMeasured > 0 ? spanWidth / totalMeasured : 1;

    // Replace span with a wrapper div that holds word-spans
    const wrapper = document.createElement("span");
    wrapper.dataset.split = "1";
    wrapper.style.cssText = span.style.cssText;
    // wrapper inherits position/transform from original span

    let offsetX = 0;
    for (const token of words) {
      if (!token) continue;
      const tokW = _mCtx.measureText(token).width * scale;
      const ws   = document.createElement("span");
      ws.textContent    = token;
      ws.dataset.word   = token.trim();
      ws.style.position = "relative";
      ws.style.display  = "inline-block";
      ws.style.width    = tokW + "px";
      ws.style.overflow = "visible";
      ws.style.whiteSpace = "pre";
      // cursor styling handled by global CSS rule
      wrapper.appendChild(ws);
      offsetX += tokW;
    }

    span.parentNode?.replaceChild(wrapper, span);
  }
}

// ─── Virtual page slot ────────────────────────────────────────────────────────
// Each slot occupies the correct scroll-height even when not rendered.
// Pages within RENDER_WINDOW of the current visible page get real PDFPage;
// the rest show a lightweight placeholder so the scrollbar stays accurate.
const RENDER_WINDOW = 2;   // pages above+below viewport to keep rendered

function VirtualPageSlot({
  pageNum, currentPage, pageSize,
  onVisible, ...pageProps
}) {
  const slotRef  = useRef();
  const near     = Math.abs(pageNum - currentPage) <= RENDER_WINDOW;

  // IntersectionObserver — tells parent which page is mid-screen
  useEffect(() => {
    if (!slotRef.current) return;
    const obs = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) onVisible(pageNum);
    }, { threshold: 0.3 });
    obs.observe(slotRef.current);
    return () => obs.disconnect();
  }, [pageNum, onVisible]);

  const { w, h } = pageSize;   // px at current scale

  return (
    <div
      id={`page-slot-${pageNum}`}
      ref={slotRef}
      style={{ marginBottom: 16, position: "relative" }}
    >
      {near ? (
        <PDFPage pageNum={pageNum} {...pageProps} />
      ) : (
        /* Placeholder — exact page size so scrollbar height is always correct */
        <div style={{
          width: w, height: h,
          background: C.surface,
          border: `1px solid ${C.border}`,
          borderRadius: 3,
          display: "flex", alignItems: "center", justifyContent: "center",
          color: C.dim, fontSize: 12, fontFamily: "monospace",
        }}>
          {pageNum}
        </div>
      )}
    </div>
  );
}

// ─── Canvas-based PDF page renderer ──────────────────────────────────────────
// Bypasses react-pdf's <Document>/<Page> so each page renders independently
// the moment pdfjs.getPage(n) resolves — no waiting for the full PDF to load.
//
// Render pipeline per page:
//   getPage(n) → getViewport() → canvas.render() → onRenderSuccess fires
//   ↳ simultaneously: getTextContent() → renderTextLayer() → splitTextLayerSpans()
//
function PDFPage({
  pageNum, scale, rotation,
  activeFieldId, boxMode, pdfDoc, onCapture,
  allCaptured, searches, external, onPageReady,
}) {
  const pageRef    = useRef();
  const canvasRef  = useRef();
  const textRef    = useRef();
  const renderTask = useRef(null);   // track active render so we can cancel on re-render

  // "idle" | "loading" | "rendering" | "ready" — local per page
  const [status, setStatus] = useState("loading");

  // ── Core render effect — re-runs whenever page/scale/rotation changes ────
  useEffect(() => {
    if (!pdfDoc || !canvasRef.current) return;

    // Cancel any in-flight render for the previous scale/rotation
    renderTask.current?.cancel();
    setStatus("loading");

    let cancelled = false;

    (async () => {
      try {
        // 1. Fetch just this one page — other pages are untouched
        const page     = await pdfDoc.getPage(pageNum);
        if (cancelled) return;
        setStatus("rendering");

        const viewport = page.getViewport({ scale, rotation });
        const canvas   = canvasRef.current;
        const ctx      = canvas.getContext("2d");

        // HiDPI support
        const dpr = window.devicePixelRatio || 1;
        canvas.width  = Math.floor(viewport.width  * dpr);
        canvas.height = Math.floor(viewport.height * dpr);
        canvas.style.width  = `${viewport.width}px`;
        canvas.style.height = `${viewport.height}px`;
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

        // 2. Render canvas — this is the real paint step
        const task = page.render({ canvasContext: ctx, viewport });
        renderTask.current = task;
        await task.promise;
        if (cancelled) return;

        // 3. Render text layer for selection/highlighting
        const textLayer = textRef.current;
        if (textLayer) {
          textLayer.innerHTML = "";
          textLayer.style.width  = `${viewport.width}px`;
          textLayer.style.height = `${viewport.height}px`;

          const textContent = await page.getTextContent({ includeMarkedContent: false });
          if (cancelled) return;

          // ── Build text layer manually from textContent items ────────────────
          // This avoids the pdfjs renderTextLayer API which changed between v4/v5
          // and gives us direct DOM control needed for word-level splitting.
          // Each text item becomes a <span> absolutely positioned using the same
          // transform math that pdfjs uses internally.
          buildTextLayer(textLayer, textContent, viewport);
          if (cancelled) return;

          // Split line-spans → individual word-spans for precise word capture
          requestAnimationFrame(() => {
            if (!cancelled) splitTextLayerSpans(textLayer);
          });
        }

        // 5. Done — notify parent; pass canvas element so it can read dimensions
        setStatus("ready");
        onPageReady?.(pageNum, canvasRef.current);

        // Cache word positions for lasso/dblclick capture
        // (getPageWords will cache internally on first call)
        getPageWords(pdfDoc, pageNum);

      } catch (err) {
        if (err?.name === "RenderingCancelledException") return;
        if (!cancelled) setStatus("error");
        console.warn("PDFPage render error:", err);
      }
    })();

    return () => {
      cancelled = true;
      renderTask.current?.cancel();
    };
  }, [pdfDoc, pageNum, scale, rotation, onPageReady]);

  // ── Lasso drag-box word capture ───────────────────────────────────────────
  const handleLassoSelect = useCallback(async (boxFrac) => {
    if (!activeFieldId || !pdfDoc) return;
    const words  = await getPageWords(pdfDoc, pageNum);
    const inside = words.filter(w =>
      overlaps(
        { x: boxFrac.x, y: boxFrac.y, w: boxFrac.w, h: boxFrac.h },
        { x: w.x, y: w.y, w: w.w, h: w.h }
      )
    );
    if (!inside.length) return;
    inside.sort((a, b) => a.y !== b.y ? a.y - b.y : a.x - b.x);
    const text = inside.map(w => w.word).join(" ");
    const minX = Math.min(...inside.map(w => w.x));
    const minY = Math.min(...inside.map(w => w.y));
    const maxX = Math.max(...inside.map(w => w.x + w.w));
    const maxY = Math.max(...inside.map(w => w.y + w.h));
    onCapture(activeFieldId, text, pageNum, {
      x: minX, y: minY, width: maxX - minX, height: maxY - minY,
      wordBoxes: inside.map(w => ({ x: w.x, y: w.y, width: w.w, height: w.h })),
    });
  }, [activeFieldId, pdfDoc, pageNum, onCapture]);

  // ── Double-click nearest word capture ────────────────────────────────────
  const handleDblClickWord = useCallback(async ({ fx, fy }) => {
    if (!activeFieldId || !pdfDoc) return;
    const words = await getPageWords(pdfDoc, pageNum);
    if (!words.length) return;
    let best = null, bestScore = Infinity;
    for (const w of words) {
      const dist  = Math.hypot(w.x + w.w / 2 - fx, w.y + w.h / 2 - fy);
      const inner = fx >= w.x && fx <= w.x + w.w && fy >= w.y && fy <= w.y + w.h;
      const score = inner ? dist - 9999 : dist;
      if (score < bestScore) { bestScore = score; best = w; }
    }
    if (!best) return;
    onCapture(activeFieldId, best.word, pageNum, {
      x: best.x, y: best.y, width: best.w, height: best.h,
      wordBoxes: [{ x: best.x, y: best.y, width: best.w, height: best.h }],
    });
  }, [activeFieldId, pdfDoc, pageNum, onCapture]);

  // ── Viewport size from canvas (for overlay alignment) ────────────────────
  const canvasW = canvasRef.current?.style.width  || "612px";
  const canvasH = canvasRef.current?.style.height || "792px";

  return (
    <div ref={pageRef} style={{ marginBottom: 24, position: "relative" }}>
      <div style={{
        position: "absolute", top: -18, left: 0,
        fontSize: 10, color: C.dim, fontFamily: "monospace", userSelect: "none",
      }}>
        Page {pageNum}
      </div>

      {/* Outer wrapper — sized to canvas */}
      <div style={{ position: "relative", display: "inline-block", lineHeight: 0 }}>

        {/* Shimmer placeholder while loading/rendering */}
        {status !== "ready" && (
          <div style={{
            position: "absolute", inset: 0, zIndex: 20,
            background: C.bg, display: "flex",
            flexDirection: "column", gap: 10,
            padding: "24px 20px", pointerEvents: "none",
            minWidth: Math.round(612 * scale),
            minHeight: Math.round(792 * scale),
          }}>
            <div style={{
              fontSize: 11, color: C.muted, marginBottom: 8,
              display: "flex", alignItems: "center", gap: 6,
            }}>
              <span style={{ animation: "pulseDot 1s ease-in-out infinite", display: "inline-block" }}>⬤</span>
              {status === "loading" ? `Loading page ${pageNum}…` : `Rendering page ${pageNum}…`}
            </div>
            {Array.from({ length: 16 }, (_, i) => (
              <div key={i} style={{
                height: 11, borderRadius: 3,
                width: `${52 + ((i * 41) % 44)}%`,
                background: `linear-gradient(90deg, ${C.border} 25%, ${C.surface2} 50%, ${C.border} 75%)`,
                backgroundSize: "200% 100%",
                animation: "shimmer 1.4s ease-in-out infinite",
                animationDelay: `${i * 0.055}s`,
              }} />
            ))}
          </div>
        )}

        {/* The actual PDF canvas — always mounted so ref is stable */}
        <canvas ref={canvasRef} style={{ display: "block" }} />

        {/* Text layer — positioned absolutely over canvas */}
        <div
          ref={textRef}
          className="pdf-text-layer"
          style={{
            position: "absolute", top: 0, left: 0,
            overflow: "hidden", opacity: 1,
            lineHeight: 1, userSelect: "text",
          }}
        />

        {/* Highlight overlay */}
        <HLOverlay
          pageNum={pageNum}
          allCaptured={allCaptured}
          activeFieldId={activeFieldId}
          searches={searches}
          external={external}
        />

        {/* Lasso draw layer */}
        <LassoOverlay
          active={!!activeFieldId && boxMode}
          onSelect={handleLassoSelect}
          onDblClickWord={handleDblClickWord}
          pageRef={canvasRef}
        />
      </div>
    </div>
  );
}


// LazyPage removed — single-page view used instead

// ─── Toolbar primitives ──────────────────────────────────────────────────────
function TbBtn({ icon, title, onClick, disabled, active }) {
  const [hov, setHov] = useState(false);
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      title={title}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        display: "flex", alignItems: "center", justifyContent: "center",
        width: 30, height: 30, borderRadius: 4, border: "none",
        background: active ? C.accentDim : hov && !disabled ? C.surface2 : "none",
        color: disabled ? C.dim : active ? C.accent : hov ? C.text : C.muted,
        cursor: disabled ? "not-allowed" : "pointer",
        fontSize: 14, fontFamily: "inherit",
        transition: "background .12s, color .12s",
        flexShrink: 0,
      }}
    >{icon}</button>
  );
}
function TbSep() {
  return (
    <div style={{
      width: 1, height: 20, background: C.border,
      margin: "0 4px", flexShrink: 0,
    }} />
  );
}

// ─── Thumbnail strip ──────────────────────────────────────────────────────────
function Thumbs({ total, current, onJump }) {
  const ref = useRef();
  useEffect(() => {
    ref.current?.querySelector(`[data-p="${current}"]`)
      ?.scrollIntoView({ block: "nearest", behavior: "smooth" });
  }, [current]);

  return (
    <div ref={ref} style={{
      width: 86, background: C.surface, borderRight: `1px solid ${C.border}`,
      overflowY: "auto", flexShrink: 0,
      scrollbarWidth: "thin", scrollbarColor: `${C.border} transparent`,
    }}>
      {Array.from({ length: total }, (_, i) => i + 1).map(p => (
        <div key={p} data-p={p} onClick={() => onJump(p)} style={{
          margin: "6px auto", width: 62, cursor: "pointer",
          border: `2px solid ${p === current ? C.accent : C.border}`,
          borderRadius: 4, overflow: "hidden", background: C.bg,
          transition: "border-color .2s",
        }}>
          <div style={{
            height: 78,
            background: p === current ? C.accentDim : C.bg,
            display: "flex", flexDirection: "column",
            alignItems: "center", justifyContent: "center", gap: 4,
          }}>
            {[40, 30, 36, 24, 34].map((w, i) => (
              <div key={i} style={{ width: w, height: 2, background: C.border, borderRadius: 1 }} />
            ))}
          </div>
          <div style={{
            textAlign: "center", fontSize: 10, padding: "2px 0 4px",
            color: p === current ? C.accent : C.dim, fontFamily: "monospace",
          }}>{p}</div>
        </div>
      ))}
    </div>
  );
}

// ─── Legend ───────────────────────────────────────────────────────────────────
function Legend({ lassoActive }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      {lassoActive && (
        <div style={{
          display: "flex", alignItems: "center", gap: 7,
          background: "rgba(79,142,247,0.09)",
          border: `1px dashed ${C.accent}`,
          borderRadius: 5, padding: "5px 9px",
          fontSize: 11, color: C.accent,
        }}>
          <span style={{ fontSize: 15 }}>⬚</span>
          Drag box to capture · dblclick a single word
        </div>
      )}
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        {[
          [C.active,      C.activeBdr,      "Active"],
          [C.activeDup,   C.activeDupBdr,   "Dup of active"],
          [C.captured,    C.capturedBdr,    "Captured"],
          [C.ext,         C.extBdr,         "External"],
          [C.srch,        C.srchBdr,        "Search"],
        ].map(([bg, bdr, label]) => (
          <div key={label} style={{ display: "flex", alignItems: "center", gap: 4 }}>
            <div style={{ width: 13, height: 9, background: bg, border: `2px solid ${bdr}`, borderRadius: 2 }} />
            <span style={{ fontSize: 10, color: C.muted }}>{label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Root Application ─────────────────────────────────────────────────────────
export default function PDFFormViewer() {
  const [pdfFile,     setPdfFile]     = useState(null);
  const [numPages,    setNumPages]    = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [scale,       setScale]       = useState(1.2);
  const [rotation,    setRotation]    = useState(0);
  const [jumpVal,     setJumpVal]     = useState("");
  const [srchInput,   setSrchInput]   = useState("");
  const [srchQuery,   setSrchQuery]   = useState("");
  const [fields,      setFields]      = useState(INITIAL_FIELDS);
  const [activeField, setActiveField] = useState(null);
  const [searches,    setSearches]    = useState([]);
  const [pdfDoc,      setPdfDoc]      = useState(null);
  const [showThumbs,  setShowThumbs]  = useState(true);
  const [isDrag,      setIsDrag]      = useState(false);
  const [zoomMode,    setZoomMode]    = useState("custom"); // custom | page-width | page-fit | actual
  const [boxMode,     setBoxMode]     = useState(true);
  // Tracks render state of the currently visible page
  // "loading" | "rendering" | "ready"
  const [pageStatus,  setPageStatus]  = useState("loading");
  // Stores rendered page dimensions {w,h} in CSS px — used to size placeholders
  const [pageSize,    setPageSize]    = useState({ w: Math.round(612 * 1.2), h: Math.round(792 * 1.2) });
  const viewerScrollRef  = useRef(null);
  const viewerWrapRef    = useRef(null);   // wraps the scroll area — used for page-width calc

  // Flatten all captures across all fields for highlight overlay
  const allCaptured = fields.flatMap(f =>
    f.captures.map(cap => ({ ...cap, fieldId: f.id }))
  );

  // ── Load PDF directly via pdfjs.getDocument() ────────────────────────────
  // This loads the document structure (xref, page count) but does NOT render
  // any pages — each page fetches and renders independently via PDFPage.
  const onLoad = useCallback(({ numPages: n }) => {
    setNumPages(n); setCurrentPage(1); wordCache.clear();
    setPageStatus("loading");
  }, []);

  useEffect(() => {
    if (!pdfFile) return;
    let cancelled = false;
    setPdfDoc(null);
    setNumPages(0);
    setPageStatus("loading");
    wordCache.clear();

    const task = pdfjs.getDocument({
      url: pdfFile,
      // disableStream: false lets the browser start rendering page 1
      // while the rest of the PDF bytes are still downloading
      disableStream: false,
      disableAutoFetch: false,
    });

    task.promise.then(doc => {
      if (cancelled) return;
      setPdfDoc(doc);
      setNumPages(doc.numPages);
      setCurrentPage(1);
    }).catch(err => {
      if (!cancelled) console.error("PDF load error:", err);
    });

    return () => {
      cancelled = true;
      task.destroy?.();
    };
  }, [pdfFile]);

  // ── scrollToPage: teleport without visible scrolling animation ─────────────
  // Strategy: hide the scroll container's overflow, set scrollTop directly to
  // the target slot's offsetTop, then re-enable overflow in the next frame.
  // This is invisible to the user — no flash of intermediate pages.
  const scrollToPage = useCallback((n) => {
    const container = viewerScrollRef.current;
    if (!container) return;
    const slot = document.getElementById(`page-slot-${n}`);
    if (!slot) return;

    // 1. Hide scrollbar + clip content so no intermediate frames are painted
    container.style.overflow = "hidden";

    // 2. Calculate target scrollTop: slot's top relative to the scroll container
    //    We can't use scrollIntoView (browser may animate it), so use offsetTop
    //    walking up the offset chain until we hit the container.
    let top = 0;
    let el  = slot;
    while (el && el !== container) {
      top += el.offsetTop;
      el   = el.offsetParent;
    }
    container.scrollTop = top;

    // 3. Re-enable overflow on next frame (after the paint at new position)
    requestAnimationFrame(() => {
      if (viewerScrollRef.current) {
        viewerScrollRef.current.style.overflow = "";
      }
    });
  }, []);

  // ── Jump — instant page teleport ──────────────────────────────────────────
  const jump = useCallback((pg) => {
    const n = parseInt(pg);
    if (!isNaN(n) && n >= 1 && n <= numPages) {
      setCurrentPage(n);
      setJumpVal("");
      // Use rAF so the slot div is guaranteed to be in the DOM
      requestAnimationFrame(() => scrollToPage(n));
    }
  }, [numPages, scrollToPage]);

  // ── Zoom / Rotate ─────────────────────────────────────────────────────────
  const applyZoomMode = useCallback((mode, currentScale) => {
    const wrap = viewerWrapRef.current;
    if (!wrap) return currentScale;
    const w = wrap.clientWidth - 56;   // minus padding
    const h = wrap.clientHeight - 56;
    const PAGE_W = 612, PAGE_H = 792;  // standard PDF points
    if (mode === "page-width") return Math.max(0.4, +(w / PAGE_W).toFixed(2));
    if (mode === "page-fit")   return Math.max(0.4, +(Math.min(w / PAGE_W, h / PAGE_H)).toFixed(2));
    if (mode === "actual")     return 1.0;
    return currentScale;
  }, []);

  const setZoom = useCallback((mode, delta = 0) => {
    setZoomMode(mode);
    setScale(prev => {
      if (mode === "custom") return Math.max(0.4, Math.min(+(prev + delta).toFixed(1), 4));
      return applyZoomMode(mode, prev);
    });
  }, [applyZoomMode]);

  const zoomIn    = () => setZoom("custom",  0.2);
  const zoomOut   = () => setZoom("custom", -0.2);
  const rotate    = () => setRotation(r => (r + 90) % 360);
  const rotateCCW = () => setRotation(r => (r - 90 + 360) % 360);

  // Keep placeholder size in sync when scale changes (before any page renders)
  useEffect(() => {
    setPageSize(prev => ({
      w: Math.round((prev.w / (scale || 1.2)) * scale),
      h: Math.round((prev.h / (scale || 1.2)) * scale),
    }));
  }, [scale]);

  // Re-apply mode-based zoom on container resize
  useEffect(() => {
    if (zoomMode === "custom") return;
    const ob = new ResizeObserver(() => {
      setScale(applyZoomMode(zoomMode, scale));
    });
    if (viewerWrapRef.current) ob.observe(viewerWrapRef.current);
    return () => ob.disconnect();
  }, [zoomMode, applyZoomMode, scale]);

  // ── Page-ready callback (fired by PDFPage after canvas is painted) ────────
  const onPageReady = useCallback((pageNum, canvasEl) => {
    setPageStatus("ready");
    setTimeout(() => setPageStatus(s => s === "ready" ? "idle" : s), 2000);
    // Capture real canvas size so placeholders match exactly
    if (canvasEl) {
      const w = parseFloat(canvasEl.style.width)  || canvasEl.offsetWidth;
      const h = parseFloat(canvasEl.style.height) || canvasEl.offsetHeight;
      if (w > 0 && h > 0) setPageSize({ w, h });
    }
  }, []);

  // ── Lasso capture ─────────────────────────────────────────────────────────
  // capture: { word, page, x, y, width, height, wordBoxes[] }
  const onCapture = useCallback((fieldId, text, page, coords) => {
    setFields(prev => prev.map(f => {
      if (f.id !== fieldId) return f;
      // Keep only the latest capture (replace previous for this field)
      return {
        ...f,
        value: text,
        captures: [{ word: text, page, ...coords }],
      };
    }));
  }, []);

  // ── Field focus → teleport viewer to captured page ─────────────────────
  const onFieldFocus = useCallback((fieldId) => {
    setActiveField(fieldId);
    const field = fields.find(f => f.id === fieldId);
    const cap   = field?.captures?.[0];
    if (cap && cap.page) {
      setCurrentPage(cap.page);
      requestAnimationFrame(() => scrollToPage(cap.page));
    }
  }, [fields, scrollToPage]);

  // ── Search ────────────────────────────────────────────────────────────────
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const runSearch = useCallback(debounce(async (q) => {
    if (!q.trim() || !pdfDoc) { setSearches([]); return; }
    const lo   = q.toLowerCase();
    const hits = [];
    for (let pg = 1; pg <= numPages; pg++) {
      const words = await getPageWords(pdfDoc, pg);
      for (const w of words) {
        if (w.word.toLowerCase().includes(lo)) {
          hits.push({ page: pg, x: w.x, y: w.y, width: w.w, height: w.h });
        }
      }
    }
    setSearches(hits);
    if (hits.length) { setCurrentPage(hits[0].page); requestAnimationFrame(() => scrollToPage(hits[0].page)); }
  }, 600), [pdfDoc, numPages, scrollToPage]);

  useEffect(() => { runSearch(srchQuery); }, [srchQuery, runSearch]);

  // ── File load ─────────────────────────────────────────────────────────────
  const loadFile = (f) => {
    if (!f || f.type !== "application/pdf") return;
    setPdfFile(URL.createObjectURL(f));  // triggers useEffect above
    setFields(INITIAL_FIELDS);
    setActiveField(null);
    setSearches([]);
    // currentPage + numPages reset handled in the useEffect
  };

  // ── Export ────────────────────────────────────────────────────────────────
  const doExport = () => {
    const data = fields.map(f => ({
      field:  f.label,
      value:  f.value,
      page:   f.captures[0]?.page ?? null,
    }));
    alert(JSON.stringify(data, null, 2));
  };

  // ─────────────────────────────────────────────────────────────────────────
  const activeLabel = fields.find(f => f.id === activeField)?.label;

  return (
    <div style={{
      fontFamily: "'IBM Plex Mono','Fira Code','Courier New',monospace",
      background: C.bg, color: C.text,
      height: "100vh", display: "flex", flexDirection: "column", overflow: "hidden",
    }}>

      {/* ══ Unified Toolbar ══ */}
      <div style={{
        background: C.surface, borderBottom: `1px solid ${C.border}`,
        height: 44, display: "flex", alignItems: "center",
        padding: "0 10px", gap: 2, flexShrink: 0, userSelect: "none",
      }}>

        {/* ── LEFT GROUP: sidebar + file ── */}
        <TbBtn icon="☰" title="Toggle thumbnails" active={showThumbs}
          onClick={() => setShowThumbs(v => !v)} />
        <TbSep />

        <label title="Open PDF" style={{
          display: "flex", alignItems: "center", justifyContent: "center",
          width: 30, height: 30, borderRadius: 4, cursor: "pointer",
          color: C.muted, fontSize: 16,
          background: "none", border: "none",
          transition: "background .15s, color .15s",
        }}
          onMouseEnter={e => { e.currentTarget.style.background = C.surface2; e.currentTarget.style.color = C.text; }}
          onMouseLeave={e => { e.currentTarget.style.background = "none"; e.currentTarget.style.color = C.muted; }}
        >
          📂
          <input type="file" accept=".pdf" style={{ display: "none" }}
            onChange={e => loadFile(e.target.files[0])} />
        </label>

        <TbSep />

        {/* ── CENTER GROUP: navigation ── */}
        <TbBtn icon="⏮" title="First page"    disabled={currentPage <= 1 || !pdfFile}     onClick={() => jump(1)} />
        <TbBtn icon="‹"  title="Previous page" disabled={currentPage <= 1 || !pdfFile}     onClick={() => jump(currentPage - 1)} />

        {/* Page input */}
        <div style={{ display: "flex", alignItems: "center", gap: 4, padding: "0 4px" }}>
          <input
            value={jumpVal}
            onChange={e => setJumpVal(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter") { jump(jumpVal); } }}
            onBlur={() => { if (jumpVal) jump(jumpVal); }}
            placeholder={pdfFile ? String(currentPage) : "—"}
            disabled={!pdfFile}
            style={{
              width: 42, background: C.bg, border: `1px solid ${C.border}`,
              borderRadius: 4, color: C.text, padding: "3px 5px",
              fontSize: 12, textAlign: "center", outline: "none", fontFamily: "inherit",
              opacity: pdfFile ? 1 : 0.4,
            }}
          />
          <span style={{ fontSize: 11, color: C.dim, whiteSpace: "nowrap" }}>
            of {pdfFile ? numPages : "—"}
          </span>

          {/* Page render status dot */}
          {pdfFile && (
            <span title={
              pageStatus === "loading"   ? "Loading page…"   :
              pageStatus === "rendering" ? "Rendering page…" :
              pageStatus === "ready"     ? "Page ready"      : ""
            } style={{
              width: 7, height: 7, borderRadius: "50%", flexShrink: 0,
              background:
                pageStatus === "ready"     ? C.ok   :
                pageStatus === "loading" || pageStatus === "rendering" ? C.warn : C.dim,
              boxShadow:
                pageStatus === "ready" ? `0 0 6px ${C.ok}` :
                pageStatus === "loading" || pageStatus === "rendering"
                  ? `0 0 6px ${C.warn}` : "none",
              animation:
                pageStatus === "loading" || pageStatus === "rendering"
                  ? "pulseDot 1s ease-in-out infinite" : "none",
              transition: "background .3s, box-shadow .3s",
            }} />
          )}
        </div>

        <TbBtn icon="›"  title="Next page"    disabled={currentPage >= numPages || !pdfFile} onClick={() => jump(currentPage + 1)} />
        <TbBtn icon="⏭" title="Last page"    disabled={currentPage >= numPages || !pdfFile} onClick={() => jump(numPages)} />

        <TbSep />

        {/* ── ZOOM GROUP ── */}
        <TbBtn icon="−" title="Zoom out" disabled={!pdfFile} onClick={zoomOut} />
        <TbBtn icon="+" title="Zoom in"  disabled={!pdfFile} onClick={zoomIn}  />

        {/* Zoom dropdown */}
        <select
          disabled={!pdfFile}
          value={zoomMode !== "custom" ? zoomMode : `${Math.round(scale * 100)}%`}
          onChange={e => {
            const v = e.target.value;
            if (v === "page-width" || v === "page-fit" || v === "actual") {
              setZoom(v);
            } else if (v.endsWith("%")) {
              const pct = parseInt(v);
              if (!isNaN(pct)) { setZoomMode("custom"); setScale(pct / 100); }
            }
          }}
          style={{
            background: C.bg, border: `1px solid ${C.border}`,
            color: pdfFile ? C.text : C.dim, borderRadius: 4,
            padding: "3px 6px", fontSize: 12, outline: "none",
            fontFamily: "inherit", cursor: "pointer", width: 118,
            opacity: pdfFile ? 1 : 0.5,
          }}
        >
          <option value={`${Math.round(scale * 100)}%`}>{Math.round(scale * 100)}%</option>
          <option disabled>──────────</option>
          <option value="actual">Actual Size (100%)</option>
          <option value="page-fit">Page Fit</option>
          <option value="page-width">Page Width</option>
          <option disabled>──────────</option>
          {[50,75,100,125,150,200,300,400].map(p => (
            <option key={p} value={`${p}%`}
              onClick={() => setZoom("custom", p/100 - scale)}
            >{p}%</option>
          ))}
        </select>

        <TbSep />

        {/* ── ROTATE GROUP ── */}
        <TbBtn icon="↺" title="Rotate counter-clockwise" disabled={!pdfFile} onClick={rotateCCW} />
        <TbBtn icon="↻" title="Rotate clockwise"         disabled={!pdfFile} onClick={rotate}    />

        <TbSep />

        {/* ── SEARCH ── */}
        <div style={{ position: "relative" }}>
          <span style={{
            position: "absolute", left: 7, top: "50%", transform: "translateY(-50%)",
            color: C.dim, fontSize: 13, pointerEvents: "none",
          }}>🔍</span>
          <input
            value={srchInput}
            onChange={e => { setSrchInput(e.target.value); setSrchQuery(e.target.value); }}
            placeholder="Search…"
            disabled={!pdfFile}
            style={{
              background: C.bg, border: `1px solid ${C.border}`, borderRadius: 4,
              color: C.text, padding: "4px 28px 4px 24px", fontSize: 12,
              width: 150, outline: "none", fontFamily: "inherit",
              opacity: pdfFile ? 1 : 0.5,
            }}
          />
          {searches.length > 0 && (
            <span style={{
              position: "absolute", right: 7, top: "50%", transform: "translateY(-50%)",
              fontSize: 10, color: C.warn, pointerEvents: "none",
            }}>{searches.length}</span>
          )}
        </div>

        {/* ── RIGHT GROUP: box mode + capture status ── */}
        <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 6 }}>
          {/* Active capture indicator */}
          {activeField && (
            <div style={{
              display: "flex", alignItems: "center", gap: 6,
              background: "rgba(79,142,247,0.12)", border: `1px dashed ${C.accent}`,
              borderRadius: 4, padding: "2px 9px", fontSize: 11, color: C.accent,
            }}>
              <span style={{ animation: "blink 1.2s step-start infinite", fontSize: 9 }}>●</span>
              <span>Drag / dblclick → <b>{activeLabel}</b></span>
              <button onClick={() => setActiveField(null)} style={{
                background: "none", border: "none", color: C.danger,
                cursor: "pointer", fontSize: 12, padding: 0, lineHeight: 1,
              }}>✕</button>
            </div>
          )}

          <TbSep />

          {/* Box Mode toggle */}
          <button
            onClick={() => setBoxMode(v => !v)}
            title="Toggle box-draw capture mode"
            style={{
              display: "flex", alignItems: "center", gap: 6,
              background: boxMode ? C.accent : "rgba(255,255,255,0.05)",
              border: `1px solid ${boxMode ? C.accent : C.border}`,
              color: boxMode ? "#fff" : C.muted,
              borderRadius: 4, padding: "3px 10px", cursor: "pointer",
              fontSize: 11, fontFamily: "inherit", fontWeight: 600,
              letterSpacing: 0.3, transition: "all .18s",
            }}
          >
            ⬚ Box Mode {boxMode ? "ON" : "OFF"}
          </button>

          {/* Logo */}
          <TbSep />
          <span style={{ fontSize: 13, fontWeight: 700, color: C.accent, letterSpacing: 1, paddingLeft: 2 }}>
            ⬡
          </span>
        </div>
      </div>

      {/* ── Body ── */}
      <div style={{ display: "flex", flex: 1, overflow: "hidden" }}>

        {/* ── PDF Side ── */}
        <div style={{ flex: 1, display: "flex", overflow: "hidden" }}>
          {showThumbs && numPages > 0 && (
            <Thumbs total={numPages} current={currentPage} onJump={jump} />
          )}

          {/* ── Single-page viewer ── */}
          <div
            ref={el => { viewerScrollRef.current = el; viewerWrapRef.current = el; }}
            style={{
              flex: 1, overflowY: "auto", overflowX: "auto",
              padding: "24px 28px", background: C.bg,
              scrollbarWidth: "thin", scrollbarColor: `${C.border} transparent`,
            }}
            onDragOver={e => { e.preventDefault(); setIsDrag(true); }}
            onDragLeave={() => setIsDrag(false)}
            onDrop={e => { e.preventDefault(); setIsDrag(false); loadFile(e.dataTransfer.files[0]); }}
          >
            {!pdfFile ? (
              <div style={{
                height: "100%", minHeight: 300,
                display: "flex", flexDirection: "column",
                alignItems: "center", justifyContent: "center", gap: 14,
                border: `2px dashed ${isDrag ? C.accent : C.border}`,
                borderRadius: 10, transition: "border-color .2s",
              }}>
                <div style={{ fontSize: 60, opacity: .15 }}>⬡</div>
                <div style={{ color: C.muted, fontSize: 14 }}>
                  Drop a PDF or click <b style={{ color: C.accent }}>Open PDF</b>
                </div>
              </div>
            ) : !pdfDoc ? (
              <div style={{
                display: "flex", flexDirection: "column",
                alignItems: "center", justifyContent: "center",
                gap: 12, paddingTop: 80, color: C.muted, fontSize: 13,
              }}>
                <span style={{ fontSize: 28, animation: "pulseDot 1s ease-in-out infinite" }}>⬤</span>
                Parsing PDF structure…
              </div>
            ) : (
              /* Scrollable virtualised page list — all slots mounted, only nearby pages rendered */
              <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-start" }}>
                {Array.from({ length: numPages }, (_, i) => i + 1).map(pg => (
                  <VirtualPageSlot
                    key={pg}
                    pageNum={pg}
                    currentPage={currentPage}
                    pageSize={pageSize}
                    onVisible={setCurrentPage}
                    scale={scale}
                    rotation={rotation}
                    activeFieldId={activeField}
                    boxMode={boxMode}
                    pdfDoc={pdfDoc}
                    onPageReady={onPageReady}
                    onCapture={onCapture}
                    allCaptured={allCaptured}
                    searches={searches}
                    external={EXTERNAL_HIGHLIGHTS}
                  />
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Divider */}
        <div style={{ width: 1, background: C.border, flexShrink: 0 }} />

        {/* ── Right: Field Panel ── */}
        <div style={{
          width: 330, background: C.surface,
          display: "flex", flexDirection: "column",
          overflow: "hidden", flexShrink: 0,
        }}>
          {/* Header */}
          <div style={{
            padding: "12px 16px", borderBottom: `1px solid ${C.border}`,
            display: "flex", flexDirection: "column", gap: 10,
          }}>
            <div style={{ fontSize: 12, color: C.accent, fontWeight: 700, letterSpacing: .5 }}>
              FIELD EXTRACTOR
            </div>
            <Legend lassoActive={!!activeField} />
          </div>

          {/* Fields list */}
          <div style={{
            flex: 1, overflowY: "auto", padding: "12px 14px",
            display: "flex", flexDirection: "column", gap: 10,
            scrollbarWidth: "thin", scrollbarColor: `${C.border} transparent`,
          }}>
            {fields.map(field => {
              const isActive = activeField === field.id;
              const cap      = field.captures[0];
              const allNorms = allCaptured.map(c => norm(c.word));
              const dupes    = cap
                ? allNorms.filter(n => n === norm(cap.word)).length - 1
                : 0;

              return (
                <div key={field.id} style={{
                  border: `1px solid ${isActive ? C.accent : C.border}`,
                  borderRadius: 6, overflow: "hidden",
                  background: isActive ? C.activeField : C.bg,
                  boxShadow: isActive ? `0 0 0 2px ${C.accentGlow}` : "none",
                  transition: "all .2s",
                }}>
                  {/* Label row */}
                  <div style={{
                    padding: "6px 10px",
                    display: "flex", alignItems: "center", justifyContent: "space-between",
                    borderBottom: `1px solid ${C.border}`,
                    cursor: "pointer",
                  }} onClick={() => onFieldFocus(field.id)}>
                    <label style={{
                      fontSize: 10, fontWeight: 600, letterSpacing: .5, cursor: "pointer",
                      color: isActive ? C.accent : C.muted,
                    }}>
                      {field.label.toUpperCase()}
                    </label>
                    <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                      {dupes > 0 && (
                        <span style={{
                          fontSize: 9, color: C.danger,
                          background: "rgba(248,113,113,0.12)",
                          border: "1px solid rgba(248,113,113,0.3)",
                          borderRadius: 3, padding: "1px 5px",
                        }}>{dupes} dup</span>
                      )}
                      {cap && <span style={{ fontSize: 9, color: C.dim }}>p.{cap.page}</span>}
                      {/* Activate lasso button */}
                      <button
                        onClick={e => { e.stopPropagation(); setActiveField(isActive ? null : field.id); }}
                        title={isActive ? "Cancel selection" : "Draw box on PDF to capture"}
                        style={{
                          background: isActive ? C.accentDim : "rgba(255,255,255,0.04)",
                          border: `1px solid ${isActive ? C.accent : C.border}`,
                          color: isActive ? C.accent : C.dim,
                          borderRadius: 3, padding: "1px 7px",
                          cursor: "pointer", fontSize: 11, fontFamily: "inherit",
                        }}
                      >
                        {isActive ? "⬚ drawing…" : "⬚ pick"}
                      </button>
                    </div>
                  </div>

                  {/* Text input */}
                  <div style={{ padding: "7px 10px" }}>
                    <input
                      value={field.value}
                      onChange={e => setFields(prev => prev.map(f =>
                        f.id === field.id ? { ...f, value: e.target.value } : f
                      ))}
                      onFocus={() => onFieldFocus(field.id)}
                      placeholder={isActive ? "Draw a box on the PDF…" : "Click ⬚ pick, then draw on PDF"}
                      style={{
                        width: "100%", background: "transparent", border: "none",
                        color: cap ? C.text : C.dim,
                        fontSize: 12, outline: "none", fontFamily: "inherit",
                        boxSizing: "border-box",
                      }}
                    />
                  </div>

                  {/* Captured words pills */}
                  {cap && (
                    <div style={{ padding: "0 10px 8px", display: "flex", flexWrap: "wrap", gap: 4 }}>
                      {/* Show each word individually if wordBoxes available */}
                      {(cap.wordBoxes
                        ? cap.word.split(" ")
                        : [cap.word]
                      ).map((w, i) => (
                        <span key={i} style={{
                          fontSize: 11, color: C.ok,
                          background: "rgba(74,222,128,0.08)",
                          border: "1px solid rgba(74,222,128,0.2)",
                          borderRadius: 3, padding: "2px 7px",
                        }}>{w}</span>
                      ))}
                      <button
                        onClick={() => {
                          setFields(prev => prev.map(f =>
                            f.id === field.id ? { ...f, value: "", captures: [] } : f
                          ));
                        }}
                        style={{
                          background: "none", border: "none", color: C.danger,
                          cursor: "pointer", fontSize: 13, padding: "0 2px",
                        }}
                        title="Clear capture"
                      >✕</button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Export */}
          <div style={{ padding: "10px 14px", borderTop: `1px solid ${C.border}` }}>
            <button onClick={doExport} style={{
              width: "100%", background: C.accentDim,
              border: `1px solid ${C.accent}`, color: C.accent,
              borderRadius: 4, padding: 8, fontSize: 12,
              cursor: "pointer", fontFamily: "inherit", letterSpacing: .5,
            }}>
              EXPORT FIELDS ↗
            </button>
          </div>
        </div>
      </div>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600;700&display=swap');
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-thumb { background: #232b3e; border-radius: 3px; }
        .lasso-active * { user-select: none !important; }
        .react-pdf__Page__textContent { opacity: 0.95; }

        /* ── Text layer (direct pdfjs renderTextLayer output) ── */
        .pdf-text-layer { pointer-events: none; }
        .pdf-text-layer span { position: absolute; white-space: pre; cursor: text; }
        /* Word-spans injected by splitTextLayerSpans */
        .pdf-text-layer span[data-split="1"] { pointer-events: auto; }
        .pdf-text-layer span[data-split="1"] > span {
          cursor: pointer; border-radius: 2px; transition: background 0.1s;
          pointer-events: auto;
        }
        .pdf-text-layer span[data-split="1"] > span:hover {
          background: rgba(79,142,247,0.25) !important;
          outline: 1px solid rgba(79,142,247,0.55);
          outline-offset: 1px;
        }
        .pdf-text-layer > span:not([data-split]):hover {
          background: rgba(79,142,247,0.18) !important;
          cursor: pointer; pointer-events: auto;
        }
        @keyframes blink { 0%,100%{opacity:1} 50%{opacity:.3} }
        @keyframes shimmer {
          0%   { background-position: 200% 0; }
          100% { background-position: -200% 0; }
        }
        @keyframes pulseDot {
          0%,100% { opacity: 1; transform: scale(1); }
          50%     { opacity: 0.5; transform: scale(0.75); }
        }
      `}</style>
    </div>
  );
}
