// ImageViewer — virtual-scroll viewer for TIF/TIFF/PNG/JPEG/DOC pages
// Highlight system: each page owns its own subscription and canvas.
// No shared refs, no memo-staleness, no timing issues with hlRefs registration.

import React, { useEffect, useRef, useCallback, useState, memo } from 'react';
import { useAppStore } from '../store/appStore';
import type { ImageAdapter, ImageFrame } from '../adapters/ImageAdapter';
import { colorToRgba } from '../utils/color';

const PAGE_GAP = 12;
const RADIUS   = 2.5;
const OVERSCAN = 2;

interface ImageViewerProps { adapter: ImageAdapter; zoom: number; }

// ── Rounded rect helper ───────────────────────────────────────────────────────
function rr(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  if (w < 2 || h < 2) return;
  r = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.arcTo(x + w, y, x + w, y + r, r);
  ctx.lineTo(x + w, y + h - r); ctx.arcTo(x + w, y + h, x + w - r, y + h, r);
  ctx.lineTo(x + r, y + h); ctx.arcTo(x, y + h, x, y + h - r, r);
  ctx.lineTo(x, y + r); ctx.arcTo(x, y, x + r, y, r);
  ctx.closePath();
}

// ── Paint one page's highlight canvas ────────────────────────────────────────
// Called directly by each page's own subscription — reads from store at paint time.
// No cached state, no snapshots to go stale — always the freshest values.
function paintPage(canvas: HTMLCanvasElement, pageNum: number) {
  const W = canvas.width;
  const H = canvas.height;
  if (!W || !H) return;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const s    = useAppStore.getState();
  const rects = s.highlightIndex.get(pageNum) ?? [];
  const aid   = s.activeFieldId;

  // Build fwc fresh each paint — tiny map, negligible cost
  const fwc = new Map<string, string>();
  for (const c of s.captures) fwc.set(c.id, c.value.toLowerCase().trim());
  const activeTxt = aid ? (fwc.get(aid) ?? '') : '';
  const hasActive = !!aid;

  ctx.clearRect(0, 0, W, H);

  // ── Search results ─────────────────────────────────────────────────────────
  for (const r of s.search.results) {
    if (r.page !== pageNum) continue;
    const isCur = s.search.results.indexOf(r) === s.search.currentIndex;
    if (!isCur && !s.search.highlightAll) continue;
    ctx.save();
    if (isCur) {
      ctx.fillStyle = 'rgba(255,140,0,.45)'; ctx.strokeStyle = 'rgba(255,100,0,.95)';
      ctx.lineWidth = 2; ctx.shadowColor = 'rgba(255,140,0,.5)'; ctx.shadowBlur = 6;
    } else {
      ctx.fillStyle = 'rgba(255,220,50,.28)'; ctx.strokeStyle = 'rgba(200,160,0,.65)'; ctx.lineWidth = 1;
    }
    rr(ctx, r.x * W, r.y * H, r.width * W, r.height * H, RADIUS);
    ctx.fill(); ctx.stroke(); ctx.restore();
  }

  // ── Captured boxes ─────────────────────────────────────────────────────────
  // Colour rules (same as PDFViewer):
  //   active field        → YELLOW
  //   same text as active → PINK strong (duplicate value)
  //   other while active  → GREY  (not pink — user confirmed: others stay grey)
  //   nothing active      → GREY
  //   custom color        → that color
  const capturedKeys = new Set<number>();
  for (const rect of rects) {
    capturedKeys.add(Math.round(rect.x * 1000) * 10000 + Math.round(rect.y * 1000));
    const isAct = rect.id === aid;
    const isDup = !isAct && !!activeTxt && (fwc.get(rect.id) ?? '') === activeTxt;
    ctx.save();
    if (isAct) {
      ctx.shadowColor = 'rgba(220,180,0,.5)'; ctx.shadowBlur = 8;
      ctx.fillStyle = 'rgba(255,230,0,.35)'; ctx.strokeStyle = 'rgb(200,160,0)'; ctx.lineWidth = 2.5;
    } else if (isDup) {
      ctx.fillStyle = 'rgba(255,182,193,.50)'; ctx.strokeStyle = 'rgba(220,80,120,.95)'; ctx.lineWidth = 2.5;
    } else if (rect.color) {
      ctx.fillStyle = colorToRgba(rect.color, .07); ctx.strokeStyle = colorToRgba(rect.color, .95); ctx.lineWidth = 2.5;
    } else {
      ctx.fillStyle = 'rgba(150,150,150,.10)'; ctx.strokeStyle = 'rgba(80,80,80,.90)'; ctx.lineWidth = 2.0;
    }
    const PAD = 0.002;
    const bx = Math.max(0, rect.x - PAD);
    const by = Math.max(0, rect.y - PAD);
    const bw = Math.min(1 - bx, rect.width + PAD * 2);
    const bh = Math.min(1 - by, rect.height + PAD * 2);
    rr(ctx, bx * W, by * H, bw * W, bh * H, RADIUS);
    ctx.fill(); ctx.stroke(); ctx.restore();
  }

  // ── Word occurrences (wordIndex) ──────────────────────────────────────────
  // Rules:
  //   active field's word  → PINK duplicates (un-captured occurrences)
  //   all other fields' words → GREY (whether or not a field is active)
  if (s.wordIndex.size > 0) {
    const pageEntries = s.wordIndex.get(pageNum) ?? [];

    // Grey occurrences for every NON-active capture (always, regardless of active state)
    for (const cap of s.captures) {
      if (cap.id === aid) continue; // skip active — handled separately below
      const wt = fwc.get(cap.id) ?? ''; if (!wt) continue;
      ctx.fillStyle   = cap.color ? colorToRgba(cap.color, .07) : 'rgba(150,150,150,.10)';
      ctx.strokeStyle = cap.color ? colorToRgba(cap.color, .90) : 'rgba(80,80,80,.85)';
      ctx.lineWidth = 2.0;
      for (const e of pageEntries) {
        if (e.text.toLowerCase().trim() !== wt) continue;
        if (capturedKeys.has(Math.round(e.x * 1000) * 10000 + Math.round(e.y * 1000))) continue;
        const wx = Math.max(0, e.x - 0.0015), wy = Math.max(0, e.y - 0.0015);
        rr(ctx, wx * W, wy * H, Math.min(1 - wx, e.width + 0.003) * W, Math.min(1 - wy, e.height + 0.003) * H, RADIUS);
        ctx.fill(); ctx.stroke();
      }
    }

    // Pink occurrences for the active field's word (un-captured duplicates)
    if (aid && activeTxt) {
      ctx.fillStyle = 'rgba(255,182,193,.40)'; ctx.strokeStyle = 'rgba(220,80,120,.80)'; ctx.lineWidth = 1.5;
      for (const e of pageEntries) {
        if (e.text.toLowerCase().trim() !== activeTxt) continue;
        if (capturedKeys.has(Math.round(e.x * 1000) * 10000 + Math.round(e.y * 1000))) continue;
        const wx = Math.max(0, e.x - 0.0015), wy = Math.max(0, e.y - 0.0015);
        rr(ctx, wx * W, wy * H, Math.min(1 - wx, e.width + 0.003) * W, Math.min(1 - wy, e.height + 0.003) * H, RADIUS);
        ctx.fill(); ctx.stroke();
      }
    }
  }

  // ── Preview pulse (cyan) ───────────────────────────────────────────────────
  if (s.previewRect?.page === pageNum) {
    const pr = s.previewRect;
    ctx.save();
    ctx.fillStyle = 'rgba(6,182,212,.15)'; ctx.strokeStyle = 'rgba(6,182,212,.9)';
    ctx.lineWidth = 2; ctx.shadowColor = 'rgba(6,182,212,.5)'; ctx.shadowBlur = 6;
    rr(ctx, pr.x * W, pr.y * H, pr.width * W, pr.height * H, RADIUS);
    ctx.fill(); ctx.stroke(); ctx.restore();
  }
}

// ── Main viewer ───────────────────────────────────────────────────────────────
export function ImageViewer({ adapter, zoom }: ImageViewerProps) {
  const setCurrentPage = useAppStore(s => s.setCurrentPage);
  const rotation       = useAppStore(s => s.rotation);
  const pageCount      = adapter.pageCount;
  const containerRef   = useRef<HTMLDivElement>(null);

  const [visiblePages, setVisiblePages] = useState<Set<number>>(() => new Set([1, 2]));
  const visibleRef = useRef<Set<number>>(new Set([1, 2]));

  useEffect(() => {
    if (containerRef.current) containerRef.current.setAttribute('data-viewer-scroll', '1');
  }, []);

  // ── IntersectionObserver ──────────────────────────────────────────────────
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    const pageVis = new Map<number, number>();

    const obs = new IntersectionObserver(entries => {
      for (const e of entries) {
        const page = Number((e.target as HTMLElement).dataset.pageNumber);
        if (e.isIntersecting) pageVis.set(page, e.intersectionRatio);
        else                  pageVis.delete(page);
      }
      const visible = new Set<number>();
      const sorted  = [...pageVis.keys()].sort((a, b) => a - b);
      if (sorted.length) {
        const first = sorted[0], last = sorted[sorted.length - 1];
        for (let p = Math.max(1, first - OVERSCAN); p <= Math.min(pageCount, last + OVERSCAN); p++) visible.add(p);
        let best = sorted[0], bestR = 0;
        for (const [pg, ratio] of pageVis) if (ratio > bestR) { best = pg; bestR = ratio; }
        setCurrentPage(best);
      }
      const prev = visibleRef.current;
      if (visible.size !== prev.size || [...visible].some(p => !prev.has(p))) {
        visibleRef.current = visible;
        setVisiblePages(new Set(visible));
      }
    }, { root: container, threshold: [0, 0.1, 0.5] });

    container.querySelectorAll<HTMLElement>('[data-page-number]').forEach(el => obs.observe(el));
    return () => obs.disconnect();
  }, [pageCount, setCurrentPage]);

  // Re-render when background decode completes
  useEffect(() => {
    const cb = (page: number) => {
      if (visibleRef.current.has(page)) setVisiblePages(s => new Set(s));
    };
    adapter.onPageRendered(cb);
    return () => adapter.offPageRendered(cb);
  }, [adapter]);

  return (
    <div ref={containerRef} className="flex-1 overflow-y-auto overflow-x-auto bg-[#e8e8e8]">
      <div className="flex flex-col items-center py-4">
        {Array.from({ length: pageCount }, (_, i) => i + 1).map(page => (
          <ImagePageCanvas
            key={page}
            pageNum={page}
            adapter={adapter}
            zoom={zoom}
            rotation={rotation}
            visible={visiblePages.has(page)}
          />
        ))}
      </div>
    </div>
  );
}

// ── Per-page canvas ───────────────────────────────────────────────────────────
// Each page owns its own Zustand subscription and highlight canvas.
// No shared hlRefs map, no timing races, no memo-staleness.
interface ImagePageCanvasProps {
  pageNum:  number;
  adapter:  ImageAdapter;
  zoom:     number;
  rotation: number;
  visible:  boolean;
}

const ImagePageCanvas = memo(function ImagePageCanvas({
  pageNum, adapter, zoom, rotation, visible,
}: ImagePageCanvasProps) {
  const wrapperRef  = useRef<HTMLDivElement>(null);
  const canvasRef   = useRef<HTMLCanvasElement>(null);
  const hlCanvasRef = useRef<HTMLCanvasElement>(null);
  const timerRef    = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [frame, setFrame] = useState<ImageFrame | null>(() =>
    visible ? adapter.getFrame(pageNum) : null
  );

  const dims     = adapter.getPageDimensions(pageNum);
  const isFlipped = rotation === 90 || rotation === 270;
  const baseW    = dims ? (isFlipped ? dims.height : dims.width)  : 0;
  const baseH    = dims ? (isFlipped ? dims.width  : dims.height) : 0;
  const displayW = Math.round(baseW * zoom);
  const displayH = Math.round(baseH * zoom);

  // Register page element with adapter
  useEffect(() => {
    adapter.registerPageElement(pageNum, wrapperRef.current);
    return () => adapter.registerPageElement(pageNum, null);
  }, [adapter, pageNum]);

  // Fetch frame when visible
  useEffect(() => {
    if (!visible) return;
    const cached = adapter.getFrame(pageNum);
    if (cached) { setFrame(cached); return; }
    adapter.getFrameAsync(pageNum).then(f => setFrame(f)).catch(() => {});
  }, [visible, adapter, pageNum]);

  // Draw image
  useEffect(() => {
    if (!visible || !frame) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.width  = displayW;
    canvas.height = displayH;
    const ctx = canvas.getContext('2d')!;
    ctx.clearRect(0, 0, displayW, displayH);
    ctx.save();
    ctx.translate(displayW / 2, displayH / 2);
    ctx.rotate((rotation * Math.PI) / 180);
    ctx.drawImage(frame.bitmap,
      -(frame.width * zoom) / 2, -(frame.height * zoom) / 2,
      frame.width * zoom, frame.height * zoom,
    );
    ctx.restore();
    adapter.notifyPageRendered(pageNum);
  }, [frame, zoom, rotation, adapter, pageNum, visible, displayW, displayH]);

  // ── Highlight redraw helper — always reads fresh from store ───────────────
  const repaint = useCallback(() => {
    const hl = hlCanvasRef.current;
    if (!hl || !hl.width || !hl.height) return;
    paintPage(hl, pageNum);
  }, [pageNum]);

  // ── Size hl canvas and paint when dims/visibility/frame changes ───────────
  useEffect(() => {
    const hl = hlCanvasRef.current;
    if (!hl || !visible || !displayW || !displayH) return;
    hl.width  = displayW;
    hl.height = displayH;
    repaint();
  }, [displayW, displayH, visible, frame, repaint]);

  // ── Per-page store subscription ───────────────────────────────────────────
  // Each page subscribes independently — no shared state, no timing issues.
  // Debounced 16ms to batch rapid state changes (e.g. activeFieldId + previewRect).
  useEffect(() => {
    const unsub = useAppStore.subscribe((n, p) => {
      const changed =
        n.captures            !== p.captures            ||
        n.activeFieldId       !== p.activeFieldId       ||
        n.highlightIndex      !== p.highlightIndex      ||
        n.wordIndex           !== p.wordIndex           ||
        n.previewRect         !== p.previewRect         ||
        n.search.results      !== p.search.results      ||
        n.search.currentIndex !== p.search.currentIndex ||
        n.search.highlightAll !== p.search.highlightAll;
      if (!changed) return;
      if (timerRef.current) clearTimeout(timerRef.current);
      timerRef.current = setTimeout(() => {
        timerRef.current = null;
        repaint();
      }, 16);
    });
    // Paint immediately with current state
    repaint();
    return () => {
      unsub();
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [repaint]);

  return (
    <div
      ref={wrapperRef}
      data-page-number={pageNum}
      className="relative shadow-md"
      style={{
        marginBottom: PAGE_GAP,
        width:   displayW || 800,
        height:  displayH || 1100,
        background: (visible && frame) ? 'transparent' : '#d0d0d0',
        flexShrink: 0,
      }}
    >
      {visible && !frame && displayW > 0 && (
        <div style={{
          position: 'absolute', inset: 0, display: 'flex',
          alignItems: 'center', justifyContent: 'center',
          color: '#888', fontSize: 11,
        }}>
          <div style={{
            width: 20, height: 20, border: '2px solid #bbb',
            borderTopColor: '#1a7fd4', borderRadius: '50%',
            animation: 'spin 0.7s linear infinite',
          }} />
        </div>
      )}
      {visible && frame && (
        <canvas ref={canvasRef} style={{ width: displayW, height: displayH, display: 'block' }} />
      )}
      {!visible && <canvas ref={canvasRef} style={{ display: 'none' }} />}

      {/* Highlight canvas — always mounted when visible so preview box
          shows even before the image has finished decoding */}
      {visible && displayW > 0 && displayH > 0 && (
        <canvas
          ref={hlCanvasRef}
          width={displayW}
          height={displayH}
          style={{
            position: 'absolute', inset: 0,
            width: displayW, height: displayH,
            pointerEvents: 'none', zIndex: 11,
          }}
        />
      )}
    </div>
  );
});
