import {
  Component,
  OnInit,
  ViewChild,
  signal,
  ChangeDetectionStrategy,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { PdfViewerComponent, CapturedWordPayload } from './components/pdf-viewer/pdf-viewer.component';
import { ThumbnailOverlayComponent } from './components/thumbnail-overlay/thumbnail-overlay.component';
import { ThumbnailCategoryService, CategoryConfig } from './services/thumbnail-category.service';
import { FieldsPanelComponent } from './components/fields-panel/fields-panel.component';
import { PdfCaptureService } from './services/pdf-capture.service';
import { HttpClient } from '@angular/common/http';
import { WordCoordinate, CapturedFieldJson, CapturedFieldFormat } from './models/pdf-capture.models';
import { CaptureItem } from './services/pdf-capture.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, PdfViewerComponent, FieldsPanelComponent, ThumbnailOverlayComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="app-shell">
      <!-- Top Bar -->
      <header class="topbar">
        <div class="brand">
          <span class="brand-icon">◈</span>
          <span class="brand-name">PDF<span class="accent">Capture</span></span>
        </div>

        <div class="topbar-actions">
          <span class="coords-status" *ngIf="coordsLoadStatus()" [class.ok]="coordsLoadStatus().startsWith('✓')">
            {{ coordsLoadStatus() }}
          </span>
          <button class="btn-action" (click)="loadDemoExternalCoords()" title="Load coordinate JSON matching current PDF filename from assets/">
            <span>⊕</span> Load Coords
          </button>
          <button class="btn-action" (click)="clearAllFields()">
            <span>⊘</span> Clear All
          </button>
          <button class="btn-action btn-export" (click)="downloadCapturedFields()" title="Download all captured fields as JSON">
            <span>↓</span> Export JSON
          </button>
        </div>
      </header>

      <!-- Main Split Layout -->
      <div class="main-layout">
        <!-- LEFT: PDF Viewer -->
        <div class="pane pane-pdf" [style.width]="leftWidth + '%'">
          <app-pdf-viewer
            #pdfViewer
            [src]="pdfSrc()"
            [captureOnLoad]="true"
            (wordCaptured)="onWordCaptured($event)"
            (pdfNameChange)="onPdfNameChange($event)"
            (boxCaptured)="onBoxCaptured($event)"
            (thumbnailDrawn)="onThumbnailDrawn($event)"
          ></app-pdf-viewer>
        </div>

        <!-- Resize Handle -->
        <div
          class="resize-handle"
          (mousedown)="startResize($event)"
          title="Drag to resize"
        >
          <div class="handle-line"></div>
        </div>

        <!-- RIGHT: Fields Panel -->
        <div class="pane pane-fields">
          <app-fields-panel
            (goToWord)="onGoToWord($event)"
            (captureConfirmed)="onConfirmCapture()"
          ></app-fields-panel>
        </div>
      </div>
      <!-- Thumbnail overlay: renders nothing here, injects into sidebar DOM -->
      <app-thumbnail-overlay></app-thumbnail-overlay>
    </div>
  `,
  styles: [`
    @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;600;700&display=swap');

    :host {
      display: block;
      height: 100vh;
      overflow: hidden;
    }

    .app-shell {
      display: flex;
      flex-direction: column;
      height: 100vh;
      background: #080f1a;
      font-family: 'DM Sans', sans-serif;
    }

    /* ── Top Bar ── */
    .topbar {
      height: 52px;
      flex-shrink: 0;
      background: #0d1b2a;
      border-bottom: 1px solid rgba(255,255,255,0.07);
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 20px;
      z-index: 100;
    }

    .brand {
      display: flex;
      align-items: center;
      gap: 10px;

      .brand-icon {
        font-size: 22px;
        color: #00d4aa;
        line-height: 1;
      }

      .brand-name {
        font-size: 17px;
        font-weight: 700;
        color: #f1f5f9;
        letter-spacing: -0.5px;

        .accent {
          color: #00d4aa;
        }
      }
    }

    .topbar-actions {
      display: flex;
      gap: 8px;
      align-items: center;

      .coords-status {
        font-size: 11px;
        color: #f87171;
        max-width: 280px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        &.ok { color: #4ade80; }
      }
    }

    .btn-action {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 6px 14px;
      background: rgba(255,255,255,0.04);
      border: 1.5px solid #1e293b;
      border-radius: 6px;
      color: #94a3b8;
      font-family: inherit;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.15s;
      letter-spacing: 0.2px;

      &:hover {
        border-color: #00d4aa;
        color: #00d4aa;
        background: rgba(0,212,170,0.06);
      }

    }

    .btn-export {
      background: rgba(16,185,129,0.08);
      border-color: rgba(16,185,129,0.35);
      color: #10b981;
      &:hover { background: rgba(16,185,129,0.20); border-color: #10b981; color: #10b981; }
    }

    /* ── Main Layout ── */
    .main-layout {
      flex: 1;
      display: flex;
      overflow: hidden;
      min-height: 0;
    }

    .pane {
      height: 100%;
      overflow: hidden;
      min-width: 0;
    }

    .pane-pdf {
      flex-shrink: 0;
    }

    .pane-fields {
      flex: 1;
      min-width: 320px;
      max-width: 500px;
    }

    /* ── Resize Handle ── */
    .resize-handle {
      width: 6px;
      cursor: col-resize;
      background: #0d1b2a;
      border-left: 1px solid rgba(255,255,255,0.06);
      border-right: 1px solid rgba(255,255,255,0.06);
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background 0.15s;
      flex-shrink: 0;

      &:hover {
        background: rgba(0,212,170,0.1);
        .handle-line { background: #00d4aa; }
      }

      .handle-line {
        width: 2px;
        height: 40px;
        background: #1e293b;
        border-radius: 2px;
        transition: background 0.15s;
      }
    }
  `],
})
export class AppComponent implements OnInit {
  @ViewChild('pdfViewer') pdfViewer!: PdfViewerComponent;

  pdfSrc = signal<string | Uint8Array>('');
  currentPdfName = signal<string>('');
  coordsLoadStatus = signal<string>('');
  leftWidth = 65;

  private isResizing = false;
  private resizeStartX = 0;
  private resizeStartWidth = 0;

  // Demo PDF - replace with actual src
  private readonly DEMO_PDF = 'assets/sample.pdf';

  constructor(
    public captureService: PdfCaptureService,
    private http: HttpClient,
    public thumbnailCatSvc: ThumbnailCategoryService,
  ) {}

  ngOnInit() {
    // Load default PDF and set its base name for coord matching
    this.pdfSrc.set(this.DEMO_PDF);
    const defaultName = this.DEMO_PDF.replace(/^assets\//, '').replace(/\.pdf$/i, '');
    this.currentPdfName.set(defaultName);
    // Silently load word index for the default PDF (500ms delay — viewer not ready yet)
    setTimeout(() => this.loadWordIndexSilently(defaultName), 500);
  }



  onWordCaptured(word: CapturedWordPayload) {
    this.captureService.storeRawCapture(word);
  }

  onBoxCaptured(payload: CapturedWordPayload) {
    this.captureService.storeRawCapture(payload);
  }

  /**
   * Called when user clicks "✓ Confirm" on the field card.
   * THIS is the moment the green highlight appears and the JSON is updated.
   */
  onConfirmCapture() {
    this.captureService.confirmCapture();
    // Now update highlights — capturedWord is set, effect will fire scheduleRedraw.
    setTimeout(() => this.pdfViewer?.scheduleRedraw(), 30);
  }

  onThumbnailDrawn(event: { pageNumber: number; thumbnail: HTMLElement }): void {
    // Primary path: event from ngx thumbnailDrawn — stamp individual thumbnail
    this.thumbnailCatSvc.stampThumbnail(event.pageNumber, event.thumbnail);
  }

  /** Called after all pages initialised — schedule fallback stamp runs */
  private scheduleThumbnailStamps(): void {
    // Stamp at multiple intervals — thumbnails render lazily (especially large docs).
    // Safe: stampAllThumbnails is idempotent (skips already-stamped thumbs).
    setTimeout(() => this.thumbnailCatSvc.stampAllThumbnails(), 500);
    setTimeout(() => this.thumbnailCatSvc.stampAllThumbnails(), 1500);
    setTimeout(() => this.thumbnailCatSvc.stampAllThumbnails(), 3500);
  }

  onFieldFocused(_fieldId: string) { /* no-op — fields panel removed */ }

  onGoToWord(item: CaptureItem) {
    this.captureService.setActiveField(item.id);
    this.pdfViewer?.navigateToPage(item.page);
  }

  clearAllFields() {
    this.captureService.fields().slice().forEach(f => this.captureService.deleteCapture(f.id));
    this.captureService.loadExternalCoordinates([]);
    this.pdfViewer?.loadExternalCoordsIndex([]);
    this.coordsLoadStatus.set('');
  }

  /**
   * Load Coords — matches the current PDF filename to a JSON file in assets/.
   *
   * Convention: if the PDF is "invoice.pdf", looks for "assets/invoice.json".
   * The JSON format is:
   *   [{ "id":"1","label":"Word","page":1,"bbox":[x,y,w,h] }, ...]
   * where bbox values are 0-1 fractions of page size (zoom-independent).
   *
   * Place coordinate JSON files in src/assets/ with the same base name as the PDF.
   */
  loadDemoExternalCoords() {
    const src = this.pdfSrc();
    if (!src || (src instanceof Uint8Array && src.length === 0)) {
      this.coordsLoadStatus.set('⚠ No PDF loaded');
      return;
    }

    // Derive base name: "assets/foo.pdf" → "foo",  "blob:..." → use currentPdfName
    let baseName = this.currentPdfName();
    if (!baseName && typeof src === 'string' && src.startsWith('assets/')) {
      baseName = src.replace(/^assets\//, '').replace(/\.pdf$/i, '');
    }
    if (!baseName) {
      this.coordsLoadStatus.set('⚠ Cannot determine PDF filename');
      return;
    }

    // Strip path separators for safety
    baseName = baseName.split('/').pop()!.split('\\').pop()!.replace(/\.pdf$/i, '');
    const jsonUrl = `assets/${baseName}.json`;

    this.coordsLoadStatus.set(`Loading ${jsonUrl}…`);

    this.http.get<any[]>(jsonUrl).subscribe({
      next: (data) => {
        const coords: WordCoordinate[] = data.map((item: any) => this.normaliseCoord(item));
        this.captureService.loadExternalCoordinates(coords);
        // Build the viewer's per-page spatial index for PATH 0 click resolution.
        // This makes click2pick / dblclick return exact JSON coordinates — not DOM-derived.
        this.pdfViewer?.loadExternalCoordsIndex(coords);
        this.coordsLoadStatus.set(`✓ Loaded ${coords.length} coords from ${jsonUrl}`);
      },
      error: (err) => {
        const msg = err.status === 404
          ? `⚠ No coords file found — place "${baseName}.json" in src/assets/`
          : `⚠ Failed to load ${jsonUrl}: ${err.message}`;
        this.coordsLoadStatus.set(msg);
        console.warn('Load Coords:', msg);
      }
    });
  }

  /** Called when the viewer's native open button loads a new PDF */
  onSrcChange(event: string | Uint8Array): void {
    this.captureService.loadExternalCoordinates([]);
    this.pdfViewer?.loadExternalCoordsIndex([]);
    this.coordsLoadStatus.set('');
  }

  /**
   * Load a PDF from a URL as binary and set it into the viewer.
   * Use this when you need to load a PDF that requires auth headers,
   * or when you have a URL that returns raw PDF bytes.
   *
   * Usage: this.loadPdfBinary('https://api.example.com/docs/123')
   *        this.loadPdfBinary('/api/report', 'report.pdf')
   */
  loadPdfBinary(url: string, filename?: string): void {
    // No generic parameter — TypeScript infers ArrayBuffer from responseType overload
    this.http.get(url, { responseType: 'arraybuffer' as const }).subscribe({
      next: (buffer: ArrayBuffer) => {
        this.pdfSrc.set(new Uint8Array(buffer));
        // If caller provides filename, trigger word index + coord lookup
        if (filename) {
          this.onPdfNameChange(filename);
        }
      },
      error: (err) => {
        console.error('Failed to load PDF binary:', err);
      }
    });
  }

  /** Called from the viewer when a file is opened via native toolbar */
  onPdfNameChange(name: string): void {
    // Wire real page dimension getter into service so submit normalisation
    // uses actual PDF.js page sizes instead of the standard size fallback list.
    this.captureService._getPageDimsFn =
      (page: number) => this.pdfViewer?.getPageDimensionsPt(page) ?? null;

    const base = name.split('/').pop()?.split('\\').pop() ?? name;
    const baseName = base.replace(/\.pdf$/i, '');

    // Only reset everything if this is actually a NEW PDF (name changed)
    const isNewPdf = baseName !== this.currentPdfName();
    this.currentPdfName.set(baseName);

    if (isNewPdf) {
      this._loadingForPdf = '';
      this.captureService.loadExternalCoordinates([]);
      this.coordsLoadStatus.set('');
      this.pdfViewer?.loadWordIndex(null);
      // Load category JSON for thumbnail sidebar — only when PDF changes
      this.loadCategoryJsonSilently(baseName);
      // Schedule fallback stamp runs after thumbnails have had time to render
      this.scheduleThumbnailStamps();
    }

    // Always try to load word index (handles both new PDF and retry on same PDF).
    this.loadWordIndexSilently(baseName);

    // Try to load pre-captured fields JSON (e.g. assets/invoice_captured_fields.json).
    // If found: fields get pre-populated with values + grey highlights immediately.
    if (isNewPdf) this.loadCapturedFieldsSilently(baseName);
  }

  /**
   * Silently load the word coordinate index for a PDF.
   * Tries two file formats in order:
   *
   * 1. assets/{baseName}.json — label/bbox format:
   *      [{ id, label, page, bbox:[x,y,w,h] }, ...]
   *    Used as the primary source when present.
   *    Loaded into _extIndex so injected spans use exact bbox coordinates.
   *
   * 2. assets/{baseName}_word_index.json — pdfplumber format:
   *      { version:1, pages:{ "1":[{t,x,y,w,h}...] } }
   *    Fallback when the label/bbox file is not found.
   *
   * No status message on success or failure — invisible to the user.
   */
  private _loadingForPdf = '';   // guard: skip duplicate loads for same PDF
  private loadWordIndexSilently(baseName: string): void {
    if (!baseName) return;
    if (this._loadingForPdf === baseName) return;   // already in-flight for this PDF
    this._loadingForPdf = baseName;

    // Try label/bbox format first (e.g. assets/MyDoc.json)
    const labelUrl = `assets/${baseName}.json`;
    this.http.get<any[]>(labelUrl).subscribe({
      next: (data) => {
        if (!Array.isArray(data) || !data.length) {
          this.loadWordIndexFallback(baseName);
          return;
        }
        this._loadingForPdf = '';  // allow future reloads if needed
        // ── Auto-detect flat absolute-coords format ───────────────────────────
        // Format: [{text, x, y, width, height, page}] with x/y/w/h in absolute
        // points/pixels and NO pageWidth field.
        // Detection: first entry has no bbox, has x/y/width/height, values > 1.
        const first = data[0];
        const isAbsFlat = !first.bbox
          && (first.x != null || first.y != null)
          && (Number(first.x ?? 0) > 1 || Number(first.y ?? 0) > 1
              || Number(first.width ?? first.w ?? 0) > 1)
          && !first.pageWidth && !first.pagewidth;

        let processedData = data;
        if (isAbsFlat) {
          // ── Infer page dimensions per page ──────────────────────────────────
          // Strategy (in order of reliability):
          //   1. Per-item pageWidth/pageHeight if user provided them
          //   2. Find the smallest standard PDF page size that fits all content
          //   3. Fall back to A4 (595×842) — most common PDF page size
          //
          // Standard PDF page sizes in points (width × height):
          const STD = [
            { w: 595.276, h: 841.890 },  // A4 portrait  ← default
            { w: 612,     h: 792     },  // Letter portrait
            { w: 612,     h: 1008    },  // Legal portrait
            { w: 841.890, h: 595.276 },  // A4 landscape
            { w: 792,     h: 612     },  // Letter landscape
          ];

          // Compute per-page max content extent
          const pageDims = new Map<number, { w: number; h: number }>();
          for (const item of data) {
            const pg  = Number(item.page ?? 1);
            // If item already has page dimensions, use them directly
            const ipw = Number(item.pageWidth ?? item.pagewidth ?? 0);
            const iph = Number(item.pageHeight ?? item.pageheight ?? 0);
            if (ipw > 1 && iph > 1) { pageDims.set(pg, { w: ipw, h: iph }); continue; }
            const x2  = Number(item.x ?? 0) + Number(item.width  ?? item.w ?? 0);
            const y2  = Number(item.y ?? 0) + Number(item.height ?? item.h ?? 0);
            const cur = pageDims.get(pg);
            pageDims.set(pg, { w: Math.max(cur?.w ?? 0, x2), h: Math.max(cur?.h ?? 0, y2) });
          }

          const inferPageSize = (maxX2: number, maxY2: number): { w: number; h: number } => {
            // Find all standard sizes where content fits (max coords don't exceed page)
            const fitting = STD.filter(s => maxX2 <= s.w && maxY2 <= s.h);
            if (!fitting.length) return { w: maxX2, h: maxY2 }; // content exceeds all — use as-is
            // Among fitting sizes, pick A4 portrait if it fits (most common default)
            // otherwise pick the one with the smallest area (tightest fit)
            const a4 = fitting.find(s => Math.abs(s.w - 595.276) < 1);
            return a4 ?? fitting.reduce((best, s) =>
              (s.w * s.h < best.w * best.h ? s : best), fitting[0]);
          };

          processedData = data.map((item: any) => {
            const pg   = Number(item.page ?? 1);
            const dims = pageDims.get(pg) ?? { w: 595.276, h: 841.890 };
            // Always run inferPageSize so max-content-extent gets mapped to
            // the nearest standard PDF page size (A4 preferred).
            // Only skip if per-item pageWidth was already provided (exact value).
            const hasExplicit = Number(item.pageWidth ?? item.pagewidth ?? 0) > 1;
            const size = hasExplicit ? dims : inferPageSize(dims.w, dims.h);
            return { ...item, pageWidth: size.w, pageHeight: size.h };
          });
        }
        const coords = processedData.map((item: any) => this.normaliseCoord(item));
        this.pdfViewer?.loadExternalCoordsIndex(coords);
        // Also load the word index independently — it powers the full text layer
        // replacement (all words as clickable spans), while extIndex only has
        // the subset from the .json file. Both can coexist.
        this.http.get<any>(`assets/${baseName}_word_index.json`).subscribe({
          next:  (wi) => this.pdfViewer?.loadWordIndex(wi),
          error: ()   => { /* no word index — extIndex handles clicks */ },
        });
      },
      error: () => this.loadWordIndexFallback(baseName),
    });
  }

  // ── Captured Fields JSON ──────────────────────────────────────────────────

  /**
   * Try to load assets/{baseName}_captured_fields.json.
   * Accepts two coord formats:
   *   A) flat: { value, x, y, width, height, page }         — already 0-1 fractions
   *   B) bbox: { value, page, bbox:[x,y,w,h] }              — 0-1 fractions
   *   C) abs:  { value, x, y, width, height, page }         — absolute pts (auto-normalised)
   *            with optional pageWidth/pageHeight fields
   */
  private loadCapturedFieldsSilently(baseName: string): void {
    const url = `assets/${baseName}_captured_fields.json`;
    this.http.get<CapturedFieldJson[]>(url).subscribe({
      next: (data) => {
        if (!Array.isArray(data) || !data.length) return;
        const normalised = data
          .filter(f => f.value && (f.id || f.label))
          .map(f => this.normaliseCapturedField(f, data));
        if (normalised.length) {
          this.captureService.loadCapturedFieldsFromJson(normalised);
          setTimeout(() => this.pdfViewer?.scheduleRedraw(), 50);
        }
      },
      error: () => { /* no captured_fields.json — silent, normal */ },
    });
  }

  /**
   * Normalise a single captured-field JSON entry to 0-1 fractional coords.
   * Supports 3 coord formats — format is detected and stored for round-trip export:
   *   'flat'      → { x, y, width, height, page, label, value }
   *   'bbox'      → { bbox:[x,y,w,h], page, label, value }
   *   'rectangle' → { rectangle:[x,y,w,h], page, label, value }
   */
  private normaliseCapturedField(
    f: CapturedFieldJson,
    allFields: CapturedFieldJson[]
  ): { id: string; label: string; value: string; page: number;
       x: number; y: number; width: number; height: number;
       sourceFormat: CapturedFieldFormat } {
    const id    = f.id    || f.label || '';
    const label = f.label || f.id    || '';
    const value = f.value || '';
    const page  = Number(f.page ?? 1);

    // Detect coord format and extract raw values
    let rx: number, ry: number, rw: number, rh: number;
    let sourceFormat: CapturedFieldFormat;

    if (f.rectangle && Array.isArray(f.rectangle) && f.rectangle.length === 4) {
      // Format C: { rectangle:[x,y,w,h] }
      [rx, ry, rw, rh] = f.rectangle.map(Number);
      sourceFormat = 'rectangle';
    } else if (f.bbox && Array.isArray(f.bbox) && f.bbox.length === 4) {
      // Format B: { bbox:[x,y,w,h] }
      [rx, ry, rw, rh] = f.bbox.map(Number);
      sourceFormat = 'bbox';
    } else {
      // Format A: flat { x, y, width, height }
      rx = Number(f.x      ?? 0);
      ry = Number(f.y      ?? 0);
      rw = Number(f.width  ?? 0);
      rh = Number(f.height ?? 0);
      sourceFormat = 'flat';
    }

    // If values > 1: absolute pts — need page dimensions to normalise
    if (rx > 1 || ry > 1 || rw > 1 || rh > 1) {
      let pw = Number(f.pageWidth ?? f.pagewidth ?? 0);
      let ph = Number(f.pageHeight ?? f.pageheight ?? 0);

      // Priority 1: explicit pageWidth/pageHeight in the JSON entry
      // Priority 2: real dims from PDF.js (accurate for any paper size/DPI)
      // Priority 3: infer from max content extent + standard size list (fallback only)
      if (pw <= 1 || ph <= 1) {
        const realDims = this.pdfViewer?.getPageDimensionsPt(page);
        if (realDims) {
          pw = realDims.widthPt;
          ph = realDims.heightPt;
        } else {
          // Fallback: infer from max content extent across all fields on same page,
          // then match against standard PDF page sizes (points, per ISO 216 / ANSI).
          // This covers A4, Letter, Legal, A3, B4, Tabloid etc.
          const STD: [number, number][] = [
            [595.276, 841.890],  // A4 portrait
            [841.890, 595.276],  // A4 landscape
            [612,     792    ],  // US Letter portrait
            [792,     612    ],  // US Letter landscape
            [612,     1008   ],  // US Legal portrait
            [1008,    612    ],  // US Legal landscape
            [841.890, 1190.55],  // A3 portrait
            [1190.55, 841.890],  // A3 landscape
            [708.661, 1000.63],  // B4 portrait
            [792,     1224   ],  // US Tabloid portrait
            [1224,    792    ],  // US Tabloid landscape
          ];
          const pageFlds = allFields.filter(o => Number(o.page ?? 1) === page);
          let maxX2 = 0, maxY2 = 0;
          for (const o of pageFlds) {
            const coords = o.rectangle ?? o.bbox;
            const ox = coords ? coords[0] + coords[2] : Number(o.x ?? 0) + Number(o.width ?? 0);
            const oy = coords ? coords[1] + coords[3] : Number(o.y ?? 0) + Number(o.height ?? 0);
            if (ox > maxX2) maxX2 = ox;
            if (oy > maxY2) maxY2 = oy;
          }
          const fitting = STD.filter(([w, h]) => maxX2 <= w && maxY2 <= h);
          const a4 = fitting.find(([w]) => Math.abs(w - 595.276) < 1);
          const best = a4
            ?? (fitting.length
              ? fitting.reduce((b, s) => s[0] * s[1] < b[0] * b[1] ? s : b)
              : [maxX2 || 612, maxY2 || 792] as [number, number]);
          [pw, ph] = best;
        }
      }
      rx /= pw; ry /= ph; rw /= pw; rh /= ph;
    }

    return {
      id, label, value, page, sourceFormat,
      x: Math.min(1, Math.max(0, rx)),
      y: Math.min(1, Math.max(0, ry)),
      width:  Math.min(1, Math.max(0, rw)),
      height: Math.min(1, Math.max(0, rh)),
    };
  }

  /**
   * Load assets/{baseName}_categories.json for thumbnail sidebar labels.
   * File format:
   * {
   *   "categories": [
   *     { "pages": [1,2,3], "label": "Invoice",   "color": "blue"  },
   *     { "pages": [4,5],   "label": "Form 15CA", "color": "teal"  },
   *     { "pages": [6],     "label": "Form 15CB"                    }
   *   ]
   * }
   * color is optional — auto-assigned from palette if absent.
   */
  private loadCategoryJsonSilently(baseName: string): void {
    const url = `assets/${baseName}_categories.json`;
    this.http.get<CategoryConfig>(url).subscribe({
      next: (data) => {
        if (!data?.categories?.length) return;
        this.thumbnailCatSvc.load(data);
        console.log('[CATEGORY] Loaded from', url);
      },
      error: () => {
        // No categories file — clear any previous categories silently
        this.thumbnailCatSvc.clear();
      },
    });
  }

  /**
   * Download all current captured fields as JSON.
   * Each field is exported in its ORIGINAL input format:
   *   'rectangle' → { label, value, page, rectangle:[x,y,w,h] }
   *   'bbox'      → { label, value, page, bbox:[x,y,w,h] }
   *   'flat'      → { label, value, page, x, y, width, height }  (default for new captures)
   */
  downloadCapturedFields(): void {
    const data = this.captureService.getCapturedFieldsJson();
    if (!data.length) { alert('No fields captured yet.'); return; }

    const r6 = (n: number) => parseFloat(n.toFixed(6));

    const output = data.map(f => {
      const fmt = f.sourceFormat || 'flat';
      const coords: [number,number,number,number] = [r6(f.x), r6(f.y), r6(f.width), r6(f.height)];

      if (fmt === 'rectangle') {
        return { label: f.label, value: f.value, page: f.page, rectangle: coords };
      }
      if (fmt === 'bbox') {
        return { id: f.id, label: f.label, value: f.value, page: f.page, bbox: coords };
      }
      // Default: flat format (for new captures or original flat input)
      return {
        id:     f.id,
        label:  f.label,
        value:  f.value,
        page:   f.page,
        x:      coords[0],
        y:      coords[1],
        width:  coords[2],
        height: coords[3],
      };
    });

    const blob = new Blob([JSON.stringify(output, null, 2)], { type: 'application/json' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    const name = this.currentPdfName() || 'document';
    a.href     = url;
    a.download = `${name}_captured_fields.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  /** Try assets/{baseName}_word_index.json (pdfplumber format). */
  private loadWordIndexFallback(baseName: string): void {
    const url = `assets/${baseName}_word_index.json`;
    this.http.get<any>(url).subscribe({
      next:  (data) => { this._loadingForPdf = ''; this.pdfViewer?.loadWordIndex(data); },
      error: ()     => { this._loadingForPdf = ''; this.pdfViewer?.loadWordIndex(null); },
    });
  }

  // ── Coordinate Normalisation ─────────────────────────────────────────────
  /**
   * Universal coordinate normaliser — converts any external bbox format into
   * our viewer's 0-1 fractional system (fraction of PDF page canvas size).
   *
   * Three formats are handled automatically with zero hardcoded magic numbers:
   *
   * FORMAT A — already fractional [x, y, w, h] all in 0-1 range:
   *   { bbox: [0.08, 0.16, 0.60, 0.02] }       ← our pdfplumber output
   *   { x, y, width, height }                   ← plain fractional fields
   *   Detection: bbox has 4 values, all ≤ 1
   *   Action: use as-is
   *
   * FORMAT B — absolute pixel [x1,y1,x2,y2] with rendered image dimensions:
   *   { pagewidth: 899, pageHeight: 1272, bbox: [206, 165, 635, 178] }
   *   These come from tools (Gemini, Stylus, AWS Textract, Google Vision, etc.)
   *   that render the PDF to a raster image and return pixel coordinates.
   *
   *   Universal formula (no magic constants):
   *     xFrac = x1 / pagewidth
   *     yFrac = y1 / pageHeight
   *     wFrac = (x2 - x1) / pagewidth
   *     hFrac = (y2 - y1) / pageHeight
   *
   *   If the tool adds UI chrome/margins around the page (making the image
   *   larger than the page content), we auto-detect this by finding the
   *   minimum x1 across all items on the same page — that minimum is the
   *   left edge of content. We subtract it to get content-relative coords.
   *   This works for ANY tool, ANY DPI, ANY page size.
   *
   * FORMAT C — [x1,y1,x2,y2] without page dimensions:
   *   { bbox: [206, 165, 635, 178] } (no pagewidth/pageHeight)
   *   We have no render scale, so treat as fractional (FORMAT A).
   *   If values > 1 they will be clamped — user should provide page dimensions.
   */
  private normaliseCoord(item: any): WordCoordinate {
    const id   = String(item.id    ?? item.label ?? '');
    const text = String(item.label ?? item.text  ?? item.id ?? '');
    const page = Number(item.page  ?? 1);

    const pw = Number(item.pagewidth  ?? item.pageWidth  ?? 0);
    const ph = Number(item.pageHeight ?? item.pageheight ?? 0);

    // ── FORMAT B: has page dimensions + absolute bbox array ──────────────────
    if (pw > 1 && ph > 1 && item.bbox && Array.isArray(item.bbox) && item.bbox.length === 4) {
      const [bx1, by1, bx2, by2] = (item.bbox as number[]).map(Number);
      if (bx1 > 1 || by1 > 1 || bx2 > 1 || by2 > 1) {
        return {
          id, text, page,
          x:      Math.min(1, Math.max(0, bx1 / pw)),
          y:      Math.min(1, Math.max(0, by1 / ph)),
          width:  Math.min(1, Math.max(0, (bx2 - bx1) / pw)),
          height: Math.min(1, Math.max(0, (by2 - by1) / ph)),
        };
      }
    }

    // ── FORMAT C: flat {text,x,y,width,height,page} with page dimensions ─────
    // Handles absolute point/pixel coords when pageWidth/pageHeight are provided.
    // pageWidth/pageHeight are injected by the loader when auto-detected.
    if (pw > 1 && ph > 1 && !item.bbox) {
      const rx = Number(item.x ?? 0);
      const ry = Number(item.y ?? 0);
      const rw = Number(item.width ?? item.w ?? 0);
      const rh = Number(item.height ?? item.h ?? 0);
      if (rx > 1 || ry > 1 || rw > 1 || rh > 1) {
        return {
          id, text, page,
          x:      Math.min(1, Math.max(0, rx / pw)),
          y:      Math.min(1, Math.max(0, ry / ph)),
          width:  Math.min(1, Math.max(0, rw / pw)),
          height: Math.min(1, Math.max(0, rh / ph)),
        };
      }
    }

    // ── Extract raw values ────────────────────────────────────────────────────
    let rawX: number, rawY: number, rawW: number, rawH: number;

    if (item.bbox && Array.isArray(item.bbox) && item.bbox.length === 4) {
      const [a, b, c, d] = (item.bbox as number[]).map(Number);
      if (a >= 0 && a <= 1 && b >= 0 && b <= 1 && c >= 0 && c <= 1 && d >= 0 && d <= 1) {
        // FORMAT A: genuine 0-1 fractions [x, y, w, h]
        rawX = a; rawY = b; rawW = c; rawH = d;
      } else if (c > a && d > b) {
        const impliedW = Math.max(c, pw || c);
        const impliedH = Math.max(d, ph || d);
        rawX = a / impliedW; rawY = b / impliedH;
        rawW = (c - a) / impliedW; rawH = (d - b) / impliedH;
      } else {
        rawX = a; rawY = b; rawW = c; rawH = d;
      }
    } else {
      rawX = Number(item.x ?? 0);
      rawY = Number(item.y ?? 0);
      rawW = Number(item.width  ?? item.w ?? 0);
      rawH = Number(item.height ?? item.h ?? 0);
    }

    return {
      id, text, page,
      x:      Math.min(1, Math.max(0, rawX)),
      y:      Math.min(1, Math.max(0, rawY)),
      width:  Math.min(1, Math.max(0, rawW)),
      height: Math.min(1, Math.max(0, rawH)),
    };
  }

  // ── Resize Panel ─────────────────────────────────────────────────────────
  startResize(event: MouseEvent) {
    this.isResizing = true;
    this.resizeStartX = event.clientX;
    this.resizeStartWidth = this.leftWidth;

    const onMove = (e: MouseEvent) => {
      if (!this.isResizing) return;
      const delta = e.clientX - this.resizeStartX;
      const totalW = window.innerWidth;
      const newW = this.resizeStartWidth + (delta / totalW) * 100;
      this.leftWidth = Math.max(35, Math.min(75, newW));
    };

    const onUp = () => {
      this.isResizing = false;
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
    };

    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
    event.preventDefault();
  }
}