// ─────────────────────────────────────────────────────────────────────────────
// DocAdapter — DOCX / DOC / TXT viewer
//
// DOCX/DOC rendering (docx-preview + html2canvas):
//   1. docx-preview.renderAsync() → renders full fidelity HTML into a hidden
//      off-screen container: fonts, colours, bold/italic, tables, images, spacing
//   2. Each page = one <section> element (breakPages: true)
//   3. html2canvas screenshots each section → HTMLCanvasElement
//   4. Word positions extracted from DOM Text nodes via Range.getBoundingClientRect()
//      → click2pick, duplicate highlighting, search all work as normal
//
// TXT:
//   Plain canvas rendering, monospace font, 52 lines per page — unchanged.
//
// Public interface is IDENTICAL to the original DocAdapter:
//   getPageCanvas(), getPageDimensions(), getWordIndex()
//   onReady(), onPageRendered(), registerPageElement(), dispose()
// No other adapter, viewer component, or store code is affected.
// ─────────────────────────────────────────────────────────────────────────────

import type { ViewerAdapter } from './types';

const PAGE_W     = 794;   // A4 at 96 dpi
const PAGE_H     = 1123;
const MARGIN     = 52;
const CONTENT_W  = PAGE_W  - MARGIN * 2;
const LINES_TXT  = 52;
const LINE_H_TXT = 19;

export interface DocWordEntry {
  text:   string;
  page:   number;
  x:      number;   // 0-1 fraction of page width
  y:      number;
  width:  number;
  height: number;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function makeCanvas(): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const c   = document.createElement('canvas');
  c.width   = PAGE_W;
  c.height  = PAGE_H;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, PAGE_W, PAGE_H);
  return [c, ctx];
}

// ── DocAdapter ────────────────────────────────────────────────────────────────

export class DocAdapter implements ViewerAdapter {
  pageCount = 0;

  private _canvases:  HTMLCanvasElement[]         = [];
  private _wordIndex: DocWordEntry[]               = [];
  private _pageEls  = new Map<number, HTMLElement>();
  private _rendCbs: Array<(p: number) => void>    = [];
  private _readyCbs: Array<() => void>             = [];
  private _isReady  = false;

  // ── Public entry point ────────────────────────────────────────────────────

  async loadFile(file: File): Promise<void> {
    const ext = file.name.split('.').pop()?.toLowerCase() ?? '';
    try {
      if (ext === 'txt') {
        await this._loadTxt(file);
      } else {
        await this._loadDocx(file);
      }
    } catch (err) {
      console.error('[DocAdapter] load failed:', err);
      const [c, ctx] = makeCanvas();
      ctx.font = '14px sans-serif'; ctx.fillStyle = '#cc3333';
      ctx.fillText('Failed to load document: ' + String(err), MARGIN, MARGIN + 20);
      this._canvases = [c];
    }
    this.pageCount = this._canvases.length;
    this._isReady  = true;
    this._readyCbs.forEach(cb => cb());
    this._readyCbs = [];
  }

  // ── TXT loader (unchanged) ────────────────────────────────────────────────

  private async _loadTxt(file: File): Promise<void> {
    const text   = await file.text();
    const lines  = text.split('\n');
    const chunks: string[][] = [];
    for (let i = 0; i < lines.length; i += LINES_TXT) chunks.push(lines.slice(i, i + LINES_TXT));
    if (!chunks.length) chunks.push(['']);

    this._canvases = chunks.map((chunk, pi) => {
      const [canvas, ctx] = makeCanvas();
      ctx.font = '13px monospace'; ctx.fillStyle = '#1a1a1a'; ctx.textBaseline = 'top';
      chunk.forEach((line, li) => {
        const y = MARGIN + li * LINE_H_TXT;
        if (y > PAGE_H - MARGIN) return;
        ctx.fillText(line, MARGIN, y, CONTENT_W);
        let cx = MARGIN;
        for (const w of line.split(/(\s+)/)) {
          const ww = ctx.measureText(w).width;
          if (w.trim()) this._wordIndex.push({
            text: w, page: pi + 1,
            x: cx / PAGE_W, y: y / PAGE_H, width: ww / PAGE_W, height: LINE_H_TXT / PAGE_H,
          });
          cx += ww;
        }
      });
      return canvas;
    });
  }

  // ── DOCX loader — docx-preview + html2canvas ──────────────────────────────

  private async _loadDocx(file: File): Promise<void> {
    // Lazy-load both libraries — only pulled in for DOCX files
    const [{ renderAsync }, html2canvas] = await Promise.all([
      import('docx-preview'),
      import('html2canvas').then(m => m.default),
    ]);

    const buffer = await file.arrayBuffer();

    // Off-screen host element — positioned off-screen so layout is computed
    // but not visible to the user during rendering
    const host = document.createElement('div');
    host.style.cssText = [
      'position:fixed', 'left:-9999px', 'top:0',
      `width:${PAGE_W}px`,  // fix width so docx-preview uses A4 layout
      'overflow:hidden', 'z-index:-1', 'pointer-events:none',
    ].join(';');
    document.body.appendChild(host);

    try {
      // renderAsync renders full OOXML fidelity: fonts, colours, bold/italic/underline,
      // tables with borders, images, paragraph spacing, columns, headers/footers
      await renderAsync(buffer, host, undefined, {
        className:      'docx',
        inWrapper:      true,
        breakPages:     true,   // each page = one <section> element
        renderHeaders:  true,
        renderFooters:  true,
        renderFootnotes: true,
        ignoreLastRenderedPageBreak: false,
        useBase64URL:   true,
      });

      // Find all page sections — docx-preview creates one <section> per page
      const sections = Array.from(
        host.querySelectorAll<HTMLElement>('.docx-wrapper > section, .docx section')
      );

      if (sections.length === 0) {
        // Fallback: whole container is one page
        sections.push(host);
      }

      // Screenshot each section with html2canvas
      for (let i = 0; i < sections.length; i++) {
        const section = sections[i];
        const pageNum = i + 1;

        // Extract word positions BEFORE screenshotting (DOM is intact here)
        this._extractWords(section, pageNum);

        // Screenshot the section
        const sectionCanvas = await html2canvas(section, {
          scale:           1,
          useCORS:         true,
          allowTaint:      true,
          backgroundColor: '#ffffff',
          logging:         false,
          // Fix dimensions to A4
          width:           PAGE_W,
          height:          section.offsetHeight || PAGE_H,
          windowWidth:     PAGE_W,
          onclone: (doc: Document) => {
            // Ensure cloned doc has the same viewport width
            const el = doc.body;
            if (el) el.style.width = PAGE_W + 'px';
          },
        });

        // Normalise to A4 dimensions
        const [outCanvas, ctx] = makeCanvas();
        const scale = Math.min(PAGE_W / sectionCanvas.width, PAGE_H / sectionCanvas.height);
        const dw    = sectionCanvas.width  * scale;
        const dh    = sectionCanvas.height * scale;
        ctx.drawImage(sectionCanvas, 0, 0, dw, dh);
        this._canvases.push(outCanvas);
      }

    } finally {
      // Remove host from DOM — no memory leak
      document.body.removeChild(host);
    }

    if (this._canvases.length === 0) {
      const [c] = makeCanvas();
      this._canvases = [c];
    }
  }

  // ── Word position extraction from DOM ─────────────────────────────────────
  // Walks all Text nodes in a section, uses Range.getBoundingClientRect()
  // to get pixel positions, normalises to 0-1 fractions.
  // This gives click2pick and duplicate highlighting accurate word positions
  // that match exactly what the user sees — far more accurate than canvas-based
  // text measurement.

  private _extractWords(section: HTMLElement, pageNum: number): void {
    const sectionRect = section.getBoundingClientRect();
    if (!sectionRect.width || !sectionRect.height) return;

    const W = sectionRect.width;
    const H = sectionRect.height || PAGE_H;

    const walker = document.createTreeWalker(section, NodeFilter.SHOW_TEXT, {
      acceptNode: (node) => {
        // Skip text inside script/style elements
        const parent = node.parentElement;
        if (!parent) return NodeFilter.FILTER_REJECT;
        const tag = parent.tagName.toLowerCase();
        if (tag === 'script' || tag === 'style') return NodeFilter.FILTER_REJECT;
        // Skip whitespace-only nodes
        if (!node.textContent?.trim()) return NodeFilter.FILTER_SKIP;
        return NodeFilter.FILTER_ACCEPT;
      }
    });

    const range = document.createRange();
    let node: Text | null;

    while ((node = walker.nextNode() as Text | null)) {
      const text = node.textContent ?? '';
      const words = text.split(/\s+/).filter(w => w.length > 0);

      // Split the text node word by word using Range
      let charOffset = 0;
      for (const word of words) {
        const wordStart = text.indexOf(word, charOffset);
        if (wordStart < 0) { charOffset += word.length; continue; }

        try {
          range.setStart(node, wordStart);
          range.setEnd(node, wordStart + word.length);
          const rect = range.getBoundingClientRect();

          if (rect.width > 0 && rect.height > 0) {
            // Convert from viewport coords to section-relative 0-1 fractions
            const x = (rect.left - sectionRect.left) / W;
            const y = (rect.top  - sectionRect.top)  / H;
            const w = rect.width  / W;
            const h = rect.height / H;

            if (x >= 0 && y >= 0 && x + w <= 1.1 && y + h <= 1.1) {
              this._wordIndex.push({
                text: word, page: pageNum,
                x: Math.max(0, x), y: Math.max(0, y),
                width: Math.min(1 - x, w), height: Math.min(1 - y, h),
              });
            }
          }
        } catch (_) {
          // Range errors on some nodes — skip silently
        }

        charOffset = wordStart + word.length;
      }
    }
  }

  // ── Word index public access ───────────────────────────────────────────────

  getWordIndex(): DocWordEntry[] { return this._wordIndex; }

  // ── ViewerAdapter implementation (identical interface to original) ─────────

  navigateToPage(page: number): void {
    const el = this._pageEls.get(page);
    if (!el) return;
    const sc = el.closest('[data-viewer-scroll]') as HTMLElement | null;
    if (sc) {
      sc.scrollTop = el.getBoundingClientRect().top
        - sc.getBoundingClientRect().top + sc.scrollTop - 8;
    } else {
      el.scrollIntoView({ behavior: 'instant' as ScrollBehavior, block: 'start' });
    }
  }

  registerPageElement(page: number, el: HTMLElement | null) {
    if (el) this._pageEls.set(page, el);
    else    this._pageEls.delete(page);
  }

  getPageDimensions(page: number) {
    const c = this._canvases[page - 1];
    return c ? { width: c.width, height: c.height } : null;
  }

  getPageCanvas(page: number): HTMLCanvasElement | null {
    return this._canvases[page - 1] ?? null;
  }

  getPageElement(page: number): HTMLElement | null {
    return this._pageEls.get(page) ?? null;
  }

  getRenderedPages(): Set<number> {
    return new Set(this._pageEls.keys());
  }

  notifyPageRendered(page: number) { this._rendCbs.forEach(cb => cb(page)); }

  onReady(cb: () => void) {
    if (this._isReady) cb(); else this._readyCbs.push(cb);
  }

  onPageRendered(cb: (page: number) => void)  { this._rendCbs.push(cb); }
  offPageRendered(cb: (page: number) => void) {
    const i = this._rendCbs.indexOf(cb);
    if (i !== -1) this._rendCbs.splice(i, 1);
  }

  dispose() {
    this._canvases = []; this._wordIndex = [];
    this._pageEls.clear(); this._rendCbs = []; this._readyCbs = [];
    this._isReady = false; this.pageCount = 0;
  }
}
