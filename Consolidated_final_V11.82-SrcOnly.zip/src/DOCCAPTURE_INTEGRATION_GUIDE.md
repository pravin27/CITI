# DocCapture Viewer — Complete Integration Guide

---

## Table of Contents

1. [Setup & Embedding](#1-setup--embedding)
2. [Handshake — READY flow](#2-handshake--ready-flow)
3. [Loading Documents](#3-loading-documents)
4. [All Flag Properties](#4-all-flag-properties)
5. [Categories](#5-categories)
6. [Captures — Highlight Boxes](#6-captures--highlight-boxes)
7. [Events — Parent → Viewer](#7-events--parent--viewer)
8. [Events — Viewer → Parent](#8-events--viewer--parent)
9. [Events — SM Iframe → Viewer](#9-events--sm-iframe--viewer)
10. [Split & Merge Feature](#10-split--merge-feature)
11. [Retrigger & Discard Buttons](#11-retrigger--discard-buttons)
12. [SM Open → Reclassify → Discard — Full Event Flow](#12-sm-open--reclassify--discard--full-event-flow)
13. [Viewer Configuration (.env)](#13-viewer-configuration-env)
14. [Coordinate System Reference](#14-coordinate-system-reference)

---

## 1. Setup & Embedding

```html
<iframe
  #viewerFrame
  src="https://your-viewer-host.com"
  style="width:100%; height:100%; border:none;"
  allow="*"
></iframe>
```

```ts
const viewer = document.querySelector('iframe').contentWindow;

function send(msg: object, transferables?: Transferable[]) {
  viewer.postMessage(msg, '*', transferables ?? []);
}

// Listen for events from viewer
window.addEventListener('message', (event) => {
  const { type, ...data } = event.data ?? {};
  if (!type) return;
  // handle — see Section 8
});
```

---

## 2. Handshake — READY flow

```
Viewer  ──── READY ────────────────────────────────────►  Parent
Parent  ──── READY_CONFIG (optional) ──────────────────►  Viewer
Parent  ──── LOAD_SINGLEDOC / LOAD_MANIFEST ───────────►  Viewer
Viewer  ──── DOC_LOADED ────────────────────────────────►  Parent
```

### READY_CONFIG (optional — sent after READY)

```ts
send({
  type:               'READY_CONFIG',
  enableCaptureDebug: true,
  initialZoom:        'page-fit',
  Click2Pick:         false,
  showSplitMerge:     true,
});
```

---

## 3. Loading Documents

### 3.1 LOAD_SINGLEDOC

```ts
send({
  type:     'LOAD_SINGLEDOC',
  buffer:   arrayBuffer,     // required — raw file bytes
  fileName: 'invoice.pdf',   // required — extension sets format

  // ── Display flags (all optional) ─────────────────────────────────────
  initialZoom:       'page-fit',
  showFieldsPanel:   true,
  showAnnotation:    false,
  showThumbnailView: true,
  showSplitMerge:    true,
  isSplitScreen:     true,   // show Retrigger + Discard buttons
  openThumbnail:     true,   // auto-open sidebar panel on load
  Click2Pick:        false,
  coordinateSpace:   'px',   // 'px' | 'pt' | 'norm'

  // ── Data (all optional) ───────────────────────────────────────────────
  categories: [...],
  captures:   [...],
  fullPageOCR: {
    1: [{ text:'Invoice', x:0.10, y:0.05, width:0.15, height:0.02 }],
  },
}, [arrayBuffer]);
```

> On every `LOAD_SINGLEDOC` the viewer automatically stores the received
> `categories` as the **original snapshot** for the Discard button.
> Sending a new `LOAD_SINGLEDOC` resets the snapshot to the new categories.

**Supported file formats:** `.pdf` · `.tif/.tiff` · `.png` · `.jpg/.jpeg` · `.xlsx/.xls` · `.docx/.doc` · `.csv`

---

### 3.2 LOAD_MANIFEST — MultiDoc:SinglePage

```ts
send({
  type: 'LOAD_MANIFEST',
  manifest: {
    mode: 'MultiDoc:SinglePage',

    categories: [
      { id:'invoice',     label:'Invoice',     color:'blue'  },
      { id:'annexure',    label:'Annexure',    color:'teal'  },
      { id:'declaration', label:'Declaration', color:'amber' },
    ],

    documents: [
      { id:'doc1', name:'Invoice_001.pdf', label:'Invoice 001', category:'invoice'     },
      { id:'doc2', name:'Invoice_002.pdf', label:'Invoice 002', category:'invoice'     },
      { id:'doc3', name:'Decl_001.pdf',    label:'Decl 001',   category:'declaration' },
      { id:'doc4', name:'Decl_002.pdf',    label:'Decl 002',   category:'declaration' },
      { id:'doc5', name:'Invoice_003.pdf', label:'Invoice 003', category:'invoice'     },
      // Consecutive same-category docs = one accordion
    ],
  },
  isSplitScreen:  true,
  openThumbnail:  true,
  showSplitMerge: true,
  activeDocId:    'doc1',
  activeBuffer:   arrayBuffer,
}, [arrayBuffer]);
```

---

### 3.3 LOAD_MANIFEST — MultiDoc:MultiPage

```ts
send({
  type: 'LOAD_MANIFEST',
  manifest: {
    mode: 'MultiDoc:MultiPage',
    categories: [
      { id:'invoice',     label:'Invoice',     color:'blue' },
      { id:'annexure',    label:'Annexure',    color:'teal' },
    ],
    documents: [
      {
        id:'docA', name:'Bundle_A.pdf', label:'Bundle A',
        totalPages: 7,
        pageCategories: [
          { category:'invoice',  pages:[1, 2, 3] },
          { category:'annexure', pages:[4, 5]    },
          { category:'invoice',  pages:[6, 7]    },  // same id = separate accordion
        ],
      },
    ],
  },
  activeDocId:  'docA',
  activeBuffer: arrayBuffer,
}, [arrayBuffer]);
```

**DOC_REQUEST / DOC_RESPONSE:**
```ts
// Viewer fires when user selects a doc with no buffer:
{ type:'DOC_REQUEST', docId:'docB' }

// Parent responds:
send({ type:'DOC_RESPONSE', docId:'docB', buffer:docBBuffer }, [docBBuffer]);
// Or URL:
send({ type:'DOC_RESPONSE', docId:'docB', url:'https://cdn.example.com/docB.pdf' });

// Pre-load all buffers upfront:
send({ type:'ALL_DOC_RESPONSE', documents:[{ docId:'docA', buffer:bufA }, ...] });
```

---

## 4. All Flag Properties

All flags work on both **LOAD_SINGLEDOC** and **LOAD_MANIFEST** (top level).

| Property | Type | Default | Effect |
|---|---|---|---|
| `showThumbnailView` | boolean | `true` | Show / hide the thumbnail sidebar icon |
| `openThumbnail` | boolean | `false` | Auto-open the thumbnail panel on load |
| `showFieldsPanel` | boolean | `false` | Show the right-side capture fields panel |
| `showAnnotation` | boolean | `false` | Show annotation / draw button in toolbar |
| `showSplitMerge` | boolean | `false` | Show scissors (Split & Merge) icon in toolbar |
| `isSplitScreen` | boolean | `false` | Show Retrigger + Discard buttons in thumbnail panel; auto-opens sidebar |
| `Click2Pick` | boolean | `false` | Enable box-capture mode on load |
| `initialZoom` | string\|number | `'page-fit'` | Starting zoom level |
| `coordinateSpace` | `'px'`\|`'pt'`\|`'norm'` | auto | Declare coordinate unit for all captures |

**`initialZoom` values:** `'page-fit'` · `'page-width'` · `'actual'` · `1.5` (numeric scale)

**`coordinateSpace` values:**

| Value | Meaning |
|---|---|
| `'px'` | Pixels from a 96dpi rasterised image |
| `'pt'` | PDF points (72pt = 1 inch) |
| `'norm'` | Already 0–1 fractions — no conversion needed |
| omitted | Auto-detected from values |

### READY_CONFIG flags

| Property | Type | Default | Effect |
|---|---|---|---|
| `enableCaptureDebug` | boolean | `false` | Right-side capture fields panel |
| `initialZoom` | string\|number | `'page-fit'` | Starting zoom |
| `Click2Pick` | boolean | `false` | Box-capture mode |
| `showSplitMerge` | boolean | `false` | Scissors icon |

---

## 5. Categories

### LOAD_SINGLEDOC — each object = one accordion

```ts
categories: [
  { label:'Invoice',     pages:[5, 3, 1], color:'blue'  },
  { label:'Invoice',     pages:[6, 7],    color:'blue'  }, // same label = separate accordion
  { label:'Annexure',    pages:[4, 2],    color:'teal'  },
  { label:'Declaration', pages:[8],       color:'amber' },
  // pages not listed → auto "Others" group at bottom
  // page order preserved exactly as sent — not sorted
]
```

### MultiDoc:SinglePage — `category` string on each document

```ts
{ id:'doc1', category:'invoice'     },  // ─┐ Invoice group 1
{ id:'doc2', category:'invoice'     },  // ─┘
{ id:'doc3', category:'declaration' },  //    Declaration group
{ id:'doc5', category:'invoice'     },  //    Invoice group 2 (not merged with group 1)
```

### MultiDoc:MultiPage — `pageCategories[]` per document

```ts
pageCategories: [
  { category:'invoice', pages:[1, 2, 3] },  // accordion 1
  { category:'invoice', pages:[6, 7]    },  // accordion 2 — separate
]
// Page order within each entry preserved as sent
```

### Color palette

| `'blue'` | `'teal'` | `'amber'` | `'gray'` | `'purple'` | `'coral'` | `'green'` | `'red'` |
|---|---|---|---|---|---|---|---|
| `'#FF6B00'` hex | omit → auto-rotation | | | | | | |

**Common mistakes:**
- `pages:['1','2']` — strings fail matching → all pages go to "Others" → use numbers
- `pages:[]` — empty → category filtered out
- `color:'FF6B00'` — missing `#` → grey fallback → use `'#FF6B00'`

---

## 6. Captures — Highlight Boxes

### All supported coordinate formats

```ts
// 0-1 normalised (safest — no unit detection)
{ id:'1', value:'Total',  page:1, x:0.65, y:0.80, width:0.20, height:0.03 }

// FORMAT 10 — page-prefixed bbox [page, x, y, w, h]
{ id:'2', value:'Name',   bbox:[1, 125, 157, 138, 12] }

// bbox 4-element
{ id:'3', value:'Amount', page:1, bbox:[0.65, 0.80, 0.20, 0.03] }

// xmin/ymin corner points
{ id:'4', value:'Ref',    page:1, xmin:0.10, ymin:0.20, xmax:0.30, ymax:0.25 }

// CSS left/top
{ id:'5', value:'Date',   page:1, left:0.10, top:0.20, width:0.15, height:0.02 }

// Polygon → AABB derived
{ id:'6', value:'Code',   page:1, bbox_relative:[[0.1,0.2],[0.3,0.2],[0.3,0.25],[0.1,0.25]] }

// With explicit unit hint
{ id:'7', value:'Field',  page:1, x:125, y:157, width:138, height:12, _rawUnit:'px' }
```

> **Coordinate origin:** `x` and `y` always refer to the **top-left corner** of the
> box. `y` increases downward. If your source uses bottom-left origin (some PDF tools),
> convert before sending: `y_corrected = pageHeight - y_raw - height`

### Declare coordinate unit

```ts
// Top-level — all captures use this unit
send({ type:'LOAD_SINGLEDOC', ..., coordinateSpace:'px', captures:[...] });

// Per item — overrides for that item only
{ ..., _rawUnit:'px' }

// Drag-drop JSON file envelope
{ "coordinateSpace":"px", "captures":[...] }
```

### SET_CAPTURES — update after load

```ts
send({
  type:     'SET_CAPTURES',
  mode:     'replace',   // 'replace' (clear all) | 'merge' (add)
  docId:    'docA',      // optional — MultiDoc targeting
  captures: [{ id:'10', value:'New', page:1, x:0.3, y:0.5, width:0.2, height:0.02 }],
});
```

---

## 7. Events — Parent → Viewer

| Event | Purpose | Key fields |
|---|---|---|
| `READY_CONFIG` | Configure after READY | `enableCaptureDebug` `showSplitMerge` `initialZoom` `Click2Pick` |
| `LOAD_SINGLEDOC` | Load one document | `buffer` `fileName` + all flags + `categories` `captures` |
| `LOAD_MANIFEST` | Load multiple documents | `manifest` `activeDocId` `activeBuffer` + all flags |
| `DOC_RESPONSE` | Reply to DOC_REQUEST | `docId` + `buffer` or `url` |
| `ALL_DOC_RESPONSE` | Pre-load all buffers | `documents:[{docId, buffer}]` |
| `SET_CAPTURES` | Update captures after load | `mode` `captures` `docId?` |
| `DELETE_CAPTURE` | Remove a capture | `id` |
| `CAPTURE_ACK` | Acknowledge capture preview | `tempId` `realId` |
| `HIGHLIGHT` | Highlight a specific field | `id` `page` `x` `y` `width` `height` |
| `EXPORT_CAPTURES` | Request current captures | — |
| `RESET_VIEWER` | Clear to blank state | — |
| `SPLIT_MERGE_SAVE` | SM app: save modified doc | `buffer?` `fileName?` |
| `SPLIT_MERGE_EXIT` | SM app: exit without save | — |

---

## 8. Events — Viewer → Parent

| Event | When fired | Key fields |
|---|---|---|
| `READY` | Viewer initialised | — |
| `DOC_LOADED` | Document rendered | `fileName` `pageCount` `docId?` |
| `DOC_LOAD_ERROR` | Document failed | `code` `reason` `fileName` `docId?` |
| `DOC_REQUEST` | User selected doc with no buffer | `docId` |
| `CAPTURE_PREVIEW` | User drew a box or clicked text | `tempId` `text` `page` `x` `y` `width` `height` `bbox?` |
| `CAPTURES_DATA` | Reply to EXPORT_CAPTURES | `captures:ExportedCapture[]` |
| `VIEWER_STATE_CHANGED` | Page navigated or doc switched | see below |
| `RETRIGGER_CLICKED` | User confirmed Retrigger popup | `fileName` `page` `pageCount` `categories` `docId?` `mode?` |
| `DISCARD_CLICKED` | User clicked Discard | `fileName` `page` `pageCount` `categories` `docId?` `mode?` |
| `SPLIT_MERGE_OPENED` | SM screen activated | `fileName` |
| `SPLIT_MERGE_SAVED` | SM saved changes | `fileName?` |
| `SPLIT_MERGE_EXITED` | SM closed without save | `reason?` |

### VIEWER_STATE_CHANGED

```ts
{
  page,       // current page (1-based)
  pageCount,  // total pages in current document
  fileName,   // current file name
  docId?,     // active document id (MultiDoc only)
  docLabel?,  // display label from manifest
  mode?,      // 'MultiDoc:SinglePage' | 'MultiDoc:MultiPage'
  totalDocs?, // total documents in manifest
}
```

### CAPTURE_PREVIEW — acknowledge flow

```ts
// Viewer fires:
{ type:'CAPTURE_PREVIEW', tempId:'tmp_abc', text:'Invoice No',
  page:1, x:0.10, y:0.05, width:0.30, height:0.02 }

// Parent must ACK within 15s:
send({ type:'CAPTURE_ACK', tempId:'tmp_abc', realId:'field_001' });
```

### DOC_LOAD_ERROR codes

| Code | Meaning |
|---|---|
| `INVALID_BUFFER` | Buffer null, empty, or corrupt |
| `CORRUPT_FILE` | File parsed but unreadable |
| `UNSUPPORTED_FORMAT` | File type not supported |
| `DOC_REQUEST_TIMEOUT` | No DOC_RESPONSE within 60s |
| `RENDER_FAILED` | File loaded but page rendering failed |
| `UNKNOWN` | Unexpected error |

---

## 9. Events — SM Iframe → Viewer

### SM_RECLASSIFY

SM sends updated categories/documents back to the viewer.
**No `originalCategories` needed** — the viewer owns the original snapshot.

**Case 1: LOAD_SINGLEDOC**
```ts
window.parent.postMessage({
  type:       'SM_RECLASSIFY',
  categories: [
    { label:'Invoice',     pages:[1, 3, 5],    color:'blue'  },
    { label:'Annexure',    pages:[2, 4, 9],    color:'teal'  },
    { label:'Declaration', pages:[6],          color:'amber' },
  ],
}, '*');
```

**Case 2: MultiDoc:SinglePage**
```ts
window.parent.postMessage({
  type:      'SM_RECLASSIFY',
  documents: [
    { id:'doc1', name:'Invoice_001.pdf', label:'Invoice 001', category:'invoice'     },
    { id:'doc2', name:'Invoice_002.pdf', label:'Invoice 002', category:'invoice'     },
    { id:'doc3', name:'Decl_001.pdf',    label:'Decl 001',   category:'invoice'     },
    { id:'doc4', name:'Decl_002.pdf',    label:'Decl 002',   category:'declaration' },
  ],
}, '*');
```

**Case 3: MultiDoc:MultiPage**
```ts
window.parent.postMessage({
  type:      'SM_RECLASSIFY',
  documents: [
    {
      id:'docA', name:'Bundle_A.pdf', label:'Bundle A',
      pageCategories: [
        { category:'invoice',  pages:[1, 2, 3, 4] },
        { category:'annexure', pages:[5]           },
      ],
    },
  ],
}, '*');
```

### SPLIT_MERGE_SAVE / SPLIT_MERGE_EXIT

```ts
window.parent.postMessage({ type:'SPLIT_MERGE_SAVE', buffer:modifiedBuffer }, '*', [modifiedBuffer]);
window.parent.postMessage({ type:'SPLIT_MERGE_EXIT' }, '*');
```

---

## 10. Split & Merge Feature

### Setup

```env
VITE_SPLIT_MERGE_URL=https://your-split-merge-app.com
```

Enable the scissors icon:
```ts
send({ type:'READY_CONFIG',   showSplitMerge:true });
// or
send({ type:'LOAD_SINGLEDOC', ..., showSplitMerge:true });
// or inside manifest:
manifest: { ..., showSplitMerge:true }
```

### SPLIT_MERGE_OPEN payload (viewer → SM iframe)

```ts
{
  type: 'SPLIT_MERGE_OPEN',
  payload: {
    // Original parent message PATCHED with CURRENT store state
    // (categories/documents reflect latest SM_RECLASSIFY or parent update)
    type:       'LOAD_SINGLEDOC',
    buffer:     ArrayBuffer,       // zero-copy transferred
    fileName:   'invoice.pdf',
    categories: [...currentCategories],  // ← always the latest, not original
    captures:   [...],
  },
  viewerState: {
    pageCount:   21,
    currentPage: 3,
    format:      'pdf',
  },
}
```

### Event forwarding while SM is active

| Direction | Events forwarded to SM iframe |
|---|---|
| Parent → SM | `DOC_RESPONSE` `ALL_DOC_RESPONSE` `SET_CAPTURES` `DELETE_CAPTURE` `CAPTURE_ACK` |
| Closes SM, restores viewer | `LOAD_SINGLEDOC` `LOAD_MANIFEST` `RESET_VIEWER` |

---

## 11. Retrigger & Discard Buttons

Both appear at the bottom of the thumbnail sidebar when `isSplitScreen: true`.

### Enable

```ts
send({ type:'LOAD_SINGLEDOC', ..., isSplitScreen:true });
// Sidebar auto-opens. Retrigger active (blue). Discard disabled until SM_RECLASSIFY.
```

### Retrigger — confirmation popup

```
User clicks Retrigger
  → Popup: "Confirm Classification"
           "You are about to finalize the document classification.
            This action cannot be undone. Do you want to proceed?"
      [ Cancel ]  [ ↑ Retrigger ]

  Cancel   → popup closes, nothing changes
  Retrigger → popup closes
            → RETRIGGER_CLICKED fired to parent (with current categories)
            → bar → green "Successfully sent" for 2s → disappears permanently
```

### Discard — instant reset

```
User clicks Discard
  → categories restored to originalCategories snapshot
  → DISCARD_CLICKED fired to parent
  → both buttons disappear
```

### Button states

| State | Discard | Retrigger |
|---|---|---|
| `isSplitScreen` not sent | Hidden | Hidden |
| `isSplitScreen:true`, no SM update yet | Disabled (faded white) | Active (blue) |
| After `SM_RECLASSIFY` received | **Active (white)** | Active (blue) |
| After Retrigger → confirm | Hidden | Hidden |
| After Discard | Hidden | Hidden |

### Event payloads

```ts
// RETRIGGER_CLICKED
{ type:'RETRIGGER_CLICKED', fileName, page, pageCount, categories, docId?, mode? }
// categories = the current (updated) categories at time of click

// DISCARD_CLICKED
{ type:'DISCARD_CLICKED', fileName, page, pageCount, categories, docId?, mode? }
// categories = the restored original categories
```

---

## 12. SM Open → Reclassify → Discard — Full Event Flow

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 1 — Parent loads Viewer
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Parent → Viewer: LOAD_SINGLEDOC { categories:[A,B,C] }

Viewer stores:
  categories         = [A, B, C]   ← displayed in sidebar
  originalCategories = [A, B, C]   ← snapshot set on every parent load
  hasReclassification = false       ← Discard disabled


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 2 — User clicks SM icon (first open)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Viewer → SM iframe: SPLIT_MERGE_OPEN {
  payload: { categories:[A, B, C] },   ← current = original
  viewerState: { page, pageCount, format }
}


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 3 — SM reclassifies and sends back
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SM → Viewer: SM_RECLASSIFY { categories:[A', B', C'] }

Viewer stores:
  categories          = [A', B', C']  ← updated, sidebar refreshes
  originalCategories  = [A, B, C]     ← UNCHANGED — snapshot protected
  hasReclassification = true           ← Discard now active


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 4 — User clicks SM icon again (second open)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Viewer → SM iframe: SPLIT_MERGE_OPEN {
  payload: { categories:[A', B', C'] },  ← UPDATED state sent, not original
  viewerState: { page, pageCount, format }
}
// SM receives the latest — can reclassify further from correct base


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 5a — User clicks Retrigger → Proceed
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Viewer → Parent: RETRIGGER_CLICKED { categories:[A', B', C'] }
// Parent receives the final reclassified categories
// Both buttons disappear permanently


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 5b — User clicks Discard
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Viewer stores:
  categories          = [A, B, C]    ← restored from snapshot
  hasReclassification = false

Viewer → Parent: DISCARD_CLICKED { categories:[A, B, C] }
// Both buttons disappear permanently


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 6 — Parent sends a new LOAD_SINGLEDOC
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Parent → Viewer: LOAD_SINGLEDOC { categories:[X, Y, Z] }

Viewer stores:
  categories          = [X, Y, Z]   ← new displayed
  originalCategories  = [X, Y, Z]   ← snapshot RESET to new parent data
  hasReclassification = false        ← Discard disabled again
```

---

## 13. Viewer Configuration (.env)

```env
VITE_SPLIT_MERGE_URL=https://your-sm-app.com
VITE_PARENT_ORIGIN=https://your-angular-app.com
```

### Build commands

```bash
npm run dev           # local  → .env.development
npm run build:uat     # UAT    → .env.uat
npm run build:prod    # PROD   → .env.production
npm run build         # same as build:prod
```

---

## 14. Coordinate System Reference

All coordinates stored internally as **0–1 fractions** of page dimensions.
`x=0, y=0` = top-left corner. `y` increases downward.

### Auto-detection (batch — global max across all captures on same page)

| Condition | Detected unit | Reference |
|---|---|---|
| All values ≤ 1.0 | Already normalised | Pass-through |
| `maxRawX > effPageWidth` AND fits in px@96 | Pixels @96dpi | `pageW × 96/72` |
| `maxRawX ≤ effPageWidth` | Points (72dpi) | pts from PDF |
| PDF UserUnit > 1 (e.g. 2550×3299) | Strip UserUnit first | 612×792 effective |

> With only 3–4 captures per page, auto-detection may be unreliable.
> Use `coordinateSpace` or `_rawUnit` to declare the unit explicitly.

### FORMAT 10 — page-prefixed bbox

```ts
{ value:'Name', bbox:[1, 125, 157, 138, 12] }
//                    ↑pg  ↑x   ↑y   ↑w   ↑h
// Page extracted from bbox[0] automatically
// CAPTURE_PREVIEW round-trip: sends back { bbox:[1,125,157,138,12] } verbatim
```

### Gemini OCR output

```ts
// Gemini x_min, y_min, width, height → maps directly to x, y, width, height
// Both use top-left origin. Check max y across all items:
//   max_y < 1000 always → Gemini 1000-grid → divide by 1000
//   max_y can exceed 1000 → px@96dpi → divide by 816/1056
```

### All supported input formats

| Format | Example |
|---|---|
| Flat x/y | `{ x, y, width, height }` or `{ x, y, w, h }` |
| bbox 4-element | `{ bbox:[x, y, w, h] }` |
| FORMAT 10 page-prefixed | `{ bbox:[page, x, y, w, h] }` |
| rectangle | `{ rectangle:[x1,y1,x2,y2] }` |
| coordinates | `{ coordinates:[ymin,xmin,ymax,xmax] }` |
| xmin/ymin | `{ xmin, ymin, xmax, ymax }` |
| bbox_relative polygon | `{ bbox_relative:[[x,y],[x,y],[x,y],[x,y]] }` |
| CSS left/top | `{ left, top, width, height }` |
| Corner points | `{ left, right, top, bottom }` |

---

*DocCapture Viewer — Integration Guide · Session 6 final*
