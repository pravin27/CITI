# DocCapture Viewer — Complete Integration Guide

---

## Table of Contents

1. [Setup & Embedding](#1-setup--embedding)
2. [Handshake — READY flow](#2-handshake--ready-flow)
3. [Loading Documents](#3-loading-documents)
4. [All Flag Properties](#4-all-flag-properties)
5. [Categories](#5-categories)
6. [Captures (Highlight Boxes)](#6-captures-highlight-boxes)
7. [Events — Parent → Viewer](#7-events--parent--viewer)
8. [Events — Viewer → Parent](#8-events--viewer--parent)
9. [Events — SM Iframe → Viewer](#9-events--sm-iframe--viewer)
10. [Split & Merge Feature](#10-split--merge-feature)
11. [Retrigger & Discard Buttons](#11-retrigger--discard-buttons)
12. [Viewer Configuration (.env)](#12-viewer-configuration-env)
13. [Coordinate System Reference](#13-coordinate-system-reference)

---

## 1. Setup & Embedding

```html
<iframe
  #viewerFrame
  src="https://your-viewer-host.com"
  style="width:100%; height:100%; border:none;"
  allow="*"
></iframe>
```

```ts
const viewer = document.querySelector('iframe').contentWindow;

function send(msg: object, transferables?: Transferable[]) {
  viewer.postMessage(msg, '*', transferables ?? []);
}

window.addEventListener('message', (event) => {
  const { type, ...data } = event.data ?? {};
  if (!type) return;
  // handle viewer events — see Section 8
});
```

---

## 2. Handshake — READY flow

```
Viewer  ──── READY ───────────────────────────────────►  Parent
Parent  ──── READY_CONFIG (optional) ─────────────────►  Viewer
Parent  ──── LOAD_SINGLEDOC / LOAD_MANIFEST ──────────►  Viewer
Viewer  ──── DOC_LOADED ───────────────────────────────►  Parent
```

### READY_CONFIG (optional — sent after READY)

```ts
send({
  type:               'READY_CONFIG',
  enableCaptureDebug: true,      // show right-side fields panel
  initialZoom:        'page-fit',
  Click2Pick:         false,
  showSplitMerge:     true,      // show scissors icon
});
```

---

## 3. Loading Documents

### 3.1 LOAD_SINGLEDOC

```ts
send({
  type:     'LOAD_SINGLEDOC',
  buffer:   arrayBuffer,    // required — raw file bytes
  fileName: 'invoice.pdf',  // required — extension sets format

  // ── Display flags (all optional) ─────────────────────────────────────
  initialZoom:       'page-fit',   // see Section 4
  showFieldsPanel:   true,
  showAnnotation:    false,
  showThumbnailView: true,
  showSplitMerge:    true,
  isSplitScreen:     true,
  openThumbnail:     true,
  Click2Pick:        false,
  coordinateSpace:   'px',         // 'px' | 'pt' | 'norm'

  // ── Data (all optional) ───────────────────────────────────────────────
  categories: [...],               // see Section 5
  captures:   [...],               // see Section 6
  fullPageOCR: {
    1: [{ text: 'Invoice', x: 0.10, y: 0.05, width: 0.15, height: 0.02 }],
  },
}, [arrayBuffer]);
```

**Supported file formats via fileName extension:**
`.pdf` · `.tif/.tiff` · `.png` · `.jpg/.jpeg` · `.xlsx/.xls` · `.docx/.doc` · `.csv`

---

### 3.2 LOAD_MANIFEST — MultiDoc:SinglePage

```ts
send({
  type: 'LOAD_MANIFEST',
  manifest: {
    mode: 'MultiDoc:SinglePage',

    // Optional — custom labels/colors. Auto-derived from category strings if omitted.
    categories: [
      { id: 'invoice',     label: 'Invoice',     color: 'blue'  },
      { id: 'annexure',    label: 'Annexure',    color: 'teal'  },
      { id: 'declaration', label: 'Declaration', color: 'amber' },
    ],

    documents: [
      { id: 'doc1', name: 'Invoice_001.pdf', label: 'Invoice 001', category: 'invoice'     },
      { id: 'doc2', name: 'Invoice_002.pdf', label: 'Invoice 002', category: 'invoice'     },
      { id: 'doc3', name: 'Decl_001.pdf',    label: 'Decl 001',   category: 'declaration' },
      { id: 'doc4', name: 'Decl_002.pdf',    label: 'Decl 002',   category: 'declaration' },
      { id: 'doc5', name: 'Invoice_003.pdf', label: 'Invoice 003', category: 'invoice'     },
      // Consecutive same-category docs = one accordion.
      // doc1+doc2 → Invoice, doc3+doc4 → Declaration, doc5 → Invoice (3 groups)
    ],
  },

  // ── Display flags ─────────────────────────────────────────────────────
  isSplitScreen:  true,
  openThumbnail:  true,
  showSplitMerge: true,

  activeDocId:  'doc1',
  activeBuffer: arrayBuffer,
}, [arrayBuffer]);
```

---

### 3.3 LOAD_MANIFEST — MultiDoc:MultiPage

```ts
send({
  type: 'LOAD_MANIFEST',
  manifest: {
    mode: 'MultiDoc:MultiPage',

    categories: [
      { id: 'invoice',     label: 'Invoice',     color: 'blue'  },
      { id: 'annexure',    label: 'Annexure',    color: 'teal'  },
      { id: 'declaration', label: 'Declaration', color: 'amber' },
    ],

    documents: [
      {
        id:         'docA',
        name:       'Bundle_A.pdf',
        label:      'Bundle A',
        totalPages: 7,             // optional — auto-derived if omitted
        pageCategories: [
          { category: 'invoice',     pages: [1, 2, 3] },  // one accordion per entry
          { category: 'annexure',    pages: [4, 5]    },
          { category: 'invoice',     pages: [6, 7]    },  // same id = separate accordion
        ],
      },
      {
        id:    'docB',
        name:  'Bundle_B.pdf',
        label: 'Bundle B',
        pageCategories: [
          { category: 'invoice',     pages: [1, 2] },
          { category: 'declaration', pages: [3]    },
        ],
      },
    ],
  },
  activeDocId:  'docA',
  activeBuffer: arrayBuffer,
}, [arrayBuffer]);
```

**When user selects a different doc**, viewer fires `DOC_REQUEST`:
```ts
// Viewer → Parent
{ type: 'DOC_REQUEST', docId: 'docB' }

// Parent responds:
send({ type: 'DOC_RESPONSE', docId: 'docB', buffer: docBBuffer }, [docBBuffer]);
// Or with URL:
send({ type: 'DOC_RESPONSE', docId: 'docB', url: 'https://cdn.example.com/docB.pdf' });

// Pre-load all buffers upfront (avoids per-doc requests):
send({ type: 'ALL_DOC_RESPONSE', documents: [{ docId:'docA', buffer:bufA }, ...] });
```

---

## 4. All Flag Properties

These can be sent on **LOAD_SINGLEDOC** and **LOAD_MANIFEST** (top level, not inside manifest).

| Property | Type | Default | Effect |
|---|---|---|---|
| `showThumbnailView` | boolean | `true` | Show/hide the thumbnail sidebar icon entirely |
| `openThumbnail` | boolean | `false` | Auto-open the thumbnail panel on load |
| `showFieldsPanel` | boolean | `false` | Show the right-side capture fields panel |
| `showAnnotation` | boolean | `false` | Show the annotation/draw button in toolbar |
| `showSplitMerge` | boolean | `false` | Show the scissors (Split & Merge) icon in toolbar |
| `isSplitScreen` | boolean | `false` | Show Retrigger + Discard buttons at bottom of thumbnail panel. Also auto-opens sidebar. |
| `Click2Pick` | boolean | `false` | Enable box-capture mode immediately on load |
| `initialZoom` | string\|number | `'page-fit'` | Starting zoom level — see zoom values below |
| `coordinateSpace` | `'px'`\|`'pt'`\|`'norm'` | auto-detect | Declare coordinate unit for captures — bypasses auto-detection |

**`initialZoom` values:**

| Value | Effect |
|---|---|
| `'page-fit'` | Fit full page in viewport |
| `'page-width'` | Fit page width, scroll vertically |
| `'actual'` | 100% zoom |
| `1.5` | Explicit numeric scale (1.0 = 100%) |

**`coordinateSpace` values:**

| Value | Meaning |
|---|---|
| `'px'` | Coordinates are pixels from a rasterised image at 96dpi |
| `'pt'` | Coordinates are PDF points (72pt = 1 inch) |
| `'norm'` | Coordinates are already 0–1 fractions — no conversion needed |
| omitted | Auto-detected from coordinate values (default) |

### READY_CONFIG flags (sent after READY event)

| Property | Type | Default | Effect |
|---|---|---|---|
| `enableCaptureDebug` | boolean | `false` | Show right-side capture fields panel |
| `initialZoom` | string\|number | `'page-fit'` | Starting zoom level |
| `Click2Pick` | boolean | `false` | Enable box-capture mode |
| `showSplitMerge` | boolean | `false` | Show scissors icon |

---

## 5. Categories

### LOAD_SINGLEDOC — each object = one accordion (order preserved)

```ts
categories: [
  { label: 'Invoice',     pages: [5, 3, 1], color: 'blue'  },
  { label: 'Invoice',     pages: [6, 7],    color: 'blue'  }, // same label = separate accordion
  { label: 'Annexure',    pages: [4, 2],    color: 'teal'  },
  { label: 'Declaration', pages: [8],       color: 'amber' },
  // pages not in any category → auto "Others" group at bottom
  // page order preserved exactly as sent — not sorted
]
```

### MultiDoc:SinglePage — `category` string on each document

```ts
// Consecutive docs with same category = one accordion group
{ id:'doc1', category:'invoice'     },  // ─┐ Invoice group
{ id:'doc2', category:'invoice'     },  // ─┘
{ id:'doc3', category:'declaration' },  //    Declaration group
{ id:'doc5', category:'invoice'     },  //    Invoice group (separate — not merged)
```

### MultiDoc:MultiPage — `pageCategories[]` per document

```ts
// Each entry = one accordion. Same category id can appear multiple times.
pageCategories: [
  { category: 'invoice', pages: [1, 2, 3] },  // accordion 1
  { category: 'invoice', pages: [6, 7]    },  // accordion 2 — separate
]
// page order within each entry preserved as sent
```

### Color palette

| Key | Key | Key | Key |
|---|---|---|---|
| `'blue'` | `'teal'` | `'amber'` | `'gray'` |
| `'purple'` | `'coral'` | `'green'` | `'red'` |
| `'#FF6B00'` (hex) | omit → auto-rotation | | |

**Common mistakes:**
- `pages: ['1','2']` — strings fail the match → all pages land in "Others" → use numbers
- `pages: []` — empty array → category filtered out
- `color: 'FF6B00'` — missing `#` → grey fallback → use `'#FF6B00'`

---

## 6. Captures (Highlight Boxes)

### All supported coordinate formats

```ts
// Normalised 0-1 (safest — no unit detection)
{ id:'1', value:'Total',  page:1, x:0.65, y:0.80, width:0.20, height:0.03 }

// FORMAT 10 — page-prefixed bbox [page, x, y, w, h]
{ id:'2', value:'Name',   bbox:[1, 125, 157, 138, 12] }
//                              ↑pg  ↑x   ↑y   ↑w   ↑h

// bbox 4-element
{ id:'3', value:'Amount', page:1, bbox:[0.65, 0.80, 0.20, 0.03] }

// xmin/ymin corner points
{ id:'4', value:'Ref',    page:1, xmin:0.10, ymin:0.20, xmax:0.30, ymax:0.25 }

// CSS left/top
{ id:'5', value:'Date',   page:1, left:0.10, top:0.20, width:0.15, height:0.02 }

// Polygon → AABB derived
{ id:'6', value:'Code',   page:1, bbox_relative:[[0.1,0.2],[0.3,0.2],[0.3,0.25],[0.1,0.25]] }

// With explicit unit hint (bypasses auto-detection)
{ id:'7', value:'Field',  page:1, x:125, y:157, width:138, height:12, _rawUnit:'px' }
```

### Send on load

```ts
captures: [
  { id:'1', value:'Emerald Earth', bbox:[1, 125, 157, 138, 12] },
  { id:'2', value:'USD',           page:1, x:0.722, y:0.149, width:0.107, height:0.011 },
]
```

### SET_CAPTURES — update after load

```ts
send({
  type:     'SET_CAPTURES',
  mode:     'replace',   // 'replace' | 'merge'
  docId:    'docA',      // optional — MultiDoc targeting
  captures: [{ id:'10', value:'New', page:1, x:0.3, y:0.5, width:0.2, height:0.02 }],
});
```

### `_rawUnit` per item / `coordinateSpace` top-level

```ts
// Per item (overrides auto-detection for that item)
{ value:'Field', page:1, x:125, y:157, width:138, height:12, _rawUnit:'px' }

// Top-level on load event (applies to all captures)
send({ type:'LOAD_SINGLEDOC', ..., coordinateSpace:'px', captures:[...] });

// Envelope format in drag-drop JSON file
{ "coordinateSpace": "px", "captures": [...] }
```

---

## 7. Events — Parent → Viewer

| Event | Purpose | Key fields |
|---|---|---|
| `READY_CONFIG` | Configure viewer after READY | `enableCaptureDebug` `showSplitMerge` `initialZoom` `Click2Pick` |
| `LOAD_SINGLEDOC` | Load one document | `buffer` `fileName` + all flags + `categories` `captures` |
| `LOAD_MANIFEST` | Load multiple documents | `manifest` `activeDocId` `activeBuffer` + all flags |
| `DOC_RESPONSE` | Reply to DOC_REQUEST | `docId` + `buffer` or `url` |
| `ALL_DOC_RESPONSE` | Pre-load all buffers | `documents: [{docId, buffer}]` |
| `SET_CAPTURES` | Update captures after load | `mode` `captures` `docId?` |
| `DELETE_CAPTURE` | Remove a capture | `id` |
| `CAPTURE_ACK` | Acknowledge capture preview | `tempId` `realId` |
| `HIGHLIGHT` | Highlight a specific field | `id` `page` `x` `y` `width` `height` |
| `EXPORT_CAPTURES` | Request current captures | — |
| `RESET_VIEWER` | Clear viewer to blank | — |
| `SPLIT_MERGE_SAVE` | SM app: save modified doc | `buffer?` `fileName?` |
| `SPLIT_MERGE_EXIT` | SM app: exit without save | — |

---

## 8. Events — Viewer → Parent

| Event | When fired | Key fields |
|---|---|---|
| `READY` | Viewer initialised, waiting for doc | — |
| `DOC_LOADED` | Document rendered successfully | `fileName` `pageCount` `docId?` |
| `DOC_LOAD_ERROR` | Document failed to load | `code` `reason` `fileName` `docId?` |
| `DOC_REQUEST` | User selected doc with no buffer | `docId` |
| `CAPTURE_PREVIEW` | User drew a box or double-clicked text | `tempId` `text` `page` `x` `y` `width` `height` `bbox?` |
| `CAPTURES_DATA` | Reply to EXPORT_CAPTURES | `captures: ExportedCapture[]` |
| `VIEWER_STATE_CHANGED` | Page navigated or document switched | see below |
| `RETRIGGER_CLICKED` | User clicked Retrigger button | `fileName` `page` `pageCount` `categories` `docId?` `mode?` |
| `DISCARD_CLICKED` | User clicked Discard button | `fileName` `page` `pageCount` `categories` `docId?` `mode?` |
| `SPLIT_MERGE_OPENED` | SM screen activated | `fileName` |
| `SPLIT_MERGE_SAVED` | SM saved changes | `fileName?` |
| `SPLIT_MERGE_EXITED` | SM closed without save | `reason?` |

### VIEWER_STATE_CHANGED — full payload

```ts
window.addEventListener('message', (event) => {
  if (event.data?.type !== 'VIEWER_STATE_CHANGED') return;
  const {
    page,       // current page (1-based)
    pageCount,  // total pages in current document
    fileName,   // current file name

    // MultiDoc only (undefined for SingleDoc):
    docId,      // active document id
    docLabel,   // display label from manifest
    mode,       // 'MultiDoc:SinglePage' | 'MultiDoc:MultiPage'
    totalDocs,  // total documents in manifest
  } = event.data;
});
```

### CAPTURE_PREVIEW — acknowledge flow

```ts
// Viewer fires:
{ type:'CAPTURE_PREVIEW', tempId:'tmp_abc', text:'Invoice No',
  page:1, x:0.10, y:0.05, width:0.30, height:0.02 }

// Parent must ACK within 15s:
send({ type:'CAPTURE_ACK', tempId:'tmp_abc', realId:'field_001' });
```

### DOC_LOAD_ERROR codes

| Code | Meaning |
|---|---|
| `INVALID_BUFFER` | Buffer null, empty, or corrupt |
| `CORRUPT_FILE` | File parsed but unreadable |
| `UNSUPPORTED_FORMAT` | File type not supported |
| `DOC_REQUEST_TIMEOUT` | No DOC_RESPONSE within 60s |
| `RENDER_FAILED` | Loaded but page render failed |
| `UNKNOWN` | Unexpected error |

---

## 9. Events — SM Iframe → Viewer

These are posted by the SM iframe app to `window.parent` (the viewer).

### SM_RECLASSIFY — update categories after reclassification

**Case 1: LOAD_SINGLEDOC** (flat categories array)

```ts
window.parent.postMessage({
  type: 'SM_RECLASSIFY',

  // Updated categories from SM reclassification
  categories: [
    { label: 'Invoice',     pages: [1, 3, 5],    color: 'blue'  },
    { label: 'Annexure',    pages: [2, 4, 9],    color: 'teal'  },
    { label: 'Declaration', pages: [6],          color: 'amber' },
  ],

  // Original categories — stored for Discard button to restore
  originalCategories: [
    { label: 'Invoice',     pages: [5, 3, 1, 9], color: 'blue'  },
    { label: 'Annexure',    pages: [2, 4],       color: 'teal'  },
    { label: 'Declaration', pages: [6],          color: 'amber' },
  ],
}, '*');
```

**Case 2: MultiDoc:SinglePage** (category string on each document)

```ts
window.parent.postMessage({
  type: 'SM_RECLASSIFY',

  documents: [
    { id:'doc1', name:'Invoice_001.pdf', label:'Invoice 001', category:'invoice'     },
    { id:'doc2', name:'Invoice_002.pdf', label:'Invoice 002', category:'invoice'     },
    { id:'doc3', name:'Decl_001.pdf',    label:'Decl 001',   category:'invoice'     }, // changed
    { id:'doc4', name:'Decl_002.pdf',    label:'Decl 002',   category:'declaration' },
  ],

  originalDocuments: [
    { id:'doc1', name:'Invoice_001.pdf', label:'Invoice 001', category:'invoice'     },
    { id:'doc2', name:'Invoice_002.pdf', label:'Invoice 002', category:'invoice'     },
    { id:'doc3', name:'Decl_001.pdf',    label:'Decl 001',   category:'declaration' }, // original
    { id:'doc4', name:'Decl_002.pdf',    label:'Decl 002',   category:'declaration' },
  ],
}, '*');
```

**Case 3: MultiDoc:MultiPage** (pageCategories per document)

```ts
window.parent.postMessage({
  type: 'SM_RECLASSIFY',

  documents: [
    {
      id:'docA', name:'Bundle_A.pdf', label:'Bundle A',
      pageCategories: [
        { category:'invoice',     pages:[1, 2, 3, 4] },  // page 4 moved in
        { category:'annexure',    pages:[5]           },
        { category:'declaration', pages:[6, 7]        },
      ],
    },
  ],

  originalDocuments: [
    {
      id:'docA', name:'Bundle_A.pdf', label:'Bundle A',
      pageCategories: [
        { category:'invoice',     pages:[1, 2, 3]  },  // page 4 was here
        { category:'annexure',    pages:[4, 5]     },
        { category:'declaration', pages:[6, 7]     },
      ],
    },
  ],
}, '*');
```

> `originalCategories` / `originalDocuments` are optional. Without them the
> viewer applies the update but the Discard button stays disabled.

### SPLIT_MERGE_SAVE / SPLIT_MERGE_EXIT

```ts
// Save with new document buffer:
window.parent.postMessage({ type:'SPLIT_MERGE_SAVE', buffer:modifiedBuffer }, '*', [modifiedBuffer]);

// Exit without changes:
window.parent.postMessage({ type:'SPLIT_MERGE_EXIT' }, '*');
```

---

## 10. Split & Merge Feature

Replaces viewer with an external iframe for split/merge operations.

### Setup

```env
# In viewer .env file:
VITE_SPLIT_MERGE_URL=https://your-split-merge-app.com
```

Enable the icon:
```ts
send({ type:'READY_CONFIG',   showSplitMerge: true });
// or
send({ type:'LOAD_SINGLEDOC', ..., showSplitMerge: true });
// or
send({ type:'LOAD_MANIFEST',  manifest:{ ..., showSplitMerge: true }, ... });
```

### SPLIT_MERGE_OPEN payload (viewer → SM iframe)

```ts
{
  type: 'SPLIT_MERGE_OPEN',

  payload: {
    // Exact copy of what parent originally sent
    type:       'LOAD_SINGLEDOC',
    buffer:     ArrayBuffer,       // zero-copy transferred
    fileName:   'invoice.pdf',
    categories: [...],
    captures:   [...],
    // ...all other fields
  },

  viewerState: {
    pageCount:   21,
    currentPage: 3,
    format:      'pdf',            // 'pdf'|'image'|'document'|'spreadsheet'
  },
}
```

### Event forwarding while SM is active

| Direction | Events forwarded to SM iframe |
|---|---|
| Parent → SM | `DOC_RESPONSE` `ALL_DOC_RESPONSE` `SET_CAPTURES` `DELETE_CAPTURE` `CAPTURE_ACK` |
| These close SM and restore viewer | `LOAD_SINGLEDOC` `LOAD_MANIFEST` `RESET_VIEWER` |

---

## 11. Retrigger & Discard Buttons

Both buttons appear at the bottom of the thumbnail sidebar when `isSplitScreen: true`.

### Enable

```ts
send({ type:'LOAD_SINGLEDOC', ..., isSplitScreen: true });
// Sidebar auto-opens. Retrigger button shown. Discard disabled until SM_RECLASSIFY received.
```

### Button states

| State | Discard | Retrigger |
|---|---|---|
| `isSplitScreen` not sent | Hidden | Hidden |
| `isSplitScreen: true` sent | Disabled (faded) | Active (blue) |
| `SM_RECLASSIFY` received | **Active (white)** | Active (blue) |
| After Retrigger clicked | Hidden | Hidden |
| After Discard clicked | Hidden | Hidden |

### RETRIGGER_CLICKED event

```ts
window.addEventListener('message', (event) => {
  if (event.data?.type !== 'RETRIGGER_CLICKED') return;
  const { fileName, page, pageCount, categories, docId, mode } = event.data;
});
```

### DISCARD_CLICKED event

```ts
window.addEventListener('message', (event) => {
  if (event.data?.type !== 'DISCARD_CLICKED') return;
  const { fileName, page, pageCount, categories, docId, mode } = event.data;
  // categories = the restored original values
});
```

---

## 12. Viewer Configuration (.env)

```env
# URL of Split & Merge app (leave empty to disable scissors icon)
VITE_SPLIT_MERGE_URL=https://your-sm-app.com

# Restrict which parent origin can postMessage (default: * = any)
VITE_PARENT_ORIGIN=https://your-angular-app.com
```

### Build commands

```bash
npm run dev           # local  → .env.development
npm run build:uat     # UAT    → .env.uat
npm run build:prod    # PROD   → .env.production
npm run build         # same as build:prod
```

---

## 13. Coordinate System Reference

All coordinates stored internally as **0–1 fractions** of page dimensions.

### Auto-detection (batch across all captures on same page)

| Condition | Unit detected | Reference dims |
|---|---|---|
| All values ≤ 1.0 | Already normalised | Pass-through |
| `maxRawX > effPageWidth` AND fits in px@96 | Pixels @96dpi | `pageW × 96/72` |
| `maxRawX ≤ effPageWidth` | Points (72dpi) | pts from PDF |
| PDF UserUnit > 1 (e.g. 2550×3299) | Strip to real pts first | 612×792 effective |

### Declare explicitly with `coordinateSpace` or `_rawUnit`

```ts
// Top-level on load event — applies to all captures
coordinateSpace: 'px'    // pixels
coordinateSpace: 'pt'    // PDF points
coordinateSpace: 'norm'  // already 0-1

// Per item — overrides auto-detection for that item
{ ..., _rawUnit: 'px' }

// Drag-drop JSON envelope
{ "coordinateSpace": "px", "captures": [...] }
```

### FORMAT 10 — page-prefixed bbox

```ts
{ value:'Name', bbox:[1, 125, 157, 138, 12] }
//                    ↑pg  ↑x   ↑y   ↑w   ↑h
// Page extracted from bbox[0]
// CAPTURE_PREVIEW sends back { bbox:[1,125,157,138,12] } verbatim
```

### All supported input formats

| Format | Example |
|---|---|
| Flat x/y | `{ x, y, width, height }` or `{ x, y, w, h }` |
| bbox 4-element | `{ bbox:[x, y, w, h] }` |
| FORMAT 10 page-prefixed | `{ bbox:[page, x, y, w, h] }` |
| rectangle | `{ rectangle:[x1,y1,x2,y2] }` |
| coordinates | `{ coordinates:[ymin,xmin,ymax,xmax] }` |
| xmin/ymin | `{ xmin, ymin, xmax, ymax }` |
| bbox_relative polygon | `{ bbox_relative:[[x,y],[x,y],[x,y],[x,y]] }` |
| CSS left/top | `{ left, top, width, height }` |
| Corner points | `{ left, right, top, bottom }` |

---

*DocCapture Viewer — Integration Guide · Session 6 complete*
