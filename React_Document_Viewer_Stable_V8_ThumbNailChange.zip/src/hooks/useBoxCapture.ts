// ─────────────────────────────────────────────────────────────────────────────
// useBoxCapture — lightweight, main-thread-safe box drawing and capture
//
// DESIGN PRINCIPLES (no freezing):
//
//  1. pointermove is throttled via requestAnimationFrame.
//     Only ONE drawRubber() call per animation frame regardless of mouse speed.
//     Raw pointermove can fire 200+ times/sec — without RAF throttle this
//     locks the main thread.
//
//  2. Rubber canvas is NOT resized on every move.
//     It is sized once on pointerdown (screen dimensions don't change during drag).
//     Canvas resize forces GPU texture reallocation — very expensive.
//
//  3. innerRect (getBoundingClientRect) called once on pointerdown and cached.
//     Not called during move or up.
//
//  4. Hit-testing (wordIndex lookup) runs synchronously but is O(words_on_page)
//     pure arithmetic — typically < 0.5ms for 500 words. No DOM access.
//
//  5. Fallback DOM scan (no wordIndex) uses MessageChannel to defer off the
//     current microtask queue — never blocks user interaction.
//
//  6. Double-click: direct wordIndex point lookup, ~0ms.
// ─────────────────────────────────────────────────────────────────────────────

import { useEffect, useRef, useCallback } from 'react';
import { useAppStore } from '../store/appStore';
import type { WordEntry } from '../adapters/types';

const DRAG_THRESHOLD = 5;     // px min movement before rubber-band starts
const HIT_TOL        = 0.001; // fractional tolerance for partial word overlap

export interface CaptureResult {
  text: string; page: number;
  x: number; y: number; width: number; height: number;
  _textField?: 'text' | 'label' | 'value';
}

// ── Rubber-band overlay ────────────────────────────────────────────────────────
// Single canvas, fixed position, always in DOM when box mode is on.
// Sized once, cleared on drag end.

let _rubberCanvas: HTMLCanvasElement | null = null;
let _rubberCtx: CanvasRenderingContext2D | null = null;

function ensureRubberCanvas(): { canvas: HTMLCanvasElement; ctx: CanvasRenderingContext2D } {
  if (!_rubberCanvas) {
    _rubberCanvas = document.createElement('canvas');
    _rubberCanvas.id = 'tov-rubber';
    _rubberCanvas.style.cssText =
      'position:fixed;inset:0;pointer-events:none;z-index:99999;';
    document.body.appendChild(_rubberCanvas);
    _rubberCtx = _rubberCanvas.getContext('2d')!;
  }
  return { canvas: _rubberCanvas, ctx: _rubberCtx! };
}

function sizeRubberOnce() {
  // Called once on drag start — not on every move
  const { canvas } = ensureRubberCanvas();
  canvas.width  = window.innerWidth;
  canvas.height = window.innerHeight;
  canvas.style.width  = window.innerWidth  + 'px';
  canvas.style.height = window.innerHeight + 'px';
}

function drawRubber(x1: number, y1: number, x2: number, y2: number) {
  const { canvas, ctx } = ensureRubberCanvas();
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  const lx = Math.min(x1, x2), ly = Math.min(y1, y2);
  const lw = Math.abs(x2 - x1), lh = Math.abs(y2 - y1);
  if (lw < 1 || lh < 1) return;
  ctx.fillStyle   = 'rgba(10,132,255,0.07)';
  ctx.strokeStyle = 'rgba(10,132,255,0.85)';
  ctx.lineWidth   = 1.5;
  ctx.setLineDash([5, 3]);
  ctx.fillRect(lx, ly, lw, lh);
  ctx.strokeRect(lx + 0.75, ly + 0.75, lw - 1.5, lh - 1.5);
  ctx.setLineDash([]);
  // Corner handles
  ctx.fillStyle = 'rgba(10,132,255,0.9)';
  ctx.fillRect(lx - 3, ly - 3, 6, 6);
  ctx.fillRect(lx + lw - 3, ly - 3, 6, 6);
  ctx.fillRect(lx - 3, ly + lh - 3, 6, 6);
  ctx.fillRect(lx + lw - 3, ly + lh - 3, 6, 6);
}

function clearRubber() {
  if (!_rubberCanvas || !_rubberCtx) return;
  _rubberCtx.clearRect(0, 0, _rubberCanvas.width, _rubberCanvas.height);
}

// ── Page element from event target ────────────────────────────────────────────
// pdfjs native viewer wraps pages in <div class="page"> with data-page-number.
// We support both our data-page-number attr and pdfjs's own attribute.

function getPageEl(el: HTMLElement): HTMLElement | null {
  return el.closest('[data-page-number]') as HTMLElement | null;
}

function getPageNum(pageEl: HTMLElement): number {
  return Number(pageEl.dataset.pageNumber ?? 0);
}

// Get the inner canvas rect — returns CSS pixel DOMRect.
// We specifically target the pdfjs-rendered canvas (not our overlay).
// getBoundingClientRect() always returns CSS pixels regardless of DPR.
function getInnerRect(pageEl: HTMLElement): DOMRect {
  // Prefer the pdfjs canvas (has correct CSS display dimensions)
  const pdfjsCanvas = pageEl.querySelector<HTMLCanvasElement>('canvas:not([data-hl-canvas])');
  if (pdfjsCanvas) return pdfjsCanvas.getBoundingClientRect();
  // Fallback: .canvasWrapper div, then page div itself
  const wrapper = pageEl.querySelector<HTMLElement>('.canvasWrapper');
  if (wrapper) return wrapper.getBoundingClientRect();
  return pageEl.getBoundingClientRect();
}

function toFrac(cx: number, cy: number, r: DOMRect) {
  return {
    fx: (cx - r.left) / r.width,
    fy: (cy - r.top)  / r.height,
  };
}

// ── Pure fractional word-index hit-test (zero DOM, zero layout) ───────────────

function hitPoint(fx: number, fy: number, page: number, wi: Map<number, WordEntry[]>): WordEntry | null {
  const entries = wi.get(page);
  if (!entries) return null;
  for (const e of entries) {
    if (fx >= e.x - HIT_TOL && fx <= e.x + e.width  + HIT_TOL &&
        fy >= e.y - HIT_TOL && fy <= e.y + e.height + HIT_TOL) {
      return e;
    }
  }
  return null;
}

function hitBox(
  minFx: number, maxFx: number, minFy: number, maxFy: number,
  page: number, wi: Map<number, WordEntry[]>
): WordEntry[] {
  const entries = wi.get(page);
  if (!entries) return [];
  const hits: WordEntry[] = [];
  for (const e of entries) {
    if (e.x + e.width  >= minFx - HIT_TOL &&
        e.x             <= maxFx + HIT_TOL &&
        e.y + e.height  >= minFy - HIT_TOL &&
        e.y             <= maxFy + HIT_TOL) {
      hits.push(e);
    }
  }
  return hits;
}

function mergeHits(hits: WordEntry[], page: number): CaptureResult {
  hits.sort((a, b) => Math.abs(a.y - b.y) > 0.008 ? a.y - b.y : a.x - b.x);
  let bx = Infinity, by = Infinity, bx2 = -Infinity, by2 = -Infinity;
  for (const h of hits) {
    if (h.x < bx) bx = h.x;
    if (h.y < by) by = h.y;
    if (h.x + h.width  > bx2) bx2 = h.x + h.width;
    if (h.y + h.height > by2) by2 = h.y + h.height;
  }
  // Use _textField from first hit (all hits from same word_index share the same key)
  const _textField = (hits[0] as any)._textField as CaptureResult['_textField'];
  return { text: hits.map(h => h.text).join(' '), page, x: bx, y: by, width: bx2 - bx, height: by2 - by, _textField };
}

// ── DOM fallback for pdfjs text layer (deferred via MessageChannel) ────────────

function hitDomDeferred(
  cx: number, cy: number,
  pageEl: HTMLElement, iRect: DOMRect, page: number,
  cb: (r: CaptureResult | null) => void
) {
  const mc = new MessageChannel();
  mc.port1.onmessage = () => {
    // elementFromPoint is fast — no querySelectorAll
    const el = document.elementFromPoint(cx, cy) as HTMLElement | null;
    const span = el?.closest('.textLayer span, span') as HTMLElement | null;
    if (!span) { cb(null); return; }
    const txt = span.textContent?.trim() ?? '';
    if (!txt) { cb(null); return; }
    const r = span.getBoundingClientRect();
    const W = iRect.width, H = iRect.height;
    cb({
      text: txt, page,
      x:      (r.left - iRect.left) / W,
      y:      (r.top  - iRect.top)  / H,
      width:   r.width  / W,
      height:  r.height / H,
    });
  };
  mc.port2.postMessage(null);
}

function boxDomDeferred(
  minFx: number, maxFx: number, minFy: number, maxFy: number,
  pageEl: HTMLElement, iRect: DOMRect, page: number,
  cb: (r: CaptureResult | null) => void
) {
  const mc = new MessageChannel();
  mc.port1.onmessage = () => {
    const W = iRect.width, H = iRect.height;
    // Only scan the text layer (pdfjs), not all spans
    const spans = pageEl.querySelectorAll<HTMLElement>('.textLayer span');
    const hits: Array<{ text: string; x: number; y: number; width: number; height: number }> = [];
    const seen = new Set<number>();

    for (const sp of spans) {
      const txt = sp.textContent?.trim() ?? '';
      if (!txt) continue;
      const r  = sp.getBoundingClientRect();
      if (r.width < 1 || r.height < 1) continue;
      const sx = (r.left - iRect.left) / W;
      const sy = (r.top  - iRect.top)  / H;
      const sw = r.width  / W;
      const sh = r.height / H;
      if (sx + sw < minFx - HIT_TOL || sx > maxFx + HIT_TOL) continue;
      if (sy + sh < minFy - HIT_TOL || sy > maxFy + HIT_TOL) continue;
      const k = Math.round(sx * 10000) * 100000 + Math.round(sy * 10000);
      if (seen.has(k)) continue;
      seen.add(k);
      hits.push({ text: txt, x: sx, y: sy, width: sw, height: sh });
    }

    if (!hits.length) { cb(null); return; }
    hits.sort((a, b) => Math.abs(a.y - b.y) > 0.008 ? a.y - b.y : a.x - b.x);
    let bx = Infinity, by = Infinity, bx2 = -Infinity, by2 = -Infinity;
    for (const h of hits) {
      if (h.x < bx) bx = h.x; if (h.y < by) by = h.y;
      if (h.x + h.width > bx2) bx2 = h.x + h.width;
      if (h.y + h.height > by2) by2 = h.y + h.height;
    }
    cb({ text: hits.map(h => h.text).join(' '), page, x: bx, y: by, width: bx2 - bx, height: by2 - by });
  };
  mc.port2.postMessage(null);
}

// ── Main hook ──────────────────────────────────────────────────────────────────

export function useBoxCapture(
  containerRef: React.RefObject<HTMLElement>,
  onCapture: (result: CaptureResult) => void
) {
  const boxMode      = useAppStore(s => s.boxMode);
  const wordIndex    = useAppStore(s => s.wordIndex);
  const setPreviewRect = useAppStore(s => s.setPreviewRect);

  // Stable refs — avoid re-registering events on every state change
  const wiRef         = useRef(wordIndex);
  const onCaptureRef  = useRef(onCapture);
  const boxModeRef    = useRef(boxMode);
  useEffect(() => { wiRef.current       = wordIndex; }, [wordIndex]);
  useEffect(() => { onCaptureRef.current = onCapture; }, [onCapture]);
  useEffect(() => { boxModeRef.current   = boxMode; },   [boxMode]);

  // Drag state — all refs, no React state = zero re-renders during drag
  const dragStart  = useRef<{ x: number; y: number; pageEl: HTMLElement; iRect: DOMRect; page: number } | null>(null);
  const dragging   = useRef(false);
  const rafPending = useRef(0);       // RAF handle for throttled move
  const lastMouse  = useRef({ x: 0, y: 0 }); // latest mouse position

  const fire = useCallback((result: CaptureResult) => {
    setPreviewRect({ page: result.page, x: result.x, y: result.y, width: result.width, height: result.height });
    onCaptureRef.current(result);
  }, [setPreviewRect]);

  // ── Pointer down ─────────────────────────────────────────────────────────────
  const onPointerDown = useCallback((e: PointerEvent) => {
    if (!boxModeRef.current || e.button !== 0) return;
    if ((e.target as HTMLElement).closest('button,input,textarea,select')) return;
    const pageEl = getPageEl(e.target as HTMLElement);
    if (!pageEl) return;

    // getBoundingClientRect ONCE here, never during move
    const iRect = getInnerRect(pageEl);
    dragStart.current = { x: e.clientX, y: e.clientY, pageEl, iRect, page: getPageNum(pageEl) };
    dragging.current  = false;

    // Size rubber canvas once (GPU texture alloc happens here, not during move)
    sizeRubberOnce();

    e.preventDefault();
    e.stopPropagation();
  }, []);

  // ── Pointer move — RAF throttled ──────────────────────────────────────────────
  const onPointerMove = useCallback((e: PointerEvent) => {
    const ds = dragStart.current;
    if (!ds) return;

    // Store latest mouse position (always up to date)
    lastMouse.current = { x: e.clientX, y: e.clientY };

    // Start drag if threshold exceeded
    if (!dragging.current) {
      const dx = e.clientX - ds.x, dy = e.clientY - ds.y;
      if (Math.abs(dx) < DRAG_THRESHOLD && Math.abs(dy) < DRAG_THRESHOLD) return;
      dragging.current = true;
      document.body.classList.add('tov-dragging');
    }

    // RAF throttle: only one draw call per animation frame
    if (!rafPending.current) {
      rafPending.current = requestAnimationFrame(() => {
        rafPending.current = 0;
        if (dragging.current && dragStart.current) {
          drawRubber(dragStart.current.x, dragStart.current.y,
                     lastMouse.current.x, lastMouse.current.y);
        }
      });
    }
  }, []);

  // ── Pointer up ────────────────────────────────────────────────────────────────
  const onPointerUp = useCallback((e: PointerEvent) => {
    // Cancel any pending RAF draw
    if (rafPending.current) {
      cancelAnimationFrame(rafPending.current);
      rafPending.current = 0;
    }

    const ds = dragStart.current;
    dragStart.current = null;
    const wasDrag = dragging.current;
    dragging.current = false;
    document.body.classList.remove('tov-dragging');
    clearRubber();

    if (!ds || !boxModeRef.current || !wasDrag) return;

    const { page, pageEl, iRect } = ds;
    const { fx: fx1, fy: fy1 } = toFrac(ds.x,      ds.y,      iRect);
    const { fx: fx2, fy: fy2 } = toFrac(e.clientX, e.clientY, iRect);
    const minFx = Math.min(fx1, fx2), maxFx = Math.max(fx1, fx2);
    const minFy = Math.min(fy1, fy2), maxFy = Math.max(fy1, fy2);

    const wi = wiRef.current;
    if (wi.size > 0 && wi.has(page)) {
      // Fast path — pure fractional arithmetic, ~0ms
      const hits = hitBox(minFx, maxFx, minFy, maxFy, page, wi);
      fire(hits.length > 0
        ? mergeHits(hits, page)
        : { text: '', page, x: minFx, y: minFy, width: maxFx - minFx, height: maxFy - minFy }
      );
    } else {
      // Deferred DOM scan — never blocks main thread
      boxDomDeferred(minFx, maxFx, minFy, maxFy, pageEl, iRect, page, result =>
        fire(result ?? { text: '', page, x: minFx, y: minFy, width: maxFx - minFx, height: maxFy - minFy })
      );
    }
  }, [fire]);

  // ── Double-click — instant point capture ──────────────────────────────────────
  const onDblClick = useCallback((e: MouseEvent) => {
    if (!boxModeRef.current) return;
    e.preventDefault();
    const pageEl = getPageEl(e.target as HTMLElement);
    if (!pageEl) return;
    const iRect = getInnerRect(pageEl);
    const page  = getPageNum(pageEl);
    const { fx, fy } = toFrac(e.clientX, e.clientY, iRect);

    const wi = wiRef.current;
    if (wi.size > 0 && wi.has(page)) {
      const entry = hitPoint(fx, fy, page, wi);
      if (entry) fire({ text: entry.text, page, x: entry.x, y: entry.y, width: entry.width, height: entry.height, _textField: (entry as any)._textField });
    } else {
      hitDomDeferred(e.clientX, e.clientY, pageEl, iRect, page, result => {
        if (result) fire(result);
      });
    }
  }, [fire]);

  // ── Attach / detach listeners ─────────────────────────────────────────────────
  // pointermove goes on the container (not window) to limit scope.
  // passive:true for move means browser doesn't wait for preventDefault.
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    if (boxMode) {
      el.style.cursor = 'crosshair';
      el.addEventListener('pointerdown', onPointerDown as EventListener, { capture: true });
      el.addEventListener('dblclick',    onDblClick    as EventListener, { capture: true });
      // pointermove on el (not window) — limits scope to the PDF container
      el.addEventListener('pointermove', onPointerMove as EventListener, { passive: true });
      // pointerup on window to catch release outside the container
      window.addEventListener('pointerup', onPointerUp as EventListener);
    } else {
      el.style.cursor = '';
      clearRubber();
      document.body.classList.remove('tov-dragging');
      if (rafPending.current) { cancelAnimationFrame(rafPending.current); rafPending.current = 0; }
    }

    return () => {
      el.style.cursor = '';
      el.removeEventListener('pointerdown', onPointerDown as EventListener, { capture: true });
      el.removeEventListener('dblclick',    onDblClick    as EventListener, { capture: true });
      el.removeEventListener('pointermove', onPointerMove as EventListener);
      window.removeEventListener('pointerup', onPointerUp as EventListener);
      clearRubber();
      document.body.classList.remove('tov-dragging');
      if (rafPending.current) { cancelAnimationFrame(rafPending.current); rafPending.current = 0; }
    };
  }, [boxMode, onPointerDown, onPointerMove, onPointerUp, onDblClick]);
}
