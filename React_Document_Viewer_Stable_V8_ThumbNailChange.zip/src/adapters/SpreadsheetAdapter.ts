// ─────────────────────────────────────────────────────────────────────────────
// SpreadsheetAdapter — SheetJS for XLS/XLSX, Papa Parse for CSV
// Each sheet = one "page". Cell regions mapped to fractional coords.
// ─────────────────────────────────────────────────────────────────────────────

import type { ViewerAdapter } from './types';

export interface SheetData {
  name: string;
  rows: string[][];
  colCount: number;
  rowCount: number;
}

export class SpreadsheetAdapter implements ViewerAdapter {
  pageCount = 0;

  private _sheets: SheetData[] = [];
  private _readyCallbacks: Array<() => void> = [];
  private _pageRenderedCallbacks: Array<(page: number) => void> = [];
  private _pageElements = new Map<number, HTMLElement>();
  private _renderedPages = new Set<number>();
  private _isReady = false;
  private _currentPage = 1;
  private _scrollContainers = new Map<number, HTMLElement>();

  async loadFile(file: File): Promise<void> {
    const isCsv = /\.csv$/i.test(file.name);
    if (isCsv) {
      await this._loadCsv(file);
    } else {
      await this._loadXlsx(file);
    }
    this._isReady = true;
    this.pageCount = this._sheets.length;
    this._readyCallbacks.forEach(cb => cb());
    this._readyCallbacks = [];
  }

  private async _loadXlsx(file: File): Promise<void> {
    const XLSX = await import('xlsx');
    const buffer = await file.arrayBuffer();
    const wb = XLSX.read(buffer, { type: 'array' });
    this._sheets = wb.SheetNames.map(name => {
      const ws = wb.Sheets[name];
      const data: string[][] = XLSX.utils.sheet_to_json(ws, {
        header: 1,
        defval: '',
        raw: false,
      }) as string[][];
      const colCount = Math.max(0, ...data.map(r => r.length));
      return { name, rows: data, colCount, rowCount: data.length };
    });
  }

  private async _loadCsv(file: File): Promise<void> {
    const Papa = await import('papaparse');
    const text = await file.text();
    const result = Papa.default.parse<string[]>(text, {
      header: false,
      skipEmptyLines: false,
    });
    const rows = result.data as string[][];
    const colCount = Math.max(0, ...rows.map(r => r.length));
    this._sheets = [{
      name: file.name.replace(/\.csv$/i, ''),
      rows,
      colCount,
      rowCount: rows.length,
    }];
  }

  getSheet(page: number): SheetData | null {
    return this._sheets[page - 1] ?? null;
  }

  getAllSheets(): SheetData[] {
    return this._sheets;
  }

  /** Convert cell (row, col) 0-based to fractional coords */
  cellToFrac(
    page: number,
    row: number, col: number,
    rowSpan = 1, colSpan = 1
  ): { x: number; y: number; width: number; height: number } | null {
    const sheet = this._sheets[page - 1];
    if (!sheet) return null;
    const { rowCount, colCount } = sheet;
    if (!rowCount || !colCount) return null;
    return {
      x: col / colCount,
      y: row / rowCount,
      width: colSpan / colCount,
      height: rowSpan / rowCount,
    };
  }

  /** Convert fractional coords back to (row, col) range */
  fracToCell(
    page: number,
    x: number, y: number, w: number, h: number
  ): { rowStart: number; rowEnd: number; colStart: number; colEnd: number } | null {
    const sheet = this._sheets[page - 1];
    if (!sheet) return null;
    const { rowCount, colCount } = sheet;
    return {
      colStart: Math.floor(x * colCount),
      rowStart: Math.floor(y * rowCount),
      colEnd: Math.floor((x + w) * colCount),
      rowEnd: Math.floor((y + h) * rowCount),
    };
  }

  // DOM registration
  registerPageElement(page: number, el: HTMLElement | null) {
    if (el) this._pageElements.set(page, el);
    else this._pageElements.delete(page);
  }

  registerScrollContainer(page: number, el: HTMLElement | null) {
    if (el) this._scrollContainers.set(page, el);
    else this._scrollContainers.delete(page);
  }

  notifyPageRendered(page: number) {
    this._renderedPages.add(page);
    this._pageRenderedCallbacks.forEach(cb => cb(page));
  }

  // ── ViewerAdapter implementation ──────────────────────────────────────────

  navigateToPage(page: number): void {
    // Note: this default implementation is overridden by the store (appStore.ts)
    // which calls set({ currentPage: p }) directly. This fallback just updates
    // the internal state in case the override hasn't been applied yet.
    this._currentPage = Math.max(1, Math.min(this.pageCount, page));
    this._pageRenderedCallbacks.forEach(cb => cb(this._currentPage));
  }

  getCurrentPage(): number {
    return this._currentPage;
  }

  getPageDimensions(page: number): { width: number; height: number } | null {
    // For spreadsheets we return the rendered table element dimensions
    const el = this._pageElements.get(page);
    if (el) return { width: el.clientWidth, height: el.clientHeight };
    // Fallback virtual size
    return { width: 1000, height: 1000 };
  }

  getPageCanvas(page: number): HTMLCanvasElement | null {
    const el = this._pageElements.get(page);
    return el?.querySelector('canvas') ?? null;
  }

  getPageElement(page: number): HTMLElement | null {
    return this._pageElements.get(page) ?? null;
  }

  getRenderedPages(): Set<number> {
    return new Set([this._currentPage]);
  }

  onReady(cb: () => void): void {
    if (this._isReady) cb();
    else this._readyCallbacks.push(cb);
  }

  onPageRendered(cb: (page: number) => void): void {
    this._pageRenderedCallbacks.push(cb);
  }

  dispose() {
    this._sheets = [];
    this._readyCallbacks = [];
    this._pageRenderedCallbacks = [];
    this._pageElements.clear();
    this._renderedPages.clear();
    this._isReady = false;
    this.pageCount = 0;
  }
}
