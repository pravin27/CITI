import React, { useRef, useCallback, useEffect, useState } from 'react';
import { useAppStore } from '../store/appStore';

// ── Shared button ──────────────────────────────────────────────────────────────
function TbBtn({
  onClick, title, children, active = false, disabled = false, className = '',
}: {
  onClick: () => void; title: string; children: React.ReactNode;
  active?: boolean; disabled?: boolean; className?: string;
}) {
  return (
    <button
      onClick={onClick} title={title} disabled={disabled}
      className={`w-7 h-7 rounded flex items-center justify-center transition-colors shrink-0
        ${active ? 'bg-[#1e2d45] text-white' : 'text-[#8899aa] hover:text-white hover:bg-[#1e2d45]'}
        ${disabled ? 'opacity-30 cursor-not-allowed' : ''}
        ${className}`}
    >
      {children}
    </button>
  );
}

function Sep() {
  return <div className="w-px h-5 bg-[#1e2d45] mx-0.5 shrink-0" />;
}

// ── Zoom preset dropdown ───────────────────────────────────────────────────────
function ZoomControl() {
  const zoom        = useAppStore(s => s.zoom);
  const zoomMode    = useAppStore(s => s.zoomMode);
  const setZoom     = useAppStore(s => s.setZoom);
  const setZoomMode = useAppStore(s => s.setZoomMode);
  const adapter     = useAppStore(s => s.adapter);
  const currentPage = useAppStore(s => s.currentPage);

  const [open, setOpen] = useState(false);
  const [dropPos, setDropPos] = useState({ top: 0, left: 0 });
  const ref    = useRef<HTMLDivElement>(null);
  const btnRef = useRef<HTMLButtonElement>(null);

  // Close on outside click
  useEffect(() => {
    if (!open) return;
    const h = (e: MouseEvent) => {
      const dropEl = document.getElementById('tov-zoom-drop');
      if (ref.current && !ref.current.contains(e.target as Node) &&
          dropEl && !dropEl.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, [open]);

  // Compute fixed position when opening — escapes overflow:hidden toolbar
  const openDropdown = () => {
    if (!btnRef.current) return;
    const r = btnRef.current.getBoundingClientRect();
    setDropPos({ top: r.bottom + 4, left: r.left + r.width / 2 });
    setOpen(v => !v);
  };

  const applyPreset = (mode: 'page-fit' | 'page-width' | 'actual' | 'custom', customZ?: number) => {
    setOpen(false);
    if (mode === 'custom' && customZ) { setZoom(customZ); return; }
    if (mode === 'actual')            { setZoomMode('actual'); return; }

    // Find the scroll container (works for all viewer types)
    const scrollEl = document.querySelector<HTMLElement>('[data-viewer-scroll]');
    const cW = scrollEl?.clientWidth  ?? window.innerWidth  * 0.6;
    const cH = scrollEl?.clientHeight ?? window.innerHeight * 0.85;

    // Get page dimensions from adapter — for spreadsheet use natural table size
    const dims = adapter?.getPageDimensions(currentPage);
    let pW = dims?.width  ?? 595;
    let pH = dims?.height ?? 842;

    // For spreadsheets the adapter returns element clientWidth/Height which
    // is already zoom-adjusted — divide by current zoom to get natural size
    const format = useAppStore.getState().format;
    if (format === 'spreadsheet') { pW = pW / zoom; pH = pH / zoom; }

    setZoomMode(mode, cW, cH, pW, pH);
  };

  const presets = [
    { label: 'Page Fit',   mode: 'page-fit'   as const },
    { label: 'Page Width', mode: 'page-width'  as const },
    { label: 'Actual Size',mode: 'actual'      as const },
    null,
    { label: '50%',  mode: 'custom' as const, z: 0.5  },
    { label: '75%',  mode: 'custom' as const, z: 0.75 },
    { label: '100%', mode: 'custom' as const, z: 1.0  },
    { label: '125%', mode: 'custom' as const, z: 1.25 },
    { label: '150%', mode: 'custom' as const, z: 1.5  },
    { label: '200%', mode: 'custom' as const, z: 2.0  },
    { label: '300%', mode: 'custom' as const, z: 3.0  },
  ];

  const label = zoomMode === 'page-fit' ? 'Fit'
    : zoomMode === 'page-width' ? 'Width'
    : zoomMode === 'actual'     ? '100%'
    : `${Math.round(zoom * 100)}%`;

  return (
    <div ref={ref} className="relative flex items-center">
      <TbBtn onClick={() => setZoom(zoom - 0.1)} title="Zoom out" disabled={zoom <= 0.1}>
        <svg width="13" height="13" viewBox="0 0 13 13" fill="none">
          <circle cx="5.5" cy="5.5" r="4" stroke="currentColor" strokeWidth="1.2"/>
          <path d="M3.5 5.5h4M8.5 8.5l2.5 2.5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/>
        </svg>
      </TbBtn>

      <button
        onClick={openDropdown}
        ref={btnRef}
        className="flex items-center gap-0.5 px-1.5 py-1 rounded text-xs text-[#8899aa]
          hover:text-white hover:bg-[#1e2d45] transition-colors min-w-[56px] justify-center"
        title="Zoom options"
      >
        {label}
        <svg width="9" height="9" viewBox="0 0 9 9" fill="none" className="mt-0.5 opacity-60">
          <path d="M2 3l2.5 3L7 3" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/>
        </svg>
      </button>

      <TbBtn onClick={() => setZoom(zoom + 0.1)} title="Zoom in" disabled={zoom >= 5}>
        <svg width="13" height="13" viewBox="0 0 13 13" fill="none">
          <circle cx="5.5" cy="5.5" r="4" stroke="currentColor" strokeWidth="1.2"/>
          <path d="M5.5 3.5v4M3.5 5.5h4M8.5 8.5l2.5 2.5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/>
        </svg>
      </TbBtn>

      {open && (
        <div id="tov-zoom-drop"
          style={{ position:'fixed', top: dropPos.top, left: dropPos.left,
            transform:'translateX(-50%)', zIndex:9999, minWidth:144 }}
          className="bg-[#0d1829] border border-[#1e2d45] rounded-lg shadow-xl py-1 overflow-hidden">
          {presets.map((p, i) =>
            p === null
              ? <div key={i} className="h-px bg-[#1e2d45] my-1" />
              : (
                <button key={p.label}
                  onClick={() => applyPreset(p.mode, 'z' in p ? p.z : undefined)}
                  className={`w-full text-left px-3 py-1.5 text-xs transition-colors
                    ${((p.mode === 'custom' && 'z' in p && Math.abs(p.z! - zoom) < 0.01 && zoomMode === 'custom')
                      || (p.mode !== 'custom' && zoomMode === p.mode))
                      ? 'text-[#0a84ff] bg-[#0a84ff]/10'
                      : 'text-[#8899aa] hover:text-white hover:bg-[#1e2d45]'
                    }`}
                >
                  {p.label}
                </button>
              )
          )}
        </div>
      )}
    </div>
  );
}

// ── Search panel ───────────────────────────────────────────────────────────────
function SearchPanel() {
  const search       = useAppStore(s => s.search);
  const setSearchOpen = useAppStore(s => s.setSearchOpen);
  const setQuery     = useAppStore(s => s.setSearchQuery);
  const setOption    = useAppStore(s => s.setSearchOption);
  const runSearch    = useAppStore(s => s.runSearch);
  const searchNext   = useAppStore(s => s.searchNext);
  const searchPrev   = useAppStore(s => s.searchPrev);
  const clearSearch  = useAppStore(s => s.clearSearch);

  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (search.isOpen) setTimeout(() => inputRef.current?.focus(), 50);
  }, [search.isOpen]);

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (!search.query.trim()) return;
      if (e.shiftKey) {
        // If no results yet, run search first
        if (search.results.length === 0) runSearch();
        else searchPrev();
      } else {
        if (search.results.length === 0) runSearch();
        else searchNext();
      }
    }
    if (e.key === 'Escape') { setSearchOpen(false); clearSearch(); }
  };

  if (!search.isOpen) return null;

  const hasResults = search.results.length > 0;
  const countLabel = hasResults
    ? `${search.currentIndex + 1} / ${search.results.length}`
    : search.query ? '0 results' : '';

  return (
    <div className="flex flex-col gap-0 border-b border-[#1a2740] bg-[#060d18] shrink-0">
      {/* Main search row */}
      <div className="flex items-center gap-1.5 px-3 py-1.5">
        {/* Search icon */}
        <svg width="13" height="13" viewBox="0 0 13 13" fill="none" className="text-[#607080] shrink-0">
          <circle cx="5.5" cy="5.5" r="4" stroke="currentColor" strokeWidth="1.3"/>
          <path d="M8.5 8.5l3 3" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/>
        </svg>

        {/* Input */}
        <input
          ref={inputRef}
          value={search.query}
          onChange={e => setQuery(e.target.value)}
          onKeyDown={handleKey}
          placeholder="Search in document…"
          className="flex-1 bg-transparent text-xs text-white placeholder-[#3a4a5a]
            focus:outline-none min-w-0"
          spellCheck={false}
        />

        {/* Count */}
        {search.query && (
          <span className={`text-[10px] shrink-0 ${hasResults ? 'text-[#607080]' : 'text-red-400'}`}>
            {countLabel}
          </span>
        )}

        {/* Run search */}
        <button onClick={runSearch}
          className="text-[10px] px-2 py-0.5 rounded bg-[#0a84ff]/20 text-[#0a84ff]
            hover:bg-[#0a84ff]/30 transition-colors shrink-0">
          Find
        </button>

        {/* Prev / Next */}
        <TbBtn onClick={searchPrev} title="Previous (Shift+Enter)" disabled={!hasResults}>
          <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
            <path d="M7 8L3 5l4-3" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </TbBtn>
        <TbBtn onClick={searchNext} title="Next (Enter)" disabled={!hasResults}>
          <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
            <path d="M3 2l4 3-4 3" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </TbBtn>

        {/* Close */}
        <TbBtn onClick={() => { setSearchOpen(false); clearSearch(); }} title="Close search">
          <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
            <path d="M2 2l6 6M8 2l-6 6" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/>
          </svg>
        </TbBtn>
      </div>

      {/* Options row */}
      <div className="flex items-center gap-3 px-8 pb-1.5">
        <ToggleChip
          label="Match case"
          active={search.matchCase}
          onClick={() => setOption('matchCase', !search.matchCase)}
        />
        <ToggleChip
          label="Exact match"
          active={search.matchType === 'exact'}
          onClick={() => setOption('matchType', search.matchType === 'exact' ? 'contains' : 'exact')}
        />
        <ToggleChip
          label="Contains"
          active={search.matchType === 'contains'}
          onClick={() => setOption('matchType', 'contains')}
        />
        <ToggleChip
          label="Highlight all"
          active={search.highlightAll}
          onClick={() => setOption('highlightAll', !search.highlightAll)}
        />
      </div>
    </div>
  );
}

function ToggleChip({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick}
      className={`text-[10px] px-2 py-0.5 rounded-full border transition-colors ${
        active
          ? 'bg-[#0a84ff]/15 text-[#0a84ff] border-[#0a84ff]/40'
          : 'text-[#607080] border-[#1e2d45] hover:text-[#8899aa] hover:border-[#2a3f60]'
      }`}
    >
      {label}
    </button>
  );
}

// ── Page number input ─────────────────────────────────────────────────────────
function PageInput() {
  const currentPage    = useAppStore(s => s.currentPage);
  const adapter        = useAppStore(s => s.adapter);
  const setCurrentPage = useAppStore(s => s.setCurrentPage);
  const storePageCount = useAppStore(s => s.pageCount);
  const pageCount = storePageCount || adapter?.pageCount || 0;
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState('');

  const commit = () => {
    const p = parseInt(val);
    if (!isNaN(p) && p >= 1 && p <= pageCount) {
      setCurrentPage(p);
      adapter?.navigateToPage(p);
    }
    setEditing(false);
  };

  // Always render — keeps toolbar layout stable for 1-page docs
  const singlePage = pageCount <= 1;

  return (
    <div className="flex items-center gap-1 shrink-0">
      {editing && !singlePage ? (
        <input
          autoFocus
          value={val}
          onChange={e => setVal(e.target.value)}
          onBlur={commit}
          onKeyDown={e => { if (e.key === 'Enter') commit(); if (e.key === 'Escape') setEditing(false); }}
          className="w-10 text-center text-xs bg-[#0d1829] border border-[#0a84ff]/60 rounded text-white focus:outline-none py-0.5"
        />
      ) : (
        <button
          onClick={() => { if (!singlePage) { setVal(String(currentPage)); setEditing(true); } }}
          className={`text-xs px-1 py-0.5 rounded min-w-[28px] text-center transition-colors
            ${singlePage ? 'text-[#3a4a5a] cursor-default' : 'text-[#8899aa] hover:text-white hover:bg-[#1e2d45] cursor-pointer'}`}
          title={singlePage ? undefined : 'Click to jump to page'}
          disabled={singlePage}
        >
          {currentPage || 1}
        </button>
      )}
      <span className="text-[#3a4a5a] text-xs">/ {pageCount || 1}</span>
    </div>
  );
}

// ── Main toolbar ───────────────────────────────────────────────────────────────
export function ViewerToolbar() {
  const sidebarOpen    = useAppStore(s => s.sidebarOpen);
  const setSidebarOpen = useAppStore(s => s.setSidebarOpen);
  const adapter        = useAppStore(s => s.adapter);
  const currentPage    = useAppStore(s => s.currentPage);
  const setCurrentPage = useAppStore(s => s.setCurrentPage);
  const rotateCW       = useAppStore(s => s.rotateCW);
  const rotateCCW      = useAppStore(s => s.rotateCCW);
  const rotation       = useAppStore(s => s.rotation);
  const boxMode        = useAppStore(s => s.boxMode);
  const setBoxMode     = useAppStore(s => s.setBoxMode);
  const setSearchOpen  = useAppStore(s => s.setSearchOpen);
  const searchOpen     = useAppStore(s => s.search.isOpen);
  const downloadFile   = useAppStore(s => s.downloadFile);
  const openFile       = useAppStore(s => s.openFile);
  const fileName       = useAppStore(s => s.fileName);

  const pageCount = useAppStore(s => s.pageCount) || adapter?.pageCount || 0;

  const prevPage = () => {
    if (currentPage > 1) { const p = currentPage - 1; setCurrentPage(p); adapter?.navigateToPage(p); }
  };
  const nextPage = () => {
    if (currentPage < pageCount) { const p = currentPage + 1; setCurrentPage(p); adapter?.navigateToPage(p); }
  };

  return (
    <>
      <div className="flex items-center gap-0.5 px-2 py-1.5 bg-[#080f1a] border-b border-[#1a2740] shrink-0 overflow-x-auto">

        {/* Sidebar toggle */}
        <TbBtn onClick={() => setSidebarOpen(!sidebarOpen)} title="Toggle sidebar" active={sidebarOpen}>
          <svg width="15" height="15" viewBox="0 0 15 15" fill="none">
            <rect x="1" y="1.5" width="4.5" height="12" rx="1" stroke="currentColor" strokeWidth="1.2"/>
            <path d="M8 4.5h5.5M8 7.5h4M8 10.5h5.5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/>
          </svg>
        </TbBtn>

        {/* Search — between thumbnail and pagination */}
        <TbBtn onClick={() => setSearchOpen(!searchOpen)} title="Search (Ctrl+F)" active={searchOpen}>
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
            <circle cx="5.8" cy="5.8" r="4" stroke="currentColor" strokeWidth="1.2"/>
            <path d="M9 9l3.5 3.5" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/>
          </svg>
        </TbBtn>

        <Sep/>

        {/* Page navigation — always visible, buttons disabled when not applicable */}
        <>
          <TbBtn onClick={() => { setCurrentPage(1); adapter?.navigateToPage(1); }} title="First page"
            disabled={currentPage <= 1 || pageCount <= 1}>
            <svg width="13" height="13" viewBox="0 0 13 13" fill="none">
              <path d="M3 2.5v8M5.5 6.5L10 2.5v8L5.5 6.5z" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </TbBtn>
          <TbBtn onClick={prevPage} title="Previous page" disabled={currentPage <= 1 || pageCount <= 1}>
            <svg width="13" height="13" viewBox="0 0 13 13" fill="none">
              <path d="M8.5 2.5L4 6.5l4.5 4" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </TbBtn>
          <PageInput />
          <TbBtn onClick={nextPage} title="Next page" disabled={currentPage >= pageCount || pageCount <= 1}>
            <svg width="13" height="13" viewBox="0 0 13 13" fill="none">
              <path d="M4.5 2.5L9 6.5l-4.5 4" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </TbBtn>
          <TbBtn onClick={() => { setCurrentPage(pageCount); adapter?.navigateToPage(pageCount); }} title="Last page"
            disabled={currentPage >= pageCount || pageCount <= 1}>
            <svg width="13" height="13" viewBox="0 0 13 13" fill="none">
              <path d="M10 2.5v8M7.5 6.5L3 2.5v8l4.5-4z" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </TbBtn>
          <Sep/>
        </>

        {/* Zoom */}
        <ZoomControl />

        <Sep/>

        {/* Rotation */}
        <TbBtn onClick={rotateCCW} title="Rotate counter-clockwise">
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
            <path d="M2.5 7A4.5 4.5 0 1 1 7 11.5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/>
            <path d="M2.5 3.5V7H6" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </TbBtn>
        <TbBtn onClick={rotateCW} title="Rotate clockwise">
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
            <path d="M11.5 7A4.5 4.5 0 1 0 7 11.5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/>
            <path d="M11.5 3.5V7H8" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </TbBtn>
        {rotation !== 0 && (
          <span className="text-[10px] text-[#607080] px-1">{rotation}°</span>
        )}

        <Sep/>

        {/* Box Capture */}
        <button
          onClick={() => setBoxMode(!boxMode)}
          title={boxMode ? 'Box Capture ON — click to disable' : 'Box Capture — draw or double-click'}
          className={`w-7 h-7 rounded flex items-center justify-center transition-all shrink-0 ${
            boxMode ? 'bg-[#0a84ff]/15 border border-[#0a84ff]' : 'border border-transparent hover:border-[#334155] text-[#8899aa] hover:text-white'
          }`}
        >
          <BoxCaptureIcon active={boxMode} />
        </button>

        {/* Right side */}
        <div className="ml-auto flex items-center gap-1 shrink-0">
          {boxMode && (
            <span className="text-[#0a84ff] text-[10px] animate-pulse hidden sm:block">● Box Capture</span>
          )}

          <Sep/>

          {/* Open file */}
          <label title="Open document" className="w-7 h-7 rounded flex items-center justify-center text-[#8899aa] hover:text-white hover:bg-[#1e2d45] cursor-pointer transition-colors">
            <input type="file" accept=".pdf,.tif,.tiff,.bmp,.jpg,.jpeg,.png,.xls,.xlsx,.csv"
              className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) openFile(f); e.currentTarget.value=''; }} />
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <path d="M1 4.5a1 1 0 0 1 1-1h2.5L6 5.5h6a1 1 0 0 1 1 1V11a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V4.5z"
                stroke="currentColor" strokeWidth="1.2" fill="none" strokeLinejoin="round"/>
            </svg>
          </label>

          {/* Download */}
          {fileName && (
            <TbBtn onClick={downloadFile} title={`Download ${fileName}`}>
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                <path d="M7 1v8M4 6l3 3 3-3" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M1 11h12" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/>
                <path d="M1 11v2h12v-2" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </TbBtn>
          )}
        </div>
      </div>

      {/* Search panel (below toolbar) */}
      <SearchPanel />
    </>
  );
}

function BoxCaptureIcon({ active }: { active: boolean }) {
  const c = active ? '#0a84ff' : 'currentColor';
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
      <path d="M9 3L6.5 9h5L9 3z" stroke={c} strokeWidth="1.1" strokeLinejoin="round" fill="none"/>
      <path d="M9 9v2.5" stroke={c} strokeWidth="1.1" strokeLinecap="round"/>
      <rect x="4.5" y="12.5" width="9" height="3.5" rx="0.8"
        stroke={c} strokeWidth="1" strokeDasharray="2 1.5" fill="none"/>
    </svg>
  );
}
