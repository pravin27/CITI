import React, { useEffect, useRef, useCallback } from 'react';
import { useAppStore } from '../store/appStore';
import type { ImageAdapter } from '../adapters/ImageAdapter';
import { colorToRgba, stripPunct } from '../utils/color';

const PAGE_GAP = 12;
const RADIUS   = 2.5;

interface ImageViewerProps { adapter: ImageAdapter; zoom: number; }

export function ImageViewer({ adapter, zoom }: ImageViewerProps) {
  const setCurrentPage = useAppStore(s => s.setCurrentPage);
  const rotation       = useAppStore(s => s.rotation);
  const frames = adapter.getAllFrames();
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (containerRef.current) containerRef.current.setAttribute('data-viewer-scroll', '1');
  }, []);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    const observer = new IntersectionObserver(
      entries => {
        let best: { page: number; ratio: number } | null = null;
        for (const e of entries) {
          if (!e.isIntersecting) continue;
          const page = Number((e.target as HTMLElement).dataset.pageNumber);
          if (!best || e.intersectionRatio > best.ratio) best = { page, ratio: e.intersectionRatio };
        }
        if (best) setCurrentPage(best.page);
      },
      { root: container, threshold: [0, 0.5] },
    );
    container.querySelectorAll<HTMLElement>('[data-page-number]').forEach(el => observer.observe(el));
    return () => observer.disconnect();
  }, [frames.length, setCurrentPage]);

  return (
    <div ref={containerRef} className="flex-1 overflow-y-auto overflow-x-auto bg-[#1a1f2e]">
      <div className="flex flex-col items-center py-4">
        {frames.map((frame, i) => (
          <ImagePageCanvas key={i} pageNum={i + 1} frame={frame} zoom={zoom} rotation={rotation} adapter={adapter} />
        ))}
      </div>
    </div>
  );
}

interface ImagePageCanvasProps {
  pageNum: number;
  frame: { canvas: HTMLCanvasElement; width: number; height: number };
  zoom: number;
  rotation: number;
  adapter: ImageAdapter;
}

function rr(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  if (w < 1 || h < 1) return;
  r = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x+r,y); ctx.lineTo(x+w-r,y); ctx.arcTo(x+w,y,x+w,y+r,r);
  ctx.lineTo(x+w,y+h-r); ctx.arcTo(x+w,y+h,x+w-r,y+h,r);
  ctx.lineTo(x+r,y+h); ctx.arcTo(x,y+h,x,y+h-r,r);
  ctx.lineTo(x,y+r); ctx.arcTo(x,y,x+r,y,r); ctx.closePath();
}

function ImagePageCanvas({ pageNum, frame, zoom, rotation, adapter }: ImagePageCanvasProps) {
  const wrapperRef  = useRef<HTMLDivElement>(null);
  const canvasRef   = useRef<HTMLCanvasElement>(null);
  const hlCanvasRef = useRef<HTMLCanvasElement>(null);

  // Register with adapter
  useEffect(() => {
    adapter.registerPageElement(pageNum, wrapperRef.current);
    return () => adapter.registerPageElement(pageNum, null);
  }, [adapter, pageNum]);

  // Render image frame to canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const isFlipped = rotation === 90 || rotation === 270;
    const displayW = Math.round((isFlipped ? frame.height : frame.width)  * zoom);
    const displayH = Math.round((isFlipped ? frame.width  : frame.height) * zoom);
    canvas.width  = displayW;
    canvas.height = displayH;
    const ctx = canvas.getContext('2d')!;
    ctx.clearRect(0, 0, displayW, displayH);
    ctx.save();
    ctx.translate(displayW / 2, displayH / 2);
    ctx.rotate((rotation * Math.PI) / 180);
    ctx.drawImage(frame.canvas, -(frame.width * zoom) / 2, -(frame.height * zoom) / 2, frame.width * zoom, frame.height * zoom);
    ctx.restore();
    adapter.notifyPageRendered(pageNum);
  }, [frame, zoom, rotation, adapter, pageNum]);

  const isFlipped = rotation === 90 || rotation === 270;
  const displayW  = Math.round((isFlipped ? frame.height : frame.width)  * zoom);
  const displayH  = Math.round((isFlipped ? frame.width  : frame.height) * zoom);

  // ── Highlight drawing — mirrors PDF viewer paintPage logic exactly ─────────
  const drawHighlights = useCallback(() => {
    const canvas = hlCanvasRef.current;
    if (!canvas) return;
    const W = canvas.width, H = canvas.height;
    if (!W || !H) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, W, H);

    const s           = useAppStore.getState();
    const rects       = s.highlightIndex.get(pageNum) ?? [];
    const aid         = s.activeFieldId;
    const previewRect = s.previewRect;
    const wi          = s.wordIndex;
    const hasWI       = wi.size > 0;

    // Build field → stripped-word and field → label maps (same as PDF fwc cache)
    const fwc = new Map<string, string>(); // id → exact lowercase value
    const flc = new Map<string, string>(); // id → label
    for (const cap of s.captures) {
      // Exact lowercase — no stripPunct so "LEADTOOLS" ≠ "LEADTOOLS®"
      fwc.set(cap.id, cap.value.toLowerCase().trim());
      flc.set(cap.id, (cap.label || cap.id).toLowerCase().trim());
    }

    const activeCapture = aid ? s.captures.find(c => c.id === aid) : null;
    const activeTxt     = activeCapture ? (fwc.get(aid!) ?? '') : '';
    const activeLabel   = activeCapture ? (flc.get(aid!) ?? '') : '';

    // ── LAYER: Search highlights ──────────────────────────────────────────────
    const sr = s.search.results.filter(r => r.page === pageNum);
    for (let i = 0; i < sr.length; i++) {
      const r = sr[i];
      const isCur = s.search.results.indexOf(r) === s.search.currentIndex;
      ctx.save();
      if (isCur) {
        ctx.fillStyle='rgba(255,140,0,.45)'; ctx.strokeStyle='rgba(255,100,0,.95)';
        ctx.lineWidth=2; ctx.shadowColor='rgba(255,140,0,.5)'; ctx.shadowBlur=6;
      } else if (s.search.highlightAll) {
        ctx.fillStyle='rgba(255,220,50,.28)'; ctx.strokeStyle='rgba(200,160,0,.65)'; ctx.lineWidth=1;
      } else { ctx.restore(); continue; }
      rr(ctx, r.x*W, r.y*H, r.width*W, r.height*H, RADIUS);
      ctx.fill(); ctx.stroke(); ctx.restore();
    }

    // ── LAYER: Confirmed capture boxes (grey / yellow / pink) ─────────────────
    const capturedPositionKeys = new Set<number>(); // skip these in word_index scan
    for (const rect of rects) {
      capturedPositionKeys.add(Math.round(rect.x*1000)*10000 + Math.round(rect.y*1000));
      const isAct = rect.id === aid;
      // isDup: same stripped value OR same label (for image captures with empty value)
      const sameVal   = !!activeTxt   && fwc.get(rect.id) === activeTxt;
      const sameLbl   = !!activeLabel && flc.get(rect.id) === activeLabel;
      const isDup     = !isAct && (sameVal || sameLbl);
      ctx.save();
      if (isAct) {
        ctx.shadowColor='rgba(220,180,0,.5)'; ctx.shadowBlur=8;
        ctx.fillStyle='rgba(255,230,0,.35)'; ctx.strokeStyle='rgb(200,160,0)'; ctx.lineWidth=2.5;
      } else if (isDup) {
        ctx.fillStyle='rgba(255,182,193,.40)'; ctx.strokeStyle='rgba(220,80,120,.85)'; ctx.lineWidth=2;
      } else if (rect.color) {
        ctx.fillStyle=colorToRgba(rect.color,.20); ctx.strokeStyle=rect.color; ctx.lineWidth=1.5;
      } else {
        ctx.fillStyle='rgba(150,150,150,.18)'; ctx.strokeStyle='rgba(120,120,120,.70)'; ctx.lineWidth=1.5;
      }
      rr(ctx, rect.x*W, rect.y*H, rect.width*W, rect.height*H, RADIUS);
      ctx.fill(); ctx.stroke(); ctx.restore();
    }

    // ── LAYER: Word-index occurrences (mirrors PDF viewer l3c / occ logic) ────
    // When word_index is loaded, draw ALL occurrences of each captured word:
    //   • Active field's word → light pink (duplicates across all positions)
    //   • Other fields' words → their colour / grey
    // This is how PDF viewer shows every occurrence of a captured word.
    if (hasWI && aid) {
      const pageEntries = wi.get(pageNum) ?? [];

      // Draw grey occurrences for all non-active captured words
      for (const cap of s.captures) {
        if (cap.id === aid) continue;
        const wt = fwc.get(cap.id) ?? '';
        if (!wt) continue;
        const fill   = cap.color ? colorToRgba(cap.color, .18) : 'rgba(150,150,150,.18)';
        const stroke = cap.color ?? 'rgba(120,120,120,.70)';
        ctx.fillStyle=fill; ctx.strokeStyle=stroke; ctx.lineWidth=1.2;
        for (const e of pageEntries) {
          if (e.text.toLowerCase().trim() !== wt) continue;
          const k = Math.round(e.x*1000)*10000 + Math.round(e.y*1000);
          if (capturedPositionKeys.has(k)) continue; // already drawn above
          rr(ctx, e.x*W, e.y*H, e.width*W, e.height*H, RADIUS);
          ctx.fill(); ctx.stroke();
        }
      }

      // Draw PINK occurrences for the active field's word
      if (activeTxt) {
        ctx.fillStyle='rgba(255,182,193,.40)'; ctx.strokeStyle='rgba(220,80,120,.80)'; ctx.lineWidth=1.5;
        for (const e of pageEntries) {
          if (e.text.toLowerCase().trim() !== activeTxt) continue;
          const k = Math.round(e.x*1000)*10000 + Math.round(e.y*1000);
          if (capturedPositionKeys.has(k)) continue; // skip — already drawn yellow
          rr(ctx, e.x*W, e.y*H, e.width*W, e.height*H, RADIUS);
          ctx.fill(); ctx.stroke();
        }
      }
    }

    // ── LAYER: Preview/pulse rect ─────────────────────────────────────────────
    if (previewRect?.page === pageNum) {
      ctx.save();
      ctx.fillStyle='rgba(6,182,212,.15)'; ctx.strokeStyle='rgba(6,182,212,.9)';
      ctx.lineWidth=2; ctx.shadowColor='rgba(6,182,212,.5)'; ctx.shadowBlur=6;
      rr(ctx, previewRect.x*W, previewRect.y*H, previewRect.width*W, previewRect.height*H, RADIUS);
      ctx.fill(); ctx.stroke(); ctx.restore();
    }
  }, [pageNum]);

  // Size highlight canvas to match image canvas, redraw when dimensions change
  useEffect(() => {
    const hl = hlCanvasRef.current;
    if (!hl) return;
    hl.width  = displayW;
    hl.height = displayH;
    drawHighlights();
  }, [displayW, displayH, drawHighlights]);

  // Subscribe to store changes and redraw highlights
  useEffect(() => {
    drawHighlights();
    const unsub = useAppStore.subscribe((n, p) => {
      if (n.highlightIndex !== p.highlightIndex ||
          n.activeFieldId  !== p.activeFieldId  ||
          n.wordIndex      !== p.wordIndex       ||
          n.previewRect    !== p.previewRect     ||
          n.search.results !== p.search.results  ||
          n.search.currentIndex !== p.search.currentIndex) {
        drawHighlights();
      }
    });
    return unsub;
  }, [drawHighlights]);

  return (
    <div ref={wrapperRef} data-page-number={pageNum}
      className="relative shadow-2xl" style={{ marginBottom: PAGE_GAP }}>
      {/* Image frame */}
      <canvas ref={canvasRef} style={{ width: displayW, height: displayH, display: 'block' }} />
      {/* Highlight overlay — same pixel dimensions, absolutely positioned on top */}
      <canvas ref={hlCanvasRef}
        width={displayW} height={displayH}
        style={{
          position: 'absolute', inset: 0,
          width: displayW, height: displayH,
          pointerEvents: 'none', zIndex: 11,
        }}
      />
    </div>
  );
}
