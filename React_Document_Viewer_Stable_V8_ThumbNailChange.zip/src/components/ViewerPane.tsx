import React, { useRef, useCallback } from 'react';
import { useAppStore } from '../store/appStore';
import { PDFViewer } from './PDFViewer';
import { ImageViewer } from './ImageViewer';
import { SpreadsheetViewer } from './SpreadsheetViewer';
import { ViewerToolbar } from './ViewerToolbar';
import { useBoxCapture } from '../hooks/useBoxCapture';
import { useHighlightCanvas } from '../hooks/useHighlightCanvas';
import { useWordSpanInjector } from '../hooks/useWordSpanInjector';
import type { PDFAdapter } from '../adapters/PDFAdapter';
import type { ImageAdapter } from '../adapters/ImageAdapter';
import type { SpreadsheetAdapter } from '../adapters/SpreadsheetAdapter';
import type { CaptureResult } from '../hooks/useBoxCapture';

// ── No-file placeholder ───────────────────────────────────────────────────────
function NoPreview() {
  const openFile = useAppStore(s => s.openFile);
  const isLoading = useAppStore(s => s.isLoading);
  const loadError = useAppStore(s => s.loadError);
  const [dragOver, setDragOver] = React.useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = (f: File) => { openFile(f); };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault(); setDragOver(false);
    const f = e.dataTransfer.files[0];
    if (f) handleFile(f);
  };

  if (isLoading) return (
    <div className="flex-1 flex items-center justify-center bg-[#0a1120]">
      <div className="text-center">
        <div className="w-10 h-10 border-2 border-[#0a84ff] border-t-transparent rounded-full animate-spin mx-auto mb-3" />
        <p className="text-[#8899aa] text-sm">Loading document…</p>
      </div>
    </div>
  );

  if (loadError) return (
    <div className="flex-1 flex items-center justify-center bg-[#0a1120]">
      <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-6 max-w-sm text-center">
        <div className="text-red-400 text-xl mb-2">⚠</div>
        <div className="text-white font-semibold mb-1 text-sm">Failed to open</div>
        <div className="text-red-400 text-xs">{loadError}</div>
      </div>
    </div>
  );

  return (
    <div
      className="flex-1 flex items-center justify-center bg-[#0a1120] select-none"
      onDragOver={e => { e.preventDefault(); setDragOver(true); }}
      onDragLeave={() => setDragOver(false)}
      onDrop={onDrop}
    >
      <input
        ref={inputRef}
        type="file"
        accept=".pdf,.tif,.tiff,.bmp,.jpg,.jpeg,.png,.xls,.xlsx,.csv"
        className="hidden"
        onChange={e => { const f = e.target.files?.[0]; if (f) handleFile(f); e.target.value = ''; }}
      />
      <div
        onClick={() => inputRef.current?.click()}
        className={`flex flex-col items-center gap-4 p-12 rounded-2xl border-2 border-dashed cursor-pointer
          transition-all duration-200 ${dragOver
            ? 'border-[#0a84ff] bg-[#0a84ff]/10'
            : 'border-[#1e2d45] hover:border-[#2a4060] hover:bg-[#0d1525]'
          }`}
      >
        {/* Document icon */}
        <div className="w-16 h-16 rounded-2xl bg-[#0d1829] border border-[#1e2d45] flex items-center justify-center">
          <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
            <path d="M8 4h10l8 8v16a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"
              stroke="#3a8ef6" strokeWidth="1.5" fill="none"/>
            <path d="M18 4v8h8" stroke="#3a8ef6" strokeWidth="1.5" strokeLinecap="round"/>
            <path d="M11 17h10M11 21h7" stroke="#3a8ef6" strokeWidth="1.5" strokeLinecap="round"/>
          </svg>
        </div>
        <div className="text-center">
          <p className="text-white font-medium text-sm mb-1">No Preview</p>
          <p className="text-[#607080] text-xs mb-3">Drop a document or click to open</p>
          <p className="text-[#3a4a5a] text-[11px]">PDF · TIF/TIFF · BMP · JPEG · PNG · XLS · XLSX · CSV</p>
        </div>
      </div>
    </div>
  );
}

// ── Main pane ─────────────────────────────────────────────────────────────────
export function ViewerPane() {
  const file             = useAppStore(s => s.file);
  const format           = useAppStore(s => s.format);
  const adapter          = useAppStore(s => s.adapter);
  const zoom             = useAppStore(s => s.zoom);
  const setPendingCapture = useAppStore(s => s.setPendingCapture);
  const setPreviewRect    = useAppStore(s => s.setPreviewRect);

  const containerRef = useRef<HTMLDivElement>(null);

  const handleCapture = useCallback((result: CaptureResult) => {
    setPendingCapture({ text: result.text, page: result.page,
      x: result.x, y: result.y, width: result.width, height: result.height,
      _textField: result._textField });
    setPreviewRect({ page: result.page, x: result.x, y: result.y,
      width: result.width, height: result.height });
  }, [setPendingCapture, setPreviewRect]);

  useBoxCapture(containerRef as React.RefObject<HTMLElement>, handleCapture);
  useHighlightCanvas(containerRef as React.RefObject<HTMLElement>);
  useWordSpanInjector(containerRef as React.RefObject<HTMLElement>);

  const hasFile = !!file && !!adapter;

  return (
    <div className="flex flex-col flex-1 overflow-hidden">
      <ViewerToolbar />
      <div ref={containerRef} className="flex-1 flex flex-col overflow-hidden relative">
        {!hasFile && <NoPreview />}
        {hasFile && format === 'pdf' && (
          <PDFViewer file={file!} adapter={adapter as PDFAdapter} zoom={zoom} />
        )}
        {hasFile && format === 'image' && (
          <ImageViewer adapter={adapter as ImageAdapter} zoom={zoom} />
        )}
        {hasFile && format === 'spreadsheet' && (
          <SpreadsheetViewer adapter={adapter as SpreadsheetAdapter} />
        )}
      </div>
    </div>
  );
}
