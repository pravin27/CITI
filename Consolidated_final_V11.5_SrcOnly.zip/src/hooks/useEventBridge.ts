// ─────────────────────────────────────────────────────────────────────────────
// useEventBridge — single owner of all parent ↔ viewer postMessage communication
//
// STANDALONE PROTECTION: every outbound/inbound path is gated behind
//   const isEmbedded = window.self !== window.top
// When running directly in a browser tab (standalone testing), this hook
// attaches no listeners and sends no messages. Zero behaviour change.
//
// ORIGIN CHECK: set VITE_PARENT_ORIGIN in .env for production.
// Leave unset (defaults to '*') for standalone / development testing.
// ─────────────────────────────────────────────────────────────────────────────

import { useEffect, useRef, useCallback } from 'react';
import type { DocumentManifest } from '../types/multiDoc';
import type { CaptureItem, Category, WordEntry } from '../adapters/types';

// ── Environment ───────────────────────────────────────────────────────────────
const ALLOWED_ORIGIN: string =
  (import.meta as any).env?.VITE_PARENT_ORIGIN ?? '*';

// Is this app running inside an iframe?
export const isEmbedded: boolean = (() => {
  try { return window.self !== window.top; }
  catch { return true; } // cross-origin parent → definitely embedded
})();

// ── Payload types ─────────────────────────────────────────────────────────────

export interface SingleDocMeta {
  wordIndex?: Record<number, WordEntry[]>;
  categories?: Category[];
  captures?: CaptureItem[];
}

// Optional metadata that can accompany DOC_RESPONSE for a specific document
export interface DocResponseMeta {
  wordIndex?: Record<number, import('../adapters/types').WordEntry[]>;
  categories?: import('../adapters/types').Category[];
  captures?: import('../adapters/types').CaptureItem[];
}

export interface HighlightPayload {
  id: string;
  label?: string;
  value?: string;
  page: number;
  x: number; y: number; width: number; height: number;
  docId?: string;
  color?: string;
  sourceFormat?: CaptureItem['sourceFormat'];
}

export interface CapturePreviewPayload {
  tempId: string;
  text: string;
  page: number;
  x: number; y: number; width: number; height: number;
  docId?: string;
  label?: string;
  color?: string;
}

export interface EventBridgeCallbacks {
  onLoadSingleDoc: (buffer: ArrayBuffer, fileName: string, meta: SingleDocMeta) => void;
  onLoadManifest:  (manifest: DocumentManifest, activeDocId?: string, activeBuffer?: ArrayBuffer, meta?: SingleDocMeta) => void;
  onHighlight:     (payload: HighlightPayload) => void;
  onCaptureAck:    (tempId: string, realId: string) => void;
  onDocMeta?:      (docId: string, meta: DocResponseMeta) => void; // called after DOC_RESPONSE with optional meta
}

export interface EventBridgeAPI {
  requestDocBuffer:   (docId: string) => Promise<ArrayBuffer>;
  emitCapturePreview: (payload: CapturePreviewPayload) => void;
  emitPdfLoaded:      (info: { fileName: string; pageCount: number; docId?: string | null }) => void;
  waitForAck:         (tempId: string, timeoutMs?: number) => Promise<string>;
  resolveAck:         (tempId: string, realId: string) => void;
  /** Call when user draws a box or double-clicks.
   *  Fires CAPTURE_PREVIEW to parent, waits for ACK, then resolves with realId.
   *  Rejects after 15s if parent doesn't respond. */
  handleCaptureResult: (result: CapturePreviewPayload & { docId?: string }) => Promise<string>;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

let _tempIdCounter = 0;
export function generateTempId(): string {
  return `tmp_${Date.now()}_${++_tempIdCounter}`;
}

function postToParent(msg: Record<string, unknown>) {
  if (!isEmbedded) return;
  window.parent.postMessage(msg, ALLOWED_ORIGIN === '*' ? '*' : ALLOWED_ORIGIN);
}

function originAllowed(origin: string): boolean {
  if (ALLOWED_ORIGIN === '*') return true;
  return origin === ALLOWED_ORIGIN;
}

// ── Hook ──────────────────────────────────────────────────────────────────────

export function useEventBridge(callbacks: EventBridgeCallbacks): EventBridgeAPI {
  // Pending DOC_REQUEST promises: docId → { resolve, reject, timer }
  const pendingDocs = useRef<Map<string, {
    resolve: (buf: ArrayBuffer) => void;
    reject:  (err: Error) => void;
    timer:   ReturnType<typeof setTimeout>;
  }>>(new Map());

  // Pending CAPTURE_ACK promises: tempId → { resolve, reject, timer }
  const pendingAcks = useRef<Map<string, {
    resolve: (realId: string) => void;
    reject:  (err: Error) => void;
    timer:   ReturnType<typeof setTimeout>;
  }>>(new Map());

  // Keep callbacks ref stable
  const cbRef = useRef(callbacks);
  useEffect(() => { cbRef.current = callbacks; });

  // ── Message handler ─────────────────────────────────────────────────────────
  useEffect(() => {
    if (!isEmbedded) return; // standalone — do nothing

    const handler = (event: MessageEvent) => {
      if (!originAllowed(event.origin)) return;
      const { type, ...data } = event.data ?? {};
      if (!type) return;

      switch (type) {
        case 'LOAD_SINGLEDOC': {
          const { buffer, fileName = 'document.pdf', wordIndex, categories, captures } = data;
          if (!buffer) return;
          cbRef.current.onLoadSingleDoc(buffer as ArrayBuffer, fileName, {
            wordIndex, categories, captures,
          });
          break;
        }

        case 'LOAD_MANIFEST': {
          const { manifest, activeDocId, activeBuffer, wordIndex, categories, captures } = data;
          if (!manifest) return;
          const meta: SingleDocMeta | undefined =
            (wordIndex || categories || captures)
              ? { wordIndex, categories, captures }
              : undefined;
          cbRef.current.onLoadManifest(manifest as DocumentManifest, activeDocId, activeBuffer, meta);
          break;
        }

        case 'DOC_RESPONSE': {
          const { docId, buffer, wordIndex, categories, captures } = data;
          const pending = pendingDocs.current.get(docId);
          if (!pending) return;
          clearTimeout(pending.timer);
          pendingDocs.current.delete(docId);
          pending.resolve(buffer as ArrayBuffer);
          // Fire optional meta callback if any meta fields were included
          if (cbRef.current.onDocMeta && (wordIndex || categories || captures)) {
            cbRef.current.onDocMeta(docId, { wordIndex, categories, captures });
          }
          break;
        }

        case 'CAPTURE_ACK': {
          const { tempId, id: realId } = data;
          cbRef.current.onCaptureAck(tempId, realId);
          break;
        }

        case 'HIGHLIGHT': {
          const { payload } = data;
          if (!payload) return;
          cbRef.current.onHighlight(payload as HighlightPayload);
          break;
        }
      }
    };

    window.addEventListener('message', handler);

    // Fire READY so parent knows iframe is listening
    postToParent({ type: 'READY' });

    return () => window.removeEventListener('message', handler);
  }, []); // mount once

  // ── API ─────────────────────────────────────────────────────────────────────

  const requestDocBuffer = useCallback((docId: string): Promise<ArrayBuffer> => {
    if (!isEmbedded) return Promise.reject(new Error('Not embedded'));

    // Return existing promise if already in-flight
    if (pendingDocs.current.has(docId)) {
      return new Promise((resolve, reject) => {
        const existing = pendingDocs.current.get(docId)!;
        const origResolve = existing.resolve;
        const origReject  = existing.reject;
        existing.resolve = (buf) => { origResolve(buf); resolve(buf); };
        existing.reject  = (err) => { origReject(err);  reject(err);  };
      });
    }

    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        pendingDocs.current.delete(docId);
        reject(new Error(`DOC_REQUEST timeout for "${docId}" (15s)`));
      }, 15_000);

      pendingDocs.current.set(docId, { resolve, reject, timer });
      postToParent({ type: 'DOC_REQUEST', docId });
    });
  }, []);

  const emitCapturePreview = useCallback((payload: CapturePreviewPayload) => {
    postToParent({ type: 'CAPTURE_PREVIEW', ...payload });
  }, []);

  const emitPdfLoaded = useCallback((info: { fileName: string; pageCount: number; docId?: string | null }) => {
    postToParent({ type: 'PDF_LOADED', ...info });
  }, []);

  // waitForAck — called by FieldsPanel after emitCapturePreview
  const waitForAck = useCallback((tempId: string, timeoutMs = 15_000): Promise<string> => {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        pendingAcks.current.delete(tempId);
        reject(new Error(`CAPTURE_ACK timeout for tempId "${tempId}"`));
      }, timeoutMs);
      pendingAcks.current.set(tempId, { resolve, reject, timer });
    });
  }, []);

  // resolveAck — called by App.tsx via onCaptureAck callback
  const resolveAck = useCallback((tempId: string, realId: string) => {
    const pending = pendingAcks.current.get(tempId);
    if (!pending) return;
    clearTimeout(pending.timer);
    pendingAcks.current.delete(tempId);
    pending.resolve(realId);
  }, []);

  // Central capture handler — fires CAPTURE_PREVIEW, waits for CAPTURE_ACK
  const handleCaptureResult = useCallback((
    payload: CapturePreviewPayload & { docId?: string }
  ): Promise<string> => {
    const tempId = generateTempId();
    emitCapturePreview({ ...payload, tempId });
    return waitForAck(tempId, 15_000);
  }, [emitCapturePreview, waitForAck]);

  return { requestDocBuffer, emitCapturePreview, emitPdfLoaded, waitForAck, resolveAck, handleCaptureResult };
}
