import React, { useEffect, useCallback } from 'react';
import { useAppStore } from './store/appStore';
import { TopBar } from './components/TopBar';
import { ResizablePanes } from './components/ResizablePanes';
import { ViewerToolbar } from './components/ViewerToolbar';
import { ViewerPane } from './components/ViewerPane';
import { FieldsPanel } from './components/FieldsPanel';
import { ThumbnailSidebar } from './components/ThumbnailSidebar';
import { useSidecarLoader } from './hooks/useSidecarLoader';
import { useMultiDoc } from './hooks/useMultiDoc';
import { MultiDocSidebar } from './components/MultiDocSidebar';
import type { DocumentManifest } from './types/multiDoc';
import { useEventBridge, isEmbedded, generateTempId } from './hooks/useEventBridge';
import { parseHighlightPayload } from './utils/parseHighlightPayload';

function useGlobalShortcuts() {
  const setSearchOpen = useAppStore(s => s.setSearchOpen);
  const searchIsOpen  = useAppStore(s => s.search.isOpen);
  const file          = useAppStore(s => s.file);
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'f' && file) {
        e.preventDefault(); setSearchOpen(!searchIsOpen);
      }
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [setSearchOpen, searchIsOpen, file]);
}

// ── normaliseEntry — pure helper used by applyDocMeta ────────────────────────
// Takes a raw wordIndex entry in ANY supported coord format and returns it
// with normalised { x, y, width, height } (0-1 fractions) so rebuildCaches
// can read e.x, e.y, e.width, e.height directly without further conversion.
function normaliseEntry(
  e: Record<string, unknown>,
  pg: number,
  adapter: any,
  extractRawCoords: Function,
  normaliseCoords: Function,
): Record<string, unknown> {
  const raw = extractRawCoords(e) as [number,number,number,number] | null;
  if (!raw) return e; // no recognised coord fields — pass through unchanged
  const [rx, ry, rw, rh] = raw;
  // If already fractional (all ≤ 1) no normalisation needed
  const [x, y, w, h] =
    rx <= 1 && ry <= 1 && rw <= 1 && rh <= 1
      ? [rx, ry, rw, rh]
      : normaliseCoords(raw, e, pg, adapter, null) as [number,number,number,number];
  return { ...e, x, y, width: w, height: h };
}

export default function App() {
  const sidebarOpen    = useAppStore(s => s.sidebarOpen);
  const openFile       = useAppStore(s => s.openFile);
  const setCurrentPage = useAppStore(s => s.setCurrentPage);
  const closeFile      = useAppStore(s => s.closeFile);
  const adapter               = useAppStore(s => s.adapter);
  const setWordIndex          = useAppStore(s => s.setWordIndex);
  const setCategories         = useAppStore(s => s.setCategories);
  const addCaptureWithId      = useAppStore(s => s.addCaptureWithId);
  const navigateAndHighlight  = useAppStore(s => s.navigateAndHighlight);
  const openFileBuffer        = useAppStore(s => s.openFileBuffer);

  useSidecarLoader();
  useGlobalShortcuts();

  // ── Multi-doc state ───────────────────────────────────────────────────────
  const multiDoc = useMultiDoc();

  // ── Event bridge (only active when running inside an iframe) ─────────────
  // ── waitForAdapter ────────────────────────────────────────────────────────
  // Returns a Promise that resolves when the adapter is loaded AND ready
  // (all page dimensions available). Safe to call any time — if already
  // ready it resolves on the next microtask.
  const waitForAdapterReady = useCallback((): Promise<void> => {
    return new Promise(resolve => {
      const tryBind = () => {
        const ad = useAppStore.getState().adapter;
        if (ad && typeof (ad as any).onReady === 'function') {
          (ad as any).onReady(resolve); // fires immediately if already ready
        } else {
          // Adapter not created yet — wait for it
          const unsub = useAppStore.subscribe((state, prev) => {
            if (state.adapter && state.adapter !== prev.adapter) {
              unsub();
              if (typeof (state.adapter as any).onReady === 'function') {
                (state.adapter as any).onReady(resolve);
              } else {
                resolve();
              }
            }
          });
        }
      };
      tryBind();
    });
  }, []);

  // ── applyDocMeta ───────────────────────────────────────────────────────────
  // Applies wordIndex / categories / captures received from parent.
  //
  // wordIndex format accepted (both detected automatically):
  //   ARRAY:  [{ x, y, width, height, page, text }, ...]   ← your format
  //   OBJECT: { "1": [{ x, y, width, height, text }], "2": [...] }
  //
  // In both cases each entry is normalised through extractRawCoords so any
  // supported coord format works (x/y, left/right, bbox, etc.).
  //
  // wordIndex + captures are deferred until adapter.onReady() so page
  // dimensions are available for coordinate normalisation. Categories
  // (no coords) apply immediately.
  const applyDocMeta = useCallback((
    meta?: import('./hooks/useEventBridge').SingleDocMeta | import('./hooks/useEventBridge').DocResponseMeta
  ) => {
    if (!meta) return;

    // Categories — no coordinates, apply immediately
    if (meta.categories) setCategories(meta.categories as any);

    // wordIndex + captures need page dimensions → defer to adapter ready
    const hasCoordMeta = meta.wordIndex || meta.captures;
    if (!hasCoordMeta) return;

    waitForAdapterReady().then(() => {
      const ad = useAppStore.getState().adapter;

      // ── wordIndex ──────────────────────────────────────────────────────
      if (meta.wordIndex) {
        import('./utils/coords').then(({ extractRawCoords, normaliseCoords }) => {
          const normalised = new Map<number, import('./adapters/types').WordEntry[]>();
          const rawWi = meta.wordIndex as any;

          // Detect format: ARRAY vs OBJECT
          if (Array.isArray(rawWi)) {
            // ARRAY format: [{ x, y, width, height, page, text }, ...]
            // Group by page first
            const byPage = new Map<number, any[]>();
            for (const e of rawWi) {
              const pg = Number(e.page ?? 1);
              if (!byPage.has(pg)) byPage.set(pg, []);
              byPage.get(pg)!.push(e);
            }
            for (const [pg, entries] of byPage) {
              normalised.set(pg, entries.map((e: any) => normaliseEntry(e, pg, ad, extractRawCoords, normaliseCoords)) as any);
            }
          } else {
            // OBJECT format: { "1": [...], "2": [...] }
            for (const [pageKey, entries] of Object.entries(rawWi)) {
              const pg = Number(pageKey);
              if (!Array.isArray(entries)) continue;
              normalised.set(pg, (entries as any[]).map((e: any) => normaliseEntry(e, pg, ad, extractRawCoords, normaliseCoords)) as any);
            }
          }

          // Debug: verify Map structure before setting
          console.log('[applyDocMeta] Setting wordIndex. Pages:', normalised.size);
          normalised.forEach((v, k) => {
            console.log(`  page ${k}: isArray=${Array.isArray(v)}, length=${Array.isArray(v) ? v.length : 'N/A'}`, v);
          });
          setWordIndex(normalised);
        });
      }

      // ── captures ───────────────────────────────────────────────────────
      if (meta.captures) {
        meta.captures.forEach((cap: any) => addCaptureWithId(cap));
      }
    });
  }, [waitForAdapterReady, setWordIndex, setCategories, addCaptureWithId]);

  const bridge = useEventBridge({
    onLoadSingleDoc: (buffer, fileName, meta) => {
      openFileBuffer(buffer, fileName);
      applyDocMeta(meta);
    },

    onLoadManifest: (manifest, activeDocId, activeBuffer, meta) => {
      multiDoc.loadManifest(manifest);
      if (activeBuffer && activeDocId) {
        const doc = (manifest.documents ?? []).find((d: any) => d.id === activeDocId);
        const name = (doc as any)?.name ?? `${activeDocId}.pdf`;
        openFileBuffer(activeBuffer, name);
        // Apply meta for the first/active doc
        applyDocMeta(meta);
      }
    },

    // Called after DOC_RESPONSE resolves — apply per-doc meta
    onDocMeta: (_docId, meta) => {
      applyDocMeta(meta);
    },

    onHighlight: async (payload) => {
      // If MultiDoc and different doc requested — fetch it first
      if (payload.docId && multiDoc.state &&
          payload.docId !== multiDoc.state.activeDocId) {
        await multiDoc.selectDoc(payload.docId);
      }

      // Try to navigate to existing capture
      const found = navigateAndHighlight(payload.id);
      if (found) return;

      // Not found — parse payload into a proper CaptureItem (handles all coord formats)
      const result = parseHighlightPayload(payload, adapter);
      if ('error' in result) {
        console.warn('[EventBridge] HIGHLIGHT parse error:', result.error);
        return;
      }
      addCaptureWithId(result.item);
    },

    onCaptureAck: (tempId, realId) => {
      bridge.resolveAck(tempId, realId);
    },
  });

  // Pass requestBuffer into multiDoc so selectDoc can fetch via postMessage
  useEffect(() => {
    if (!isEmbedded) return;
    multiDoc.setConfig({ requestBuffer: bridge.requestDocBuffer });
  }, [bridge.requestDocBuffer]); // eslint-disable-line

  // Register manifest handler in the store — synchronous, no timing race
  const handleManifest = useCallback((manifest: DocumentManifest) => {
    multiDoc.loadManifest(manifest);
  }, [multiDoc]);

  useEffect(() => {
    useAppStore.getState().registerManifestHandler(handleManifest);
    // Also set window bridge for ViewerPane drop zone (belt-and-suspenders)
    (window as any).__onManifest = handleManifest;
    return () => {
      (window as any).__onManifest = undefined;
    };
  }, [handleManifest]);

  // Exit multi-doc mode — clear state + reset viewer
  const handleClearMultiDoc = useCallback(() => {
    multiDoc.clearMultiDoc();
    closeFile();
  }, [multiDoc, closeFile]);

  // pendingPageRef: when selectDoc resolves a new file, navigate to requested page
  // after pdfjs adapter is ready (adapter.onReady fires after page dims loaded)
  const pendingPageRef = React.useRef<number>(1);

  const handleSelectDoc = useCallback(async (docId: string, page = 1) => {
    pendingPageRef.current = page;
    await multiDoc.selectDoc(docId, page);
  }, [multiDoc]);

  // Track last loaded file name to skip re-opening on cache hits (same File object)
  const lastLoadedFileRef = React.useRef<string>('');

  // When a new activeFile is resolved → load it into the viewer
  useEffect(() => {
    if (!multiDoc.activeFile) return;
    const fileKey = multiDoc.activeFile.name + multiDoc.activeFile.size;
    if (fileKey === lastLoadedFileRef.current) {
      // Cache hit — same File object, pdfjs already loaded.
      // Just navigate to the requested page.
      const pg = pendingPageRef.current;
      if (pg >= 1) {
        setCurrentPage(pg);
        useAppStore.getState().adapter?.navigateToPage?.(pg);
      }
      return;
    }
    lastLoadedFileRef.current = fileKey;
    // Preserve user zoom across multi-doc navigation.
    // If zoomMode is 'custom' (explicit %): restore immediately after the sync reset.
    // If zoomMode is 'page-fit'/'page-width': let ViewerToolbar auto-apply recalculate
    //   for the new document's dimensions — do not restore the old doc's pixel zoom.
    const { zoom: savedZoom, zoomMode: savedZoomMode } = useAppStore.getState();
    openFile(multiDoc.activeFile).then(() => {
      if (savedZoomMode === 'custom') {
        // Restore exact zoom — this also sets zoomMode='custom' which blocks auto-apply
        useAppStore.getState().setZoom(savedZoom);
      }
      // For page-fit/page-width: openFile already reset to zoomMode='page-fit',
      // and the ViewerToolbar useEffect fires when adapter+pageCount are ready,
      // recalculating the correct zoom for the new doc size automatically.
      const adapter = useAppStore.getState().adapter as any;
      if (adapter && typeof adapter.onReady === 'function') {
        adapter.onReady(() => {
          const pg = pendingPageRef.current;
          if (pg > 1) {
            setCurrentPage(pg);
            useAppStore.getState().adapter?.navigateToPage?.(pg);
          }
        });
      }
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [multiDoc.activeFile]);

  // Page selection within the current document
  const handleSelectPage = useCallback((page: number) => {
    multiDoc.selectPage(page);
    setCurrentPage(page);
    useAppStore.getState().adapter?.navigateToPage?.(page);
  }, [multiDoc, setCurrentPage]);

  const showMultiSidebar   = !!multiDoc.state && sidebarOpen;
  const showDefaultSidebar = !multiDoc.state && sidebarOpen;

  return (
    <div className="flex flex-col h-screen bg-[#060d1a] overflow-hidden">
      <TopBar />
      <ResizablePanes
        left={
          <div className="flex flex-col flex-1 overflow-hidden">
            {/* Toolbar spans full width above viewer+sidebar */}
            <ViewerToolbar />
            {/* Below toolbar: sidebar overlays the viewer body only */}
            <div className="flex flex-1 overflow-hidden relative">
              {showMultiSidebar && multiDoc.state && (
                <MultiDocSidebar
                  state={multiDoc.state}
                  isLoading={multiDoc.activeDocLoading}
                  loadError={multiDoc.activeDocError}
                  adapter={adapter}
                  onSelectDoc={handleSelectDoc}
                  onSelectPage={handleSelectPage}
                  onClose={handleClearMultiDoc}
                />
              )}
              {/* ThumbnailSidebar overlays viewer body — sits below toolbar, does not push viewer */}
              {showDefaultSidebar && (
                <div style={{
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  bottom: 0,
                  zIndex: 30,
                  display: 'flex',
                }}>
                  <ThumbnailSidebar />
                </div>
              )}
              <ViewerPane multiDocLoading={multiDoc.activeDocLoading && !multiDoc.activeFile} bridge={bridge} />
            </div>
          </div>
        }
        right={<FieldsPanel bridge={bridge} />}
        defaultSplit={0.80}
        minLeft={320}
        minRight={200}
      />
    </div>
  );
}
