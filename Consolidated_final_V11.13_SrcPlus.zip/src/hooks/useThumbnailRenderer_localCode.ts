// ─────────────────────────────────────────────────────────────────────────────
// useThumbnailRenderer — scroll-aware background thumbnail rendering
//
// How it works:
//   1. ThumbnailItem calls `registerThumb(page, canvas)` on mount.
//      The hook attaches an IntersectionObserver to each canvas's wrapper div.
//
//   2. When a thumbnail enters the sidebar viewport, it's added to a
//      priority queue with high priority.
//      Pages ±PRELOAD_AHEAD beyond visible range are added with low priority.
//
//   3. A rate-limited scheduler drains the queue, rendering one page per
//      animation frame (PDF) or batching a few per frame (TIF/Image).
//      This keeps the main thread free — no jank during scroll.
//
//   4. PDF thumbnails: use pdfjs `page.render()` at thumbnail scale on a
//      separate offscreen canvas — completely independent of the main viewer.
//      Never touches the main pdfjs PDFViewer instance.
//
//   5. TIF/Image thumbnails: call `adapter.getFrameAsync(page)` which uses
//      the LRU cache. If already decoded (user visited that page), instant.
//      If not, decodes lazily. Result drawn at thumbnail scale via drawImage.
//
//   6. Rendered thumbnails are stored in a WeakMap — evicted by GC when
//      canvas element is removed from DOM (accordion collapse). Re-renders
//      on next visibility if needed.
// ─────────────────────────────────────────────────────────────────────────────

import { useEffect, useRef, useCallback } from 'react';
import type { AdapterInstance } from '../store/appStore';
import type { PDFAdapter } from '../adapters/PDFAdapter';
import type { ImageAdapter } from '../adapters/ImageAdapter';

const THUMB_W       = 140;   // thumbnail render width in px
const PRELOAD_AHEAD = 15;    // pages to preload beyond visible range
const FRAME_BUDGET  = 14;    // ms per frame — leave headroom for React/pdfjs

type Priority = 'high' | 'low';

interface QueueEntry { page: number; priority: Priority; }

// Get the pdfjs PDFDocumentProxy from the global set by PDFViewer
function getPdfDoc(): any | null {
  return (window as any).__tovPdfDoc ?? null;
}

export function useThumbnailRenderer(adapter: AdapterInstance | null) {
  // canvas refs registered by each ThumbnailItem: page → canvas element
  const canvasMap   = useRef<Map<number, HTMLCanvasElement>>(new Map());
  // rendered set — pages whose thumbnails are already drawn
  const rendered    = useRef<Set<number>>(new Set());
  // pages currently being rendered (in-flight)
  const inFlight    = useRef<Set<number>>(new Set());
  // priority queue
  const queue       = useRef<QueueEntry[]>([]);
  // scheduler RAF handle
  const rafHandle   = useRef(0);
  // IntersectionObserver for sidebar scroll
  const observer    = useRef<IntersectionObserver | null>(null);
  // currently visible page range
  const visibleRange = useRef<[number, number]>([1, 1]);

  // ── Scheduler ──────────────────────────────────────────────────────────────

  const scheduleNext = useCallback(() => {
    cancelAnimationFrame(rafHandle.current);
    rafHandle.current = requestAnimationFrame(async () => {
      if (!queue.current.length) return;

      const deadline = performance.now() + FRAME_BUDGET;

      while (queue.current.length && performance.now() < deadline) {
        // Sort: high priority first, then by page number
        queue.current.sort((a, b) => {
          if (a.priority !== b.priority) return a.priority === 'high' ? -1 : 1;
          // For visible pages, prefer pages closest to top of visible range
          const [vFirst] = visibleRange.current;
          return Math.abs(a.page - vFirst) - Math.abs(b.page - vFirst);
        });

        const entry = queue.current.shift();
        if (!entry) break;
        const { page } = entry;

        // Skip if already rendered or in-flight
        if (rendered.current.has(page) || inFlight.current.has(page)) continue;

        const canvas = canvasMap.current.get(page);
        if (!canvas) continue; // unmounted

        inFlight.current.add(page);
        try {
          await renderThumbnail(page, canvas, adapter);
          rendered.current.add(page);
        } catch (_) {
          // Rendering failed — will retry if page becomes visible again
        } finally {
          inFlight.current.delete(page);
        }
      }

      // Continue draining if more remain
      if (queue.current.length) scheduleNext();
    });
  }, [adapter]);

  // ── Queue management ───────────────────────────────────────────────────────

  const enqueue = useCallback((page: number, priority: Priority) => {
    if (rendered.current.has(page)) return;
    if (inFlight.current.has(page)) return;
    if (!canvasMap.current.has(page)) return;
    // Deduplicate — upgrade priority if already queued as low
    const existing = queue.current.find(e => e.page === page);
    if (existing) {
      if (priority === 'high') existing.priority = 'high';
      return;
    }
    queue.current.push({ page, priority });
    scheduleNext();
  }, [scheduleNext]);

  const enqueueRange = useCallback((first: number, last: number, priority: Priority) => {
    for (let p = first; p <= last; p++) enqueue(p, priority);
  }, [enqueue]);

  // ── IntersectionObserver setup ─────────────────────────────────────────────

  const setupObserver = useCallback((scrollRoot: Element) => {
    observer.current?.disconnect();

    observer.current = new IntersectionObserver(entries => {
      const visiblePages: number[] = [];

      for (const entry of entries) {
        const page = Number((entry.target as HTMLElement).dataset.thumbPage);
        if (!page) continue;
        if (entry.isIntersecting) {
          visiblePages.push(page);
          enqueue(page, 'high');
        }
      }

      if (visiblePages.length) {
        const sorted = visiblePages.sort((a, b) => a - b);
        const first = sorted[0], last = sorted[sorted.length - 1];
        visibleRange.current = [first, last];

        // Preload pages ahead and behind visible range
        const pageCount = adapter ? getPageCount(adapter) : 0;
        enqueueRange(
          Math.max(1, first - PRELOAD_AHEAD),
          Math.min(pageCount, last + PRELOAD_AHEAD),
          'low'
        );
      }
    }, {
      root: scrollRoot,
      threshold: 0.01, // fire as soon as 1% is visible
    });

    // Observe all registered thumb wrappers
    canvasMap.current.forEach((canvas, page) => {
      const wrapper = canvas.closest('[data-thumb-page]') as HTMLElement | null;
      if (wrapper) observer.current!.observe(wrapper);
    });
  }, [adapter, enqueue, enqueueRange]);

  // ── Public API — called by ThumbnailItem ───────────────────────────────────

  const registerThumb = useCallback((
    page: number,
    canvas: HTMLCanvasElement | null,
    scrollRoot?: Element | null,
  ) => {
    if (!canvas) {
      canvasMap.current.delete(page);
      return;
    }
    canvasMap.current.set(page, canvas);

    // Set up observer when first thumb is registered
    if (scrollRoot && !observer.current) {
      setupObserver(scrollRoot);
    }

    // Observe this thumb's wrapper
    const wrapper = canvas.closest('[data-thumb-page]') as HTMLElement | null;
    if (wrapper && observer.current) {
      observer.current.observe(wrapper);
    }

    // Immediately queue visible pages (page 1-5 on first mount)
    const [vFirst, vLast] = visibleRange.current;
    if (page >= vFirst - 2 && page <= vLast + 2) {
      enqueue(page, 'high');
    }
  }, [setupObserver, enqueue]);

  const unregisterThumb = useCallback((page: number, canvas: HTMLCanvasElement | null) => {
    canvasMap.current.delete(page);
    rendered.current.delete(page); // allow re-render if re-mounted (accordion reopen)
    if (canvas) {
      const wrapper = canvas.closest('[data-thumb-page]') as HTMLElement | null;
      if (wrapper && observer.current) observer.current.unobserve(wrapper);
    }
  }, []);

  // Invalidate all rendered state — called when adapter changes
  const invalidateAll = useCallback(() => {
    rendered.current.clear();
    inFlight.current.clear();
    queue.current = [];
    cancelAnimationFrame(rafHandle.current);
    // Re-queue all registered pages at low priority
    canvasMap.current.forEach((_, page) => enqueue(page, 'low'));
    scheduleNext();
  }, [enqueue, scheduleNext]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      observer.current?.disconnect();
      cancelAnimationFrame(rafHandle.current);
    };
  }, []);

  // Re-render all thumbs when adapter changes (new file loaded)
  useEffect(() => {
    if (adapter) invalidateAll();
  }, [adapter, invalidateAll]);

  return { registerThumb, unregisterThumb, invalidateAll };
}

// ── Render a single thumbnail onto a canvas ───────────────────────────────────

async function renderThumbnail(
  page: number,
  canvas: HTMLCanvasElement,
  adapter: AdapterInstance | null,
): Promise<void> {
  if (!adapter) return;

  // ── PDF ──────────────────────────────────────────────────────────────────
  if (adapter.constructor.name === 'PDFAdapter') {
    const pdfDoc = getPdfDoc();
    if (!pdfDoc) return;

    const pdfPage  = await pdfDoc.getPage(page);
    const viewport = pdfPage.getViewport({ scale: 1 });
    const scale    = THUMB_W / viewport.width;
    const scaledVP = pdfPage.getViewport({ scale });

    canvas.width  = Math.round(scaledVP.width);
    canvas.height = Math.round(scaledVP.height);

    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Use 'print' intent so this render is independent of the main viewer's
    // 'display' render queue — the two will never conflict or cancel each other.
    // Do NOT call pdfPage.cleanup() — it destroys shared operator list / font
    // resources and causes the main viewer to lose its rendered overlay.
    const task = pdfPage.render({ canvasContext: ctx, viewport: scaledVP, intent: 'print' });
    await task.promise;
    return;
  }

  // ── TIF / Image ───────────────────────────────────────────────────────────
  if (adapter.constructor.name === 'ImageAdapter') {
    const imgAdapter = adapter as ImageAdapter;
    const frame = await imgAdapter.getFrameAsync(page);
    if (!frame) return;

    const scale  = THUMB_W / frame.width;
    canvas.width  = THUMB_W;
    canvas.height = Math.round(frame.height * scale);

    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(frame.bitmap, 0, 0, canvas.width, canvas.height);
    return;
  }

  // ── Fallback: try getPageCanvas (Doc, Spreadsheet) ────────────────────────
  const src = adapter.getPageCanvas?.(page);
  if (!src) return;
  const scale  = THUMB_W / src.width;
  canvas.width  = THUMB_W;
  canvas.height = Math.round(src.height * scale);
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(src, 0, 0, canvas.width, canvas.height);
}

function getPageCount(adapter: AdapterInstance): number {
  return adapter.pageCount ?? 0;
}
