# DocCapture Viewer — Parent ↔ Viewer Integration Guide

## Overview

DocCapture Viewer runs inside an `<iframe>` embedded in your parent application.
All communication uses `window.postMessage`. No SDK required — pure browser API.

```
Parent Application
│
│  postMessage  ──────────────────►  iframe (DocCapture Viewer)
│
│  window.addEventListener  ◄──────  postMessage
```

---

## Quick Setup

```html
<!-- Parent HTML -->
<iframe
  id="doc-viewer"
  src="https://your-viewer-domain.com"
  style="width:100%; height:100%; border:none;"
></iframe>
```

```js
// Parent JS — reference once
const iframe   = document.getElementById('doc-viewer');
const VIEWER   = '*';  // replace with 'https://your-viewer-domain.com' in production

// Helper to send to viewer
function sendToViewer(msg, transferable = []) {
  iframe.contentWindow.postMessage(msg, VIEWER, transferable);
}

// Central listener for all viewer events
window.addEventListener('message', (e) => {
  // if (e.origin !== 'https://your-viewer-domain.com') return;  // enable in production
  const { type, ...data } = e.data;
  switch (type) {
    case 'READY':          onViewerReady();         break;
    case 'PDF_LOADED':     onPdfLoaded(data);       break;
    case 'DOC_REQUEST':    onDocRequest(data);      break;
    case 'CAPTURE_PREVIEW':onCapturePreview(data);  break;
    case 'CAPTURES_DATA':  onCapturesData(data);    break;
  }
});
```

---

## Section 1 — Complete Event Reference

### Events: Parent → Viewer

---

#### `LOAD_SINGLEDOC`
Load a single document (PDF, TIFF, XLSX, DOCX, PNG, JPEG, CSV).

```js
const buffer = await fetch('/api/invoice.pdf').then(r => r.arrayBuffer());

sendToViewer({
  type:            'LOAD_SINGLEDOC',

  // ── Required ─────────────────────────────────────────────
  buffer,                      // ArrayBuffer — the document binary
  fileName:        'invoice.pdf',  // Extension determines format (pdf/tif/xlsx/docx/png/jpg/csv)

  // ── Optional data ─────────────────────────────────────────
  wordIndex:       [...],      // see Section 4
  categories:      [...],      // see Section 2
  captures:        [...],      // see Section 3 — pre-existing captured fields (grey boxes)

  // ── Optional UI flags ─────────────────────────────────────
  Click2Pick:      true,       // enable box-draw mode on load  (default: false)
  showFieldsPanel: true,       // show right-side fields panel  (default: false)
  showAnnotation:  true,       // show annotation/draw button   (default: false)
});

// ⚠️  Do NOT pass buffer as Transferable ([buffer] 3rd arg).
//     Use plain postMessage — structured clone keeps buffer intact.
```

---

#### `LOAD_MANIFEST`
Load a multi-document session. Viewer shows sidebar with all docs.

```js
sendToViewer({
  type: 'LOAD_MANIFEST',

  manifest: {
    mode: 'MultiDoc:MultiPage',      // or 'MultiDoc:SinglePage'
    documents: [
      { id: 'doc1', name: 'Invoice.pdf',   label: 'Invoice',   totalPages: 3 },
      { id: 'doc2', name: 'Form15CA.pdf',  label: 'Form 15CA', totalPages: 2 },
      { id: 'doc3', name: 'Statement.xlsx',label: 'Statement', totalPages: 1 },
    ],
    categories: [                    // optional — same as Section 2
      { label: 'Invoice', color: '#1a7fd4', pages: [1,2,3] },
    ],
  },

  activeDocId:   'doc1',            // which doc to show first
  activeBuffer,                      // ArrayBuffer for the first/active doc

  // Optional — applies to the active doc on load:
  wordIndex:       [...],
  captures:        [...],
  Click2Pick:      false,
  showFieldsPanel: true,
  showAnnotation:  false,
});
```

---

#### `DOC_RESPONSE`
Send a document buffer when viewer requests it (user clicked a doc in MultiDoc sidebar).

```js
// Sent in response to DOC_REQUEST from viewer:
async function onDocRequest({ docId }) {
  const buffer = await fetchDocumentFromBackend(docId);

  sendToViewer({
    type:   'DOC_RESPONSE',
    docId,         // must match what viewer requested
    buffer,        // ArrayBuffer

    // Optional — meta for this specific doc:
    wordIndex:  await fetchWordIndex(docId),
    categories: await fetchCategories(docId),
    captures:   await fetchCaptures(docId),
  });
}
```

---

#### `CAPTURE_ACK`
Acknowledge a capture preview sent by the viewer.

```js
async function onCapturePreview({ tempId, text, page, x, y, width, height, docId, label }) {
  // Save to your backend:
  const { id } = await fetch('/api/captures', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text, page, x, y, width, height, docId, label }),
  }).then(r => r.json());

  // ACK with real backend ID:
  sendToViewer({ type: 'CAPTURE_ACK', tempId, id });

  // To reject (don't save):        → don't send anything (viewer times out after 15s)
  // To delete an existing capture: → send with empty coords: { tempId, id, x:0, y:0, width:0, height:0 }
  // Or explicit delete flag:       → { tempId, id, delete: true }
}
```

---

#### `HIGHLIGHT`
Navigate viewer to a specific field and highlight it.

```js
// Navigate to an existing capture (by id):
sendToViewer({
  type: 'HIGHLIGHT',
  payload: {
    id:    'field-invoice-no',   // required — empty id is ignored
    page:   1,
    x:      0.08, y: 0.06, width: 0.14, height: 0.03,  // normalised 0-1 OR raw pixels

    // Optional:
    label:  'Invoice Number',
    value:  'INV-2024-001',
    color:  '#1a7fd4',
    docId:  'doc2',             // MultiDoc: load this doc first if not active
  }
});

// Rules:
// • id present + exists in viewer → navigate + highlight (yellow)
// • id present + NOT in viewer   → add to captures then highlight
// • id missing or empty          → completely ignored
// • docId differs from active    → viewer auto-requests that doc first, then highlights
```

---

#### `EXPORT_CAPTURES`
Request all current captured fields from viewer.

```js
// Trigger:
sendToViewer({ type: 'EXPORT_CAPTURES' });

// Viewer responds with CAPTURES_DATA (see Viewer → Parent below)
```

---

### Events: Viewer → Parent

---

#### `READY`
Viewer iframe is mounted and listening. **Always wait for this before sending any data.**

```js
let viewerReady    = false;
let pendingPayload = null;

function onViewerReady() {
  viewerReady = true;
  if (pendingPayload) {
    sendToViewer(pendingPayload);
    pendingPayload = null;
  }
}

// Start your API calls immediately — don't wait for READY:
async function init() {
  const buffer = await fetch('/api/doc.pdf').then(r => r.arrayBuffer());
  const payload = { type: 'LOAD_SINGLEDOC', fileName: 'doc.pdf', buffer };

  if (viewerReady) sendToViewer(payload);
  else             pendingPayload = payload;   // will send when READY fires
}
init();
```

---

#### `PDF_LOADED`
PDF has finished rendering. Enable action buttons in your UI.

```js
function onPdfLoaded({ fileName, pageCount, docId }) {
  console.log(`${fileName} loaded — ${pageCount} pages`);
  document.getElementById('action-btn').disabled = false;
  // docId is set in MultiDoc mode (which doc was just loaded)
}
```

---

#### `DOC_REQUEST`
User clicked a doc in the MultiDoc sidebar — send its buffer.

```js
async function onDocRequest({ docId }) {
  const buffer = await fetchDocumentFromBackend(docId);
  sendToViewer({ type: 'DOC_RESPONSE', docId, buffer });
  // Viewer shows "Loading…" until it receives DOC_RESPONSE (15s timeout then shows error)
}
```

---

#### `CAPTURE_PREVIEW`
User drew a box or double-clicked a word — fires immediately before any Submit.

```js
function onCapturePreview({ tempId, text, page, x, y, width, height, docId, label }) {
  // Coordinates are in the SAME FORMAT as your wordIndex/captures input.
  // If you sent { x:14, y:144, width:30, height:9 } in wordIndex,
  // you receive { x:14, y:144, width:30, height:9 } back here.
  // If no wordIndex was sent, coordinates are normalised 0-1 fractions.

  console.log('Capture:', { tempId, text, page, x, y, width, height });
  // Must respond with CAPTURE_ACK within 15s or capture is discarded.
}
```

---

#### `CAPTURES_DATA`
Response to your `EXPORT_CAPTURES` request.

```js
function onCapturesData({ captures }) {
  // captures is an array — see Section 3 for full shape
  console.log('All captures:', captures);
  fetch('/api/captures/bulk', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(captures),
  });
}
```

---

## Section 2 — Categories JSON

Categories group pages by document type. They control the thumbnail sidebar accordion view and colour-coded highlights in the viewer.

### Format A — Bare array (recommended)

```json
[
  {
    "label": "Invoice",
    "color": "#1a7fd4",
    "pages": [1, 2, 3]
  },
  {
    "label": "Form 15CA",
    "color": "#0f9e6e",
    "pages": [4, 5]
  },
  {
    "label": "Bank Statement",
    "color": "#d97706",
    "pages": [6, 7, 8, 9, 10]
  }
]
```

### Format B — SingleDoc envelope

```json
{
  "mode": "SingleDoc",
  "categories": [
    { "label": "Invoice",    "color": "#1a7fd4", "pages": [1, 2, 3] },
    { "label": "Form 15CA", "color": "#0f9e6e", "pages": [4, 5]    }
  ]
}
```

### Format C — Inside LOAD_MANIFEST (MultiDoc)

```js
sendToViewer({
  type: 'LOAD_MANIFEST',
  manifest: {
    mode: 'MultiDoc:MultiPage',
    documents: [...],
    categories: [
      { label: 'Invoice',    color: '#1a7fd4', pages: [1, 2, 3] },
      { label: 'Form 15CA', color: '#0f9e6e', pages: [4, 5]    },
    ],
  },
  activeDocId: 'doc1',
  activeBuffer,
});
```

### Rules

| Property | Type     | Required | Notes                                           |
|----------|----------|----------|-------------------------------------------------|
| `label`  | string   | ✅        | Shown in sidebar accordion header               |
| `color`  | string   | ❌        | CSS colour. If omitted, auto-assigned from palette |
| `pages`  | number[] | ✅        | 1-based page numbers. Pages not in any category appear under "Others" |

---

## Section 3 — Captured Fields JSON

Captured fields are highlighted boxes on the document. They appear in the right-side Fields panel and as coloured boxes on the PDF.

### Shape

```json
[
  {
    "id":    "invoice_no",
    "value": "INV-2024-001",
    "page":  1,
    "color": "#1a7fd4",
    "x":     0.08,
    "y":     0.06,
    "width": 0.14,
    "height":0.03
  }
]
```

### Full field reference

| Property | Type   | Required | Notes |
|----------|--------|----------|-------|
| `id`     | string | ✅        | Unique identifier. Used for dedup and HIGHLIGHT navigation |
| `value`  | string | ✅        | The captured text / field value |
| `page`   | number | ✅        | 1-based page number |
| `color`  | string | ❌        | CSS colour for box border. If omitted → grey box |
| Coords   | —      | ✅        | Any of the 9 coordinate formats below |

### Coordinate formats (any of these work)

```json
// Format 1 — flat x/y (normalised 0-1 or raw pixels)
{ "x": 0.08, "y": 0.06, "width": 0.14, "height": 0.03 }
{ "x": 50,   "y": 42,   "width": 88,   "height": 20   }

// Format 2 — bbox array [x, y, w, h]
{ "bbox": [0.08, 0.06, 0.14, 0.03] }
{ "bbox": [50, 42, 88, 20] }

// Format 3/4 — rectangle [x, y, w, h] or [x1, y1, x2, y2]
{ "rectangle": [0.08, 0.06, 0.14, 0.03] }
{ "rectangle": [50, 42, 138, 62] }

// Format 5 — coordinates [ymin, xmin, ymax, xmax] (Google Vision style)
{ "coordinates": [0.06, 0.08, 0.09, 0.22] }

// Format 6 — min/max
{ "xmin": 0.08, "ymin": 0.06, "xmax": 0.22, "ymax": 0.09 }

// Format 7 — bbox_relative (polygon corners)
{ "bbox_relative": [[0.08,0.06],[0.22,0.06],[0.22,0.09],[0.08,0.09]] }

// Format 8 — left/right/width/height (left=x origin)
{ "left": 50, "right": 138, "width": 88, "height": 20 }
{ "left": 50, "right": 138, "width": 88, "height": 20, "top": 42 }

// Format 9 — four corners: left/right/top/bottom
{ "left": 50, "right": 138, "top": 42, "bottom": 62 }
```

### Round-trip fidelity

Coordinates sent to viewer in any format are sent **back in the same format** in `CAPTURE_PREVIEW` and `CAPTURES_DATA`. If you sent `{ x:50, y:42, width:88, height:20 }`, you receive those exact pixel values back — not normalised 0-1. Only when no `wordIndex` or `captures` were provided does the viewer send normalised 0-1 values.

### Complete example

```json
[
  {
    "id":     "inv_number",
    "value":  "INV-2024-001",
    "page":   1,
    "color":  "#1a7fd4",
    "x":      50,
    "y":      42,
    "width":  88,
    "height": 20
  },
  {
    "id":     "inv_date",
    "value":  "15-Jan-2024",
    "page":   1,
    "color":  "#0f9e6e",
    "x":      0.60,
    "y":      0.06,
    "width":  0.18,
    "height": 0.03
  },
  {
    "id":     "total_amount",
    "value":  "₹1,25,000",
    "page":   2,
    "bbox":   [320, 680, 200, 22]
  }
]
```

---

## Section 4 — word_index JSON

The word index maps every word on every page to its coordinates. The viewer uses it for:
- **Click2Pick / Double-click** — detect which word was clicked
- **Search** — highlight matching words across all pages
- **Duplicate detection** — show light-pink boxes for duplicate captured values

### Format A — Flat array (recommended)

Each entry has a `page` property. The viewer groups by page automatically.

```json
[
  { "text": "Invoice",    "page": 1, "x": 50,   "y": 42,  "width": 88,  "height": 20 },
  { "text": "Number",     "page": 1, "x": 140,  "y": 42,  "width": 66,  "height": 20 },
  { "text": "INV-001",    "page": 1, "x": 220,  "y": 42,  "width": 100, "height": 20 },
  { "text": "Date",       "page": 1, "x": 50,   "y": 70,  "width": 44,  "height": 20 },
  { "text": "15-Jan-2024","page": 1, "x": 140,  "y": 70,  "width": 120, "height": 20 },
  { "text": "Total",      "page": 2, "x": 300,  "y": 680, "width": 55,  "height": 20 },
  { "text": "₹1,25,000",  "page": 2, "x": 380,  "y": 680, "width": 110, "height": 20 }
]
```

### Format B — Object keyed by page

```json
{
  "1": [
    { "text": "Invoice",  "x": 50,  "y": 42, "width": 88,  "height": 20 },
    { "text": "INV-001",  "x": 220, "y": 42, "width": 100, "height": 20 }
  ],
  "2": [
    { "text": "Total",    "x": 300, "y": 680, "width": 55, "height": 20 },
    { "text": "₹1,25,000","x": 380, "y": 680, "width": 110,"height": 20 }
  ]
}
```

### Field reference

| Property | Type   | Required | Notes |
|----------|--------|----------|-------|
| `text`   | string | ✅        | The word / token text |
| `page`   | number | ✅ (Format A) | 1-based. Not needed in Format B (key is the page) |
| Coords   | —      | ✅        | Any of the 9 coordinate formats from Section 3 |

### Coordinate values — pixels or normalised

Both work. The viewer auto-detects by checking if any value > 1:

```json
// Normalised 0-1 fractions:
{ "text": "Invoice", "page": 1, "x": 0.08, "y": 0.06, "width": 0.14, "height": 0.03 }

// Raw pixel values (viewer normalises using page dimensions):
{ "text": "Invoice", "page": 1, "x": 50, "y": 42, "width": 88, "height": 20 }
```

---

## Section 5 — Full Working Example (SingleDoc)

```js
const iframe = document.getElementById('doc-viewer');
const VIEWER = '*'; // 'https://your-viewer.com' in production

// State
let viewerReady = false;
let payload     = null;

// Listener
window.addEventListener('message', async (e) => {
  const { type, ...data } = e.data ?? {};

  switch (type) {
    case 'READY': {
      viewerReady = true;
      if (payload) { iframe.contentWindow.postMessage(payload, VIEWER); payload = null; }
      break;
    }
    case 'PDF_LOADED': {
      console.log('Ready:', data.fileName, data.pageCount, 'pages');
      document.getElementById('capture-btn').disabled = false;
      break;
    }
    case 'DOC_REQUEST': {
      const buf = await fetch(`/api/docs/${data.docId}`).then(r => r.arrayBuffer());
      iframe.contentWindow.postMessage({ type: 'DOC_RESPONSE', docId: data.docId, buffer: buf }, VIEWER);
      break;
    }
    case 'CAPTURE_PREVIEW': {
      const { tempId, text, page, x, y, width, height, docId } = data;
      const { id } = await fetch('/api/captures', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, page, x, y, width, height, docId }),
      }).then(r => r.json());
      iframe.contentWindow.postMessage({ type: 'CAPTURE_ACK', tempId, id }, VIEWER);
      break;
    }
    case 'CAPTURES_DATA': {
      console.log('Export:', data.captures);
      break;
    }
  }
});

// Load document
async function loadDocument() {
  const [buffer, wordIndex, captures] = await Promise.all([
    fetch('/api/invoice.pdf').then(r => r.arrayBuffer()),
    fetch('/api/invoice/words').then(r => r.json()),
    fetch('/api/invoice/captures').then(r => r.json()),
  ]);

  const msg = {
    type:            'LOAD_SINGLEDOC',
    fileName:        'invoice.pdf',
    buffer,
    wordIndex,       // flat array format
    captures,        // pre-existing captured fields
    categories:      [{ label: 'Invoice', color: '#1a7fd4', pages: [1,2,3] }],
    Click2Pick:      true,
    showFieldsPanel: true,
    showAnnotation:  false,
  };

  if (viewerReady) iframe.contentWindow.postMessage(msg, VIEWER);
  else             payload = msg;
}

loadDocument();

// Highlight a field
function highlight(field) {
  iframe.contentWindow.postMessage({
    type: 'HIGHLIGHT',
    payload: { id: field.id, label: field.label, value: field.value,
               page: field.page, x: field.x, y: field.y,
               width: field.width, height: field.height },
  }, VIEWER);
}

// Request export
function exportCaptures() {
  iframe.contentWindow.postMessage({ type: 'EXPORT_CAPTURES' }, VIEWER);
}
```

---

## Environment Configuration

### Viewer `.env` (project root)

```bash
# Development / standalone testing:
VITE_PARENT_ORIGIN=*

# Production (replace with your actual parent domain):
VITE_PARENT_ORIGIN=https://your-parent-app.com
```

### Production web server — cache headers (important for performance)

Add to nginx / Apache / CDN for the viewer's static assets:

```nginx
# nginx — cache fonts and cmaps forever (content-addressed filenames)
location ~* \.(pfb|ttf|bcmap|mjs)$ {
  add_header Cache-Control "public, max-age=31536000, immutable";
}
```

Without these headers, pdfjs fetches fonts/CMaps on every page navigation, causing 200-800ms delays per page on moderate networks.

---

## Event Quick Reference

| Direction         | Event              | Trigger                                   |
|-------------------|--------------------|-------------------------------------------|
| Parent → Viewer   | `LOAD_SINGLEDOC`   | Load a document from buffer               |
| Parent → Viewer   | `LOAD_MANIFEST`    | Load a multi-doc session                  |
| Parent → Viewer   | `DOC_RESPONSE`     | Deliver requested doc buffer              |
| Parent → Viewer   | `CAPTURE_ACK`      | Acknowledge a capture with a backend ID   |
| Parent → Viewer   | `HIGHLIGHT`        | Navigate viewer to a specific field       |
| Parent → Viewer   | `EXPORT_CAPTURES`  | Request all current captured fields       |
| Viewer → Parent   | `READY`            | Viewer is mounted and ready               |
| Viewer → Parent   | `PDF_LOADED`       | Document rendered, page count known       |
| Viewer → Parent   | `DOC_REQUEST`      | User clicked a doc in MultiDoc sidebar    |
| Viewer → Parent   | `CAPTURE_PREVIEW`  | User drew/clicked a capture box           |
| Viewer → Parent   | `CAPTURES_DATA`    | Response to `EXPORT_CAPTURES`             |

