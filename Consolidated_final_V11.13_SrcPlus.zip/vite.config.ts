import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [react(), tailwindcss()],
  optimizeDeps: {
    exclude: ['pdfjs-dist'],
  },
  worker: { format: 'es' },
  build: {
    rollupOptions: {
      external: [],
    }
  },
  server: {
    // Only cache static PDF.js assets (fonts, cmaps, worker) — NOT all responses.
    // Applying Cache-Control globally breaks Vite HMR WebSocket.
    headers: {
      // HMR WebSocket works on its own protocol — these headers apply to HTTP only
    },
    // Explicitly configure HMR so it doesn't get caught by proxy/iframe
    hmr: {
      protocol: 'ws',
      host: 'localhost',
    },
  },
  preview: {
    // In production preview, cache all static assets
    headers: {
      'Cache-Control': 'public, max-age=31536000, immutable',
    },
  },
})
