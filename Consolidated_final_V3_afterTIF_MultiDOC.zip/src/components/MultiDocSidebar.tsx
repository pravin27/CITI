// MultiDocSidebar — thumbnail + outline sidebar for SINGLE and MULTI manifest modes
// Works for ALL adapter types: PDF, TIF/TIFF, DOC, DOCX, XLS/XLSX/CSV
//
// Real thumbnails: uses the same useThumbnailRenderer + VirtualThumbList as
// ThumbnailSidebar — module-scope bitmap cache, virtual scroll, lazy render.
// DocThumbRow (mode:single): one ThumbnailItem per document.
// PageThumbRow (mode:multi thumbnail tab): VirtualThumbList over the doc's pages.

import { useState, useRef } from 'react';
import type { MultiDocState, ResolvedCategory } from '../types/multiDoc';
import { buildPageCatMap } from '../types/multiDoc';
import { MultiDocOutline } from './MultiDocOutline';
import { ThumbnailItem, VirtualThumbList } from './ThumbnailSidebar';
import { useThumbnailRenderer } from '../hooks/useThumbnailRenderer';
import type { AdapterInstance } from '../store/appStore';

// Inject spin keyframe once
if (typeof document !== 'undefined' && !document.getElementById('mds-spin')) {
  const s = document.createElement('style');
  s.id = 'mds-spin';
  s.textContent = '@keyframes spin { to { transform: rotate(360deg); } }';
  document.head.appendChild(s);
}

export interface MultiDocSidebarProps {
  state: MultiDocState;
  isLoading: boolean;
  loadError: string | null;
  adapter: AdapterInstance | null;        // current live adapter (for real thumbnails)
  onSelectDoc: (docId: string, page?: number) => void;
  onSelectPage: (page: number) => void;
  onClose?: () => void;
}

export function MultiDocSidebar({
  state, isLoading, loadError, adapter,
  onSelectDoc, onSelectPage, onClose,
}: MultiDocSidebarProps) {
  const [tab, setTab] = useState<'thumb' | 'outline'>('thumb');
  const [collapsedCats, setCollapsedCats] = useState<Set<string>>(new Set());
  const toggleCat = (id: string) => setCollapsedCats(s => {
    const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n;
  });

  const { documents, categories, activeDocId, activePage, mode } = state;

  // Keep showing previous doc during load — no blank flash / layout jump
  const lastLoadedDocId = useRef<string | null>(null);
  if (!isLoading && activeDocId) lastLoadedDocId.current = activeDocId;
  const displayDocId = lastLoadedDocId.current ?? activeDocId;

  const catById   = Object.fromEntries(categories.map(c => [c.id, c]));
  const activeDoc = documents.find(d => d.id === activeDocId);
  const displayDoc = documents.find(d => d.id === displayDocId) ?? activeDoc;
  const activeIdx = activeDocId ? documents.findIndex(d => d.id === activeDocId) : -1;

  // Real thumbnail renderer — works for PDF, TIF, DOC, XLS
  const { registerThumb, unregisterThumb } = useThumbnailRenderer(adapter);
  const scrollRootRef = useRef<Element | null>(null);

  // mode:single — group docs by category
  const catGroups: Record<string, typeof documents> = {};
  if (mode === 'single') {
    documents.forEach(d => {
      const cid = d.categoryId ?? '__none__';
      if (!catGroups[cid]) catGroups[cid] = [];
      catGroups[cid].push(d);
    });
  }

  // mode:multi thumbnail tab — pages of the displayed doc grouped by category
  const pagesByCat: Record<string, number[]> = {};
  if (mode === 'multi' && displayDoc?.pageCategories) {
    displayDoc.pageCategories.forEach(pc => {
      pagesByCat[pc.category] = [...pc.pages].sort((a, b) => a - b);
    });
  }

  // page → category map for active page highlight
  const pageCatMap = (mode === 'multi' && displayDoc?.pageCategories)
    ? buildPageCatMap(displayDoc.pageCategories)
    : new Map<number, string>();

  return (
    <div style={{
      width: 196, flexShrink: 0, display: 'flex', flexDirection: 'column',
      background: '#0d1829', borderRight: '1px solid #1a2740', height: '100%',
    }}>

      {/* ── Header ── */}
      <div style={{
        padding: '8px 10px 6px', borderBottom: '1px solid #1a2740',
        background: '#080f1a', flexShrink: 0,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <div style={{
            fontSize: 11, color: '#e8f0f6', fontWeight: 500,
            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1,
          }}>
            {mode === 'multi' && activeDoc ? `${activeDoc.name}` : 'Documents'}
          </div>
          {onClose && (
            <button onClick={onClose} title="Exit multi-doc mode" style={{
              background: 'transparent', border: 'none', color: '#4a6070',
              cursor: 'pointer', fontSize: 14, lineHeight: 1, padding: '0 2px', flexShrink: 0,
            }}>✕</button>
          )}
        </div>
        <div style={{ fontSize: 9, color: '#4a6070', marginTop: 1 }}>
          {mode === 'multi'
            ? `Doc ${activeIdx + 1} of ${documents.length} · ${activeDoc?.totalPages ?? 0} pages`
            : `${documents.length} docs · ${categories.length} categories`}
        </div>
      </div>

      {/* ── Prev / Next (mode:multi) ── */}
      {mode === 'multi' && (
        <div style={{
          display: 'flex', alignItems: 'center', gap: 5,
          padding: '6px 8px', borderBottom: '1px solid #1a2740',
          background: '#0a1520', flexShrink: 0,
        }}>
          <button
            disabled={activeIdx <= 0}
            onClick={() => {
              const p = documents[activeIdx - 1];
              if (p) onSelectDoc(p.id, p.pageCategories?.[0]?.pages?.[0] ?? 1);
            }}
            style={{
              background: '#1a2f47', border: '0.5px solid #2a4060', color: '#8ab0c8',
              borderRadius: 5, width: 28, height: 26, cursor: 'pointer', fontSize: 16,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              opacity: activeIdx <= 0 ? 0.3 : 1,
            }}
          >‹</button>
          <div style={{
            flex: 1, textAlign: 'center', fontSize: 10, color: '#e8f0f6', fontWeight: 500,
            background: '#142035', borderRadius: 4, padding: '3px 0',
          }}>
            {activeIdx >= 0 ? `${activeIdx + 1} / ${documents.length}` : `— / ${documents.length}`}
          </div>
          <button
            disabled={activeIdx >= documents.length - 1}
            onClick={() => {
              const n = documents[activeIdx + 1];
              if (n) onSelectDoc(n.id, n.pageCategories?.[0]?.pages?.[0] ?? 1);
            }}
            style={{
              background: '#1a2f47', border: '0.5px solid #2a4060', color: '#8ab0c8',
              borderRadius: 5, width: 28, height: 26, cursor: 'pointer', fontSize: 16,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              opacity: activeIdx >= documents.length - 1 ? 0.3 : 1,
            }}
          >›</button>
        </div>
      )}

      {/* ── Tabs (mode:multi) ── */}
      {mode === 'multi' && (
        <div style={{ display: 'flex', borderBottom: '1px solid #1a2740', flexShrink: 0 }}>
          {(['thumb', 'outline'] as const).map(t => (
            <div
              key={t}
              onClick={() => setTab(t)}
              style={{
                flex: 1, padding: '6px 0', fontSize: 10, fontWeight: 500,
                color: tab === t ? '#8ab0c8' : '#4a6070',
                textAlign: 'center', cursor: 'pointer',
                borderBottom: tab === t ? '2px solid #1a7fd4' : '2px solid transparent',
                transition: 'color 0.12s',
              }}
            >{t === 'thumb' ? 'Thumbnails' : 'Doc outline'}</div>
          ))}
        </div>
      )}

      {/* ── Error bar ── */}
      {loadError && (
        <div style={{
          padding: '8px 10px', fontSize: 10, color: '#f87171',
          borderBottom: '0.5px solid #2a2020', flexShrink: 0,
        }}>{loadError}</div>
      )}

      {/* ── Scroll content ── */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', position: 'relative', overflow: 'hidden' }}>

        {/* Loading spinner overlay — no layout shift */}
        {isLoading && (
          <div style={{
            position: 'absolute', inset: 0, zIndex: 20,
            background: 'rgba(242,244,246,0.75)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <div style={{
              width: 20, height: 20, borderRadius: '50%',
              border: '2px solid #1a2740', borderTopColor: '#1a7fd4',
              animation: 'spin 0.7s linear infinite',
            }} />
          </div>
        )}

        {/* ── SINGLE: category accordion with real thumbnails ── */}
        {mode === 'single' && (
          <div
            ref={el => { scrollRootRef.current = el; }}
            style={{ flex: 1, overflowY: 'auto', background: '#f2f4f6' }}
          >
            {categories.map(cat => {
              const catDocs = catGroups[cat.id] ?? [];
              if (!catDocs.length) return null;
              const isCollapsed = collapsedCats.has(cat.id);
              return (
                <div key={cat.id}>
                  <button
                    onClick={() => toggleCat(cat.id)}
                    style={{
                      width: '100%', display: 'flex', alignItems: 'center', gap: 6,
                      padding: '7px 10px 6px 8px', cursor: 'pointer', userSelect: 'none',
                      background: cat.color, border: 'none',
                      borderLeft: `4px solid ${cat.color}`,
                      borderBottom: '0.5px solid rgba(0,0,0,.15)', textAlign: 'left',
                      position: 'sticky', top: 0, zIndex: 10,
                    }}
                  >
                    <span style={{
                      fontSize: 9, color: '#fff', opacity: 0.85, display: 'inline-block',
                      transform: isCollapsed ? 'rotate(0deg)' : 'rotate(90deg)',
                      transition: 'transform 0.15s', flexShrink: 0,
                    }}>▶</span>
                    <span style={{ width: 7, height: 7, borderRadius: '50%', background: 'rgba(255,255,255,0.6)', flexShrink: 0 }} />
                    <span style={{ fontSize: 11, fontWeight: 500, color: '#fff', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {cat.label}
                    </span>
                    <span style={{ fontSize: 10, padding: '1px 6px', borderRadius: 10, background: 'rgba(255,255,255,0.2)', color: '#fff', fontWeight: 500, flexShrink: 0 }}>
                      {catDocs.length}
                    </span>
                  </button>
                  {!isCollapsed && catDocs.map(d => (
                    // Real thumbnail via ThumbnailItem — works for PDF, TIF, DOC, XLS
                    // page=1 because mode:single each doc = 1 page
                    <ThumbnailItem
                      key={d.id}
                      page={1}
                      adapter={adapter}
                      categoryLabel={cat.label}
                      color={cat.color}
                      onClick={() => onSelectDoc(d.id, 1)}
                      registerThumb={registerThumb}
                      unregisterThumb={unregisterThumb}
                      scrollRoot={scrollRootRef as React.RefObject<Element | null>}
                    />
                  ))}
                </div>
              );
            })}
          </div>
        )}

        {/* ── MULTI thumbnail tab: one outer scroll, category accordions inside ── */}
        {mode === 'multi' && tab === 'thumb' && (
          displayDocId ? (
            <div
              ref={el => { scrollRootRef.current = el; }}
              style={{ flex: 1, overflowY: 'auto', background: '#f2f4f6' }}
            >
              {categories.map(cat => {
                const pages = pagesByCat[cat.id];
                if (!pages?.length) return null;
                const isCollapsed = collapsedCats.has(`multi:${cat.id}`);
                const catByPage = new Map<number, { label: string; color?: string } | null>(
                  pages.map(pg => [pg, { label: cat.label, color: cat.color }])
                );
                return (
                  <div key={cat.id}>
                    {/* Sticky category header */}
                    <button
                      onClick={() => toggleCat(`multi:${cat.id}`)}
                      style={{
                        width: '100%', display: 'flex', alignItems: 'center', gap: 6,
                        padding: '7px 10px 6px 8px', cursor: 'pointer', userSelect: 'none',
                        background: cat.color, border: 'none',
                        borderLeft: `4px solid ${cat.color}`,
                        borderBottom: '0.5px solid rgba(0,0,0,.15)', textAlign: 'left',
                        position: 'sticky', top: 0, zIndex: 10,
                      }}
                    >
                      <span style={{
                        fontSize: 9, color: '#fff', opacity: 0.85, display: 'inline-block',
                        transform: isCollapsed ? 'rotate(0deg)' : 'rotate(90deg)',
                        transition: 'transform 0.15s', flexShrink: 0,
                      }}>▶</span>
                      <span style={{ width: 7, height: 7, borderRadius: '50%', background: 'rgba(255,255,255,0.6)', flexShrink: 0 }} />
                      <span style={{ fontSize: 11, fontWeight: 500, color: '#fff', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {cat.label}
                      </span>
                      <span style={{ fontSize: 10, padding: '1px 6px', borderRadius: 10, background: 'rgba(255,255,255,0.2)', color: '#fff', fontWeight: 500, flexShrink: 0 }}>
                        {pages.length} pg
                      </span>
                    </button>
                    {/* Virtual list shares the outer scroll container — one scrollbar for all categories */}
                    {!isCollapsed && (
                      <VirtualThumbList
                        pages={pages}
                        adapter={adapter}
                        categoryByPage={catByPage}
                        registerThumb={registerThumb}
                        unregisterThumb={unregisterThumb}
                        onPageClick={pg => onSelectPage(pg)}
                        hasBadge={true}
                        sharedScrollRoot={scrollRootRef as React.RefObject<Element | null>}
                      />
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            <div style={{ padding: '16px 10px', fontSize: 10, color: '#4a6070', textAlign: 'center' }}>
              Select a document to view pages
            </div>
          )
        )}

        {/* ── MULTI outline tab ── */}
        {mode === 'multi' && tab === 'outline' && (
          <MultiDocOutline
            state={state}
            onSelectDoc={onSelectDoc}
            onSelectPage={onSelectPage}
          />
        )}
      </div>
    </div>
  );
}
