import { Injectable, signal, computed } from '@angular/core';

export interface PageCategory {
  pages: number[];
  label: string;
  color?: string;
}

export type PaletteKey = 'blue' | 'teal' | 'amber' | 'gray' | 'purple' | 'coral' | 'green' | 'red';

export const PALETTE: Record<PaletteKey, { bg: string; text: string; divBg: string; divText: string }> = {
  blue:   { bg:'#185FA5', text:'#E6F1FB', divBg:'#E6F1FB', divText:'#185FA5' },
  teal:   { bg:'#0F6E56', text:'#E1F5EE', divBg:'#E1F5EE', divText:'#0F6E56' },
  amber:  { bg:'#854F0B', text:'#FAEEDA', divBg:'#FAEEDA', divText:'#854F0B' },
  gray:   { bg:'#5F5E5A', text:'#F1EFE8', divBg:'#F1EFE8', divText:'#5F5E5A' },
  purple: { bg:'#3C3489', text:'#EEEDFE', divBg:'#EEEDFE', divText:'#3C3489' },
  coral:  { bg:'#993C1D', text:'#FAECE7', divBg:'#FAECE7', divText:'#993C1D' },
  green:  { bg:'#3B6D11', text:'#EAF3DE', divBg:'#EAF3DE', divText:'#3B6D11' },
  red:    { bg:'#A32D2D', text:'#FCEBEB', divBg:'#FCEBEB', divText:'#A32D2D' },
};

const AUTO_ORDER: PaletteKey[] = ['blue', 'teal', 'amber', 'gray', 'purple', 'coral', 'green', 'red'];

@Injectable({ providedIn: 'root' })
export class ThumbnailCategoryService {

  // ── State signals (read by Angular component template) ────────────────────
  readonly categories = signal<Array<PageCategory & { resolvedColor: PaletteKey }>>([]);
  readonly activeFilter = signal<string | null>(null);
  readonly otherCount = signal<number>(0);

  readonly pageMap = computed(() => {
    const map = new Map<number, PageCategory & { resolvedColor: PaletteKey }>();
    for (const cat of this.categories()) {
      for (const pg of cat.pages) map.set(pg, cat);
    }
    return map;
  });

  get totalPages(): number {
    return this.categories().reduce((s, c) => s + c.pages.length, 0);
  }

  load(categories: PageCategory[]): void {
    const resolved = categories.map((cat, i) => {
      const c = (cat.color ?? '').toLowerCase().trim() as PaletteKey;
      const key: PaletteKey = (c && PALETTE[c]) ? c : AUTO_ORDER[i % AUTO_ORDER.length];
      return { ...cat, resolvedColor: key };
    });
    this.categories.set(resolved);
    this.activeFilter.set(null);
    this.otherCount.set(0);
    console.log('[CATEGORY] Loaded', resolved.length, 'categories:',
      resolved.map(c => c.label + '(' + c.resolvedColor + ')').join(', '));
  }

  clear(): void {
    this.categories.set([]);
    this.activeFilter.set(null);
    this.otherCount.set(0);
  }

  setFilter(label: string | null): void {
    this.activeFilter.set(label);
    this._applyFilter(label);
  }

  getPalette(key: PaletteKey) { return PALETTE[key]; }

  // ── Badge stamping (called from thumbnailDrawn event) ─────────────────────

  stampThumbnail(pageNum: number, thumbEl: HTMLElement): void {
    if (!this.categories().length) return;
    const cat   = this.pageMap().get(pageNum);
    const label = cat?.label ?? 'Other';
    const pal   = PALETTE[cat?.resolvedColor ?? 'gray'];
    this._applyBadge(thumbEl, label, pal);
    // Track Other count
    if (!cat) this.otherCount.update(n => n + 1);
    // Apply current filter immediately
    const f = this.activeFilter();
    thumbEl.style.display = (!f || label === f) ? '' : 'none';
  }

  stampAllThumbnails(): void {
    if (!this.categories().length) return;
    const thumbView = document.querySelector('#thumbnailView');
    if (!thumbView) return;

    const thumbs = Array.from(
      thumbView.querySelectorAll<HTMLElement>('.thumbnail[data-page-number]')
    );
    console.log('[TOV] stampAllThumbnails:', thumbs.length, 'thumbs');
    if (!thumbs.length) return;

    const map = this.pageMap();
    let otherFound = 0;
    for (const thumb of thumbs) {
      const pageNum = parseInt(thumb.getAttribute('data-page-number') ?? '0', 10);
      const cat     = map.get(pageNum);
      const label   = cat?.label ?? 'Other';
      const pal     = cat ? PALETTE[cat.resolvedColor] : PALETTE['gray'];
      this._applyBadge(thumb, label, pal);
      if (!cat) otherFound++;
    }
    if (otherFound) this.otherCount.set(otherFound);
    this._applyFilter(this.activeFilter());
  }

  private _applyBadge(
    thumb: HTMLElement,
    label: string,
    pal: { bg: string; text: string; divBg: string; divText: string },
  ): void {
    if (thumb.querySelector('.tov-badge')) return;
    thumb.style.position = 'relative';
    thumb.style.overflow  = 'hidden';
    // Left border for visual grouping
    thumb.style.borderLeft = '4px solid ' + pal.bg;
    thumb.style.boxSizing  = 'border-box';
    // Footer badge
    const badge = document.createElement('div');
    badge.className = 'tov-badge';
    badge.dataset['tovBadge'] = label;
    badge.textContent = label;
    badge.style.cssText =
      'background:' + pal.bg + ';color:' + pal.text + ';' +
      'position:absolute;bottom:0;left:0;right:0;' +
      'font-size:9px;font-weight:700;text-align:center;padding:2px 4px;' +
      'pointer-events:none;z-index:10;letter-spacing:.2px;' +
      'white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-family:sans-serif;';
    thumb.appendChild(badge);
  }

  private _applyFilter(label: string | null): void {
    document.querySelectorAll<HTMLElement>('#thumbnailView .thumbnail[data-page-number]').forEach(t => {
      const cat = t.querySelector<HTMLElement>('.tov-badge')?.dataset['tovBadge'] ?? null;
      t.style.display = (!label || cat === label) ? '' : 'none';
    });
  }
}