import {
  Component,
  OnInit,
  ViewChild,
  signal,
  ChangeDetectionStrategy,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { PdfViewerComponent, CapturedWordPayload } from './components/pdf-viewer/pdf-viewer.component';
import { ThumbnailOverlayComponent } from './components/thumbnail-overlay/thumbnail-overlay.component';
import { ThumbnailCategoryService, PageCategory } from './services/thumbnail-category.service';
import { FieldsPanelComponent } from './components/fields-panel/fields-panel.component';
import { PdfCaptureService } from './services/pdf-capture.service';
import { HttpClient } from '@angular/common/http';
import { CapturedFieldJson, CapturedFieldFormat } from './models/pdf-capture.models';
import { CaptureItem } from './services/pdf-capture.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, PdfViewerComponent, FieldsPanelComponent, ThumbnailOverlayComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="app-shell">
      <!-- Top Bar -->
      <header class="topbar">
        <div class="brand">
          <span class="brand-icon">◈</span>
          <span class="brand-name">PDF<span class="accent">Capture</span></span>
        </div>

        <div class="topbar-actions">

          <button class="btn-action" (click)="clearAllFields()">
            <span>⊘</span> Clear All
          </button>
          <button class="btn-action btn-export" (click)="downloadCapturedFields()" title="Download all captured fields as JSON">
            <span>↓</span> Export JSON
          </button>
        </div>
      </header>

      <!-- Main Split Layout -->
      <div class="main-layout">
        <!-- LEFT: PDF Viewer -->
        <div class="pane pane-pdf" [style.width]="leftWidth + '%'">
          <app-pdf-viewer
            #pdfViewer
            [src]="pdfSrc()"
            [captureOnLoad]="true"
            (wordCaptured)="onWordCaptured($event)"
            (pdfNameChange)="onPdfNameChange($event)"
            (boxCaptured)="onBoxCaptured($event)"
            (thumbnailDrawn)="onThumbnailDrawn($event)"
          ></app-pdf-viewer>
        </div>

        <!-- Resize Handle -->
        <div
          class="resize-handle"
          (mousedown)="startResize($event)"
          title="Drag to resize"
        >
          <div class="handle-line"></div>
        </div>

        <!-- RIGHT: Fields Panel -->
        <div class="pane pane-fields">
          <app-fields-panel
            (goToWord)="onGoToWord($event)"
            (captureConfirmed)="onConfirmCapture()"
          ></app-fields-panel>
        </div>
      </div>
      <!-- Thumbnail overlay: renders nothing here, injects into sidebar DOM -->
      <app-thumbnail-overlay></app-thumbnail-overlay>
    </div>
  `,
  styles: [`
    @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;600;700&display=swap');

    :host {
      display: block;
      height: 100vh;
      overflow: hidden;
    }

    .app-shell {
      display: flex;
      flex-direction: column;
      height: 100vh;
      background: #080f1a;
      font-family: 'DM Sans', sans-serif;
    }

    /* ── Top Bar ── */
    .topbar {
      height: 52px;
      flex-shrink: 0;
      background: #0d1b2a;
      border-bottom: 1px solid rgba(255,255,255,0.07);
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 20px;
      z-index: 100;
    }

    .brand {
      display: flex;
      align-items: center;
      gap: 10px;

      .brand-icon {
        font-size: 22px;
        color: #00d4aa;
        line-height: 1;
      }

      .brand-name {
        font-size: 17px;
        font-weight: 700;
        color: #f1f5f9;
        letter-spacing: -0.5px;

        .accent {
          color: #00d4aa;
        }
      }
    }

    .topbar-actions {
      display: flex;
      gap: 8px;
      align-items: center;

      .coords-status {
        font-size: 11px;
        color: #f87171;
        max-width: 280px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        &.ok { color: #4ade80; }
      }
    }

    .btn-action {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 6px 14px;
      background: rgba(255,255,255,0.04);
      border: 1.5px solid #1e293b;
      border-radius: 6px;
      color: #94a3b8;
      font-family: inherit;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.15s;
      letter-spacing: 0.2px;

      &:hover {
        border-color: #00d4aa;
        color: #00d4aa;
        background: rgba(0,212,170,0.06);
      }

    }

    .btn-export {
      background: rgba(16,185,129,0.08);
      border-color: rgba(16,185,129,0.35);
      color: #10b981;
      &:hover { background: rgba(16,185,129,0.20); border-color: #10b981; color: #10b981; }
    }

    /* ── Main Layout ── */
    .main-layout {
      flex: 1;
      display: flex;
      overflow: hidden;
      min-height: 0;
    }

    .pane {
      height: 100%;
      overflow: hidden;
      min-width: 0;
    }

    .pane-pdf {
      flex-shrink: 0;
    }

    .pane-fields {
      flex: 1;
      min-width: 320px;
      max-width: 500px;
    }

    /* ── Resize Handle ── */
    .resize-handle {
      width: 6px;
      cursor: col-resize;
      background: #0d1b2a;
      border-left: 1px solid rgba(255,255,255,0.06);
      border-right: 1px solid rgba(255,255,255,0.06);
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background 0.15s;
      flex-shrink: 0;

      &:hover {
        background: rgba(0,212,170,0.1);
        .handle-line { background: #00d4aa; }
      }

      .handle-line {
        width: 2px;
        height: 40px;
        background: #1e293b;
        border-radius: 2px;
        transition: background 0.15s;
      }
    }
  `],
})
export class AppComponent implements OnInit {
  @ViewChild('pdfViewer') pdfViewer!: PdfViewerComponent;

  pdfSrc = signal<string | Uint8Array>('');
  currentPdfName = signal<string>('');

  leftWidth = 65;

  private isResizing = false;
  private resizeStartX = 0;
  private resizeStartWidth = 0;

  // Demo PDF - replace with actual src
  private readonly DEMO_PDF = 'assets/sample.pdf';

  constructor(
    public captureService: PdfCaptureService,
    private http: HttpClient,
    public thumbnailCatSvc: ThumbnailCategoryService,
  ) {}

  ngOnInit() {
    // Load default PDF and set its base name for coord matching
    this.pdfSrc.set(this.DEMO_PDF);
    const defaultName = this.DEMO_PDF.replace(/^assets\//, '').replace(/\.pdf$/i, '');
    this.currentPdfName.set(defaultName);
    // Silently load word index for the default PDF (500ms delay — viewer not ready yet)
    setTimeout(() => this.loadWordIndexSilently(defaultName), 500);
  }



  onWordCaptured(word: CapturedWordPayload) {
    this.captureService.storeRawCapture(word);
  }

  onBoxCaptured(payload: CapturedWordPayload) {
    this.captureService.storeRawCapture(payload);
  }

  /**
   * Called when user clicks "✓ Confirm" on the field card.
   * THIS is the moment the green highlight appears and the JSON is updated.
   */
  onConfirmCapture() {
    // Triggered on add / replace / delete from Submit JSON or ✕ button.
    // rAF ensures Angular signal updates (activeFieldId, fields) settle
    // before canvas redraws — correct green/grey highlight state immediately.
    requestAnimationFrame(() => this.pdfViewer?.scheduleRedraw());
  }

  onThumbnailDrawn(event: { pageNumber: number; thumbnail: HTMLElement }): void {
    // Primary path: event from ngx thumbnailDrawn — stamp individual thumbnail
    this.thumbnailCatSvc.stampThumbnail(event.pageNumber, event.thumbnail);
  }

  /** Called after all pages initialised — schedule fallback stamp runs */
  private scheduleThumbnailStamps(): void {
    // Stamp thumbnails after short delays — only if sidebar opens and categories loaded.
    // Two attempts: one early (sidebar may be opened later), one late (large docs).
    // stampAllThumbnails() is idempotent and exits immediately if no categories.
    setTimeout(() => this.thumbnailCatSvc.stampAllThumbnails(), 1000);
    setTimeout(() => this.thumbnailCatSvc.stampAllThumbnails(), 4000);
  }

  onFieldFocused(_fieldId: string) { /* no-op — fields panel removed */ }

  onGoToWord(item: CaptureItem) {
    this.captureService.setActiveField(item.id);
    this.pdfViewer?.navigateToPage(item.page);
  }

  clearAllFields() {
    this.captureService.fields().slice().forEach(f => this.captureService.deleteCapture(f.id));
    this.pdfViewer?.loadWordIndex(null);
    this.pdfViewer?.scheduleRedraw();
  }



  /** Called when the viewer's native open button loads a new PDF */
  onSrcChange(event: string | Uint8Array): void {
    this.pdfViewer?.loadWordIndex(null);
  }

  /**
   * Load a PDF from a URL as binary and set it into the viewer.
   * Use this when you need to load a PDF that requires auth headers,
   * or when you have a URL that returns raw PDF bytes.
   *
   * Usage: this.loadPdfBinary('https://api.example.com/docs/123')
   *        this.loadPdfBinary('/api/report', 'report.pdf')
   */
  loadPdfBinary(url: string, filename?: string): void {
    // No generic parameter — TypeScript infers ArrayBuffer from responseType overload
    this.http.get(url, { responseType: 'arraybuffer' as const }).subscribe({
      next: (buffer: ArrayBuffer) => {
        this.pdfSrc.set(new Uint8Array(buffer));
        // If caller provides filename, trigger word index + coord lookup
        if (filename) {
          this.onPdfNameChange(filename);
        }
      },
      error: (err) => {
        console.error('Failed to load PDF binary:', err);
      }
    });
  }

  /** Called from the viewer when a file is opened via native toolbar */
  onPdfNameChange(name: string): void {
    // Wire real page dimension getter into service so submit normalisation
    // uses actual PDF.js page sizes instead of the standard size fallback list.
    this.captureService._getPageDimsFn =
      (page: number) => this.pdfViewer?.getPageDimensionsPt(page) ?? null;

    const base = name.split('/').pop()?.split('\\').pop() ?? name;
    const baseName = base.replace(/\.pdf$/i, '');

    // Only reset everything if this is actually a NEW PDF (name changed)
    const isNewPdf = baseName !== this.currentPdfName();
    this.currentPdfName.set(baseName);

    if (isNewPdf) {
      this._loadingForPdf = '';

      this.pdfViewer?.loadWordIndex(null);
      // Load category JSON for thumbnail sidebar — only when PDF changes
      this.loadCategoryJsonSilently(baseName);
      // Schedule fallback stamp runs after thumbnails have had time to render
      this.scheduleThumbnailStamps();
    }

    // Always try to load word index (handles both new PDF and retry on same PDF).
    this.loadWordIndexSilently(baseName);

    // Try to load pre-captured fields JSON (e.g. assets/invoice_captured_fields.json).
    // If found: fields get pre-populated with values + grey highlights immediately.
    if (isNewPdf) this.loadCapturedFieldsSilently(baseName);
  }

  /**
   * Silently load assets/{baseName}_word_index.json and pass it to the viewer.
   *
   * The word index replaces PDF.js text layer spans with custom JSON-positioned
   * spans for precise click2pick / box-select on every word.
   *
   * Accepted file formats (auto-detected, all normalised to 0-1 fractions):
   *
   * FORMAT 1 — pdfplumber native (already fractional):
   *   { "version":1, "pages": { "1": [{t,x,y,w,h}, ...] } }
   *   Values are 0-1 fractions → passed to loadWordIndex() as-is.
   *
   * FORMAT 2 — flat entry array with any coord style:
   *   [ { "text":"Word", "page":1, "x":0.17, "y":0.12, "width":0.04, "height":0.015 } ]
   *   [ { "text":"Word", "page":1, "bbox":[0.17,0.12,0.04,0.015] } ]
   *   [ { "text":"Word", "page":1, "rectangle":[72,140,144,155], "pageWidth":595, "pageHeight":842 } ]
   *   Flat arrays are normalised then re-packed into the pdfplumber page-map format.
   *
   * Silent: no user-visible status — logs to console only.
   */
  private _loadingForPdf = '';
  private loadWordIndexSilently(baseName: string): void {
    if (!baseName) return;
    if (this._loadingForPdf === baseName) return;
    this._loadingForPdf = baseName;

    const url = `assets/${baseName}_word_index.json`;
    this.http.get<any>(url).subscribe({
      next: (data) => {
        this._loadingForPdf = '';
        const wi = this._normaliseWordIndex(data, baseName);
        this.pdfViewer?.loadWordIndex(wi);
        console.log('[WORD-INDEX] Loaded', url);
      },
      error: () => {
        this._loadingForPdf = '';
        this.pdfViewer?.loadWordIndex(null);
        console.log('[WORD-INDEX] Not found:', url, '(PDF.js text layer used instead)');
      },
    });
  }

  /**
   * Normalise any word-index format into the pdfplumber page-map structure:
   *   { version:1, pages:{ "1":[{t,x,y,w,h},...], "2":[...] } }
   *
   * Supports all three coord formats (values may be fractions 0-1 or absolute pts):
   *   flat:        { text|t, page, x, y, width|w, height|h }
   *   bbox:        { text|t, page, bbox:[x,y,w,h] }
   *   rectangle:   { text|t, page, rectangle:[x,y,w,h] }  (may be [x1,y1,x2,y2] or [x,y,w,h])
   *   coordinates: { text|t, page, coordinates:[ymin,xmin,ymax,xmax] }
   *
   * Absolute coords (values > 1) are auto-normalised using:
   *   1. Per-item pageWidth/pageHeight if present
   *   2. Smallest standard PDF page size that fits all content on that page
   *   3. PDF.js real page dimensions via getPageDimensionsPt()
   */
  private _normaliseWordIndex(
    data: any,
    baseName: string,
  ): { version: number; pages: Record<string, Array<{t:string;x:number;y:number;w:number;h:number}>> } {

    // ── Already in pdfplumber format? Pass through with fractional check ─────
    if (data && typeof data === 'object' && !Array.isArray(data) && data.pages) {
      return data as any;
    }

    // ── Flat array format — normalise each entry ──────────────────────────────
    if (!Array.isArray(data) || !data.length) {
      return { version: 1, pages: {} };
    }

    // Standard PDF page sizes in points for absolute coord inference
    const STD = [
      { w: 595.276, h: 841.890 }, { w: 841.890, h: 595.276 },
      { w: 612,     h: 792     }, { w: 792,     h: 612     },
      { w: 612,     h: 1008    }, { w: 1008,    h: 612     },
      { w: 841.890, h:1190.551 }, { w:1190.551, h: 841.890 },
      { w: 792,     h: 1224    }, { w: 1224,    h: 792     },
    ];

    // ── Pass 1: compute per-page max content extent (for abs coord inference) ─
    const pageDims = new Map<number, { w: number; h: number }>();
    for (const item of data) {
      const pg  = Number(item.page ?? 1);
      const ipw = Number(item.pageWidth ?? item.pagewidth ?? 0);
      const iph = Number(item.pageHeight ?? item.pageheight ?? 0);
      if (ipw > 1 && iph > 1) { pageDims.set(pg, { w: ipw, h: iph }); continue; }
      const [rx, ry, rw, rh] = this._extractRawCoords(item);
      const x2 = rx + rw, y2 = ry + rh;
      const cur = pageDims.get(pg);
      pageDims.set(pg, { w: Math.max(cur?.w ?? 0, x2), h: Math.max(cur?.h ?? 0, y2) });
    }

    // ── Infer standard page size from max extent per page ─────────────────────
    const inferSize = (maxX2: number, maxY2: number): { w: number; h: number } => {
      if (maxX2 <= 1 && maxY2 <= 1) return { w: 1, h: 1 }; // already fractional
      const fitting = STD.filter(s => maxX2 <= s.w && maxY2 <= s.h);
      if (!fitting.length) return { w: maxX2, h: maxY2 };
      const a4 = fitting.find(s => Math.abs(s.w - 595.276) < 1);
      return a4 ?? fitting.reduce((b, s) => s.w * s.h < b.w * b.h ? s : b);
    };

    const pageSizes = new Map<number, { w: number; h: number }>();
    pageDims.forEach((dims, pg) => pageSizes.set(pg, inferSize(dims.w, dims.h)));

    // ── Pass 2: normalise every entry to {t,x,y,w,h} fractions ───────────────
    const pages: Record<string, Array<{t:string;x:number;y:number;w:number;h:number}>> = {};

    for (const item of data) {
      const pg    = Number(item.page ?? 1);
      const text  = String(item.text ?? item.t ?? item.label ?? '');
      if (!text) continue;

      let [rx, ry, rw, rh] = this._extractRawCoords(item);

      // Normalise absolute coords using per-page inferred size
      if (rx > 1 || ry > 1 || rw > 1 || rh > 1) {
        const size = pageSizes.get(pg) ?? { w: 595.276, h: 841.890 };
        const real = this.pdfViewer?.getPageDimensionsPt(pg);
        const pw   = real?.widthPt  ?? size.w;
        const ph   = real?.heightPt ?? size.h;
        rx /= pw; ry /= ph; rw /= pw; rh /= ph;
      }

      const key = String(pg);
      if (!pages[key]) pages[key] = [];
      pages[key].push({
        t: text,
        x: Math.min(1, Math.max(0, rx)),
        y: Math.min(1, Math.max(0, ry)),
        w: Math.min(1, Math.max(0, rw)),
        h: Math.min(1, Math.max(0, rh)),
      });
    }

    // Log summary for large datasets
    const pageCount = Object.keys(pages).length;
    const wordCount = Object.values(pages).reduce((s, arr) => s + arr.length, 0);
    console.log('[WORD-INDEX] Normalised', wordCount, 'words across', pageCount, 'pages');

    return { version: 1, pages };
  }

  /**
   * Extract raw [x,y,w,h] from any supported coord format.
   * Always returns [x, y, width, height] in the same units as the input
   * (caller is responsible for normalising absolute→fractional afterwards).
   *
   * Supported formats:
   *   flat:        { x, y, width|w, height|h }
   *   bbox:        { bbox: [x, y, w, h] }
   *   rectangle:   { rectangle: [x, y, w, h] }  — or [x1,y1,x2,y2] auto-detected
   *   coordinates: { coordinates: [ymin, xmin, ymax, xmax] }  ← TF Object Detection style
   */
  private _extractRawCoords(item: any): [number, number, number, number] {
    // ── coordinates: [ymin, xmin, ymax, xmax] (TF/COCO/Vision API style) ──────
    if (Array.isArray(item.coordinates) && item.coordinates.length === 4) {
      const [ymin, xmin, ymax, xmax] = item.coordinates.map(Number);
      return [xmin, ymin, xmax - xmin, ymax - ymin];
    }
    // ── rectangle: [x,y,w,h] OR [x1,y1,x2,y2] ────────────────────────────────
    if (Array.isArray(item.rectangle) && item.rectangle.length === 4) {
      const [a, b, c, d] = item.rectangle.map(Number);
      // [x1,y1,x2,y2] detected when c>a, d>b, and at least one value > 1
      if ((a > 1 || b > 1 || c > 1 || d > 1) && c > a && d > b) {
        return [a, b, c - a, d - b];
      }
      return [a, b, c, d];
    }
    // ── bbox: [x,y,w,h] ───────────────────────────────────────────────────────
    if (Array.isArray(item.bbox) && item.bbox.length === 4) {
      const [a, b, c, d] = item.bbox.map(Number);
      return [a, b, c, d];
    }
    // ── flat: x, y, width/w, height/h ─────────────────────────────────────────
    return [
      Number(item.x      ?? 0),
      Number(item.y      ?? 0),
      Number(item.width  ?? item.w ?? 0),
      Number(item.height ?? item.h ?? 0),
    ];
  }

  // ── Captured Fields JSON ──────────────────────────────────────────────────

  /**
   * Try to load assets/{baseName}_captured_fields.json.
   * Accepts flat / bbox / rectangle coord formats, fractional or absolute pts.
   * Uses a single O(n) pass to pre-compute per-page dimensions before normalising
   * — safe for 400+ fields with no O(n²) cost.
   */
  private loadCapturedFieldsSilently(baseName: string): void {
    const url = `assets/${baseName}_captured_fields.json`;
    this.http.get<CapturedFieldJson[]>(url).subscribe({
      next: (data) => {
        if (!Array.isArray(data) || !data.length) return;
        const filtered = data.filter(f => f.value && (f.id || f.label));
        if (!filtered.length) return;

        // ── O(n) pre-pass: compute per-page max extent for absolute coord inference ──
        // This avoids the O(n²) allFields.filter() inside the per-field loop.
        const STD: [number, number][] = [
          [595.276, 841.890], [841.890, 595.276],
          [612, 792],         [792, 612],
          [612, 1008],        [1008, 612],
          [841.890, 1190.55], [1190.55, 841.890],
          [792, 1224],        [1224, 792],
        ];
        const pageMaxExtent = new Map<number, { x2: number; y2: number }>();
        for (const f of filtered) {
          const pg = Number(f.page ?? 1);
          // Use _extractRawCoords to handle all formats uniformly
          const [rx, ry, rw, rh] = this._extractRawCoords(f as any);
          const cur = pageMaxExtent.get(pg);
          pageMaxExtent.set(pg, {
            x2: Math.max(cur?.x2 ?? 0, rx + rw),
            y2: Math.max(cur?.y2 ?? 0, ry + rh),
          });
        }

        // ── Infer per-page standard size once ────────────────────────────────────
        const pageSizeCache = new Map<number, [number, number]>();
        pageMaxExtent.forEach(({ x2, y2 }, pg) => {
          // Try PDF.js real dims first (most accurate)
          const real = this.pdfViewer?.getPageDimensionsPt(pg);
          if (real) { pageSizeCache.set(pg, [real.widthPt, real.heightPt]); return; }
          // Standard size inference
          const fitting = STD.filter(([w, h]) => x2 <= w && y2 <= h);
          const a4 = fitting.find(([w]) => Math.abs(w - 595.276) < 1);
          const best = a4 ?? (fitting.length
            ? fitting.reduce((b, s) => s[0] * s[1] < b[0] * b[1] ? s : b)
            : [x2 || 612, y2 || 792] as [number, number]);
          pageSizeCache.set(pg, best);
        });

        // ── Normalise each field using pre-computed page size — O(n) total ────────
        const normalised = filtered.map(f => this.normaliseCapturedField(f, pageSizeCache));
        if (normalised.length) {
          this.captureService.loadCapturedFieldsFromJson(normalised);
          console.log('[CAPTURED-FIELDS] Loaded', normalised.length, 'fields');
          // Defer redraw to idle time — avoids blocking initial PDF render
          // for large captured_fields sets (400+ items).
          if ('requestIdleCallback' in window) {
            (window as any).requestIdleCallback(() => this.pdfViewer?.scheduleRedraw(), { timeout: 500 });
          } else {
            setTimeout(() => this.pdfViewer?.scheduleRedraw(), 100);
          }
        }
      },
      error: () => { /* no captured_fields.json — silent */ },
    });
  }

  /**
   * Normalise a single captured-field entry using a pre-computed pageSizeCache.
   * Accepts flat / bbox / rectangle formats, fractional or absolute pts.
   * pageSizeCache is built once for all fields (O(n) total, not O(n²)).
   */
  private normaliseCapturedField(
    f: CapturedFieldJson,
    pageSizeCache: Map<number, [number, number]>
  ): { id: string; label: string; value: string; page: number;
       x: number; y: number; width: number; height: number;
       sourceFormat: CapturedFieldFormat; color?: string } {
    const id    = f.id    || f.label || '';
    const label = f.label || f.id    || '';
    const value = f.value || '';
    const page  = Number(f.page ?? 1);

    // Detect sourceFormat for round-trip export, then extract raw coords via shared helper
    let sourceFormat: CapturedFieldFormat;
    const fa = f as any;
    if (Array.isArray(fa.coordinates) && fa.coordinates.length === 4) {
      sourceFormat = 'coordinates' as any;
    } else if (Array.isArray(f.rectangle) && f.rectangle.length === 4) {
      sourceFormat = 'rectangle';
    } else if (Array.isArray(f.bbox) && f.bbox.length === 4) {
      sourceFormat = 'bbox';
    } else {
      sourceFormat = 'flat';
    }

    // _extractRawCoords handles all formats: flat, bbox, rectangle, coordinates
    let [rx, ry, rw, rh] = this._extractRawCoords(fa);

    // Normalise absolute coords — same priority chain as word_index normalisation:
    //   1. Per-item pageWidth/pageHeight
    //   2. Pre-computed pageSizeCache (O(1) lookup, built once for all fields)
    //   3. PDF.js real page dims (queried lazily and stored in cache)
    if (rx > 1 || ry > 1 || rw > 1 || rh > 1) {
      let pw = Number(fa.pageWidth ?? fa.pagewidth ?? 0);
      let ph = Number(fa.pageHeight ?? fa.pageheight ?? 0);
      if (pw <= 1 || ph <= 1) {
        const real = this.pdfViewer?.getPageDimensionsPt(page);
        if (real) {
          pw = real.widthPt; ph = real.heightPt;
        } else {
          const cached = pageSizeCache.get(page);
          [pw, ph] = cached ?? [595.276, 841.890];
        }
      }
      rx /= pw; ry /= ph; rw /= pw; rh /= ph;
    }

    // Resolve color (from JSON field, any CSS format)
    const rawColor = String((f as any).color ?? '').trim();
    const color = rawColor
      ? (/^[0-9a-fA-F]{3}$|^[0-9a-fA-F]{6}$/.test(rawColor)
          ? '#' + rawColor
          : rawColor.toLowerCase())
      : undefined;

    return {
      id, label, value, page, sourceFormat, color,
      x:      Math.min(1, Math.max(0, rx)),
      y:      Math.min(1, Math.max(0, ry)),
      width:  Math.min(1, Math.max(0, rw)),
      height: Math.min(1, Math.max(0, rh)),
    };
  }

  /**
   * Load assets/{baseName}_categories.json for thumbnail sidebar labels.
   * File format:
   * {
   *   "categories": [
   *     { "pages": [1,2,3], "label": "Invoice",   "color": "blue"  },
   *     { "pages": [4,5],   "label": "Form 15CA", "color": "teal"  },
   *     { "pages": [6],     "label": "Form 15CB"                    }
   *   ]
   * }
   * color is optional — auto-assigned from palette if absent.
   */
  private loadCategoryJsonSilently(baseName: string): void {
    const url = `assets/${baseName}_categories.json`;
    this.http.get<PageCategory[]>(url).subscribe({
      next: (data) => {
        if (!Array.isArray(data) || !data.length) return;
        this.thumbnailCatSvc.load(data);
        console.log('[CATEGORY] Loaded', data.length, 'categories from', url);
      },
      error: () => {
        // No categories file — clear any previous categories silently
        this.thumbnailCatSvc.clear();
      },
    });
  }

  /**
   * Download all current captured fields as JSON.
   * Each field is exported in its ORIGINAL input format:
   *   'rectangle' → { label, value, page, rectangle:[x,y,w,h] }
   *   'bbox'      → { label, value, page, bbox:[x,y,w,h] }
   *   'flat'      → { label, value, page, x, y, width, height }  (default for new captures)
   */
  downloadCapturedFields(): void {
    const data = this.captureService.getCapturedFieldsJson();
    if (!data.length) { alert('No fields captured yet.'); return; }

    const r6 = (n: number) => parseFloat(n.toFixed(6));

    const output = data.map(f => {
      const fmt = f.sourceFormat || 'flat';
      const coords: [number,number,number,number] = [r6(f.x), r6(f.y), r6(f.width), r6(f.height)];

      if (fmt === 'rectangle') {
        return { id: f.id, label: f.label, value: f.value, page: f.page, rectangle: coords };
      }
      if (fmt === 'bbox') {
        return { id: f.id, label: f.label, value: f.value, page: f.page, bbox: coords };
      }
      if (fmt === 'coordinates') {
        // Re-export as [ymin, xmin, ymax, xmax]
        const [x, y, w, h] = [coords[0], coords[1], coords[2], coords[3]];
        return { id: f.id, label: f.label, value: f.value, page: f.page,
                 coordinates: [r6(y), r6(x), r6(y + h), r6(x + w)] };
      }
      // Default: flat format (for new captures or original flat input)
      return {
        id:     f.id,
        label:  f.label,
        value:  f.value,
        page:   f.page,
        x:      coords[0],
        y:      coords[1],
        width:  coords[2],
        height: coords[3],
      };
    });

    const blob = new Blob([JSON.stringify(output, null, 2)], { type: 'application/json' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    const name = this.currentPdfName() || 'document';
    a.href     = url;
    a.download = `${name}_captured_fields.json`;
    a.click();
    URL.revokeObjectURL(url);
  }




  // ── Resize Panel ─────────────────────────────────────────────────────────
  startResize(event: MouseEvent) {
    this.isResizing = true;
    this.resizeStartX = event.clientX;
    this.resizeStartWidth = this.leftWidth;

    const onMove = (e: MouseEvent) => {
      if (!this.isResizing) return;
      const delta = e.clientX - this.resizeStartX;
      const totalW = window.innerWidth;
      const newW = this.resizeStartWidth + (delta / totalW) * 100;
      this.leftWidth = Math.max(35, Math.min(75, newW));
    };

    const onUp = () => {
      this.isResizing = false;
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
    };

    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
    event.preventDefault();
  }
}