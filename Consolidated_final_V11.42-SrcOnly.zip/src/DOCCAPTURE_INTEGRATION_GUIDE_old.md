# DocCapture Viewer — Complete Integration Guide

---

## Table of Contents

1. [Setup & Embedding](#1-setup--embedding)
2. [Handshake — READY flow](#2-handshake--ready-flow)
3. [Loading Documents](#3-loading-documents)
   - 3.1 LOAD_SINGLEDOC
   - 3.2 LOAD_MANIFEST — MultiDoc:SinglePage
   - 3.3 LOAD_MANIFEST — MultiDoc:MultiPage
4. [Categories](#4-categories)
5. [Captures (Highlight Boxes)](#5-captures-highlight-boxes)
   - 5.1 Coordinate formats
   - 5.2 Sending captures on load
   - 5.3 SET_CAPTURES (after load)
6. [Events — Parent → Viewer](#6-events--parent--viewer)
7. [Events — Viewer → Parent](#7-events--viewer--parent)
8. [Split & Merge Feature](#8-split--merge-feature)
9. [Viewer Configuration (.env)](#9-viewer-configuration-env)
10. [Coordinate System Reference](#10-coordinate-system-reference)

---

## 1. Setup & Embedding

```html
<!-- In your Angular template -->
<iframe
  #viewerFrame
  src="https://your-viewer-host.com"
  style="width:100%; height:100%; border:none;"
  allow="*"
></iframe>
```

```ts
// Angular service — basic helper
const iframe = document.querySelector('iframe');
const viewer = iframe.contentWindow;

function send(msg: object, transferables?: Transferable[]) {
  viewer.postMessage(msg, '*', transferables ?? []);
}

// Listen for events FROM the viewer
window.addEventListener('message', (event) => {
  const { type, ...data } = event.data ?? {};
  if (!type) return;
  handleViewerEvent(type, data);
});
```

---

## 2. Handshake — READY flow

The viewer fires `READY` when it has initialised and is waiting for a document.
Parent must listen for `READY` before sending any load event.

```
Viewer  ──── READY ────────────────────────────────────►  Parent
Parent  ──── READY_CONFIG (optional) ──────────────────►  Viewer
Parent  ──── LOAD_SINGLEDOC / LOAD_MANIFEST ───────────►  Viewer
Viewer  ──── DOC_LOADED ────────────────────────────────►  Parent
```

### READY_CONFIG (parent → viewer, optional)

Send after receiving `READY` to configure the viewer before any document loads.

```ts
send({
  type:             'READY_CONFIG',
  enableCaptureDebug: true,    // show right-side fields panel
  initialZoom:      'page-fit',// zoom mode
  Click2Pick:       false,     // enable capture mode on load
  showSplitMerge:   true,      // show scissors icon (needs VITE_SPLIT_MERGE_URL in .env)
});
```

| Field | Type | Default | Description |
|---|---|---|---|
| `enableCaptureDebug` | boolean | false | Show right-side capture fields panel |
| `initialZoom` | string\|number | 'page-fit' | Initial zoom — see zoom values below |
| `Click2Pick` | boolean | false | Enable box-capture mode on load |
| `showSplitMerge` | boolean | false | Show Split & Merge toolbar icon |

**Zoom values:** `'page-fit'` · `'page-width'` · `'actual'` · `1.5` (numeric = scale factor)

---

## 3. Loading Documents

### 3.1 LOAD_SINGLEDOC

One document, any number of pages.

```ts
// Minimal
send({ type: 'LOAD_SINGLEDOC', buffer: arrayBuffer, fileName: 'invoice.pdf' },
     [arrayBuffer]);  // transfer buffer — zero copy

// Full example
send({
  type:              'LOAD_SINGLEDOC',
  buffer:            arrayBuffer,
  fileName:          'invoice.pdf',       // extension determines format: pdf/tif/tiff/png/jpg/xlsx/docx/csv

  // ── Optional display config ──────────────────────────────────────────────
  initialZoom:       'page-fit',          // 'page-fit'|'page-width'|'actual'|1.5
  showFieldsPanel:   true,                // show right-side panel
  showAnnotation:    false,               // show annotation button
  showThumbnailView: true,                // show thumbnail sidebar
  showSplitMerge:    true,                // show scissors icon
  Click2Pick:        false,               // enable capture mode

  // ── Optional data ────────────────────────────────────────────────────────
  categories: [ ... ],                    // see Section 4
  captures:   [ ... ],                    // see Section 5
  fullPageOCR: {                          // word index for Click2Pick / search
    1: [{ text: 'Invoice', x: 0.10, y: 0.05, width: 0.15, height: 0.02 }],
    2: [{ text: 'Total',   x: 0.65, y: 0.80, width: 0.10, height: 0.02 }],
  },
}, [arrayBuffer]);
```

**Supported file formats via `fileName` extension:**

| Extension | Format |
|---|---|
| `.pdf` | PDF (text + image) |
| `.tif` `.tiff` | TIFF (multi-page image) |
| `.png` `.jpg` `.jpeg` | Image |
| `.xlsx` `.xls` | Spreadsheet |
| `.docx` `.doc` | Word document |
| `.csv` | CSV |

---

### 3.2 LOAD_MANIFEST — MultiDoc:SinglePage

Multiple documents, each exactly 1 page. User navigates between documents.

```ts
send({
  type: 'LOAD_MANIFEST',
  manifest: {
    mode: 'MultiDoc:SinglePage',

    // Optional — defines labels and colors for categories.
    // If omitted, ids from document.category strings are used as labels
    // with auto-assigned palette colors.
    categories: [
      { id: 'invoice',     label: 'Invoice',     color: 'blue'  },
      { id: 'annexure',    label: 'Annexure',    color: 'teal'  },
      { id: 'declaration', label: 'Declaration', color: 'amber' },
    ],

    documents: [
      { id: 'doc1', name: 'Invoice_001.pdf',     label: 'Invoice 001',    category: 'invoice'     },
      { id: 'doc2', name: 'Invoice_002.pdf',     label: 'Invoice 002',    category: 'invoice'     },
      { id: 'doc3', name: 'Declaration_001.pdf', label: 'Declaration 01', category: 'declaration' },
      { id: 'doc4', name: 'Declaration_002.pdf', label: 'Declaration 02', category: 'declaration' },
      { id: 'doc5', name: 'Invoice_003.pdf',     label: 'Invoice 003',    category: 'invoice'     },
      // doc1+doc2 → Invoice group, doc3+doc4 → Declaration group, doc5 → Invoice group
      // CONSECUTIVE same-category docs = one accordion group in sidebar
    ],
  },
  activeDocId:  'doc1',           // which document to show first
  activeBuffer: arrayBuffer,      // buffer for doc1 (avoids DOC_REQUEST for first doc)
}, [arrayBuffer]);
```

**Accordion grouping for SinglePage:** Documents are grouped by **consecutive runs** of the same category — not all same-category docs merged into one. If `doc1, doc2` are Invoice, `doc3, doc4` are Declaration, `doc5` is Invoice → **3 separate accordions**: Invoice(doc1,doc2), Declaration(doc3,doc4), Invoice(doc5).

---

### 3.3 LOAD_MANIFEST — MultiDoc:MultiPage

Multiple documents, each with multiple pages. `pageCategories` defines which pages of each document belong to which category.

```ts
send({
  type: 'LOAD_MANIFEST',
  manifest: {
    mode: 'MultiDoc:MultiPage',

    categories: [
      { id: 'invoice',     label: 'Invoice',     color: 'blue'  },
      { id: 'annexure',    label: 'Annexure',    color: 'teal'  },
      { id: 'declaration', label: 'Declaration', color: 'amber' },
    ],

    documents: [
      {
        id:    'docA',
        name:  'Bundle_A.pdf',
        label: 'Bundle A',
        totalPages: 7,            // optional — auto-derived if omitted

        // Each entry = one accordion group in the thumbnail sidebar.
        // Same category id can appear multiple times = multiple accordions.
        pageCategories: [
          { category: 'invoice',     pages: [1, 2, 3] },   // accordion 1: Invoice (pg 1-3)
          { category: 'annexure',    pages: [4, 5]    },   // accordion 2: Annexure (pg 4-5)
          { category: 'invoice',     pages: [6, 7]    },   // accordion 3: Invoice (pg 6-7)
        ],
      },
      {
        id:    'docB',
        name:  'Bundle_B.pdf',
        label: 'Bundle B',
        pageCategories: [
          { category: 'invoice',     pages: [1, 2] },
          { category: 'declaration', pages: [3]    },
        ],
      },
    ],
  },
  activeDocId:  'docA',
  activeBuffer: arrayBuffer,      // buffer for docA
}, [arrayBuffer]);
```

**When user selects a different document**, viewer sends `DOC_REQUEST` to parent:

```ts
// Viewer → Parent
{ type: 'DOC_REQUEST', docId: 'docB' }

// Parent must respond with:
send({ type: 'DOC_RESPONSE', docId: 'docB', buffer: docBBuffer }, [docBBuffer]);
// Or with URL:
send({ type: 'DOC_RESPONSE', docId: 'docB', url: 'https://your-cdn.com/docB.pdf' });
```

**`ALL_DOC_RESPONSE`** — send all buffers upfront to avoid per-doc requests:

```ts
send({
  type: 'ALL_DOC_RESPONSE',
  documents: [
    { docId: 'docA', buffer: bufA },
    { docId: 'docB', buffer: bufB },
  ],
});
```

---

## 4. Categories

Categories create accordion groups in the thumbnail sidebar.

### LOAD_SINGLEDOC — one object per accordion

```ts
categories: [
  { label: 'Invoice',     pages: [1, 2, 3], color: 'blue'  },
  { label: 'Invoice',     pages: [6, 7],    color: 'blue'  }, // same label = separate accordion
  { label: 'Annexure',    pages: [4, 5],    color: 'teal'  },
  { label: 'Declaration', pages: [8],       color: 'amber' },
  // pages not listed in any category → auto "Others" group at bottom
]
```

### MultiDoc:SinglePage — `category` string on each document

```ts
// In manifest.documents[]:
{ id: 'doc1', name: 'inv1.pdf', category: 'invoice' }
// Consecutive same-category docs = one accordion.
```

### MultiDoc:MultiPage — `pageCategories[]` on each document

```ts
// In manifest.documents[].pageCategories:
pageCategories: [
  { category: 'invoice', pages: [1, 2, 3] },   // one accordion per entry
  { category: 'invoice', pages: [6, 7]    },   // same category = separate accordion
]
```

### Color palette

| Key | Key | Key | Key |
|---|---|---|---|
| `'blue'` | `'teal'` | `'amber'` | `'gray'` |
| `'purple'` | `'coral'` | `'green'` | `'red'` |
| `'#FF6B00'` (hex) | omit → auto-rotation | | |

---

## 5. Captures (Highlight Boxes)

### 5.1 Coordinate formats

All formats accepted. **Use 0–1 fractions (normalised) for safest results.**

```ts
// FORMAT 1 — normalised 0-1 fractions (recommended, no unit detection needed)
{ id: 1, value: 'Total', page: 1, x: 0.65, y: 0.80, width: 0.20, height: 0.03 }

// FORMAT 2 — bbox [x, y, w, h]
{ id: 2, value: 'Amount', page: 1, bbox: [0.65, 0.80, 0.20, 0.03] }

// FORMAT 10 — page-prefixed bbox [page, x_min, y_min, width, height]
{ id: 3, value: 'Name', bbox: [1, 125, 157, 138, 12] }
//                              ↑pg  ↑x   ↑y   ↑w   ↑h
// Page is extracted from bbox[0] automatically

// FORMAT — polygon / bbox_relative
{ id: 4, value: 'Code', bbox_relative: [[0.10,0.20],[0.30,0.20],[0.30,0.25],[0.10,0.25]] }

// FORMAT — corner points
{ id: 5, value: 'Date', xmin: 0.65, ymin: 0.80, xmax: 0.85, ymax: 0.83 }

// FORMAT — CSS-style
{ id: 6, value: 'Ref', left: 0.10, top: 0.20, width: 0.15, height: 0.02 }
```

### 5.2 Sending captures on load

```ts
// In LOAD_SINGLEDOC or LOAD_MANIFEST:
captures: [
  { id: '1', value: 'Emerald Earth Enterprises', bbox: [1, 125, 157, 138, 12] },
  { id: '2', value: 'S1007 - Advertising',       bbox: [1, 318, 157, 106, 20] },
  { id: '3', value: 'USD',                        bbox: [1, 589, 157,  87, 12] },
  { id: '4', value: 'PALMS RESOURCES PTE LTD',   page: 2, x: 0.163, y: 0.632, width: 0.225, height: 0.021 },
]
```

### 5.3 SET_CAPTURES — update captures after load

```ts
send({
  type:    'SET_CAPTURES',
  mode:    'replace',          // 'replace' (clear existing) | 'merge' (add to existing)
  docId:   'docA',             // optional — for MultiDoc targeting
  captures: [
    { id: '10', value: 'New Field', page: 1, x: 0.3, y: 0.5, width: 0.2, height: 0.02 },
  ],
});
```

---

## 6. Events — Parent → Viewer

| Event | When to send | Key fields |
|---|---|---|
| `READY_CONFIG` | After viewer fires `READY` | `enableCaptureDebug`, `showSplitMerge`, `initialZoom` |
| `LOAD_SINGLEDOC` | Load one document | `buffer`, `fileName`, `categories`, `captures` |
| `LOAD_MANIFEST` | Load multiple documents | `manifest`, `activeDocId`, `activeBuffer` |
| `DOC_RESPONSE` | Reply to `DOC_REQUEST` | `docId`, `buffer` or `url` |
| `ALL_DOC_RESPONSE` | Pre-load all buffers | `documents: [{docId, buffer}]` |
| `SET_CAPTURES` | Update captures after load | `mode`, `captures`, `docId` |
| `DELETE_CAPTURE` | Remove a capture | `id` |
| `CAPTURE_ACK` | Acknowledge capture preview | `tempId`, `realId` |
| `HIGHLIGHT` | Highlight a specific field | `id`, `page`, `x`, `y`, `width`, `height` |
| `EXPORT_CAPTURES` | Request current captures | — |
| `RESET_VIEWER` | Clear viewer to blank | — |
| `SPLIT_MERGE_SAVE` | SM app: save and return | `buffer?`, `fileName?` |
| `SPLIT_MERGE_EXIT` | SM app: exit without save | — |

---

## 7. Events — Viewer → Parent

| Event | When fired | Key fields |
|---|---|---|
| `READY` | Viewer initialised, waiting for doc | — |
| `DOC_LOADED` | Document rendered successfully | `fileName`, `pageCount`, `docId?` |
| `DOC_LOAD_ERROR` | Document failed to load | `code`, `reason`, `fileName`, `docId?` |
| `DOC_REQUEST` | MultiDoc: user selected a doc that has no buffer | `docId` |
| `CAPTURE_PREVIEW` | User drew a box or double-clicked text | `tempId`, `text`, `page`, `x`, `y`, `width`, `height`, `bbox?` |
| `CAPTURES_DATA` | Reply to `EXPORT_CAPTURES` | `captures: ExportedCapture[]` |
| `VIEWER_STATE_CHANGED` | Page navigated or document switched | `page`, `pageCount`, `fileName`, `docId?`, `docLabel?`, `mode?`, `totalDocs?` |
| `SPLIT_MERGE_OPENED` | Split & Merge screen activated | `fileName` |
| `SPLIT_MERGE_SAVED` | Split & Merge saved changes | `fileName?`, `buffer?` |
| `SPLIT_MERGE_EXITED` | Split & Merge closed without save | `reason?` |

### VIEWER_STATE_CHANGED — subscribe in Angular

```ts
window.addEventListener('message', (event) => {
  if (event.data?.type !== 'VIEWER_STATE_CHANGED') return;
  const { page, pageCount, fileName, docId, docLabel, mode, totalDocs } = event.data;

  // SingleDoc: page, pageCount, fileName
  console.log(`Page ${page}/${pageCount} — ${fileName}`);

  // MultiDoc: additionally docId, docLabel, mode, totalDocs
  if (docId) {
    console.log(`Doc: ${docLabel} (${docId}) in ${mode} — ${totalDocs} total docs`);
  }
});
```

### DOC_LOAD_ERROR codes

| Code | Meaning |
|---|---|
| `INVALID_BUFFER` | Buffer is null, empty, or corrupted |
| `CORRUPT_FILE` | File parsed but content unreadable |
| `UNSUPPORTED_FORMAT` | File type not supported |
| `DOC_REQUEST_TIMEOUT` | Parent did not respond to DOC_REQUEST within 60s |
| `RENDER_FAILED` | File loaded but page rendering failed |
| `UNKNOWN` | Unexpected error |

### CAPTURE_PREVIEW — acknowledge flow

```ts
// Viewer fires:
{ type: 'CAPTURE_PREVIEW', tempId: 'tmp_abc123', text: 'Invoice No', page: 1,
  x: 0.10, y: 0.05, width: 0.30, height: 0.02 }

// Parent must ACK within 15s or viewer shows error:
send({ type: 'CAPTURE_ACK', tempId: 'tmp_abc123', realId: 'field_001' });
```

---

## 8. Split & Merge Feature

Replaces the entire viewer with an external iframe for split/merge operations.

### Setup

**Step 1 — Set URL in viewer `.env`:**
```env
VITE_SPLIT_MERGE_URL=https://your-split-merge-app.com
```

**Step 2 — Enable the icon from parent:**
```ts
// Via READY_CONFIG:
send({ type: 'READY_CONFIG', showSplitMerge: true });

// Or via LOAD_SINGLEDOC:
send({ type: 'LOAD_SINGLEDOC', buffer, fileName, showSplitMerge: true }, [buffer]);

// Or via LOAD_MANIFEST:
manifest: { ..., showSplitMerge: true }
```

### What SM iframe receives (`SPLIT_MERGE_OPEN`)

```ts
// Posted to SM iframe contentWindow when user clicks scissors icon:
{
  type: 'SPLIT_MERGE_OPEN',

  payload: {
    // Exact copy of what parent originally sent (LOAD_SINGLEDOC or LOAD_MANIFEST)
    type:       'LOAD_SINGLEDOC',          // or 'LOAD_MANIFEST'
    buffer:     ArrayBuffer,               // transferred zero-copy
    fileName:   'invoice.pdf',
    categories: [...],
    captures:   [...],
    // ...all other fields parent sent
  },

  viewerState: {
    pageCount:   21,
    currentPage: 3,
    format:      'pdf',                    // 'pdf'|'image'|'document'|'spreadsheet'
  },
}
```

**How SM app listens:**
```ts
window.addEventListener('message', (event) => {
  if (event.data?.type !== 'SPLIT_MERGE_OPEN') return;
  const { payload, viewerState } = event.data;
  const blob = new Blob([payload.buffer], { type: 'application/pdf' });
  loadDocument(URL.createObjectURL(blob), payload);
});
```

### SM app → Viewer (close SM mode)

```ts
// Save with modified document:
window.parent.postMessage({
  type:     'SPLIT_MERGE_SAVE',
  buffer:   modifiedBuffer,         // optional — new doc bytes
  fileName: 'invoice_split.pdf',    // optional
}, '*', [modifiedBuffer]);

// Exit without changes:
window.parent.postMessage({ type: 'SPLIT_MERGE_EXIT' }, '*');
```

### Events while SM is active

When Split & Merge is active, these events are **forwarded to the SM iframe** (viewer does not process them):
`DOC_RESPONSE` · `ALL_DOC_RESPONSE` · `SET_CAPTURES` · `DELETE_CAPTURE` · `CAPTURE_ACK`

These events **close SM and restore viewer**:
`LOAD_SINGLEDOC` · `LOAD_MANIFEST` · `RESET_VIEWER`

---

## 9. Viewer Configuration (.env)

Create `.env` in the viewer project root (copy from `.env.example`):

```env
# URL of the Split & Merge application iframe (leave empty to disable)
VITE_SPLIT_MERGE_URL=https://your-split-merge-app.com

# Restrict which parent origin can postMessage to this viewer (default: *)
VITE_PARENT_ORIGIN=https://your-angular-app.com
```

### Build commands

```bash
npm run dev           # local dev  → reads .env.development
npm run build:uat     # UAT build  → reads .env.uat
npm run build:prod    # PROD build → reads .env.production
npm run build         # same as build:prod
```

**Environment files:**
- `.env.development` — local dev values
- `.env.uat` — UAT environment
- `.env.production` — production environment

---

## 10. Coordinate System Reference

All coordinates stored internally as **0–1 fractions** of page dimensions:
- `x=0.0` → left edge, `x=1.0` → right edge
- `y=0.0` → top edge, `y=1.0` → bottom edge

### Auto-detection rules

| Condition | Detected as | Reference |
|---|---|---|
| All values ≤ 1.0 | Already normalised | None — pass-through |
| maxCoord > pts page width AND fits in px@96 | Pixels @ 96dpi | `pageW×96/72` |
| maxCoord ≤ pts page width | Points (72dpi) | pts dims from PDF |
| PDF has UserUnit (e.g. reported 2550×3299) | Stripped to real pts first, then above | 612×792 effective |

Detection is **batch-based** — unit detected once from the global maximum across all captures on the same page, not per-item.

### FORMAT 10 — page-prefixed bbox

```ts
// Input: { bbox: [page, x_min, y_min, width, height] }
{ value: 'Name', bbox: [1, 125, 157, 138, 12] }
//                      ↑    ↑    ↑    ↑    ↑
//                     page  x    y    w    h

// Viewer extracts page=1 from bbox[0], normalises [125,157,138,12]
// CAPTURE_PREVIEW round-trip: sends back { bbox: [1,125,157,138,12] } verbatim
```

### Supported coordinate formats

| Format | Example |
|---|---|
| Flat x/y | `{ x, y, width, height }` or `{ x, y, w, h }` |
| bbox 4-elem | `{ bbox: [x, y, w, h] }` |
| bbox FORMAT 10 | `{ bbox: [page, x, y, w, h] }` |
| rectangle | `{ rectangle: [x1,y1,x2,y2] }` or `[x,y,w,h]` |
| coordinates | `{ coordinates: [ymin,xmin,ymax,xmax] }` |
| xmin/ymin | `{ xmin, ymin, xmax, ymax }` |
| bbox_relative | `{ bbox_relative: [[x,y],[x,y],[x,y],[x,y]] }` (polygon → AABB) |
| left/top | `{ left, top, width, height }` |
| corner points | `{ left, right, top, bottom }` |

---

*Last updated: Session 6 — DocCapture Viewer v1.x*
