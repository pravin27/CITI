# DocCapture Viewer — Complete Integration Guide

---

## Table of Contents

1. [Setup & Embedding](#1-setup--embedding)
2. [Handshake — READY flow](#2-handshake--ready-flow)
3. [Loading Documents](#3-loading-documents)
4. [Categories](#4-categories)
5. [Captures (Highlight Boxes)](#5-captures-highlight-boxes)
6. [Events — Parent → Viewer](#6-events--parent--viewer)
7. [Events — Viewer → Parent](#7-events--viewer--parent)
8. [Split & Merge Feature](#8-split--merge-feature)
9. [Retrigger Button (Split-Screen)](#9-retrigger-button-split-screen)
10. [Viewer Configuration (.env)](#10-viewer-configuration-env)
11. [Coordinate System Reference](#11-coordinate-system-reference)

---

## 1. Setup & Embedding

```html
<iframe
  #viewerFrame
  src="https://your-viewer-host.com"
  style="width:100%; height:100%; border:none;"
  allow="*"
></iframe>
```

```ts
const viewer = document.querySelector('iframe').contentWindow;

function send(msg: object, transferables?: Transferable[]) {
  viewer.postMessage(msg, '*', transferables ?? []);
}

window.addEventListener('message', (event) => {
  const { type, ...data } = event.data ?? {};
  if (!type) return;
  // handle type → see Section 7
});
```

---

## 2. Handshake — READY flow

```
Viewer  ──── READY ───────────────────────────────────►  Parent
Parent  ──── READY_CONFIG (optional) ─────────────────►  Viewer
Parent  ──── LOAD_SINGLEDOC / LOAD_MANIFEST ──────────►  Viewer
Viewer  ──── DOC_LOADED ───────────────────────────────►  Parent
```

### READY_CONFIG

```ts
send({
  type:               'READY_CONFIG',
  enableCaptureDebug: true,      // show right-side fields panel
  initialZoom:        'page-fit',
  Click2Pick:         false,
  showSplitMerge:     true,      // show scissors icon (needs VITE_SPLIT_MERGE_URL)
});
```

| Field | Type | Default | Description |
|---|---|---|---|
| `enableCaptureDebug` | boolean | false | Show right-side capture fields panel |
| `initialZoom` | string\|number | 'page-fit' | `'page-fit'` `'page-width'` `'actual'` or numeric scale e.g. `1.5` |
| `Click2Pick` | boolean | false | Enable box-capture mode on load |
| `showSplitMerge` | boolean | false | Show Split & Merge scissors icon in toolbar |

---

## 3. Loading Documents

### 3.1 LOAD_SINGLEDOC

```ts
send({
  type:     'LOAD_SINGLEDOC',
  buffer:   arrayBuffer,          // required — raw bytes
  fileName: 'invoice.pdf',        // required — extension sets format

  // ── Optional display config ─────────────────────────────────────────────
  initialZoom:       'page-fit',  // 'page-fit'|'page-width'|'actual'|1.5
  showFieldsPanel:   true,        // right-side panel
  showAnnotation:    false,
  showThumbnailView: true,
  showSplitMerge:    true,        // scissors icon (needs VITE_SPLIT_MERGE_URL)
  isSplitScreen:     true,        // show Retrigger button (see Section 9)
  Click2Pick:        false,

  // ── Optional data ────────────────────────────────────────────────────────
  categories: [...],              // see Section 4
  captures:   [...],              // see Section 5
  fullPageOCR: {
    1: [{ text: 'Invoice', x: 0.10, y: 0.05, width: 0.15, height: 0.02 }],
  },
}, [arrayBuffer]);
```

**Supported formats:** `.pdf` · `.tif` / `.tiff` · `.png` · `.jpg` / `.jpeg` · `.xlsx` / `.xls` · `.docx` / `.doc` · `.csv`

---

### 3.2 LOAD_MANIFEST — MultiDoc:SinglePage

Each document is a single page. `category` string on each document drives grouping.

```ts
send({
  type: 'LOAD_MANIFEST',
  manifest: {
    mode: 'MultiDoc:SinglePage',

    // Optional — custom labels/colors. Auto-derived from category strings if omitted.
    categories: [
      { id: 'invoice',     label: 'Invoice',     color: 'blue'  },
      { id: 'annexure',    label: 'Annexure',    color: 'teal'  },
      { id: 'declaration', label: 'Declaration', color: 'amber' },
    ],

    documents: [
      { id: 'doc1', name: 'Invoice_001.pdf', label: 'Invoice 001', category: 'invoice'     },
      { id: 'doc2', name: 'Invoice_002.pdf', label: 'Invoice 002', category: 'invoice'     },
      { id: 'doc3', name: 'Decl_001.pdf',    label: 'Decl 001',   category: 'declaration' },
      { id: 'doc4', name: 'Decl_002.pdf',    label: 'Decl 002',   category: 'declaration' },
      { id: 'doc5', name: 'Invoice_003.pdf', label: 'Invoice 003', category: 'invoice'     },
      // Consecutive same-category docs = one accordion.
      // doc1+doc2 → Invoice, doc3+doc4 → Declaration, doc5 → Invoice (3 separate accordions)
    ],

    isSplitScreen: true,   // optional — show Retrigger button
  },
  activeDocId:  'doc1',
  activeBuffer: arrayBuffer,  // buffer for doc1 — avoids DOC_REQUEST for first doc
}, [arrayBuffer]);
```

---

### 3.3 LOAD_MANIFEST — MultiDoc:MultiPage

Each document has multiple pages. `pageCategories[]` maps category ids to page numbers per document.

```ts
send({
  type: 'LOAD_MANIFEST',
  manifest: {
    mode: 'MultiDoc:MultiPage',

    categories: [
      { id: 'invoice',     label: 'Invoice',     color: 'blue'  },
      { id: 'annexure',    label: 'Annexure',    color: 'teal'  },
      { id: 'declaration', label: 'Declaration', color: 'amber' },
    ],

    documents: [
      {
        id:    'docA',
        name:  'Bundle_A.pdf',
        label: 'Bundle A',
        totalPages: 7,           // optional — auto-derived if omitted

        // Each entry = one accordion group. Same id can appear multiple times.
        pageCategories: [
          { category: 'invoice',     pages: [1, 2, 3] },  // accordion 1
          { category: 'annexure',    pages: [4, 5]    },  // accordion 2
          { category: 'invoice',     pages: [6, 7]    },  // accordion 3 — separate group
        ],
      },
      {
        id:    'docB',
        name:  'Bundle_B.pdf',
        label: 'Bundle B',
        pageCategories: [
          { category: 'invoice',     pages: [1, 2] },
          { category: 'declaration', pages: [3]    },
        ],
      },
    ],

    isSplitScreen: true,   // optional
  },
  activeDocId:  'docA',
  activeBuffer: arrayBuffer,
}, [arrayBuffer]);
```

**DOC_REQUEST / DOC_RESPONSE** — when user selects a doc without a pre-loaded buffer:

```ts
// Viewer fires:
{ type: 'DOC_REQUEST', docId: 'docB' }

// Parent responds:
send({ type: 'DOC_RESPONSE', docId: 'docB', buffer: docBBuffer }, [docBBuffer]);
// Or with URL:
send({ type: 'DOC_RESPONSE', docId: 'docB', url: 'https://cdn.example.com/docB.pdf' });

// Pre-load all buffers upfront (avoids per-doc requests):
send({ type: 'ALL_DOC_RESPONSE', documents: [{ docId: 'docA', buffer: bufA }, ...] });
```

---

## 4. Categories

### LOAD_SINGLEDOC — each object = one accordion

```ts
categories: [
  { label: 'Invoice',     pages: [1, 2, 3], color: 'blue'  },
  { label: 'Invoice',     pages: [6, 7],    color: 'blue'  }, // same label = separate accordion
  { label: 'Annexure',    pages: [4, 5],    color: 'teal'  },
  { label: 'Declaration', pages: [8],       color: 'amber' },
  // pages not in any category → auto "Others" group at bottom
]
```

### MultiDoc:SinglePage — `category` string on each document

```ts
// Consecutive docs with same category = one accordion group
{ id: 'doc1', category: 'invoice' },   // ─┐ Invoice group 1
{ id: 'doc2', category: 'invoice' },   // ─┘
{ id: 'doc3', category: 'declaration' }, // Declaration group
{ id: 'doc5', category: 'invoice' },   //   Invoice group 2 (separate)
```

### MultiDoc:MultiPage — `pageCategories[]` per document

```ts
pageCategories: [
  { category: 'invoice',  pages: [1, 2, 3] },  // one accordion per entry
  { category: 'invoice',  pages: [6, 7]    },  // same id = still separate accordion
]
```

### Color reference

| Key | Key | Key | Key |
|---|---|---|---|
| `'blue'` | `'teal'` | `'amber'` | `'gray'` |
| `'purple'` | `'coral'` | `'green'` | `'red'` |
| `'#FF6B00'` hex | omit → auto-rotation | | |

**Common mistakes:**
- `pages: ['1','2']` — strings fail the check, all land in "Others" → use numbers
- `pages: []` — empty array → category filtered out → use at least one page
- `color: 'FF6B00'` — missing `#` → grey fallback → use `'#FF6B00'`

---

## 5. Captures (Highlight Boxes)

### Coordinate formats supported

```ts
// Normalised 0-1 (recommended — no unit detection needed)
{ id: '1', value: 'Total',  page: 1, x: 0.65, y: 0.80, width: 0.20, height: 0.03 }

// FORMAT 10 — page-prefixed bbox [page, x_min, y_min, width, height]
{ id: '2', value: 'Name',   bbox: [1, 125, 157, 138, 12] }
//                                  ↑pg  ↑x   ↑y   ↑w   ↑h

// bbox 4-element
{ id: '3', value: 'Amount', page: 1, bbox: [0.65, 0.80, 0.20, 0.03] }

// xmin/ymin corner points
{ id: '4', value: 'Ref',    page: 1, xmin: 0.10, ymin: 0.20, xmax: 0.30, ymax: 0.25 }

// CSS-style
{ id: '5', value: 'Date',   page: 1, left: 0.10, top: 0.20, width: 0.15, height: 0.02 }

// Polygon (AABB derived automatically)
{ id: '6', value: 'Code',   page: 1, bbox_relative: [[0.1,0.2],[0.3,0.2],[0.3,0.25],[0.1,0.25]] }
```

### Sending on load

```ts
// In LOAD_SINGLEDOC or LOAD_MANIFEST:
captures: [
  { id: '1', value: 'Emerald Earth Enterprises', bbox: [1, 125, 157, 138, 12] },
  { id: '2', value: 'USD',                        page: 1, x: 0.722, y: 0.149, width: 0.107, height: 0.011 },
]
```

### SET_CAPTURES — update after load

```ts
send({
  type:     'SET_CAPTURES',
  mode:     'replace',     // 'replace' | 'merge'
  docId:    'docA',        // optional, for MultiDoc targeting
  captures: [{ id: '10', value: 'New Field', page: 1, x: 0.3, y: 0.5, width: 0.2, height: 0.02 }],
});
```

---

## 6. Events — Parent → Viewer

| Event | Purpose | Key fields |
|---|---|---|
| `READY_CONFIG` | Configure viewer after READY | `enableCaptureDebug` `showSplitMerge` `initialZoom` |
| `LOAD_SINGLEDOC` | Load one document | `buffer` `fileName` `categories` `captures` `isSplitScreen` |
| `LOAD_MANIFEST` | Load multiple documents | `manifest` `activeDocId` `activeBuffer` `isSplitScreen` |
| `DOC_RESPONSE` | Reply to DOC_REQUEST | `docId` + `buffer` or `url` |
| `ALL_DOC_RESPONSE` | Pre-load all buffers | `documents: [{docId, buffer}]` |
| `SET_CAPTURES` | Update captures after load | `mode` `captures` `docId?` |
| `DELETE_CAPTURE` | Remove a capture by id | `id` |
| `CAPTURE_ACK` | Acknowledge capture preview | `tempId` `realId` |
| `HIGHLIGHT` | Highlight a specific field | `id` `page` `x` `y` `width` `height` |
| `EXPORT_CAPTURES` | Request current captures list | — |
| `RESET_VIEWER` | Clear viewer to blank state | — |
| `SPLIT_MERGE_SAVE` | SM app: save modified doc | `buffer?` `fileName?` |
| `SPLIT_MERGE_EXIT` | SM app: exit without save | — |

---

## 7. Events — Viewer → Parent

| Event | When fired | Key fields |
|---|---|---|
| `READY` | Viewer initialised, waiting for document | — |
| `DOC_LOADED` | Document rendered successfully | `fileName` `pageCount` `docId?` |
| `DOC_LOAD_ERROR` | Document failed to load | `code` `reason` `fileName` `docId?` |
| `DOC_REQUEST` | User selected doc with no buffer | `docId` |
| `CAPTURE_PREVIEW` | User drew a box or double-clicked text | `tempId` `text` `page` `x` `y` `width` `height` `bbox?` |
| `CAPTURES_DATA` | Reply to EXPORT_CAPTURES | `captures: ExportedCapture[]` |
| `VIEWER_STATE_CHANGED` | Page navigated or document switched | see below |
| `RETRIGGER_CLICKED` | User clicked Retrigger button | `fileName` `page` `pageCount` `categories` `docId?` `mode?` |
| `SPLIT_MERGE_OPENED` | Split & Merge screen activated | `fileName` |
| `SPLIT_MERGE_SAVED` | Split & Merge saved changes | `fileName?` |
| `SPLIT_MERGE_EXITED` | Split & Merge closed without save | `reason?` |

### VIEWER_STATE_CHANGED

Fires on every page navigation and every document switch. Single unified event for all navigation.

```ts
window.addEventListener('message', (event) => {
  if (event.data?.type !== 'VIEWER_STATE_CHANGED') return;
  const {
    page,       // current page number (1-based)
    pageCount,  // total pages in current document
    fileName,   // file name of current document

    // MultiDoc only (undefined for SingleDoc):
    docId,      // active document id
    docLabel,   // display label from manifest
    mode,       // 'MultiDoc:SinglePage' | 'MultiDoc:MultiPage'
    totalDocs,  // total documents in manifest
  } = event.data;
});
```

### CAPTURE_PREVIEW — acknowledge flow

```ts
// Viewer fires:
{ type: 'CAPTURE_PREVIEW', tempId: 'tmp_abc', text: 'Invoice No',
  page: 1, x: 0.10, y: 0.05, width: 0.30, height: 0.02 }

// Parent must ACK within 15s:
send({ type: 'CAPTURE_ACK', tempId: 'tmp_abc', realId: 'field_001' });
```

### DOC_LOAD_ERROR codes

| Code | Meaning |
|---|---|
| `INVALID_BUFFER` | Buffer null, empty, or corrupt |
| `CORRUPT_FILE` | File parsed but unreadable |
| `UNSUPPORTED_FORMAT` | File type not supported |
| `DOC_REQUEST_TIMEOUT` | Parent did not respond to DOC_REQUEST within 60s |
| `RENDER_FAILED` | File loaded but page rendering failed |
| `UNKNOWN` | Unexpected error |

---

## 8. Split & Merge Feature

Replaces the entire viewer with an external iframe for split/merge operations.

### Setup

**Step 1 — Set URL in viewer `.env`:**
```env
VITE_SPLIT_MERGE_URL=https://your-split-merge-app.com
```

**Step 2 — Enable the icon from parent (any of):**
```ts
send({ type: 'READY_CONFIG',    showSplitMerge: true });
send({ type: 'LOAD_SINGLEDOC',  ..., showSplitMerge: true }, [buffer]);
send({ type: 'LOAD_MANIFEST',   manifest: { ..., showSplitMerge: true }, ... });
```

### What SM iframe receives (`SPLIT_MERGE_OPEN`)

```ts
{
  type: 'SPLIT_MERGE_OPEN',

  // Exact copy of what parent originally sent (LOAD_SINGLEDOC or LOAD_MANIFEST)
  payload: {
    type:       'LOAD_SINGLEDOC',     // or 'LOAD_MANIFEST'
    buffer:     ArrayBuffer,          // transferred zero-copy
    fileName:   'invoice.pdf',
    categories: [...],
    captures:   [...],
    // ...all other fields parent sent
  },

  viewerState: {
    pageCount:   21,
    currentPage: 3,
    format:      'pdf',               // 'pdf'|'image'|'document'|'spreadsheet'
  },
}
```

**How SM app listens:**
```ts
window.addEventListener('message', (event) => {
  if (event.data?.type !== 'SPLIT_MERGE_OPEN') return;
  const { payload, viewerState } = event.data;
  const blob = new Blob([payload.buffer], { type: 'application/pdf' });
  loadDocument(URL.createObjectURL(blob), payload);
});
```

**SM app → Viewer to close:**
```ts
// Save with new document:
window.parent.postMessage({ type: 'SPLIT_MERGE_SAVE', buffer: modifiedBuffer }, '*', [modifiedBuffer]);
// Exit without changes:
window.parent.postMessage({ type: 'SPLIT_MERGE_EXIT' }, '*');
```

**Events while SM is active:**
- Forwarded to SM iframe: `DOC_RESPONSE` · `ALL_DOC_RESPONSE` · `SET_CAPTURES` · `DELETE_CAPTURE` · `CAPTURE_ACK`
- Close SM and restore viewer: `LOAD_SINGLEDOC` · `LOAD_MANIFEST` · `RESET_VIEWER`

---

## 9. Retrigger Button (Split-Screen)

When `isSplitScreen: true` is sent, a **Retrigger** button appears fixed at the bottom of the thumbnail sidebar — visible above all page thumbnails, never scrolls away.

### Enable

```ts
// LOAD_SINGLEDOC:
send({ type: 'LOAD_SINGLEDOC', buffer, fileName, isSplitScreen: true }, [buffer]);

// LOAD_MANIFEST:
send({ type: 'LOAD_MANIFEST', manifest: { ..., isSplitScreen: true }, ... });
```

### Event fired on click

```ts
window.addEventListener('message', (event) => {
  if (event.data?.type !== 'RETRIGGER_CLICKED') return;
  const {
    fileName,   // current file name
    page,       // current page
    pageCount,  // total pages
    categories, // current categories with pages and colors

    // MultiDoc only:
    docId,      // active document id
    mode,       // 'MultiDoc:SinglePage' | 'MultiDoc:MultiPage'
  } = event.data;
});
```

### Behaviour

- Hidden by default — only shown when `isSplitScreen: true` received
- Fixed to bottom of thumbnail panel — never scrolls out of view
- Works in all three modes: SingleDoc, MultiDoc:SinglePage, MultiDoc:MultiPage
- Scroll area gets bottom padding so last thumbnail is never hidden behind the bar

---

## 10. Viewer Configuration (.env)

```env
# URL of the Split & Merge app iframe (leave empty to disable scissors icon entirely)
VITE_SPLIT_MERGE_URL=https://your-split-merge-app.com

# Restrict which parent origin can postMessage to this viewer (default: * = any)
VITE_PARENT_ORIGIN=https://your-angular-app.com
```

### Build commands

```bash
npm run dev           # local dev  → reads .env.development
npm run build:uat     # UAT build  → reads .env.uat
npm run build:prod    # PROD build → reads .env.production
npm run build         # same as build:prod
```

Create per-environment files: `.env.development`, `.env.uat`, `.env.production`

---

## 11. Coordinate System Reference

All coordinates stored internally as **0–1 fractions** of page dimensions.

### Auto-detection (batch across all captures on the same page)

| Condition | Detected as | Reference dims |
|---|---|---|
| All values ≤ 1.0 | Already normalised | None — pass-through |
| maxCoord > pts page width, fits in px@96 | Pixels @96dpi | `pageW × 96/72` |
| maxCoord ≤ pts page width | Points (72dpi) | pts dims from PDF |
| PDF UserUnit > 1 (e.g. reported 2550×3299) | Stripped to real pts first | 612×792 effective |

Detection is **batch-based** — one unit detected from the global maximum across all items on the same page. Never per-item.

### FORMAT 10 — page-prefixed bbox

```ts
{ value: 'Name', bbox: [1, 125, 157, 138, 12] }
//                      ↑pg  ↑x   ↑y   ↑w   ↑h
// Page is extracted from bbox[0]
// CAPTURE_PREVIEW sends back { bbox: [1,125,157,138,12] } verbatim
```

### All supported formats

| Format | Example |
|---|---|
| Flat x/y | `{ x, y, width, height }` |
| bbox 4-element | `{ bbox: [x, y, w, h] }` |
| FORMAT 10 page-prefixed | `{ bbox: [page, x, y, w, h] }` |
| rectangle | `{ rectangle: [x1,y1,x2,y2] }` |
| coordinates | `{ coordinates: [ymin, xmin, ymax, xmax] }` |
| xmin/ymin | `{ xmin, ymin, xmax, ymax }` |
| bbox_relative polygon | `{ bbox_relative: [[x,y],[x,y],[x,y],[x,y]] }` |
| CSS left/top | `{ left, top, width, height }` |
| Corner points | `{ left, right, top, bottom }` |

---

*DocCapture Viewer — Integration Guide · Updated Session 6*
