// ── Viewer configuration ──────────────────────────────────────────────────────
// All environment-specific values live here.
// Set these in .env (local dev) or in your deployment environment.
//
// To create a local config:
//   cp .env.example .env
//   # Edit .env and set VITE_SPLIT_MERGE_URL=https://your-app.com
//
// Vite injects VITE_* variables at build time via import.meta.env.

/**
 * URL of the Split & Merge application iframe.
 * Set VITE_SPLIT_MERGE_URL in your .env or deployment environment.
 * Leave empty to disable the Split & Merge feature entirely.
 *
 * Example (.env):
 *   VITE_SPLIT_MERGE_URL=https://splitmerge.your-domain.com
 */
export const SPLIT_MERGE_URL: string =
  (import.meta as any).env?.VITE_SPLIT_MERGE_URL ?? '';

/**
 * Allowed parent origin for postMessage security.
 * Defaults to '*' (any origin) — restrict in production.
 */
export const PARENT_ORIGIN: string =
  (import.meta as any).env?.VITE_PARENT_ORIGIN ?? '*';
