// xlsxWorker — parses XLSX/XLS/CSV entirely off the main thread.
//
// Inbound:  { type:'parse', buffer:ArrayBuffer, isLarge?:boolean, isCsv?:boolean, fileName?:string }
// Outbound: { type:'done', sheets:SheetData[] } | { type:'error', message:string }

import * as XLSX from 'xlsx';

export interface CellStyle  { fillRgb: string; }
export interface ColInfo    { wpx: number; }
export interface RowInfo    { hpx: number; hidden: boolean; }
export interface MergeRange { s:{r:number;c:number}; e:{r:number;c:number}; }
export interface SheetData  {
  name: string; rows: string[][];
  colCount: number; rowCount: number;
  styles?:  (CellStyle|null)[][] | null;
  colInfos?: ColInfo[]; rowInfos?: RowInfo[]; merges?: MergeRange[];
}

// ── CSV parser ────────────────────────────────────────────────────────────────
function parseCsv(text: string, fileName: string): SheetData {
  const rows: string[][] = [];
  let cur = '', inQuote = false;
  let curRow: string[] = [];

  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    const next = text[i + 1];
    if (ch === '"') {
      if (inQuote && next === '"') { cur += '"'; i++; }
      else inQuote = !inQuote;
    } else if (!inQuote && (ch === ',' || ch === '\t')) {
      curRow.push(cur); cur = '';
    } else if (!inQuote && ch === '\n') {
      curRow.push(cur); cur = '';
      rows.push(curRow); curRow = [];
    } else if (!inQuote && ch === '\r' && next === '\n') {
      curRow.push(cur); cur = '';
      rows.push(curRow); curRow = [];
      i++; // skip \n
    } else {
      cur += ch;
    }
  }
  // Last row
  if (curRow.length > 0 || cur) {
    curRow.push(cur);
    if (curRow.some(v => v.trim())) rows.push(curRow);
  }

  const colCount = Math.max(0, ...rows.map(r => r.length));
  const colInfos: ColInfo[] = Array.from({ length: colCount }, () => ({ wpx: 120 }));
  const rowInfos: RowInfo[] = Array.from({ length: rows.length }, () => ({ hpx: 22, hidden: false }));

  return {
    name: (fileName ?? 'Sheet1').replace(/\.csv$/i, ''),
    rows, colCount, rowCount: rows.length,
    colInfos, rowInfos, styles: null, merges: [],
  };
}

// ── XLSX parser ───────────────────────────────────────────────────────────────
function parseXlsx(buffer: ArrayBuffer, isLarge: boolean): SheetData[] {
  const wb = (XLSX as any).read(new Uint8Array(buffer), {
    type:       'array',
    cellStyles: !isLarge,
    cellDates:  true,
    dense:      false,
  });

  const sheets: SheetData[] = [];
  for (const name of wb.SheetNames) {
    const ws = wb.Sheets[name] as Record<string, any>;
    const range = (XLSX as any).utils.decode_range(ws['!ref'] || 'A1');
    const R = range.e.r + 1;
    const C = range.e.c + 1;

    const rows:   string[][] = [];
    const styles: (CellStyle|null)[][] = [];

    for (let r = 0; r <= range.e.r; r++) {
      const row:      string[]           = [];
      const styleRow: (CellStyle|null)[] = [];
      for (let c = 0; c <= range.e.c; c++) {
        const addr = (XLSX as any).utils.encode_cell({ r, c });
        const cell = ws[addr];
        if (!cell) { row.push(''); styleRow.push(null); continue; }
        const val = cell.w != null ? String(cell.w)
                  : cell.v != null ? String(cell.v) : '';
        row.push(val);
        const fillRgb = cell.s?.fgColor?.rgb ?? cell.s?.patternFg?.rgb ?? null;
        styleRow.push(
          fillRgb && cell.s?.patternType !== 'none' && fillRgb !== 'FFFFFF' && fillRgb !== 'ffffff'
            ? { fillRgb } : null
        );
      }
      rows.push(row);
      styles.push(styleRow);
    }

    const colInfos: ColInfo[] = [];
    const rawCols: any[] = ws['!cols'] ?? [];
    for (let c = 0; c < C; c++) {
      const col = rawCols[c];
      colInfos.push({ wpx: col?.wpx ?? (col?.width ? Math.round(col.width * 7) : 96) });
    }

    const rowInfos: RowInfo[] = [];
    const rawRows: any[] = ws['!rows'] ?? [];
    for (let r = 0; r < R; r++) {
      const row = rawRows[r];
      rowInfos.push({ hpx: row?.hpx ?? 22, hidden: row?.hidden ?? false });
    }

    const merges: MergeRange[] = (ws['!merges'] ?? []).map((m: any) => ({
      s: { r: m.s.r, c: m.s.c }, e: { r: m.e.r, c: m.e.c },
    }));

    sheets.push({ name, rows, colCount: C, rowCount: R, styles, colInfos, rowInfos, merges });
  }
  return sheets;
}

// ── Message handler ───────────────────────────────────────────────────────────
self.onmessage = async (e: MessageEvent) => {
  const { type, buffer, isLarge = false, isCsv = false, fileName = 'Sheet1' } = e.data;
  if (type !== 'parse') return;
  try {
    if (isCsv) {
      const text   = new TextDecoder().decode(buffer);
      const sheet  = parseCsv(text, fileName);
      self.postMessage({ type: 'done', sheets: [sheet] });
    } else {
      const sheets = parseXlsx(buffer, isLarge);
      self.postMessage({ type: 'done', sheets });
    }
  } catch (err) {
    self.postMessage({ type: 'error', message: String(err) });
  }
};
