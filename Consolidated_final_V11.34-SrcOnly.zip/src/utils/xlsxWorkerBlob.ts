// xlsxWorkerBlob.ts — loads xlsxWorker.js from public/

export interface SheetImage {
  src:      string;   // data URI (data:image/png;base64,...)
  colStart: number;   // 0-based column of top-left anchor
  rowStart: number;   // 0-based row of top-left anchor
  colEnd:   number;   // 0-based column of bottom-right anchor (fallback only)
  rowEnd:   number;   // 0-based row of bottom-right anchor (fallback only)
  widthPx:  number;   // exact pixel width from EMU (0 = use col span fallback)
  heightPx: number;   // exact pixel height from EMU (0 = use row span fallback)
}

export interface SheetResult {
  name:       string;
  rowCount:   number;
  colCount:   number;
  flatBuf:    Uint8Array;   // all rows encoded as UTF-8: rows\n, cols\t
  rowOffsets: Uint32Array;  // byte offset of each row in flatBuf (Transferable)
  colW:       Int16Array;
  rowH:       Int16Array;   // -1 sentinel means hidden row
  merges:     Array<{s:{r:number;c:number};e:{r:number;c:number}}>;
  stylesJson: string | null; // compact JSON: { [r]: { [c]: CellStyleCompact } }
  images:     SheetImage[];
}

let _worker: Worker | null = null;
let _ready   = false;
let _queue:  Array<()=>void> = [];
let _pending = new Map<number, {resolve:Function; reject:Function}>();
let _id      = 1;

function getWorker(): Promise<Worker> {
  if (!_worker) {
    const workerUrl = new URL('/xlsxWorker.js', document.baseURI).href;
    const xlsxUrl   = new URL('/xlsx.full.min.js', document.baseURI).href;
    _worker = new Worker(workerUrl);

    _worker.onmessage = (e: MessageEvent) => {
      if (e.data.type === 'ready') {
        _ready = true;
        _queue.splice(0).forEach(fn => fn());
        return;
      }
      const p = _pending.get(e.data.id);
      if (!p) return;
      _pending.delete(e.data.id);
      if (e.data.error) p.reject(new Error(e.data.error));
      else               p.resolve(e.data.sheets);
    };

    _worker.onerror = (err) => {
      console.error('[xlsxWorker]', err.message);
      _worker = null; _ready = false;
      _pending.forEach(p => p.reject(new Error(err.message)));
      _pending.clear(); _queue = [];
    };

    _worker.postMessage({ type: 'init', url: xlsxUrl });
  }
  if (_ready) return Promise.resolve(_worker);
  return new Promise(resolve => { _queue.push(() => resolve(_worker!)); });
}

export async function parseXlsx(buffer: ArrayBuffer): Promise<SheetResult[]> {
  const id     = _id++;
  const worker = await getWorker();
  return new Promise((resolve, reject) => {
    _pending.set(id, { resolve, reject });
    worker.postMessage({ type: 'parse', id, buffer }, [buffer]);
  });
}

export function prewarm(): void { getWorker().catch(() => {}); }

if (typeof window !== 'undefined') {
  setTimeout(() => getWorker().catch(() => {}), 300);
}
