// pdfResourceCache — pre-loads all pdfjs fonts and CMaps into memory.
//
// WHY: pdfjs fetches /cmaps/*.bcmap and /standard_fonts/*.pfb on every
// document open and on every page that uses a new font. Over a slow network
// this causes 200-800ms delays PER PAGE. By serving from memory we eliminate
// all network dependency for these resources after the first load.
//
// HOW: We fetch all font files once eagerly (they total ~2MB), cache them in
// a Map, then pass custom CMapReaderFactory and StandardFontDataFactory to
// getDocument() that serve from the in-memory cache.

const fontCache  = new Map<string, Uint8Array>();
// Resolve paths relative to deployed base — works at any sub-path
const _pdfBase = () => (import.meta.env.BASE_URL || '/').replace(/\/$/, '');
const cmapCache  = new Map<string, Uint8Array>();

let fontLoadPromise:  Promise<void> | null = null;
let cmapLoadPromise:  Promise<void> | null = null;

// Standard font filenames shipped with pdfjs
const STANDARD_FONTS = [
  'FoxitDingbats.pfb',
  'FoxitFixed.pfb', 'FoxitFixedBold.pfb', 'FoxitFixedBoldItalic.pfb', 'FoxitFixedItalic.pfb',
  'FoxitSerif.pfb', 'FoxitSerifBold.pfb', 'FoxitSerifBoldItalic.pfb', 'FoxitSerifItalic.pfb',
  'FoxitSymbol.pfb',
  'LiberationSans-Bold.ttf', 'LiberationSans-BoldItalic.ttf',
  'LiberationSans-Italic.ttf', 'LiberationSans-Regular.ttf',
];

// ── Eager preload ─────────────────────────────────────────────────────────────

async function fetchBinary(url: string): Promise<Uint8Array> {
  const res = await fetch(url, { cache: 'force-cache' });
  return new Uint8Array(await res.arrayBuffer());
}

/** Call once at app startup (e.g. after React mounts). Fire-and-forget. */
export function preloadPdfResources(): void {
  // Fonts — ~770KB total, load eagerly
  if (!fontLoadPromise) {
    fontLoadPromise = Promise.all(
      STANDARD_FONTS.map(async name => {
        try {
          fontCache.set(name, await fetchBinary(new URL(_pdfBase()+`/standard_fonts/${name}`, document.baseURI).href));
        } catch (_) { /* network unavailable — pdfjs will fall back to URL */ }
      })
    ).then(() => {});
  }

  // CMaps — 169 files, ~1.2MB total.
  // We don't eagerly load ALL cmaps (too many requests).
  // Instead we cache on-demand (first access per name) — see InMemoryCMapFactory.
  // But we DO preload the 10 most common ones used by standard PDFs:
  const COMMON_CMAPS = [
    'Adobe-GB1-UCS2', 'Adobe-CNS1-UCS2', 'Adobe-Japan1-UCS2', 'Adobe-Korea1-UCS2',
    'Identity-H', 'Identity-V', 'UniGB-UCS2-H', 'UniCNS-UCS2-H',
    'UniJIS-UCS2-H', 'UniKS-UCS2-H',
  ];
  if (!cmapLoadPromise) {
    cmapLoadPromise = Promise.all(
      COMMON_CMAPS.map(async name => {
        try {
          cmapCache.set(name, await fetchBinary(new URL(_pdfBase()+`/cmaps/${name}.bcmap`, document.baseURI).href));
        } catch (_) {}
      })
    ).then(() => {});
  }
}

// ── Custom factories ──────────────────────────────────────────────────────────

/**
 * Custom CMapReaderFactory — serves from in-memory cache, falls back to fetch.
 * Pass as `CMapReaderFactory` option in `pdfjsLib.getDocument()`.
 */
export class InMemoryCMapReaderFactory {
  private baseUrl: string;
  private isCompressed: boolean;

  constructor({ baseUrl = '/cmaps/', isCompressed = true }: { baseUrl?: string; isCompressed?: boolean } = {}) {
    this.baseUrl     = baseUrl;
    this.isCompressed = isCompressed;
  }

  async fetch({ name }: { name: string }): Promise<{ cMapData: Uint8Array; compressionType: number }> {
    // Serve from cache if available
    if (cmapCache.has(name)) {
      return {
        cMapData:        cmapCache.get(name)!,
        compressionType: this.isCompressed ? 1 : 0,
      };
    }
    // Cache miss — fetch and cache for next time
    try {
      const data = await fetchBinary(`${this.baseUrl}${name}.bcmap`);
      cmapCache.set(name, data);
      return { cMapData: data, compressionType: this.isCompressed ? 1 : 0 };
    } catch (err) {
      throw new Error(`Failed to fetch CMap "${name}": ${err}`);
    }
  }
}

/**
 * Custom StandardFontDataFactory — serves from in-memory cache, falls back to fetch.
 * Pass as `StandardFontDataFactory` option in `pdfjsLib.getDocument()`.
 */
export class InMemoryStandardFontDataFactory {
  private baseUrl: string;

  constructor({ baseUrl = '/standard_fonts/' }: { baseUrl?: string } = {}) {
    this.baseUrl = baseUrl;
  }

  async fetch({ filename }: { filename: string }): Promise<Uint8Array> {
    if (fontCache.has(filename)) {
      return fontCache.get(filename)!;
    }
    // Cache miss — fetch and cache
    try {
      const data = await fetchBinary(`${this.baseUrl}${filename}`);
      fontCache.set(filename, data);
      return data;
    } catch (err) {
      throw new Error(`Failed to fetch font "${filename}": ${err}`);
    }
  }
}
