// xlsxLoader.ts — lazy XLSX loader, isolated so Vite code-splits it properly.
// Import this file with a dynamic import() to avoid bundling xlsx into main chunks.
export { read, utils } from 'xlsx';
