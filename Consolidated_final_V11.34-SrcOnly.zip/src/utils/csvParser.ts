// csvParser.ts — non-blocking CSV parser + XLSX via blob worker
import type { SheetData } from '../adapters/SpreadsheetAdapter';

const macrotask = (): Promise<void> => new Promise(r => setTimeout(r, 0));

// ── CSV: chunked byte-level parser (no XLSX needed) ────────────────────────────
export async function parseCsvAsync(buffer: ArrayBuffer, fileName: string): Promise<SheetData[]> {
  await macrotask(); // let spinner render first

  const bytes = new Uint8Array(buffer);
  const CHUNK = 65536; // yield every 64KB
  const rows: string[][] = [];
  let cur = '', inQ = false, curRow: string[] = [];

  for (let i = 0; i < bytes.length; i++) {
    const b = bytes[i];
    if      (b === 0x22 && inQ && bytes[i+1] === 0x22) { cur += '"'; i++; }
    else if (b === 0x22)                                 { inQ = !inQ; }
    else if (!inQ && b === 0x2C)                         { curRow.push(cur); cur = ''; }
    else if (!inQ && b === 0x0A)                         { curRow.push(cur); cur = ''; if (curRow.some(v=>v)) rows.push(curRow); curRow = []; }
    else if (!inQ && b === 0x0D && bytes[i+1] === 0x0A) { curRow.push(cur); cur = ''; if (curRow.some(v=>v)) rows.push(curRow); curRow = []; i++; }
    else if (b < 0x80)                                   { cur += String.fromCharCode(b); }
    else {
      let code = b, extra = 0;
      if      (b >= 0xF0) { code = b & 0x07; extra = 3; }
      else if (b >= 0xE0) { code = b & 0x0F; extra = 2; }
      else if (b >= 0xC0) { code = b & 0x1F; extra = 1; }
      for (let e = 0; e < extra; e++) { i++; code = (code << 6) | (bytes[i] & 0x3F); }
      cur += String.fromCodePoint(code);
    }
    if (i > 0 && (i % CHUNK) === 0) await macrotask();
  }
  if (curRow.length > 0 || cur) { curRow.push(cur); if (curRow.some(v=>v.trim())) rows.push(curRow); }
  await macrotask();

  // Use reduce instead of Math.max(...) spread — spread causes stack overflow for 20k+ rows
  const colCount = rows.reduce((max, r) => r.length > max ? r.length : max, 0);
  return [{
    name: fileName.replace(/\.csv$/i, ''),
    rows, colCount, rowCount: rows.length,
    colInfos: Array.from({ length: colCount }, () => ({ wpx: 120 })),
    rowInfos: Array.from({ length: rows.length }, () => ({ hpx: 22, hidden: false })),
    styles: undefined, merges: [],
  }];
}

// parseXlsxAsync removed — SpreadsheetAdapter imports parseXlsxInWorker directly
