// ImageViewer — virtual-scroll viewer for TIF/TIFF/PNG/JPEG/DOC pages
// Highlight system: each page owns its own subscription and canvas.
// No shared refs, no memo-staleness, no timing issues with hlRefs registration.

import React, { useEffect, useRef, useCallback, useState, memo } from 'react';
import { useAppStore } from '../store/appStore';
import type { ImageAdapter, ImageFrame } from '../adapters/ImageAdapter';
import { colorToRgba } from '../utils/color';

const PAGE_GAP = 12;
const RADIUS   = 2.5;
const OVERSCAN = 2;

interface ImageViewerProps { adapter: ImageAdapter; zoom: number; }

// ── Rounded rect helper ───────────────────────────────────────────────────────
function rr(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  if (w < 2 || h < 2) return;
  r = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.arcTo(x + w, y, x + w, y + r, r);
  ctx.lineTo(x + w, y + h - r); ctx.arcTo(x + w, y + h, x + w - r, y + h, r);
  ctx.lineTo(x + r, y + h); ctx.arcTo(x, y + h, x, y + h - r, r);
  ctx.lineTo(x, y + r); ctx.arcTo(x, y, x + r, y, r);
  ctx.closePath();
}

// ── Paint one page's highlight canvas ────────────────────────────────────────
// Called directly by each page's own subscription — reads from store at paint time.
// No cached state, no snapshots to go stale — always the freshest values.
// l3c: pre-built Map<page, Map<word, [{x,y,w,h}]>> — passed from per-page subscription
function paintPage(canvas: HTMLCanvasElement, pageNum: number,
  l3c?: Map<number, Map<string, Array<{x:number;y:number;w:number;h:number}>>>) {
  const W = canvas.width;
  const H = canvas.height;
  if (!W || !H) return;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const s    = useAppStore.getState();
  const rects = s.highlightIndex.get(pageNum) ?? [];
  const aid   = s.activeFieldId;

  // Build fwc: exact lowercase — "invoice." ≠ "invoice" (user requirement: exact match only)
  const fwc = new Map<string, string>();
  for (const c of s.captures) fwc.set(c.id, c.value.toLowerCase().trim());
  const activeTxt   = aid ? (fwc.get(aid) ?? '') : '';
  const activeExact = activeTxt; // same — exact match used for both isDup and word matching

  ctx.clearRect(0, 0, W, H);

  // ── Search results ─────────────────────────────────────────────────────────
  for (const r of s.search.results) {
    if (r.page !== pageNum) continue;
    const isCur = s.search.results.indexOf(r) === s.search.currentIndex;
    if (!isCur && !s.search.highlightAll) continue;
    ctx.save();
    if (isCur) {
      ctx.fillStyle = 'rgba(255,140,0,.45)'; ctx.strokeStyle = 'rgba(255,100,0,.95)';
      ctx.lineWidth = 2; ctx.shadowColor = 'rgba(255,140,0,.5)'; ctx.shadowBlur = 6;
    } else {
      ctx.fillStyle = 'rgba(255,220,50,.28)'; ctx.strokeStyle = 'rgba(200,160,0,.65)'; ctx.lineWidth = 1;
    }
    rr(ctx, r.x * W, r.y * H, r.width * W, r.height * H, RADIUS);
    ctx.fill(); ctx.stroke(); ctx.restore();
  }

  // ── Captured boxes ─────────────────────────────────────────────────────────
  // Colour rules (same as PDFViewer):
  //   active field        → YELLOW
  //   same text as active → PINK strong (duplicate value)
  //   other while active  → GREY  (not pink — user confirmed: others stay grey)
  //   nothing active      → GREY
  //   custom color        → that color
  const capturedKeys = new Set<number>();
  for (const rect of rects) {
    capturedKeys.add(Math.round(rect.x * 1000) * 10000 + Math.round(rect.y * 1000));
    const isAct = rect.id === aid;
    const isDup = !isAct && !!activeExact && (fwc.get(rect.id) ?? '') === activeExact;
    ctx.save();
    if (isAct) {
      ctx.shadowColor = 'rgba(220,180,0,.5)'; ctx.shadowBlur = 8;
      ctx.fillStyle = 'rgba(255,230,0,.35)'; ctx.strokeStyle = 'rgb(200,160,0)'; ctx.lineWidth = 2.5;
    } else if (isDup) {
      ctx.fillStyle = 'rgba(255,182,193,.50)'; ctx.strokeStyle = 'rgba(220,80,120,.95)'; ctx.lineWidth = 2.5;
    } else if (rect.color) {
      ctx.fillStyle = colorToRgba(rect.color, .07); ctx.strokeStyle = colorToRgba(rect.color, .95); ctx.lineWidth = 2.5;
    } else {
      ctx.fillStyle = 'rgba(150,150,150,.10)'; ctx.strokeStyle = 'rgba(80,80,80,.90)'; ctx.lineWidth = 2.0;
    }
    const PAD = 0.002;
    const bx = Math.max(0, rect.x - PAD);
    const by = Math.max(0, rect.y - PAD);
    const bw = Math.min(1 - bx, rect.width + PAD * 2);
    const bh = Math.min(1 - by, rect.height + PAD * 2);
    rr(ctx, bx * W, by * H, bw * W, bh * H, RADIUS);
    ctx.fill(); ctx.stroke(); ctx.restore();
  }

  // ── Word occurrences (wordIndex / l3c) ───────────────────────────────────
  // Uses the pre-built l3c cache (passed in) for O(1) per-page lookup.
  // Pages not in l3c have no text data — nothing drawn for those pages.
  // l3c is rebuilt whenever captures or wordIndex changes (see per-page subscription).
  if (l3c) {
    const pl3 = l3c.get(pageNum);
    if (pl3?.size) {
      // Grey for every non-active capture's word
      for (const cap of s.captures) {
        if (cap.id === aid) continue;
        const wt = fwc.get(cap.id) ?? ''; if (!wt) continue;
        const es = pl3.get(wt); if (!es?.length) continue;
        ctx.fillStyle   = cap.color ? colorToRgba(cap.color, .07) : 'rgba(150,150,150,.10)';
        ctx.strokeStyle = cap.color ? colorToRgba(cap.color, .90) : 'rgba(80,80,80,.85)';
        ctx.lineWidth = 2.0;
        for (const e of es) {
          if (capturedKeys.has(Math.round(e.x * 1000) * 10000 + Math.round(e.y * 1000))) continue;
          const wx = Math.max(0, e.x - 0.0015), wy = Math.max(0, e.y - 0.0015);
          rr(ctx, wx * W, wy * H, Math.min(1 - wx, e.w + 0.003) * W, Math.min(1 - wy, e.h + 0.003) * H, RADIUS);
          ctx.fill(); ctx.stroke();
        }
      }
      // Pink for the active field's word
      if (aid && activeTxt) {
        const es = pl3.get(activeTxt); if (es?.length) {
          ctx.fillStyle = 'rgba(255,182,193,.40)'; ctx.strokeStyle = 'rgba(220,80,120,.80)'; ctx.lineWidth = 1.5;
          for (const e of es) {
            if (capturedKeys.has(Math.round(e.x * 1000) * 10000 + Math.round(e.y * 1000))) continue;
            const wx = Math.max(0, e.x - 0.0015), wy = Math.max(0, e.y - 0.0015);
            rr(ctx, wx * W, wy * H, Math.min(1 - wx, e.w + 0.003) * W, Math.min(1 - wy, e.h + 0.003) * H, RADIUS);
            ctx.fill(); ctx.stroke();
          }
        }
      }
    }
  }

  // ── Preview pulse (cyan) ───────────────────────────────────────────────────
  if (s.previewRect?.page === pageNum) {
    const pr = s.previewRect;
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.04)'; ctx.strokeStyle = 'rgba(0,0,0,0.75)';
    ctx.lineWidth = 1.5;
    rr(ctx, pr.x * W, pr.y * H, pr.width * W, pr.height * H, RADIUS);
    ctx.fill(); ctx.stroke(); ctx.restore();
  }
}

// ── Main viewer ───────────────────────────────────────────────────────────────
export function ImageViewer({ adapter, zoom }: ImageViewerProps) {
  const setCurrentPage = useAppStore(s => s.setCurrentPage);
  const rotation       = useAppStore(s => s.rotation);
  const pageCount      = adapter.pageCount;
  const containerRef   = useRef<HTMLDivElement>(null);

  const [visiblePages, setVisiblePages] = useState<Set<number>>(() => new Set([1, 2]));
  const visibleRef = useRef<Set<number>>(new Set([1, 2]));

  useEffect(() => {
    if (containerRef.current) containerRef.current.setAttribute('data-viewer-scroll', '1');
  }, []);

  // ── IntersectionObserver ──────────────────────────────────────────────────
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    const pageVis = new Map<number, number>();

    const obs = new IntersectionObserver(entries => {
      for (const e of entries) {
        const page = Number((e.target as HTMLElement).dataset.pageNumber);
        if (e.isIntersecting) pageVis.set(page, e.intersectionRatio);
        else                  pageVis.delete(page);
      }
      const visible = new Set<number>();
      const sorted  = [...pageVis.keys()].sort((a, b) => a - b);
      if (sorted.length) {
        const first = sorted[0], last = sorted[sorted.length - 1];
        for (let p = Math.max(1, first - OVERSCAN); p <= Math.min(pageCount, last + OVERSCAN); p++) visible.add(p);
        let best = sorted[0], bestR = 0;
        for (const [pg, ratio] of pageVis) if (ratio > bestR) { best = pg; bestR = ratio; }
        setCurrentPage(best);
      }
      const prev = visibleRef.current;
      if (visible.size !== prev.size || [...visible].some(p => !prev.has(p))) {
        visibleRef.current = visible;
        setVisiblePages(new Set(visible));
      }
    }, { root: container, threshold: [0, 0.1, 0.5] });

    container.querySelectorAll<HTMLElement>('[data-page-number]').forEach(el => obs.observe(el));
    return () => obs.disconnect();
  }, [pageCount, setCurrentPage]);

  // Re-render when background decode completes
  useEffect(() => {
    const cb = (page: number) => {
      if (visibleRef.current.has(page)) setVisiblePages(s => new Set(s));
    };
    adapter.onPageRendered(cb);
    return () => adapter.offPageRendered(cb);
  }, [adapter]);

  return (
    <div ref={containerRef} className="flex-1 overflow-y-auto overflow-x-auto bg-[#e8e8e8]">
      <div className="flex flex-col items-center py-4">
        {Array.from({ length: pageCount }, (_, i) => i + 1).map(page => (
          <ImagePageCanvas
            key={page}
            pageNum={page}
            adapter={adapter}
            zoom={zoom}
            rotation={rotation}
            visible={visiblePages.has(page)}
          />
        ))}
      </div>
    </div>
  );
}

// ── l3c builder (non-PDF) ────────────────────────────────────────────────────
// Builds a per-page word lookup from wordIndex, identical to PDFViewer's l3c.
// Called whenever captures or wordIndex changes.
// wordIndex entries: { text, x, y, width, height } — already 0-1 fractions
//   (normalised by applyDocMeta before being stored in the Zustand store).
function buildL3c(
  captures: ReturnType<typeof useAppStore.getState>['captures'],
  wordIndex: Map<number, any[]>
): Map<number, Map<string, Array<{x:number;y:number;w:number;h:number}>>> {
  const l3c = new Map<number, Map<string, Array<{x:number;y:number;w:number;h:number}>>>();
  if (!wordIndex.size || !captures.length) return l3c;

  // Build watch set: exact lowercase capture values
  const watch = new Set<string>();
  for (const c of captures) {
    const wt = c.value.toLowerCase().trim();
    if (wt) watch.add(wt);
  }
  if (!watch.size) return l3c;

  for (const [pg, entries] of wordIndex) {
    if (!Array.isArray(entries)) continue;
    const pm = new Map<string, Array<{x:number;y:number;w:number;h:number}>>();
    for (const e of entries) {
      const wt = (e.text ?? '').toLowerCase().trim();
      if (!wt) continue;
      const ew = e.width ?? e.w ?? 0;
      const eh = e.height ?? e.h ?? 0;
      if (watch.has(wt)) {
        if (!pm.has(wt)) pm.set(wt, []);
        pm.get(wt)!.push({ x: e.x, y: e.y, w: ew, h: eh });
        continue;
      }
      // Multi-word entry: split and match individual words
      if (wt.includes(' ')) {
        const words = wt.split(/\s+/);
        let charsSoFar = 0;
        for (const word of words) {
          if (watch.has(word)) {
            const startFrac = charsSoFar / Math.max(wt.length, 1);
            const widthFrac = word.length / Math.max(wt.length, 1);
            if (!pm.has(word)) pm.set(word, []);
            pm.get(word)!.push({
              x: e.x + startFrac * ew,
              y: e.y,
              w: widthFrac * ew,
              h: eh,
            });
          }
          charsSoFar += word.length + 1;
        }
      }
    }
    if (pm.size) l3c.set(pg, pm);
  }
  return l3c;
}

// ── Per-page canvas ───────────────────────────────────────────────────────────
// Each page owns its own Zustand subscription and highlight canvas.
// No shared hlRefs map, no timing races, no memo-staleness.
interface ImagePageCanvasProps {
  pageNum:  number;
  adapter:  ImageAdapter;
  zoom:     number;
  rotation: number;
  visible:  boolean;
}

const ImagePageCanvas = memo(function ImagePageCanvas({
  pageNum, adapter, zoom, rotation, visible,
}: ImagePageCanvasProps) {
  const wrapperRef  = useRef<HTMLDivElement>(null);
  const canvasRef   = useRef<HTMLCanvasElement>(null);
  const hlCanvasRef = useRef<HTMLCanvasElement>(null);
  const timerRef    = useRef<ReturnType<typeof setTimeout> | null>(null);
  // l3c: pre-indexed word lookup for this page — rebuilt when captures/wordIndex changes.
  // Map<page, Map<word, [{x,y,w,h}]>> — same structure as PDFViewer's cachesRef.current.l3c.
  // For non-PDF (TIFF/PNG/JPG) there is no native text layer; l3c is the ONLY text source.
  // Pages beyond wordIndex coverage will have no entry — nothing drawn, no data available.
  const l3cRef = useRef<Map<number, Map<string, Array<{x:number;y:number;w:number;h:number}>>>>(new Map());

  // DocAdapter uses getPageCanvas() — no getFrame()/getFrameAsync().
  // Synthesise a compatible frame from its canvas so ImagePageCanvas
  // works for both ImageAdapter (TIFF/PNG) and DocAdapter (DOCX).
  const hasGetFrame = typeof (adapter as any).getFrame === 'function';

  const [frame, setFrame] = useState<ImageFrame | null>(() => {
    if (!visible) return null;
    if (hasGetFrame) return (adapter as any).getFrame(pageNum);
    // DocAdapter: build a synthetic frame from its pre-rendered canvas
    const cv = (adapter as any).getPageCanvas?.(pageNum);
    if (!cv || cv.width === 0) return null;
    return { bitmap: cv as any, width: cv.width, height: cv.height };
  });

  const dims     = adapter.getPageDimensions(pageNum);
  const isFlipped = rotation === 90 || rotation === 270;
  const baseW    = dims ? (isFlipped ? dims.height : dims.width)  : 0;
  const baseH    = dims ? (isFlipped ? dims.width  : dims.height) : 0;
  const displayW = Math.round(baseW * zoom);
  const displayH = Math.round(baseH * zoom);

  // Register page element with adapter
  useEffect(() => {
    adapter.registerPageElement(pageNum, wrapperRef.current);
    return () => adapter.registerPageElement(pageNum, null);
  }, [adapter, pageNum]);

  // Fetch frame when visible
  useEffect(() => {
    if (!visible) return;
    if (hasGetFrame) {
      // ImageAdapter path — async decode with LRU cache
      const cached = (adapter as any).getFrame(pageNum);
      if (cached) { setFrame(cached); return; }
      (adapter as any).getFrameAsync(pageNum)
        .then((f: ImageFrame | null) => setFrame(f))
        .catch(() => {});
    } else {
      // DocAdapter path — pages are pre-rendered synchronously;
      // poll until the canvas is ready (DocAdapter renders on first access)
      const tryGet = () => {
        const cv = (adapter as any).getPageCanvas?.(pageNum);
        if (cv && cv.width > 0) {
          setFrame({ bitmap: cv as any, width: cv.width, height: cv.height });
        } else {
          // Canvas not ready yet — retry after adapter signals ready
          (adapter as any).onPageRendered?.((p: number) => {
            if (p === pageNum) {
              const c = (adapter as any).getPageCanvas?.(pageNum);
              if (c && c.width > 0) setFrame({ bitmap: c as any, width: c.width, height: c.height });
            }
          });
        }
      };
      tryGet();
    }
  }, [visible, adapter, pageNum, hasGetFrame]);

  // Draw image — works for both ImageBitmap (TIFF/PNG) and HTMLCanvasElement (DOCX)
  useEffect(() => {
    if (!visible || !frame) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    // Guard: frame.bitmap may be a closed ImageBitmap or a detached canvas
    const src = frame.bitmap as any;
    if (!src) return;
    try {
      canvas.width  = displayW;
      canvas.height = displayH;
      const ctx = canvas.getContext('2d')!;
      ctx.clearRect(0, 0, displayW, displayH);
      ctx.save();
      ctx.translate(displayW / 2, displayH / 2);
      ctx.rotate((rotation * Math.PI) / 180);
      ctx.drawImage(src,
        -(frame.width * zoom) / 2, -(frame.height * zoom) / 2,
        frame.width * zoom, frame.height * zoom,
      );
      ctx.restore();
      adapter.notifyPageRendered(pageNum);
    } catch (_) {
      // Closed bitmap or disposed adapter — silently skip
    }
  }, [frame, zoom, rotation, adapter, pageNum, visible, displayW, displayH]);

  // ── Highlight redraw helper — always reads fresh from store ───────────────
  const repaint = useCallback(() => {
    const hl = hlCanvasRef.current;
    if (!hl || !hl.width || !hl.height) return;
    paintPage(hl, pageNum, l3cRef.current);
  }, [pageNum]);

  // ── Size hl canvas and paint when dims/visibility/frame changes ───────────
  useEffect(() => {
    const hl = hlCanvasRef.current;
    if (!hl || !visible || !displayW || !displayH) return;
    hl.width  = displayW;
    hl.height = displayH;
    repaint();
  }, [displayW, displayH, visible, frame, repaint]);

  // ── Per-page store subscription ───────────────────────────────────────────
  // Rebuilds l3c when captures or wordIndex changes, then repaints.
  useEffect(() => {
    // Seed l3c on mount
    const s0 = useAppStore.getState();
    l3cRef.current = buildL3c(s0.captures, s0.wordIndex);

    const unsub = useAppStore.subscribe((n, p) => {
      const changed =
        n.captures            !== p.captures            ||
        n.activeFieldId       !== p.activeFieldId       ||
        n.highlightIndex      !== p.highlightIndex      ||
        n.wordIndex           !== p.wordIndex           ||
        n.previewRect         !== p.previewRect         ||
        n.search.results      !== p.search.results      ||
        n.search.currentIndex !== p.search.currentIndex ||
        n.search.highlightAll !== p.search.highlightAll;
      if (!changed) return;

      // Rebuild l3c if captures or wordIndex changed — same trigger as PDFViewer rebuildCaches
      if (n.captures !== p.captures || n.wordIndex !== p.wordIndex) {
        l3cRef.current = buildL3c(n.captures, n.wordIndex);
      }

      if (timerRef.current) clearTimeout(timerRef.current);
      timerRef.current = setTimeout(() => {
        timerRef.current = null;
        repaint();
      }, 16);
    });

    // Paint immediately with current state
    repaint();
    return () => {
      unsub();
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [repaint]);

  return (
    <div
      ref={wrapperRef}
      data-page-number={pageNum}
      className="relative shadow-md"
      style={{
        marginBottom: PAGE_GAP,
        width:   displayW || 800,
        height:  displayH || 1100,
        // White background when frame is loaded — prevents the grey viewer
        // background (#e8e8e8) from bleeding through transparent page edges.
        // Grey only used as placeholder colour while the frame is decoding.
        background: (visible && frame) ? '#ffffff' : '#d0d0d0',
        flexShrink: 0,
      }}
    >
      {visible && !frame && displayW > 0 && (
        <div style={{
          position: 'absolute', inset: 0, display: 'flex',
          alignItems: 'center', justifyContent: 'center',
          color: '#888', fontSize: 11,
        }}>
          <div style={{
            width: 20, height: 20, border: '2px solid #bbb',
            borderTopColor: '#1a7fd4', borderRadius: '50%',
            animation: 'spin 0.7s linear infinite',
          }} />
        </div>
      )}
      {visible && frame && (
        <canvas ref={canvasRef} style={{ width: displayW, height: displayH, display: 'block' }} />
      )}
      {!visible && <canvas ref={canvasRef} style={{ display: 'none' }} />}

      {/* Highlight canvas — always mounted when visible so preview box
          shows even before the image has finished decoding */}
      {visible && displayW > 0 && displayH > 0 && (
        <canvas
          ref={hlCanvasRef}
          width={displayW}
          height={displayH}
          style={{
            position: 'absolute', inset: 0,
            width: displayW, height: displayH,
            pointerEvents: 'none', zIndex: 11,
          }}
        />
      )}
    </div>
  );
});
