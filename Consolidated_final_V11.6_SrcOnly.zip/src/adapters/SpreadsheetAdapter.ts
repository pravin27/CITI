// ─────────────────────────────────────────────────────────────────────────────
// SpreadsheetAdapter — SheetJS for XLS/XLSX, Papa Parse for CSV
// Each sheet = one "page". Cell regions mapped to fractional coords.
// ─────────────────────────────────────────────────────────────────────────────

import type { ViewerAdapter } from './types';

// Cell fill color (background) — from cell.s.fgColor.rgb when cellStyles:true
export interface CellStyle {
  fillRgb?: string;   // 6-char hex e.g. "4472C4" — background fill color
}

// Column metadata from ws['!cols']
export interface ColInfo {
  wpx: number;        // width in pixels
}

// Row metadata from ws['!rows']
export interface RowInfo {
  hpx: number;        // height in pixels
  hidden?: boolean;
}

// Merged cell range from ws['!merges']
export interface MergeRange {
  s: { r: number; c: number }; // start row/col (0-based)
  e: { r: number; c: number }; // end   row/col (0-based)
}

export interface SheetData {
  name:     string;
  // rows[r][c] = display text (cell.w for formatted, cell.v stringified otherwise)
  rows:     string[][];
  colCount: number;
  rowCount: number;
  // Style metadata — all optional, only populated when reading .xlsx/.xls
  styles?:  (CellStyle | null)[][];   // styles[r][c]
  colInfos?: ColInfo[];               // one per column
  rowInfos?: RowInfo[];               // one per row
  merges?:  MergeRange[];            // merged cell regions
}

export class SpreadsheetAdapter implements ViewerAdapter {
  pageCount = 0;

  private _sheets: SheetData[] = [];
  private _readyCallbacks: Array<() => void> = [];
  private _pageRenderedCallbacks: Array<(page: number) => void> = [];
  private _pageElements = new Map<number, HTMLElement>();
  private _renderedPages = new Set<number>();
  private _isReady = false;
  private _currentPage = 1;
  // Offscreen canvas cache: one per sheet (page), populated on first render.
  // Allows thumbnails to render for sheets that aren't currently active in the DOM.
  private _thumbnailCanvases = new Map<number, HTMLCanvasElement>();
  private _scrollContainers = new Map<number, HTMLElement>();

  async loadFile(file: File): Promise<void> {
    const isCsv = /\.csv$/i.test(file.name);
    if (isCsv) {
      await this._loadCsv(file);
    } else {
      await this._loadXlsx(file);
    }
    this._isReady = true;
    this.pageCount = this._sheets.length;
    this._readyCallbacks.forEach(cb => cb());
    this._readyCallbacks = [];
  }

  private async _loadXlsx(file: File): Promise<void> {
    const XLSX = await import('xlsx');
    const buffer = await file.arrayBuffer();

    // cellStyles:true → populates cell.s.fgColor for background fills
    // cellDates:true  → parses date serial numbers to Date objects (cell.w gets formatted)
    const wb = (XLSX as any).read(buffer, {
      type:       'array',
      cellStyles: true,
      cellDates:  true,
    });

    this._sheets = wb.SheetNames.map((name: string) => {
      const ws = wb.Sheets[name] as Record<string, any>;

      // ── Display text rows ─────────────────────────────────────────────────
      // Use cell.w (formatted display string) when available, otherwise cell.v
      const range = (XLSX as any).utils.decode_range(ws['!ref'] || 'A1');
      const R = range.e.r + 1; // row count
      const C = range.e.c + 1; // col count

      const rows: string[][] = [];
      const styles: (CellStyle | null)[][] = [];

      for (let r = 0; r <= range.e.r; r++) {
        const row: string[] = [];
        const styleRow: (CellStyle | null)[] = [];
        for (let c = 0; c <= range.e.c; c++) {
          const addr = (XLSX as any).utils.encode_cell({ r, c });
          const cell = ws[addr];
          if (!cell) {
            row.push('');
            styleRow.push(null);
            continue;
          }
          // Prefer cell.w (formatted display text: dates, currency, %)
          // Fall back to cell.v stringified
          const val = cell.w != null ? String(cell.w)
            : cell.v != null ? String(cell.v) : '';
          row.push(val);

          // Extract fill color from cell.s (only fill is reliably available)
          const fillRgb = cell.s?.fgColor?.rgb ?? cell.s?.patternFg?.rgb ?? null;
          // Ignore white/none fills (patternType=none means no fill)
          styleRow.push(
            fillRgb && cell.s?.patternType !== 'none' && fillRgb !== 'FFFFFF' && fillRgb !== 'ffffff'
              ? { fillRgb }
              : null
          );
        }
        rows.push(row);
        styles.push(styleRow);
      }

      // ── Column widths ─────────────────────────────────────────────────────
      const colInfos: ColInfo[] = [];
      const rawCols: any[] = ws['!cols'] ?? [];
      for (let c = 0; c < C; c++) {
        const col = rawCols[c];
        colInfos.push({ wpx: col?.wpx ?? col?.width ? Math.round(col.width * 7) : 96 });
      }

      // ── Row heights ───────────────────────────────────────────────────────
      const rowInfos: RowInfo[] = [];
      const rawRows: any[] = ws['!rows'] ?? [];
      for (let r = 0; r < R; r++) {
        const row = rawRows[r];
        rowInfos.push({ hpx: row?.hpx ?? 22, hidden: row?.hidden ?? false });
      }

      // ── Merges ────────────────────────────────────────────────────────────
      const merges: MergeRange[] = (ws['!merges'] ?? []).map((m: any) => ({
        s: { r: m.s.r, c: m.s.c },
        e: { r: m.e.r, c: m.e.c },
      }));

      return {
        name,
        rows,
        colCount: C,
        rowCount: R,
        styles,
        colInfos,
        rowInfos,
        merges,
      } satisfies SheetData;
    });
  }

  private async _loadCsv(file: File): Promise<void> {
    const Papa = await import('papaparse');
    const text = await file.text();
    const result = Papa.default.parse<string[]>(text, {
      header: false,
      skipEmptyLines: false,
    });
    const rows = result.data as string[][];
    const colCount = Math.max(0, ...rows.map(r => r.length));
    this._sheets = [{
      name: file.name.replace(/\.csv$/i, ''),
      rows,
      colCount,
      rowCount: rows.length,
    }];
  }

  getSheet(page: number): SheetData | null {
    return this._sheets[page - 1] ?? null;
  }

  getAllSheets(): SheetData[] {
    return this._sheets;
  }

  /** Convert cell (row, col) 0-based to fractional coords */
  cellToFrac(
    page: number,
    row: number, col: number,
    rowSpan = 1, colSpan = 1
  ): { x: number; y: number; width: number; height: number } | null {
    const sheet = this._sheets[page - 1];
    if (!sheet) return null;
    const { rowCount, colCount } = sheet;
    if (!rowCount || !colCount) return null;
    return {
      x: col / colCount,
      y: row / rowCount,
      width: colSpan / colCount,
      height: rowSpan / rowCount,
    };
  }

  /** Convert fractional coords back to (row, col) range */
  fracToCell(
    page: number,
    x: number, y: number, w: number, h: number
  ): { rowStart: number; rowEnd: number; colStart: number; colEnd: number } | null {
    const sheet = this._sheets[page - 1];
    if (!sheet) return null;
    const { rowCount, colCount } = sheet;
    return {
      colStart: Math.floor(x * colCount),
      rowStart: Math.floor(y * rowCount),
      colEnd: Math.floor((x + w) * colCount),
      rowEnd: Math.floor((y + h) * rowCount),
    };
  }

  // DOM registration
  registerPageElement(page: number, el: HTMLElement | null) {
    if (el) this._pageElements.set(page, el);
    else this._pageElements.delete(page);
  }

  registerScrollContainer(page: number, el: HTMLElement | null) {
    if (el) this._scrollContainers.set(page, el);
    else this._scrollContainers.delete(page);
  }

  notifyPageRendered(page: number) {
    this._renderedPages.add(page);
    this._pageRenderedCallbacks.forEach(cb => cb(page));
  }

  // ── ViewerAdapter implementation ──────────────────────────────────────────

  navigateToPage(page: number): void {
    // Note: this default implementation is overridden by the store (appStore.ts)
    // which calls set({ currentPage: p }) directly. This fallback just updates
    // the internal state in case the override hasn't been applied yet.
    this._currentPage = Math.max(1, Math.min(this.pageCount, page));
    this._pageRenderedCallbacks.forEach(cb => cb(this._currentPage));
  }

  getCurrentPage(): number {
    return this._currentPage;
  }

  getPageDimensions(page: number): { width: number; height: number } | null {
    // For spreadsheets we return the rendered table element dimensions
    const el = this._pageElements.get(page);
    if (el) return { width: el.clientWidth, height: el.clientHeight };
    // Fallback virtual size
    return { width: 1000, height: 1000 };
  }

  /** Called by SpreadsheetViewer after a sheet renders — stores an offscreen snapshot */
  storeSheetSnapshot(page: number, sourceCanvas: HTMLCanvasElement): void {
    // Copy into an offscreen canvas so it persists even when the sheet unmounts
    const off = document.createElement('canvas');
    off.width  = sourceCanvas.width;
    off.height = sourceCanvas.height;
    const ctx = off.getContext('2d');
    if (ctx) ctx.drawImage(sourceCanvas, 0, 0);
    this._thumbnailCanvases.set(page, off);
  }

  getPageCanvas(page: number): HTMLCanvasElement | null {
    // Prefer cached offscreen snapshot (works for inactive sheets too)
    if (this._thumbnailCanvases.has(page)) return this._thumbnailCanvases.get(page)!;
    // Fallback: live DOM canvas (only available for active sheet)
    const el = this._pageElements.get(page);
    return el?.querySelector('canvas') ?? null;
  }

  getPageElement(page: number): HTMLElement | null {
    return this._pageElements.get(page) ?? null;
  }

  getRenderedPages(): Set<number> {
    return new Set([this._currentPage]);
  }

  onReady(cb: () => void): void {
    if (this._isReady) cb();
    else this._readyCallbacks.push(cb);
  }

  onPageRendered(cb: (page: number) => void): void {
    this._pageRenderedCallbacks.push(cb);
  }

  offPageRendered(cb: (page: number) => void): void {
    const idx = this._pageRenderedCallbacks.indexOf(cb);
    if (idx !== -1) this._pageRenderedCallbacks.splice(idx, 1);
  }

  dispose() {
    this._sheets = [];
    this._readyCallbacks = [];
    this._pageRenderedCallbacks = [];
    this._pageElements.clear();
    this._renderedPages.clear();
    this._thumbnailCanvases.clear();
    this._isReady = false;
    this.pageCount = 0;
  }
}
