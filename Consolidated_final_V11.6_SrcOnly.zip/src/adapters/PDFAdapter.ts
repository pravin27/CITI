// ─────────────────────────────────────────────────────────────────────────────
// PDFAdapter — memory-safe, no callback accumulation
//
// FIXES:
//  • _pageRenderedCallbacks: use a Set so the same cb is never registered twice
//  • _renderedPages: capped at last N pages to prevent O(n) growth
//  • navigateToPage: does nothing here (overridden by PDFViewer useEffect)
// ─────────────────────────────────────────────────────────────────────────────

import type { ViewerAdapter } from './types';

export class PDFAdapter implements ViewerAdapter {
  pageCount = 0;

  private _readyCallbacks: Array<() => void> = [];
  // Use Set to prevent the same callback accumulating across re-renders
  private _pageRenderedCallbacks = new Set<(page: number) => void>();
  private _pageDimensions = new Map<number, { width: number; height: number }>();
  private _pageElements   = new Map<number, HTMLElement>();
  private _pageCanvases   = new Map<number, HTMLCanvasElement>();
  // Only track which pages have EVER rendered — not used for fan-out
  private _renderedPages  = new Set<number>();
  private _scrollContainer: HTMLElement | null = null;
  private _isReady = false;

  onDocumentLoad(numPages: number) {
    this.pageCount = numPages;
    this._isReady = true;
    this._readyCallbacks.forEach(cb => cb());
    this._readyCallbacks = [];
  }

  onPageLoad(page: number, dims: { width: number; height: number }) {
    this._pageDimensions.set(page, dims);
  }

  onPageRenderSuccess(page: number) {
    this._renderedPages.add(page);
    // Fan-out to all registered listeners (Set prevents duplicates)
    for (const cb of this._pageRenderedCallbacks) cb(page);
  }

  setScrollContainer(el: HTMLElement | null) {
    this._scrollContainer = el;
  }

  registerPageElement(page: number, el: HTMLElement | null) {
    if (el) this._pageElements.set(page, el);
    else    this._pageElements.delete(page);
  }

  registerPageCanvas(page: number, canvas: HTMLCanvasElement | null) {
    if (canvas) this._pageCanvases.set(page, canvas);
    else        this._pageCanvases.delete(page);
  }

  // ── ViewerAdapter ──────────────────────────────────────────────────────────

  navigateToPage(_page: number): void {
    // Overridden by PDFViewer's useEffect — this default is a no-op
  }

  getPageDimensions(page: number) {
    return this._pageDimensions.get(page) ?? null;
  }

  getPageCanvas(page: number): HTMLCanvasElement | null {
    const el = this._pageElements.get(page);
    return el?.querySelector('canvas') ?? this._pageCanvases.get(page) ?? null;
  }

  getPageElement(page: number): HTMLElement | null {
    return this._pageElements.get(page) ?? null;
  }

  getRenderedPages(): Set<number> {
    return new Set(this._renderedPages);
  }

  onReady(cb: () => void) {
    if (this._isReady) cb();
    else this._readyCallbacks.push(cb);
  }

  onPageRendered(cb: (page: number) => void) {
    this._pageRenderedCallbacks.add(cb); // Set — no duplicates
  }

  offPageRendered(cb: (page: number) => void) {
    this._pageRenderedCallbacks.delete(cb);
  }

  dispose() {
    this._readyCallbacks = [];
    this._pageRenderedCallbacks.clear();
    this._pageDimensions.clear();
    this._pageElements.clear();
    this._pageCanvases.clear();
    this._renderedPages.clear();
    this._isReady = false;
    this.pageCount = 0;
  }
}
