// ─────────────────────────────────────────────────────────────────────────────
// DocAdapter — DOCX / DOC / TXT viewer
//
// Handles THREE document types:
//
//  1. DIGITAL DOCX/DOC — paragraphs of text, headings, lists
//     mammoth → HTML → paginate → render text to canvas
//
//  2. IMAGE-BASED DOCX/DOC — scanned pages embedded as PNG/JPEG/WMF/EMF
//     mammoth.images.dataUri → base64 data URIs → load Image → draw to canvas
//     Each full-page image becomes its own page canvas.
//     These docs are treated identically to TIF/PNG files after decoding.
//
//  3. MIXED DOCX/DOC — combination of digital text and inline images
//     Text paragraphs and images rendered together in reading order.
//     Inline images (< 70% page width) drawn at natural size within text flow.
//     Full-page images (≥ 70% page width) rendered as standalone pages.
//
//  4. TXT — plain text, monospace, 52 lines per page
//
// ALL FORMATS produce:
//   • Array of <canvas> elements (one per page) — used by ImageViewer
//   • Word index entries — used by search, click2pick, duplicate highlight
//   • getPageCanvas() — for thumbnails
//   • navigateToPage() — instant scroll via data-viewer-scroll container
//
// PERFORMANCE:
//   • mammoth runs once, pages rendered sequentially in one pass
//   • Image decoding uses Promise.all — parallel for multi-image docs
//   • Canvas elements cached — no re-render on zoom (CSS zoom handles it)
//   • No DOM nodes left in document after rendering (hidden host removed)
// ─────────────────────────────────────────────────────────────────────────────

import type { ViewerAdapter } from './types';

const PAGE_W     = 794;   // A4 at 96 dpi, portrait
const PAGE_H     = 1123;
const MARGIN     = 52;    // px inside each edge
const CONTENT_W  = PAGE_W - MARGIN * 2;
const CONTENT_H  = PAGE_H - MARGIN * 2;
const LINE_H_TXT = 19;    // monospace line height
const LINE_H_DOC = 22;    // serif body line height
const LINES_TXT  = 52;    // lines per TXT page

// An image is "full page" if its natural width fills ≥ 70 % of the content area
const FULL_PAGE_THRESHOLD = 0.70;

export interface DocWordEntry {
  text:   string;
  page:   number;
  x:      number; // 0-1 fraction
  y:      number;
  width:  number;
  height: number;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function makeCanvas(): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const c   = document.createElement('canvas');
  c.width   = PAGE_W;
  c.height  = PAGE_H;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, PAGE_W, PAGE_H);
  ctx.strokeStyle = '#e5e5e5';
  ctx.lineWidth   = 0.5;
  ctx.strokeRect(0.5, 0.5, PAGE_W - 1, PAGE_H - 1);
  return [c, ctx];
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((res, rej) => {
    const img = new Image();
    img.onload  = () => res(img);
    img.onerror = () => rej(new Error('Image load failed'));
    img.src = src;
  });
}

// ── DocAdapter ────────────────────────────────────────────────────────────────

export class DocAdapter implements ViewerAdapter {
  pageCount = 0;

  private _canvases:   HTMLCanvasElement[]                  = [];
  private _wordIndex:  DocWordEntry[]                       = [];
  private _pageEls   = new Map<number, HTMLElement>();
  private _rendCbs:  Array<(p: number) => void>            = [];
  private _readyCbs: Array<() => void>                      = [];
  private _isReady   = false;

  // ── Public entry point ────────────────────────────────────────────────────

  async loadFile(file: File): Promise<void> {
    const ext = file.name.split('.').pop()?.toLowerCase() ?? '';
    try {
      if (ext === 'txt') {
        await this._loadTxt(file);
      } else {
        await this._loadDocx(file);
      }
    } catch (err) {
      console.error('[DocAdapter] load failed:', err);
      // Produce one blank error page so the viewer doesn't hang
      const [c] = makeCanvas();
      const ctx = c.getContext('2d')!;
      ctx.font      = '14px sans-serif';
      ctx.fillStyle = '#cc3333';
      ctx.fillText('Failed to load document: ' + String(err), MARGIN, MARGIN + 20);
      this._canvases = [c];
    }
    this.pageCount = this._canvases.length;
    this._isReady  = true;
    this._readyCbs.forEach(cb => cb());
    this._readyCbs = [];
  }

  // ── TXT loader ────────────────────────────────────────────────────────────

  private async _loadTxt(file: File): Promise<void> {
    const text   = await file.text();
    const lines  = text.split('\n');
    const chunks: string[][] = [];
    for (let i = 0; i < lines.length; i += LINES_TXT) chunks.push(lines.slice(i, i + LINES_TXT));
    if (!chunks.length) chunks.push(['']);

    this._canvases = chunks.map((chunk, pi) => {
      const [canvas, ctx] = makeCanvas();
      ctx.font         = '13px monospace';
      ctx.fillStyle    = '#1a1a1a';
      ctx.textBaseline = 'top';

      chunk.forEach((line, li) => {
        const y = MARGIN + li * LINE_H_TXT;
        if (y > PAGE_H - MARGIN) return;
        ctx.fillText(line, MARGIN, y, CONTENT_W);
        // Word index for this line
        let cx = MARGIN;
        for (const w of line.split(/(\s+)/)) {
          const ww = ctx.measureText(w).width;
          if (w.trim()) this._wordIndex.push({
            text: w, page: pi + 1,
            x: cx / PAGE_W, y: y / PAGE_H,
            width: ww / PAGE_W, height: LINE_H_TXT / PAGE_H,
          });
          cx += ww;
        }
      });
      return canvas;
    });
  }

  // ── DOCX/DOC loader ───────────────────────────────────────────────────────

  private async _loadDocx(file: File): Promise<void> {
    const mammoth = await import('mammoth');
    const buffer  = await file.arrayBuffer();

    // Always use dataUri converter — captures ALL embedded images (PNG, JPEG, WMF, EMF)
    const result = await (mammoth as any).convertToHtml(
      { arrayBuffer: buffer },
      {
        convertImage: (mammoth as any).images.dataUri,
        styleMap: [
          'p[style-name="Heading 1"] => h1:fresh',
          'p[style-name="Heading 2"] => h2:fresh',
          'p[style-name="Heading 3"] => h3:fresh',
        ],
      }
    );

    const html = result.value as string;

    // Parse HTML into ordered content blocks
    const blocks = this._parseHtml(html);

    // Pre-load all images in parallel (fast for multi-image docs)
    const imgSrcs = [...new Set(
      blocks.filter(b => b.type === 'img').map(b => b.src!)
    )];
    const imgMap = new Map<string, HTMLImageElement>();
    if (imgSrcs.length > 0) {
      const loaded = await Promise.all(imgSrcs.map(src =>
        loadImage(src).catch(() => null)
      ));
      imgSrcs.forEach((src, i) => { if (loaded[i]) imgMap.set(src, loaded[i]!); });
    }

    // Detect document type
    const hasFullPageImages = blocks.some(b => {
      if (b.type !== 'img' || !b.src) return false;
      const img = imgMap.get(b.src);
      return img && (img.naturalWidth / img.naturalHeight) >= (PAGE_W / PAGE_H) * 0.6;
    });
    const hasText = blocks.some(b => b.type !== 'img' && (b.text ?? '').trim());

    if (hasFullPageImages && !hasText) {
      // Pure image-based doc — each image = one page
      await this._renderImagePages(blocks, imgMap);
    } else {
      // Digital or mixed — paginate text+images together
      await this._renderMixedPages(blocks, imgMap);
    }
  }

  // ── Pure image-based: one canvas per embedded image ───────────────────────

  private async _renderImagePages(
    blocks: ContentBlock[], imgMap: Map<string, HTMLImageElement>
  ): Promise<void> {
    for (const block of blocks) {
      if (block.type !== 'img' || !block.src) continue;
      const img = imgMap.get(block.src);
      if (!img) continue;

      const [canvas, ctx] = makeCanvas();
      const page = this._canvases.length + 1;

      // Scale image to fill page content area, preserving aspect ratio
      const scale  = Math.min(CONTENT_W / img.naturalWidth, CONTENT_H / img.naturalHeight);
      const dw     = img.naturalWidth  * scale;
      const dh     = img.naturalHeight * scale;
      const dx     = MARGIN + (CONTENT_W - dw) / 2;
      const dy     = MARGIN + (CONTENT_H - dh) / 2;

      ctx.drawImage(img, dx, dy, dw, dh);

      // For image-only pages, the whole page is one "word" — click2pick captures full page
      this._wordIndex.push({
        text:   '',  // no text to extract from scanned image
        page,
        x:      dx / PAGE_W, y: dy / PAGE_H,
        width:  dw / PAGE_W, height: dh / PAGE_H,
      });

      this._canvases.push(canvas);
    }

    // If nothing rendered (all images failed), make a blank page
    if (this._canvases.length === 0) {
      const [c] = makeCanvas();
      this._canvases = [c];
    }
  }

  // ── Digital / mixed: paginate text and inline images ─────────────────────

  private async _renderMixedPages(
    blocks: ContentBlock[], imgMap: Map<string, HTMLImageElement>
  ): Promise<void> {
    let [canvas, ctx] = makeCanvas();
    let cy = MARGIN; // current Y within page
    let pageIdx = 1;
    this._canvases.push(canvas);

    const newPage = () => {
      [canvas, ctx] = makeCanvas();
      cy = MARGIN;
      pageIdx++;
      this._canvases.push(canvas);
      ctx.textBaseline = 'top';
    };

    ctx.textBaseline = 'top';

    for (const block of blocks) {
      if (block.type === 'img' && block.src) {
        const img = imgMap.get(block.src);
        if (!img) continue;

        const isFullPage = (img.naturalWidth / CONTENT_W) >= FULL_PAGE_THRESHOLD;

        if (isFullPage) {
          // Full-page image — start a fresh page for it
          if (cy > MARGIN + 10) newPage();
          const scale = Math.min(CONTENT_W / img.naturalWidth, CONTENT_H / img.naturalHeight);
          const dw = img.naturalWidth  * scale;
          const dh = img.naturalHeight * scale;
          const dx = MARGIN + (CONTENT_W - dw) / 2;
          ctx.drawImage(img, dx, cy, dw, dh);
          cy += dh + LINE_H_DOC;
          if (cy > PAGE_H - MARGIN) newPage();
        } else {
          // Inline image — draw at natural size (scaled to max content width)
          const scale = Math.min(1, CONTENT_W / img.naturalWidth);
          const dw    = img.naturalWidth  * scale;
          const dh    = img.naturalHeight * scale;
          if (cy + dh > PAGE_H - MARGIN) newPage();
          ctx.drawImage(img, MARGIN, cy, dw, dh);
          cy += dh + 8;
        }
        continue;
      }

      // Text block
      const text = (block.text ?? '').trim();
      if (!text) { cy += LINE_H_DOC / 2; continue; }

      // Set font by block type
      let font: string, color = '#1a1a1a', extraBefore = 0;
      switch (block.type) {
        case 'h1': font = 'bold 20px Georgia,serif'; color='#111'; extraBefore=12; break;
        case 'h2': font = 'bold 16px Georgia,serif'; color='#222'; extraBefore=10; break;
        case 'h3': font = 'bold 14px Georgia,serif'; color='#333'; extraBefore=8;  break;
        case 'li': font = '13px Georgia,serif'; break;
        default:   font = '13px Georgia,serif'; break;
      }
      ctx.font      = font;
      ctx.fillStyle = color;
      const indent  = block.type === 'li' ? 18 : 0;
      const lineH   = block.type === 'h1' ? 28 : block.type === 'h2' ? 24 : block.type === 'h3' ? 20 : LINE_H_DOC;

      cy += extraBefore;
      if (cy > PAGE_H - MARGIN) newPage();

      if (block.type === 'li') {
        ctx.fillText('•', MARGIN, cy, 14);
      }

      // Word-wrap
      const words = text.split(' ');
      let line    = '';
      for (const word of words) {
        const test = line ? line + ' ' + word : word;
        if (ctx.measureText(test).width > CONTENT_W - indent && line) {
          ctx.fillText(line, MARGIN + indent, cy, CONTENT_W - indent);
          this._recordLine(line, MARGIN + indent, cy, lineH, pageIdx, ctx);
          line = word;
          cy  += lineH;
          if (cy > PAGE_H - MARGIN) newPage();
        } else {
          line = test;
        }
      }
      if (line) {
        ctx.fillText(line, MARGIN + indent, cy, CONTENT_W - indent);
        this._recordLine(line, MARGIN + indent, cy, lineH, pageIdx, ctx);
        cy += lineH + (block.type === 'h1' ? 6 : 2);
      }
    }
  }

  // ── HTML parser — extract ordered content blocks ──────────────────────────

  private _parseHtml(html: string): ContentBlock[] {
    const div = document.createElement('div');
    div.innerHTML = this._sanitize(html);
    const blocks: ContentBlock[] = [];

    const walk = (el: Element) => {
      const tag = el.tagName?.toLowerCase() ?? '';
      if (['script','style'].includes(tag)) return;

      if (tag === 'img') {
        const src = (el as HTMLImageElement).src || el.getAttribute('src') || '';
        if (src) blocks.push({ type: 'img', src, text: '' });
        return;
      }

      const block_tags = ['p','h1','h2','h3','h4','h5','h6','li','div','blockquote','pre','tr'];
      if (block_tags.includes(tag)) {
        const text = (el as HTMLElement).innerText || el.textContent || '';
        if (text.trim() || el.querySelector('img')) {
          // Check for embedded images inside block
          for (const img of el.querySelectorAll('img')) {
            const src = (img as HTMLImageElement).src || img.getAttribute('src') || '';
            if (src) blocks.push({ type: 'img', src, text: '' });
          }
          if (text.trim()) blocks.push({ type: tag as any, text: text.trim() });
        }
        return; // don't recurse into block elements — already got text
      }

      // Recurse into containers (ul, ol, table, etc.)
      for (const child of Array.from(el.children)) walk(child);
    };

    for (const child of Array.from(div.children)) walk(child);
    return blocks;
  }

  // ── Record word positions for click2pick / search / highlight ─────────────

  private _recordLine(
    line: string, x: number, y: number, lineH: number,
    page: number, ctx: CanvasRenderingContext2D,
  ) {
    let cx = x;
    for (const w of line.split(' ')) {
      if (!w) continue;
      const ww = ctx.measureText(w).width;
      this._wordIndex.push({
        text: w, page,
        x: cx / PAGE_W, y: y / PAGE_H,
        width: ww / PAGE_W, height: lineH / PAGE_H,
      });
      cx += ww + ctx.measureText(' ').width;
    }
  }

  // ── Sanitize HTML ─────────────────────────────────────────────────────────

  private _sanitize(html: string): string {
    return html
      .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
      .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
      .replace(/on\w+="[^"]*"/gi, '');
  }

  // ── Word index public access ───────────────────────────────────────────────

  getWordIndex(): DocWordEntry[] { return this._wordIndex; }

  // ── ViewerAdapter implementation ──────────────────────────────────────────

  navigateToPage(page: number): void {
    const el = this._pageEls.get(page);
    if (!el) return;
    const sc = el.closest('[data-viewer-scroll]') as HTMLElement | null;
    if (sc) {
      sc.scrollTop = el.getBoundingClientRect().top - sc.getBoundingClientRect().top + sc.scrollTop - 8;
    } else {
      el.scrollIntoView({ behavior: 'instant' as ScrollBehavior, block: 'start' });
    }
  }

  registerPageElement(page: number, el: HTMLElement | null) {
    if (el) this._pageEls.set(page, el);
    else    this._pageEls.delete(page);
  }

  getPageDimensions(page: number) {
    const c = this._canvases[page - 1];
    return c ? { width: c.width, height: c.height } : null;
  }

  getPageCanvas(page: number): HTMLCanvasElement | null {
    return this._canvases[page - 1] ?? null;
  }

  getPageElement(page: number): HTMLElement | null {
    return this._pageEls.get(page) ?? null;
  }

  getRenderedPages(): Set<number> {
    return new Set(this._pageEls.keys());
  }

  getAllFrames() {
    return this._canvases.map(c => ({ canvas: c, width: c.width, height: c.height }));
  }

  notifyPageRendered(page: number) { this._rendCbs.forEach(cb => cb(page)); }

  onReady(cb: () => void) {
    if (this._isReady) cb(); else this._readyCbs.push(cb);
  }

  onPageRendered(cb: (page: number) => void)  { this._rendCbs.push(cb); }
  offPageRendered(cb: (page: number) => void) {
    const i = this._rendCbs.indexOf(cb);
    if (i !== -1) this._rendCbs.splice(i, 1);
  }

  dispose() {
    this._canvases = []; this._wordIndex = [];
    this._pageEls.clear(); this._rendCbs = []; this._readyCbs = [];
    this._isReady = false; this.pageCount = 0;
  }
}

// ── Content block type ────────────────────────────────────────────────────────

interface ContentBlock {
  type: 'p' | 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6' | 'li' | 'img' | 'div' | 'blockquote' | 'pre' | 'tr';
  text?: string;
  src?:  string;   // for img blocks — data URI from mammoth
}
