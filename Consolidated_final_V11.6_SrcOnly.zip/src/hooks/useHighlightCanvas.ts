// Highlight drawing is now handled entirely inside PDFViewer.tsx
// (inside the pdfjs 'pagerendered' event handler where timing is guaranteed).
// This file is kept as a shim so imports in ViewerPane.tsx still compile.
export function useHighlightCanvas(_containerRef: React.RefObject<HTMLElement>): void {}
