// ─────────────────────────────────────────────────────────────────────────────
// useWordSpanInjector — ZERO DOM spans. Pure in-memory hit-testing.
//
// Previous approach: inject N×pages DOM <span> elements (up to 200,000+).
// This caused browser freezes and crashes on large documents.
//
// New approach:
//   • Word index is kept entirely in memory (already in the store).
//   • A simple fractional bounding-box lookup replaces DOM hit-testing.
//   • NO spans are ever injected into the page DOM.
//   • The highlight canvas draws word positions directly from the index.
//   • Click/box capture reads from the in-memory index (O(n) per page,
//     n = words on that page, typically 100–500, not 200,000).
//
// This file is now a no-op shim so imports don't break. All word index
// hit-testing is done in useBoxCapture directly from the store.
// ─────────────────────────────────────────────────────────────────────────────

// No DOM injection. Word index hit-testing is done in useBoxCapture
// directly from the store's wordIndex Map. This file is kept as a shim
// so the import in ViewerPane.tsx continues to compile.
export function useWordSpanInjector(
  _containerRef: React.RefObject<HTMLElement>
): void {
  // Intentionally empty — see comment above.
}
