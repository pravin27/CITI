// useAnnotation — per-page drawing canvas overlay
// Strokes are stored in a Map<pageNumber, Stroke[]> so each page has independent annotations.
// The canvas is positioned absolute over the viewer, pointer-events:none when annotateMode=false.

import { useEffect, useRef, useCallback } from 'react';
import { useAppStore } from '../store/appStore';

export type StrokeTool = 'pencil' | 'line' | 'rect' | 'circle' | 'eraser';

export interface AnnotationSettings {
  tool: StrokeTool;
  color: string;
  size: number;
  opacity: number;
}

export interface Stroke {
  tool: StrokeTool;
  color: string;
  size: number;
  opacity: number;
  pts?: [number, number][];  // pencil
  x1?: number; y1?: number; x2?: number; y2?: number; // shapes/line
}

// Module-scope stroke storage — persists across re-renders, keyed by adapterKey+page
const annotationStore = new Map<string, Stroke[]>();

// Export for direct inspection by downloadFile (bypasses key computation issues)
export function getAllAnnotationKeys(): string[] {
  return [...annotationStore.keys()];
}
export function hasAnyAnnotations(): boolean {
  return annotationStore.size > 0 && [...annotationStore.values()].some(s => s.length > 0);
}
export function getAllStrokes(): Map<string, Stroke[]> {
  return annotationStore;
}

export function getAnnotationKey(adapterKey: string, page: number) {
  return `${adapterKey}:${page}`;
}

export function getStrokes(adapterKey: string, page: number): Stroke[] {
  return annotationStore.get(getAnnotationKey(adapterKey, page)) ?? [];
}

export function clearAnnotationsForAdapter(adapterKey: string, pageCount: number) {
  for (let p = 1; p <= pageCount; p++) {
    annotationStore.delete(getAnnotationKey(adapterKey, p));
  }
}

function addStroke(adapterKey: string, page: number, stroke: Stroke) {
  const key = getAnnotationKey(adapterKey, page);
  const arr = annotationStore.get(key) ?? [];
  arr.push(stroke);
  annotationStore.set(key, arr);
}

function undoStroke(adapterKey: string, page: number) {
  const key = getAnnotationKey(adapterKey, page);
  const arr = annotationStore.get(key);
  if (arr?.length) arr.pop();
}

function clearPageStrokes(adapterKey: string, page: number) {
  annotationStore.delete(getAnnotationKey(adapterKey, page));
}

function drawStroke(ctx: CanvasRenderingContext2D, s: Stroke, scaleX: number, scaleY: number) {
  ctx.save();
  ctx.globalAlpha = s.opacity / 100;
  ctx.strokeStyle = s.color;
  ctx.lineWidth = s.size;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  if (s.tool === 'pencil' && s.pts && s.pts.length > 1) {
    ctx.beginPath();
    ctx.moveTo(s.pts[0][0] * scaleX, s.pts[0][1] * scaleY);
    for (const [x, y] of s.pts) ctx.lineTo(x * scaleX, y * scaleY);
    ctx.stroke();
  } else if (s.tool === 'line') {
    ctx.beginPath();
    ctx.moveTo(s.x1! * scaleX, s.y1! * scaleY);
    ctx.lineTo(s.x2! * scaleX, s.y2! * scaleY);
    ctx.stroke();
  } else if (s.tool === 'rect') {
    ctx.strokeRect(
      s.x1! * scaleX, s.y1! * scaleY,
      (s.x2! - s.x1!) * scaleX, (s.y2! - s.y1!) * scaleY
    );
  } else if (s.tool === 'circle') {
    const rx = Math.abs(s.x2! - s.x1!) / 2 * scaleX;
    const ry = Math.abs(s.y2! - s.y1!) / 2 * scaleY;
    ctx.beginPath();
    ctx.ellipse(
      (s.x1! + (s.x2! - s.x1!) / 2) * scaleX,
      (s.y1! + (s.y2! - s.y1!) / 2) * scaleY,
      rx, ry, 0, 0, Math.PI * 2
    );
    ctx.stroke();
  } else if (s.tool === 'eraser') {
    ctx.globalCompositeOperation = 'destination-out';
    ctx.globalAlpha = 1;
    if (s.pts && s.pts.length > 1) {
      ctx.lineWidth = s.size * 4;
      ctx.beginPath();
      ctx.moveTo(s.pts[0][0] * scaleX, s.pts[0][1] * scaleY);
      for (const [x, y] of s.pts) ctx.lineTo(x * scaleX, y * scaleY);
      ctx.stroke();
    }
  }
  ctx.restore();
}

export function redrawAnnotations(
  canvas: HTMLCanvasElement,
  strokes: Stroke[],
  scaleX = 1,
  scaleY = 1,
  externalCtx?: CanvasRenderingContext2D  // optional pre-translated ctx for baking
) {
  const ctx = externalCtx ?? canvas.getContext('2d');
  if (!ctx) return;
  if (!externalCtx) ctx.clearRect(0, 0, canvas.width, canvas.height);
  for (const s of strokes) drawStroke(ctx, s, scaleX, scaleY);
}

// ── Hook ──────────────────────────────────────────────────────────────────────

export function useAnnotation(
  containerRef: React.RefObject<HTMLElement>,
  settings: React.RefObject<AnnotationSettings>
) {
  const annotateMode = useAppStore(s => s.annotateMode);
  const currentPage  = useAppStore(s => s.currentPage);
  const adapter      = useAppStore(s => s.adapter);

  const canvasRef   = useRef<HTMLCanvasElement | null>(null);
  const isDrawing   = useRef(false);
  const currentStroke = useRef<Stroke | null>(null);

  // Use refs so event handler closures always see the latest values (not stale captures)
  const adapterKeyRef  = useRef('');
  const currentPageRef = useRef(1);
  adapterKeyRef.current = adapter
    ? `${adapter.constructor.name}:${useAppStore.getState().fileName}:${useAppStore.getState().file?.size ?? 0}`
    : '';
  currentPageRef.current = currentPage;
  const adapterKey = adapterKeyRef.current;

  // Create/remove annotation canvas
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const canvas = document.createElement('canvas');
    canvas.style.cssText = `
      position: absolute; inset: 0; width: 100%; height: 100%;
      z-index: 25; pointer-events: none; touch-action: none;
    `;
    canvas.dataset.annotationCanvas = '1';
    container.appendChild(canvas);
    canvasRef.current = canvas;

    const ro = new ResizeObserver(() => {
      canvas.width  = container.clientWidth;
      canvas.height = container.clientHeight;
      redrawAnnotations(canvas, getStrokes(adapterKeyRef.current, currentPage));
    });
    ro.observe(container);
    canvas.width  = container.clientWidth;
    canvas.height = container.clientHeight;

    return () => {
      ro.disconnect();
      canvas.remove();
      canvasRef.current = null;
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [containerRef]);

  // Enable/disable pointer events based on annotateMode
  // Cursor: crosshair only over the page area, default cursor in grey margins
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.style.pointerEvents = annotateMode ? 'all' : 'none';
    if (!annotateMode) { canvas.style.cursor = 'default'; return; }

    const updateCursor = (e: MouseEvent) => {
      const r = canvas.getBoundingClientRect();
      const x = e.clientX - r.left;
      const y = e.clientY - r.top;
      const viewer = (window as any).__tovPdfViewer;
      let overPage = true; // default allow if no pdfjs viewer
      if (viewer) {
        try {
          const page = viewer.getPageView(useAppStore.getState().currentPage - 1);
          const pc = page?.canvas as HTMLCanvasElement | null;
          if (pc) {
            const pr = pc.getBoundingClientRect();
            const ar = canvas.getBoundingClientRect();
            const px = pr.left - ar.left, py = pr.top - ar.top;
            overPage = x >= px && x <= px + pr.width && y >= py && y <= py + pr.height;
          }
        } catch (_) {}
      }
      const tool = settings.current?.tool ?? 'pencil';
      canvas.style.cursor = overPage
        ? (tool === 'eraser' ? 'cell' : 'crosshair')
        : 'default';
    };

    canvas.addEventListener('mousemove', updateCursor, { passive: true });
    return () => canvas.removeEventListener('mousemove', updateCursor);
  }, [annotateMode, settings]);

  // Redraw when page changes
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    redrawAnnotations(canvas, getStrokes(adapterKey, currentPage));
  }, [currentPage, adapterKey]);

  // Drawing event handlers
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const getXY = (e: MouseEvent): [number, number] => {
      const r = canvas.getBoundingClientRect();
      return [e.clientX - r.left, e.clientY - r.top];
    };

    // Returns the pdfjs page canvas bounds relative to the annotation canvas.
    // Returns null for non-PDF formats (no restriction needed).
    const getPageBounds = (): { x: number; y: number; w: number; h: number } | null => {
      const viewer = (window as any).__tovPdfViewer;
      if (!viewer) return null;
      try {
        const page = viewer.getPageView(currentPageRef.current - 1);
        const pageCanvas = page?.canvas as HTMLCanvasElement | null;
        if (!pageCanvas) return null;
        const pr = pageCanvas.getBoundingClientRect();
        const ar = canvas.getBoundingClientRect();
        return {
          x: pr.left - ar.left,
          y: pr.top  - ar.top,
          w: pr.width,
          h: pr.height,
        };
      } catch (_) { return null; }
    };

    const clampToPage = (
      x: number, y: number,
      bounds: { x: number; y: number; w: number; h: number }
    ): [number, number] => [
      Math.max(bounds.x, Math.min(bounds.x + bounds.w, x)),
      Math.max(bounds.y, Math.min(bounds.y + bounds.h, y)),
    ];

    // Store page bounds per-stroke so clamp is consistent even if viewer scrolls
    const pageBoundsRef = { current: null as { x:number;y:number;w:number;h:number } | null };

    const onDown = (e: MouseEvent) => {
      if (!annotateMode) return;
      const [x, y] = getXY(e);
      const bounds = getPageBounds();
      // If we can determine the page bounds, reject clicks outside the page
      if (bounds) {
        const outside = x < bounds.x || x > bounds.x + bounds.w ||
                        y < bounds.y || y > bounds.y + bounds.h;
        if (outside) return; // don't start drawing outside the page
      }
      e.preventDefault();
      pageBoundsRef.current = bounds;
      isDrawing.current = true;
      const s = settings.current!;
      currentStroke.current = {
        tool: s.tool, color: s.color, size: s.size, opacity: s.opacity,
        pts: [[x, y]], x1: x, y1: y, x2: x, y2: y,
      };
    };

    const onMove = (e: MouseEvent) => {
      if (!isDrawing.current || !currentStroke.current) return;
      let [x, y] = getXY(e);
      // Clamp to page bounds so strokes can't exceed the page area
      const bounds = pageBoundsRef.current;
      if (bounds) { [x, y] = clampToPage(x, y, bounds); }
      const s = currentStroke.current;
      s.x2 = x; s.y2 = y;
      if (s.tool === 'pencil' || s.tool === 'eraser') s.pts!.push([x, y]);

      // Live preview
      const ctx = canvas.getContext('2d')!;
      redrawAnnotations(canvas, getStrokes(adapterKey, currentPage));
      drawStroke(ctx, s, 1, 1);
    };

    const onUp = () => {
      if (!isDrawing.current || !currentStroke.current) return;
      isDrawing.current = false;
      const key  = adapterKeyRef.current;
      const page = currentPageRef.current;
      addStroke(key, page, { ...currentStroke.current });
      currentStroke.current = null;
      // Debug: log stroke save
      console.log('[Annotation] stroke saved — key:', key, 'page:', page, 'total strokes:', getStrokes(key, page).length);
      redrawAnnotations(canvas, getStrokes(key, page));
    };

    canvas.addEventListener('mousedown', onDown);
    canvas.addEventListener('mousemove', onMove);
    canvas.addEventListener('mouseup', onUp);
    canvas.addEventListener('mouseleave', onUp);

    return () => {
      canvas.removeEventListener('mousedown', onDown);
      canvas.removeEventListener('mousemove', onMove);
      canvas.removeEventListener('mouseup', onUp);
      canvas.removeEventListener('mouseleave', onUp);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [annotateMode, currentPage, adapterKey]);

  const undo = useCallback(() => {
    undoStroke(adapterKey, currentPage);
    const canvas = canvasRef.current;
    if (canvas) redrawAnnotations(canvas, getStrokes(adapterKey, currentPage));
  }, [adapterKey, currentPage]);

  const clear = useCallback(() => {
    clearPageStrokes(adapterKey, currentPage);
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      ctx?.clearRect(0, 0, canvas.width, canvas.height);
    }
  }, [adapterKey, currentPage]);

  return { undo, clear, canvasRef };
}
