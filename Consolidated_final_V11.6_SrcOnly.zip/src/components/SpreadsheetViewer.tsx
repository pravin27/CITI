// ─────────────────────────────────────────────────────────────────────────────
// SpreadsheetViewer
//
// PERFORMANCE:
//   Only the active sheet is mounted. Switching tabs unmounts the old sheet
//   and mounts the new one. Non-visible sheets are never in the DOM.
//   This eliminates the main lag source — large sheets were all rendered
//   simultaneously even when hidden.
//
// MULTI-CELL SELECTION (Click2Pick):
//   • Single click  → capture that cell
//   • Click + drag  → rubber-band selection across multiple cells
//     Shows a blue overlay while dragging. On mouseup, captures the
//     bounding box of all selected cells with text joined by " | "
//   • Double-click  → same as single click (immediate capture)
//   Selection state is tracked in refs (no React state during drag
//   = zero re-renders while the user moves the mouse).
// ─────────────────────────────────────────────────────────────────────────────

import React, { useEffect, useRef, useCallback, useMemo } from 'react';
import { useAppStore } from '../store/appStore';
import type { SpreadsheetAdapter } from '../adapters/SpreadsheetAdapter';
import { colorToRgba } from '../utils/color';

const COL_WIDTH_DEFAULT  = 96;   // px — fallback when no col width info
const ROW_HEIGHT_DEFAULT = 22;   // px — fallback when no row height info
const ROW_NUM_W          = 44;   // px — row number gutter (always fixed)
const HEADER_H           = 26;   // px — column letter header row

interface SpreadsheetViewerProps { adapter: SpreadsheetAdapter; }

function colLetter(i: number): string {
  let r = '';
  while (i >= 0) { r = String.fromCharCode(65 + (i % 26)) + r; i = Math.floor(i / 26) - 1; }
  return r;
}
function cellAddr(row: number, col: number) { return `${colLetter(col)}${row + 1}`; }

// ── Main component ─────────────────────────────────────────────────────────────
export function SpreadsheetViewer({ adapter }: SpreadsheetViewerProps) {
  const currentPage    = useAppStore(s => s.currentPage);
  const setCurrentPage = useAppStore(s => s.setCurrentPage);
  const sheets = adapter.getAllSheets();

  // Clamp currentPage to valid range
  const activePage = Math.max(1, Math.min(currentPage, sheets.length));

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-[#f5f5f5]">
      {sheets.length > 1 && (
        <div className="flex items-center gap-1 px-3 py-2 bg-[#0d1829] border-b border-[#1e2d45] overflow-x-auto shrink-0">
          {sheets.map((sheet, i) => (
            <button key={i} onClick={() => setCurrentPage(i + 1)}
              className={`px-3 py-1.5 text-xs rounded-md font-medium whitespace-nowrap transition-colors ${
                activePage === i + 1
                  ? 'bg-[#0a84ff] text-white'
                  : 'text-[#8899aa] hover:text-white hover:bg-[#1e2d45]'
              }`}>
              {sheet.name || `Sheet ${i + 1}`}
            </button>
          ))}
        </div>
      )}

      <div className="flex-1 overflow-hidden relative">
        {/* KEY FIX: only mount the active sheet — not all sheets simultaneously */}
        {sheets[activePage - 1] && (
          <SheetTable
            key={activePage}          // remount on sheet change (fresh DOM)
            pageNum={activePage}
            sheet={sheets[activePage - 1]}
            adapter={adapter}
          />
        )}
      </div>
    </div>
  );
}

// ── Helpers ──────────────────────────────────────────────────────────────────────
// Determine if a hex fill color is light (white-ish) → use dark text on it
function isLightColor(hex: string): boolean {
  const r = parseInt(hex.slice(0, 2), 16);
  const g = parseInt(hex.slice(2, 4), 16);
  const b = parseInt(hex.slice(4, 6), 16);
  // Relative luminance approximation
  return (r * 299 + g * 587 + b * 114) / 1000 > 140;
}

// ── Sheet table ────────────────────────────────────────────────────────────────
interface SheetTableProps {
  pageNum: number;
  sheet: import('../adapters/SpreadsheetAdapter').SheetData;
  adapter: SpreadsheetAdapter;
}

function SheetTable({ pageNum, sheet, adapter }: SheetTableProps) {
  const boxMode          = useAppStore(s => s.boxMode);
  const zoom             = useAppStore(s => s.zoom);
  const setPendingCapture = useAppStore(s => s.setPendingCapture);
  const setPreviewRect   = useAppStore(s => s.setPreviewRect);
  const search           = useAppStore(s => s.search);

  const scrollRef  = useRef<HTMLDivElement>(null);
  const tableRef   = useRef<HTMLTableElement>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);

  const { rows, colCount, rowCount, styles, colInfos, rowInfos, merges } = sheet;

  // ── Derived sizing from sheet metadata ────────────────────────────────────────
  // Use per-column widths from xlsx if available, otherwise fixed default
  const colWidths = Array.from({ length: colCount }, (_, ci) =>
    colInfos?.[ci]?.wpx ?? COL_WIDTH_DEFAULT
  );
  const rowHeights = Array.from({ length: rowCount }, (_, ri) =>
    rowInfos?.[ri]?.hpx ?? ROW_HEIGHT_DEFAULT
  );
  const naturalW = ROW_NUM_W + colWidths.reduce((s, w) => s + w, 0);
  const naturalH = HEADER_H  + rowHeights.reduce((s, h) => s + h, 0);

  // ── Merge lookup: for each cell, is it spanned by another? ───────────────────
  // mergeMap[r][c] = {colSpan, rowSpan} if this cell is the TOP-LEFT of a merge
  //                = 'hidden' if this cell is covered by a merge (skip rendering)
  const mergeMap = useMemo(() => {
    const map = new Map<string, { colSpan: number; rowSpan: number } | 'hidden'>();
    for (const m of (merges ?? [])) {
      const rs = m.e.r - m.s.r + 1;
      const cs = m.e.c - m.s.c + 1;
      // Top-left cell gets span info
      map.set(`\${m.s.r},\${m.s.c}`, { colSpan: cs, rowSpan: rs });
      // All other cells in the merge are hidden
      for (let r = m.s.r; r <= m.e.r; r++) {
        for (let c_ = m.s.c; c_ <= m.e.c; c_++) {
          if (r === m.s.r && c_ === m.s.c) continue; // skip top-left
          map.set(`\${r},\${c_}`, 'hidden');
        }
      }
    }
    return map;
  }, [merges]);

  // ── Multi-cell drag selection state ──────────────────────────────────────────
  // All in refs — no React state during drag (zero re-renders while dragging)
  const dragStart  = useRef<{ row: number; col: number } | null>(null);
  const dragEnd    = useRef<{ row: number; col: number } | null>(null);
  const isDragging = useRef(false);
  // Visual selection overlay — a single <div> we move/resize during drag
  const selBoxRef  = useRef<HTMLDivElement | null>(null);

  // Register with adapter + store offscreen thumbnail snapshot
  useEffect(() => {
    adapter.registerPageElement(pageNum, wrapperRef.current);
    adapter.notifyPageRendered(pageNum);
    // Capture offscreen snapshot for thumbnail rendering (works even when sheet unmounts)
    const canvas = wrapperRef.current?.querySelector('canvas');
    if (canvas && typeof (adapter as any).storeSheetSnapshot === 'function') {
      (adapter as any).storeSheetSnapshot(pageNum, canvas);
    }
    return () => adapter.registerPageElement(pageNum, null);
  }, [adapter, pageNum]);

  // ── Coordinate helper ─────────────────────────────────────────────────────────
  const getCellFrac = useCallback((cell: HTMLElement) => {
    const table = tableRef.current;
    if (!table) return null;
    const tR = table.getBoundingClientRect();
    const cR = cell.getBoundingClientRect();
    const nW = tR.width  / zoom;
    const nH = tR.height / zoom;
    const rL = (cR.left - tR.left) / zoom;
    const rT = (cR.top  - tR.top)  / zoom;
    const cW = cR.width  / zoom;
    const cH = cR.height / zoom;
    return { x: rL/nW, y: rT/nH, width: cW/nW, height: cH/nH };
  }, [zoom]);

  // ── Get cell element by row/col ───────────────────────────────────────────────
  const getCellEl = useCallback((row: number, col: number): HTMLTableCellElement | null => {
    return tableRef.current?.querySelector<HTMLTableCellElement>(
      `td[data-row="${row}"][data-col="${col}"]`
    ) ?? null;
  }, []);

  // ── Compute bounding frac of a range ─────────────────────────────────────────
  const getRangeFrac = useCallback((
    r1: number, c1: number, r2: number, c2: number
  ) => {
    const table = tableRef.current;
    if (!table) return null;
    const tR = table.getBoundingClientRect();
    const nW = tR.width  / zoom;
    const nH = tR.height / zoom;

    const minR = Math.min(r1, r2), maxR = Math.max(r1, r2);
    const minC = Math.min(c1, c2), maxC = Math.max(c1, c2);

    // Get top-left and bottom-right corner cells
    const tlEl = getCellEl(minR, minC);
    const brEl = getCellEl(maxR, maxC);
    if (!tlEl || !brEl) return null;

    const tlR = tlEl.getBoundingClientRect();
    const brR = brEl.getBoundingClientRect();

    const left   = (tlR.left   - tR.left) / zoom;
    const top    = (tlR.top    - tR.top)  / zoom;
    const right  = (brR.right  - tR.left) / zoom;
    const bottom = (brR.bottom - tR.top)  / zoom;

    return {
      x:      left / nW,
      y:      top  / nH,
      width:  (right  - left) / nW,
      height: (bottom - top)  / nH,
    };
  }, [zoom, getCellEl]);

  // ── Get all cell values in range ──────────────────────────────────────────────
  const getRangeText = useCallback((
    r1: number, c1: number, r2: number, c2: number
  ): string => {
    const minR = Math.min(r1, r2), maxR = Math.max(r1, r2);
    const minC = Math.min(c1, c2), maxC = Math.max(c1, c2);
    const parts: string[] = [];
    for (let r = minR; r <= maxR; r++) {
      for (let c = minC; c <= maxC; c++) {
        const v = rows[r]?.[c]?.trim();
        if (v) parts.push(v);
      }
    }
    return parts.join(' | ');
  }, [rows]);

  // ── Selection visual overlay ──────────────────────────────────────────────────
  const updateSelBox = useCallback((
    r1: number, c1: number, r2: number, c2: number
  ) => {
    const table = tableRef.current;
    const wrapper = wrapperRef.current;
    if (!table || !wrapper) return;

    if (!selBoxRef.current) {
      const div = document.createElement('div');
      div.style.cssText = [
        'position:absolute', 'pointer-events:none', 'z-index:30',
        'border:2px solid rgba(10,132,255,0.9)',
        'background:rgba(10,132,255,0.12)',
        'border-radius:2px', 'transition:none',
      ].join(';');
      wrapper.appendChild(div);
      selBoxRef.current = div;
    }

    const tR  = table.getBoundingClientRect();
    const wR  = wrapper.getBoundingClientRect();
    const minR = Math.min(r1, r2), maxR = Math.max(r1, r2);
    const minC = Math.min(c1, c2), maxC = Math.max(c1, c2);
    const tlEl = getCellEl(minR, minC);
    const brEl = getCellEl(maxR, maxC);
    if (!tlEl || !brEl) return;
    const tlR = tlEl.getBoundingClientRect();
    const brR = brEl.getBoundingClientRect();

    // Position relative to wrapper (unzoomed via /zoom)
    const left   = (tlR.left   - wR.left) / zoom;
    const top    = (tlR.top    - wR.top)  / zoom;
    const width  = (brR.right  - tlR.left) / zoom;
    const height = (brR.bottom - tlR.top)  / zoom;

    selBoxRef.current.style.left   = left   + 'px';
    selBoxRef.current.style.top    = top    + 'px';
    selBoxRef.current.style.width  = width  + 'px';
    selBoxRef.current.style.height = height + 'px';
    selBoxRef.current.style.display = 'block';
  }, [zoom, getCellEl]);

  const clearSelBox = useCallback(() => {
    if (selBoxRef.current) {
      selBoxRef.current.style.display = 'none';
    }
  }, []);

  // Cleanup selBox on unmount
  useEffect(() => () => { selBoxRef.current?.remove(); selBoxRef.current = null; }, []);

  // ── Fire capture from range ───────────────────────────────────────────────────
  const fireCapture = useCallback((
    r1: number, c1: number, r2: number, c2: number
  ) => {
    const frac = getRangeFrac(r1, c1, r2, c2);
    if (!frac) return;
    const text = getRangeText(r1, c1, r2, c2);
    const minR = Math.min(r1, r2), maxR = Math.max(r1, r2);
    const minC = Math.min(c1, c2), maxC = Math.max(c1, c2);
    const label = minR === maxR && minC === maxC
      ? (text || cellAddr(minR, minC))
      : `${cellAddr(minR, minC)}:${cellAddr(maxR, maxC)}`;
    setPendingCapture({ text: text || label, page: pageNum, ...frac, sourceFormat: 'flat' });
    setPreviewRect({ page: pageNum, ...frac });
  }, [getRangeFrac, getRangeText, pageNum, setPendingCapture, setPreviewRect]);

  // ── Cell pointer events ───────────────────────────────────────────────────────
  // Strategy: use onClick for single-cell capture (reliable, no conflict).
  //           use onMouseDown+onMouseEnter+window-mouseup for multi-cell drag.
  //           A drag is only confirmed when the mouse enters a DIFFERENT cell
  //           (isDragging.current = true). Single-click never sets isDragging.

  const onCellClick = useCallback((
    e: React.MouseEvent<HTMLTableCellElement>, row: number, col: number
  ) => {
    if (!boxMode) return;
    // Only handle single-cell click (no drag happened)
    if (isDragging.current) return;
    const frac = getCellFrac(e.currentTarget);
    if (!frac) return;
    const val = rows[row]?.[col] ?? '';
    setPendingCapture({ text: val || cellAddr(row, col), page: pageNum, ...frac, sourceFormat: 'flat' });
    setPreviewRect({ page: pageNum, ...frac });
  }, [boxMode, getCellFrac, rows, pageNum, setPendingCapture, setPreviewRect]);

  const onCellMouseDown = useCallback((
    e: React.MouseEvent<HTMLTableCellElement>, row: number, col: number
  ) => {
    if (!boxMode || e.button !== 0) return;
    // Don't preventDefault — allows click event to fire normally for single-click
    dragStart.current  = { row, col };
    dragEnd.current    = { row, col };
    isDragging.current = false;
  }, [boxMode]);

  const onCellMouseEnter = useCallback((row: number, col: number) => {
    if (!boxMode || !dragStart.current) return;
    // Only mark as drag when entering a DIFFERENT cell
    const ds = dragStart.current;
    if (row === ds.row && col === ds.col) return;
    dragEnd.current    = { row, col };
    isDragging.current = true;
    updateSelBox(ds.row, ds.col, row, col);
  }, [boxMode, updateSelBox]);

  // Global mouseup — only fires for multi-cell drag (isDragging === true)
  useEffect(() => {
    if (!boxMode) return;
    const onUp = () => {
      const ds = dragStart.current;
      const de = dragEnd.current;
      const wasDragging = isDragging.current;
      // Always reset drag state
      dragStart.current  = null;
      dragEnd.current    = null;
      isDragging.current = false;
      clearSelBox();
      // Only capture on genuine drag (entered a different cell)
      if (wasDragging && ds && de) {
        fireCapture(ds.row, ds.col, de.row, de.col);
      }
      // Single-click case handled by onCellClick (no action here)
    };
    window.addEventListener('mouseup', onUp);
    return () => window.removeEventListener('mouseup', onUp);
  }, [boxMode, clearSelBox, fireCapture]);

  // ── Search ────────────────────────────────────────────────────────────────────
  const searchHitCells = useMemo(() => {
    const set = new Set<string>();
    if (!search.query.trim()) return set;
    const q = search.matchCase ? search.query : search.query.toLowerCase();
    rows.forEach((row, ri) => {
      row.forEach((cell, ci) => {
        if (!cell) return;
        const t = search.matchCase ? cell : cell.toLowerCase();
        if (search.matchType === 'exact' ? t === q : t.includes(q)) set.add(`${ri},${ci}`);
      });
    });
    return set;
  }, [rows, search.query, search.matchCase, search.matchType]);

  const currentResultKey = useMemo(() => {
    const r = search.results[search.currentIndex];
    if (!r || r.page !== pageNum || !tableRef.current) return null;
    const tR = tableRef.current.getBoundingClientRect();
    const nW = tR.width / zoom;
    const nH = tR.height / zoom;
    const col = Math.round(r.x * nW / COL_WIDTH_DEFAULT) - 1;
    const row = Math.round(r.y * nH / ROW_HEIGHT_DEFAULT) - 1;
    return `${row},${col}`;
  }, [search.results, search.currentIndex, pageNum, zoom]);

  // ── Search: populate store results for this sheet ────────────────────────────
  useEffect(() => {
    if (!search.query.trim()) return;
    const q = search.matchCase ? search.query : search.query.toLowerCase();
    const results: Array<{ page: number; x: number; y: number; width: number; height: number; text: string }> = [];
    // Use row/col index to compute fractional coords directly (no DOM query needed)
    const nW = naturalW;
    const nH = naturalH;
    // Pre-compute cumulative column/row offsets for accurate search rect positions
    const colOffsets = colWidths.reduce<number[]>((acc, w) => {
      acc.push((acc[acc.length - 1] ?? ROW_NUM_W) + w); return acc;
    }, [ROW_NUM_W]);
    const rowOffsets = rowHeights.reduce<number[]>((acc, h) => {
      acc.push((acc[acc.length - 1] ?? HEADER_H) + h); return acc;
    }, [HEADER_H]);

    rows.forEach((row, ri) => {
      row.forEach((cell, ci) => {
        if (!cell) return;
        const t = search.matchCase ? cell : cell.toLowerCase();
        if (!(search.matchType === 'exact' ? t === q : t.includes(q))) return;
        const left = colOffsets[ci] ?? (ROW_NUM_W + ci * COL_WIDTH_DEFAULT);
        const top  = rowOffsets[ri] ?? (HEADER_H  + ri * ROW_HEIGHT_DEFAULT);
        results.push({
          page: pageNum,
          x:      left / nW,
          y:      top  / nH,
          width:  (colWidths[ci] ?? COL_WIDTH_DEFAULT)  / nW,
          height: (rowHeights[ri] ?? ROW_HEIGHT_DEFAULT) / nH,
          text: cell,
        });
      });
    });
    if (results.length > 0) {
      useAppStore.setState(s => {
        const merged = [...s.search.results.filter(r => r.page !== pageNum), ...results]
          .sort((a, b) => a.page !== b.page ? a.page - b.page : a.y !== b.y ? a.y - b.y : a.x - b.x);
        return { search: { ...s.search, results: merged, currentIndex: merged.length > 0 ? 0 : -1 } };
      });
    }
  }, [search.query, search.matchCase, search.matchType, rows, colCount, rowCount, pageNum]);

  // ── Highlight canvas overlay ─────────────────────────────────────────────────
  // Draws capture boxes and preview pulse directly onto a canvas overlay
  // sized to natural (pre-zoom) table dimensions. CSS transform:scale on the
  // wrapper handles zoom — so fractional coords × natural dims = correct pixels.
  const hlCanvasRef = useRef<HTMLCanvasElement>(null);

  const drawHighlights = useCallback(() => {
    const canvas = hlCanvasRef.current;
    if (!canvas) return;
    const W = canvas.width;
    const H = canvas.height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, W, H);

    const state       = useAppStore.getState();
    const rects       = state.highlightIndex.get(pageNum) ?? [];
    const activeId    = state.activeFieldId;
    const previewRect = state.previewRect;

    const RADIUS = 2;
    const rr = (x: number, y: number, w: number, h: number) => {
      if (w < 1 || h < 1) return;
      const r = Math.min(RADIUS, w/2, h/2);
      ctx.beginPath();
      ctx.moveTo(x+r,y); ctx.lineTo(x+w-r,y); ctx.arcTo(x+w,y,x+w,y+r,r);
      ctx.lineTo(x+w,y+h-r); ctx.arcTo(x+w,y+h,x+w-r,y+h,r);
      ctx.lineTo(x+r,y+h); ctx.arcTo(x,y+h,x,y+h-r,r);
      ctx.lineTo(x,y+r); ctx.arcTo(x,y,x+r,y,r); ctx.closePath();
    };

    // Exact-lowercase value map — no stripPunct so "LEADTOOLS" ≠ "LEADTOOLS®"
    const fwc = new Map<string, string>();
    for (const cap of state.captures) fwc.set(cap.id, cap.value.toLowerCase().trim());
    const activeCapture = activeId ? state.captures.find(c => c.id === activeId) : null;
    const activeTxt     = activeCapture ? (fwc.get(activeId!) ?? '') : '';

    // Draw confirmed capture boxes
    for (const rect of rects) {
      const isActive = rect.id === activeId;
      const isDup    = !isActive && !!activeTxt && fwc.get(rect.id) === activeTxt;
      ctx.save();
      if (isActive) {
        ctx.shadowColor = 'rgba(220,180,0,.5)'; ctx.shadowBlur = 8;
        ctx.fillStyle = 'rgba(255,230,0,.35)'; ctx.strokeStyle = 'rgb(200,160,0)'; ctx.lineWidth = 2.5;
      } else if (isDup) {
        ctx.fillStyle = 'rgba(255,182,193,.40)'; ctx.strokeStyle = 'rgba(220,80,120,.85)'; ctx.lineWidth = 2;
      } else if (rect.color) {
        ctx.fillStyle = colorToRgba(rect.color, .20); ctx.strokeStyle = rect.color; ctx.lineWidth = 1.5;
      } else {
        ctx.fillStyle = 'rgba(100,100,200,.12)'; ctx.strokeStyle = 'rgba(80,80,180,.70)'; ctx.lineWidth = 1.5;
      }
      rr(rect.x*W, rect.y*H, rect.width*W, rect.height*H);
      ctx.fill(); ctx.stroke(); ctx.restore();
    }

    // Draw preview pulse (cyan) for pending/just-captured
    if (previewRect && previewRect.page === pageNum) {
      ctx.save();
      ctx.fillStyle = 'rgba(6,182,212,.18)';
      ctx.strokeStyle = 'rgba(6,182,212,.9)';
      ctx.lineWidth = 2;
      ctx.shadowColor = 'rgba(6,182,212,.5)'; ctx.shadowBlur = 6;
      rr(previewRect.x*W, previewRect.y*H, previewRect.width*W, previewRect.height*H);
      ctx.fill(); ctx.stroke(); ctx.restore();
    }
  }, [pageNum]);

  // Re-draw when captures / activeField / previewRect change
  useEffect(() => {
    drawHighlights();
    const unsub = useAppStore.subscribe((n, p) => {
      if (n.highlightIndex !== p.highlightIndex ||
          n.activeFieldId  !== p.activeFieldId  ||
          n.previewRect    !== p.previewRect) {
        drawHighlights();
      }
    });
    return unsub;
  }, [drawHighlights]);

  return (
    <div
      ref={scrollRef}
      data-viewer-scroll="1"
      className="w-full h-full overflow-auto bg-white"
    >
      <div style={{ width: naturalW * zoom, height: naturalH * zoom, position: 'relative' }}>
        <div
          ref={wrapperRef}
          data-page-number={pageNum}
          style={{
            position: 'absolute', top: 0, left: 0,
            transform: `scale(${zoom})`, transformOrigin: 'top left',
            width: naturalW, height: naturalH,
          }}
        >
          <table
            ref={tableRef}
            className="border-collapse select-none"
            style={{ tableLayout: 'fixed', width: naturalW, fontSize: 12 }}
          >
            {/* Dynamic column widths from xlsx metadata */}
            <colgroup>
              <col style={{ width: ROW_NUM_W }} />
              {colWidths.map((w, ci) => <col key={ci} style={{ width: w }} />)}
            </colgroup>

            {/* Column letter header */}
            <thead>
              <tr style={{ height: HEADER_H }}>
                <th className="bg-[#f2f2f2] border border-[#d0d0d0] text-[#555] font-normal text-center sticky top-0 left-0 z-20"
                  style={{ width: ROW_NUM_W, height: HEADER_H }} />
                {colWidths.map((w, ci) => (
                  <th key={ci} className="bg-[#f2f2f2] border border-[#d0d0d0] text-[#555] font-normal text-center px-1"
                    style={{ width: w, height: HEADER_H }}>
                    {colLetter(ci)}
                  </th>
                ))}
              </tr>
            </thead>

            <tbody>
              {rows.map((row, ri) => {
                // Skip hidden rows
                if (rowInfos?.[ri]?.hidden) return null;
                const rowH = rowHeights[ri];
                return (
                  <tr key={ri} style={{ height: rowH }}>
                    {/* Row number gutter */}
                    <td className="bg-[#f2f2f2] border border-[#d0d0d0] text-[#555] text-center text-xs sticky left-0 z-10"
                      style={{ width: ROW_NUM_W, height: rowH, fontSize: 11 }}>
                      {ri + 1}
                    </td>

                    {Array.from({ length: colCount }, (_, ci) => {
                      const key = `\${ri},\${ci}`;
                      const mergeInfo = mergeMap.get(key);

                      // Cell covered by a merge — render nothing (the spanning cell covers it)
                      if (mergeInfo === 'hidden') return null;

                      const val     = row[ci] ?? '';
                      const cellSty = styles?.[ri]?.[ci];
                      const isHit   = searchHitCells.has(key);
                      const isCur   = currentResultKey === key;
                      const colW    = colWidths[ci];

                      // Background: search highlight > fill color from xlsx > default
                      let bgStyle: React.CSSProperties = {};
                      if (isCur) {
                        bgStyle = { background: 'rgba(255,140,0,0.4)', color: '#fff' };
                      } else if (isHit) {
                        bgStyle = { background: 'rgba(255,220,50,0.25)', color: '#ffe066' };
                      } else if (cellSty?.fillRgb) {
                        // Fill color from xlsx — lighten for dark-mode readability
                        bgStyle = {
                          background: '#' + cellSty.fillRgb,
                          color: isLightColor(cellSty.fillRgb) ? '#111' : '#eee',
                        };
                      }

                      const colSpan = mergeInfo ? mergeInfo.colSpan : 1;
                      const rowSpan = mergeInfo ? mergeInfo.rowSpan : 1;

                      return (
                        <td
                          key={ci}
                          data-row={ri} data-col={ci} data-cell-text={val}
                          title={val}
                          colSpan={colSpan}
                          rowSpan={rowSpan}
                          onClick={e => onCellClick(e, ri, ci)}
                          onMouseDown={e => onCellMouseDown(e, ri, ci)}
                          onMouseEnter={() => onCellMouseEnter(ri, ci)}
                          className={`border border-[#d0d0d0] px-1.5 text-xs whitespace-nowrap overflow-hidden
                            \${boxMode ? 'cursor-crosshair' : 'cursor-default'}
                            \${!isCur && !isHit && !cellSty?.fillRgb ? 'bg-white text-[#111]' : ''}
                            \${boxMode && !isHit && !isCur ? 'hover:brightness-110' : ''}
                          `}
                          style={{
                            width: colW, height: rowH, maxWidth: colW * colSpan,
                            ...bgStyle,
                          }}
                        >
                          {val}
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
          {/* Highlight canvas — natural size, zoom applied by parent transform */}
          <canvas
            ref={hlCanvasRef}
            width={naturalW}
            height={naturalH}
            style={{
              position: 'absolute',
              inset: 0,
              width: naturalW,
              height: naturalH,
              pointerEvents: 'none',
              zIndex: 25,
            }}
          />
        </div>
      </div>
    </div>
  );
}
