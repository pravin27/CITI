// ─────────────────────────────────────────────────────────────────────────────
// MultiDocTestHarness
//
// Drop-in test panel. Add <MultiDocTestHarness /> anywhere in the app to
// validate the full multi-doc flow without touching App.tsx permanently.
//
// Usage in App.tsx (temporary):
//   import { MultiDocTestHarness } from './components/MultiDocTestHarness';
//   // Add inside return, anywhere visible:
//   <MultiDocTestHarness />
//
// What it tests:
//   1. Drop / pick a manifest JSON → sidebar renders immediately
//   2. Click any doc thumbnail → PDF loads via src URL or callback
//   3. Navigate pages (mode:multi) → proportion bar + pills update
//   4. Switch outline tab → doc accordion with category sub-rows
//   5. Click a page pill → viewer jumps to that page
//   6. Prev/Next doc arrows → doc switches, page resets to 1
//   7. Click same doc twice → no network call (cache hit, instant)
//   8. loadDocumentData callback path → registered before manifest drop
// ─────────────────────────────────────────────────────────────────────────────
import { useRef, useState, useEffect } from 'react';
import { useMultiDoc } from '../hooks/useMultiDoc';
import { MultiDocSidebar } from './MultiDocSidebar';
import { useAppStore } from '../store/appStore';
import type { DocumentManifest } from '../types/multiDoc';

export function MultiDocTestHarness() {
  const [open, setOpen] = useState(false);
  const [log, setLog] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const openFile = useAppStore(s => s.openFile);
  const multiDoc  = useMultiDoc();

  const addLog = (msg: string) => setLog(l => [`[${new Date().toLocaleTimeString()}] ${msg}`, ...l.slice(0, 19)]);

  // Register loadDocumentData callback — simulates API call
  // In production this is your real backend call
  useEffect(() => {
    multiDoc.setConfig({
      loadDocumentData: async (docId: string) => {
        addLog(`📡 API: loadDocumentData("${docId}") called`);
        // Simulate network delay
        await new Promise(r => setTimeout(r, 300));
        // In a real app: return await fetch(`/api/docs/${docId}/data`).then(r => r.arrayBuffer())
        // For testing: fall through to "no data" error to confirm callback fires
        throw new Error(`No test file for "${docId}" — add a src in the manifest`);
      }
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadManifest = async (file: File) => {
    try {
      const text = await file.text();
      const json = JSON.parse(text) as DocumentManifest;
      if (!json.mode || !json.documents) {
        addLog('❌ Invalid manifest — missing mode or documents');
        return;
      }
      multiDoc.loadManifest(json);
      addLog(`✓ Manifest loaded — mode:${json.mode}, ${json.documents.length} docs, ${json.categories.length} categories`);
    } catch (e) {
      addLog(`❌ Parse error: ${e}`);
    }
  };

  const handleSelectDoc = async (docId: string, page = 1) => {
    const doc = multiDoc.state?.documents.find(d => d.id === docId);
    addLog(`→ selectDoc("${docId}", page=${page})  name="${doc?.name ?? '?'}"`);
    await multiDoc.selectDoc(docId, page);
    if (multiDoc.activeFile) {
      addLog(`✓ File ready: ${multiDoc.activeFile.name} (${(multiDoc.activeFile.size/1024).toFixed(1)} KB)`);
      openFile(multiDoc.activeFile);
    }
  };

  const handleSelectPage = (page: number) => {
    addLog(`→ selectPage(${page})`);
    multiDoc.selectPage(page);
    // Sync page navigation to the existing viewer
    useAppStore.getState().setCurrentPage(page);
    useAppStore.getState().adapter?.navigateToPage?.(page);
  };

  // Sync activeFile to viewer whenever it changes
  useEffect(() => {
    if (multiDoc.activeFile) {
      openFile(multiDoc.activeFile);
      addLog(`  viewer updated → ${multiDoc.activeFile.name}`);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [multiDoc.activeFile]);

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        style={{
          position: 'fixed', bottom: 16, right: 16, zIndex: 9999,
          background: '#1a7fd4', color: '#fff', border: 'none',
          borderRadius: 8, padding: '8px 14px', fontSize: 11,
          fontWeight: 500, cursor: 'pointer', fontFamily: 'var(--font-sans,sans-serif)',
        }}
      >
        Multi-doc test
      </button>
    );
  }

  return (
    <div style={{
      position: 'fixed', bottom: 0, right: 0, zIndex: 9999,
      width: 420, height: '100vh', display: 'flex', flexDirection: 'column',
      background: '#0d1829', borderLeft: '1px solid #1a2740',
      fontFamily: 'var(--font-sans,sans-serif)',
    }}>

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px', background: '#080f1a', borderBottom: '1px solid #1a2740', flexShrink: 0 }}>
        <span style={{ fontSize: 11, color: '#e8f0f6', fontWeight: 500, flex: 1 }}>Multi-doc test harness</span>
        {multiDoc.state && (
          <button onClick={() => { multiDoc.clearMultiDoc(); setLog([]); addLog('Cleared'); }}
            style={{ fontSize: 10, background: '#2a1a1a', color: '#f87171', border: '0.5px solid #4a2020', borderRadius: 4, padding: '2px 8px', cursor: 'pointer' }}>
            Clear
          </button>
        )}
        <button onClick={() => setOpen(false)}
          style={{ fontSize: 12, background: 'transparent', color: '#4a6070', border: 'none', cursor: 'pointer', padding: '0 4px' }}>
          ✕
        </button>
      </div>

      {/* Load manifest */}
      {!multiDoc.state && (
        <div style={{ padding: 14, borderBottom: '1px solid #1a2740', flexShrink: 0 }}>
          <div style={{ fontSize: 10, color: '#4a6070', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '.06em' }}>Step 1 — load manifest JSON</div>
          <input ref={fileInputRef} type="file" accept=".json" style={{ display: 'none' }}
            onChange={e => { const f = e.target.files?.[0]; if (f) loadManifest(f); e.target.value = ''; }} />
          <button onClick={() => fileInputRef.current?.click()}
            style={{ width: '100%', background: '#1a2f47', border: '0.5px solid #2a4060', color: '#8ab0c8', borderRadius: 6, padding: '8px 0', fontSize: 11, cursor: 'pointer', marginBottom: 8 }}>
            Pick manifest JSON file
          </button>
          <div style={{ fontSize: 9.5, color: '#3a5060', lineHeight: 1.6 }}>
            Test files ready in <code style={{ color: '#6ab0d0' }}>public/test-docs/</code><br />
            • <code style={{ color: '#6ab0d0' }}>manifest_case1.json</code> — 9 single-page docs, 4 categories<br />
            • <code style={{ color: '#6ab0d0' }}>manifest_case2.json</code> — 4 multi-page docs incl. 50-page doc
          </div>
        </div>
      )}

      {/* State summary */}
      {multiDoc.state && (
        <div style={{ padding: '8px 12px', borderBottom: '1px solid #1a2740', flexShrink: 0, background: '#0a1520' }}>
          <div style={{ fontSize: 10, color: '#4a6070', marginBottom: 4 }}>
            mode: <span style={{ color: '#8ab0c8' }}>{multiDoc.state.mode}</span> ·
            docs: <span style={{ color: '#8ab0c8' }}>{multiDoc.state.documents.length}</span> ·
            active: <span style={{ color: '#8ab0c8' }}>{multiDoc.state.activeDocId ?? 'none'}</span> ·
            pg: <span style={{ color: '#8ab0c8' }}>{multiDoc.state.activePage}</span>
          </div>
          {multiDoc.activeDocLoading && <div style={{ fontSize: 10, color: '#fbbf24' }}>⏳ Loading document…</div>}
          {multiDoc.activeDocError  && <div style={{ fontSize: 10, color: '#f87171' }}>❌ {multiDoc.activeDocError}</div>}
        </div>
      )}

      {/* Sidebar preview */}
      {multiDoc.state && (
        <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
          <MultiDocSidebar
            state={multiDoc.state}
            isLoading={multiDoc.activeDocLoading}
            loadError={multiDoc.activeDocError}
            onSelectDoc={handleSelectDoc}
            onSelectPage={handleSelectPage}
          />
          {/* Event log */}
          <div style={{ flex: 1, overflowY: 'auto', padding: 10, background: '#060d1a' }}>
            <div style={{ fontSize: 9.5, color: '#3a5060', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '.06em' }}>Event log</div>
            {log.length === 0 && <div style={{ fontSize: 10, color: '#2a3a4a' }}>Click a document…</div>}
            {log.map((l, i) => (
              <div key={i} style={{ fontSize: 10, color: l.startsWith('[') ? '#6a9ab0' : '#e8f0f6', marginBottom: 3, lineHeight: 1.4, fontFamily: 'monospace' }}>{l}</div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
