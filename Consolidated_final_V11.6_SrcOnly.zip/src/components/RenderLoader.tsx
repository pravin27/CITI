// RenderLoader — progress bar + S1 skeleton overlay shown while PDF renders
// Appears when renderProgress is 1–99, fades out at 100.
// The skeleton sits over the viewer area without blocking layout.

import React, { useEffect, useRef, useState } from 'react';
import { useAppStore } from '../store/appStore';

// ── Shimmer line ──────────────────────────────────────────────────────────────
function ShimLine({ w = '100%', delay = 0, h = 8 }: { w?: string; delay?: number; h?: number }) {
  return (
    <div style={{
      height: h, width: w, borderRadius: 3,
      background: 'linear-gradient(90deg, #ebebeb 25%, #f5f5f5 50%, #ebebeb 75%)',
      backgroundSize: '200% 100%',
      animation: `shimmer 1.6s ease-in-out ${delay}s infinite`,
      flexShrink: 0,
    }} />
  );
}

// ── S1 Skeleton page ──────────────────────────────────────────────────────────
function SkeletonPage() {
  return (
    <div style={{
      position: 'absolute', left: '50%', top: 20,
      transform: 'translateX(-50%)',
      background: '#fff', borderRadius: 2,
      boxShadow: '0 2px 12px rgba(0,0,0,.12)',
      padding: '24px 20px',
      display: 'flex', flexDirection: 'column', gap: 7,
      width: 'min(220px, 55%)',
      // Height fills most of the viewer
      minHeight: 200,
      zIndex: 5,
    }}>
      <ShimLine w="70%" h={11} delay={0} />
      <div style={{ height: 6 }} />
      <ShimLine w="100%" delay={0.00} />
      <ShimLine w="96%"  delay={0.10} />
      <ShimLine w="88%"  delay={0.05} />
      <ShimLine w="100%" delay={0.15} />
      <ShimLine w="72%"  delay={0.20} />
      <div style={{ height: 8 }} />
      <ShimLine w="100%" delay={0.08} />
      <ShimLine w="94%"  delay={0.18} />
      <ShimLine w="80%"  delay={0.12} />
      <ShimLine w="100%" delay={0.22} />
      <ShimLine w="60%"  delay={0.06} />
      <div style={{ height: 8 }} />
      <ShimLine w="100%" delay={0.14} />
      <ShimLine w="90%"  delay={0.04} />
      <ShimLine w="75%"  delay={0.16} />
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────────
export function RenderLoader() {
  const progress  = useAppStore(s => s.renderProgress);
  const pageCount = useAppStore(s => s.pageCount);
  const curPage   = useAppStore(s => s.currentPage);

  const [visible, setVisible]     = useState(false);
  const [opacity, setOpacity]     = useState(1);
  const [barWidth, setBarWidth]   = useState(0);
  const fadeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (progress > 0 && progress < 100) {
      setVisible(true);
      setOpacity(1);
      setBarWidth(progress);
    } else if (progress === 100) {
      setBarWidth(100);
      // Fade out
      if (fadeTimer.current) clearTimeout(fadeTimer.current);
      fadeTimer.current = setTimeout(() => {
        setOpacity(0);
        fadeTimer.current = setTimeout(() => setVisible(false), 400);
      }, 200);
    } else {
      setVisible(false);
      setBarWidth(0);
    }
    return () => { if (fadeTimer.current) clearTimeout(fadeTimer.current); };
  }, [progress]);

  if (!visible) return null;

  const renderedPages = Math.max(1, Math.round((progress / 100) * (pageCount || 1)));
  const isDone = progress >= 100;

  return (
    <>
      {/* Shimmer keyframe — injected once */}
      <style>{`
        @keyframes shimmer {
          0%   { background-position: 200% 0; }
          100% { background-position: -200% 0; }
        }
        @keyframes rl-pulse {
          0%, 100% { opacity: .4; transform: scale(.9); }
          50%       { opacity: 1;  transform: scale(1.1); }
        }
      `}</style>

      {/* Skeleton only on initial load (progress == 1 means just started, page 1) */}
      {!isDone && barWidth <= 5 && <SkeletonPage />}

      {/* Progress bar — top edge of viewer */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0,
        height: 3, background: 'rgba(0,0,0,.08)',
        zIndex: 40, opacity, transition: 'opacity .4s',
      }}>
        <div style={{
          height: '100%', width: `${barWidth}%`,
          background: 'linear-gradient(90deg, #0a84ff, #38bdf8)',
          borderRadius: '0 2px 2px 0',
          transition: 'width .35s ease',
          position: 'relative',
        }}>
          {/* Glow at leading edge */}
          <div style={{
            position: 'absolute', right: -2, top: -3,
            width: 40, height: 9,
            background: 'radial-gradient(ellipse, rgba(56,189,248,.65) 0%, transparent 70%)',
            borderRadius: '50%',
          }} />
        </div>
      </div>

      {/* Label — top right */}
      <div style={{
        position: 'absolute', top: 8, right: 10,
        background: 'rgba(14,22,34,.7)',
        borderRadius: 5, padding: '3px 9px',
        display: 'flex', alignItems: 'center', gap: 6,
        zIndex: 41, opacity,
        transition: 'opacity .4s',
        backdropFilter: 'blur(4px)',
        fontSize: 10, fontWeight: 500, color: '#fff',
        pointerEvents: 'none',
      }}>
        {!isDone && (
          <div style={{
            width: 6, height: 6, borderRadius: '50%',
            background: '#38bdf8',
            animation: 'rl-pulse 1.4s ease-in-out infinite',
          }} />
        )}
        <span>
          {isDone
            ? 'Rendered ✓'
            : `Loading page ${curPage}…`}
        </span>
      </div>
    </>
  );
}
