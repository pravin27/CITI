import React, { useCallback, useEffect, useRef, useState } from 'react';

interface ResizablePanesProps {
  left: React.ReactNode;
  right: React.ReactNode;
  defaultSplit?: number; // 0–1, fraction for left pane
  minLeft?: number;      // px
  minRight?: number;     // px
}

export function ResizablePanes({
  left,
  right,
  defaultSplit = 0.62,
  minLeft = 320,
  minRight = 280,
}: ResizablePanesProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [split, setSplit] = useState(defaultSplit);
  const dragging = useRef(false);
  const startX = useRef(0);
  const startSplit = useRef(defaultSplit);

  const onMouseDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    dragging.current = true;
    startX.current = e.clientX;
    startSplit.current = split;
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';
  }, [split]);

  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      if (!dragging.current || !containerRef.current) return;
      const containerW = containerRef.current.offsetWidth;
      const dx = e.clientX - startX.current;
      const newSplit = startSplit.current + dx / containerW;
      const minLFrac = minLeft / containerW;
      const minRFrac = minRight / containerW;
      setSplit(Math.max(minLFrac, Math.min(1 - minRFrac, newSplit)));
    };

    const onUp = () => {
      if (!dragging.current) return;
      dragging.current = false;
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
    };

    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    return () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
  }, [minLeft, minRight]);

  return (
    <div ref={containerRef} className="flex flex-1 overflow-hidden">
      {/* Left pane */}
      <div
        className="flex flex-col overflow-hidden"
        style={{ width: `${split * 100}%`, minWidth: minLeft }}
      >
        {left}
      </div>

      {/* Drag handle */}
      <div
        onMouseDown={onMouseDown}
        className="w-1 bg-[#1a2740] hover:bg-[#0a84ff]/50 cursor-col-resize shrink-0
          transition-colors duration-150 select-none"
        title="Drag to resize"
      />

      {/* Right pane */}
      <div
        className="flex flex-col overflow-hidden"
        style={{ flex: 1, minWidth: minRight }}
      >
        {right}
      </div>
    </div>
  );
}
