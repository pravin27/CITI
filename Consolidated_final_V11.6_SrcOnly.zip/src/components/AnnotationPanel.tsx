import React, { useRef } from 'react';
import { useAppStore } from '../store/appStore';
import type { AnnotationSettings, StrokeTool } from '../hooks/useAnnotation';

const COLORS = ['#e74c3c','#2980b9','#27ae60','#f39c12','#8e44ad','#111827'];
const TOOLS: { id: StrokeTool; label: string; icon: React.ReactNode }[] = [
  { id: 'pencil', label: 'Pencil', icon: <svg width="12" height="12" viewBox="0 0 14 14" fill="none"><path d="M2 10L9 3l2 2-7 7H2v-2z" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/></svg> },
  { id: 'line',   label: 'Line',   icon: <svg width="12" height="12" viewBox="0 0 14 14" fill="none"><path d="M2 12L12 2" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/></svg> },
  { id: 'rect',   label: 'Rect',   icon: <svg width="12" height="12" viewBox="0 0 14 14" fill="none"><rect x="2" y="2" width="10" height="10" rx="1" stroke="currentColor" strokeWidth="1.4"/></svg> },
  { id: 'circle', label: 'Circle', icon: <svg width="12" height="12" viewBox="0 0 14 14" fill="none"><circle cx="7" cy="7" r="5" stroke="currentColor" strokeWidth="1.4"/></svg> },
  { id: 'eraser', label: 'Eraser', icon: <svg width="12" height="12" viewBox="0 0 14 14" fill="none"><rect x="1" y="5" width="12" height="6" rx="1" stroke="currentColor" strokeWidth="1.3"/><path d="M6 5V11" stroke="currentColor" strokeWidth="1" strokeLinecap="round"/></svg> },
];

interface Props {
  settings: React.MutableRefObject<AnnotationSettings>;
  onSettingsChange: (s: Partial<AnnotationSettings>) => void;
  onUndo: () => void;
  onClear: () => void;
}

export function AnnotationPanel({ settings, onSettingsChange, onUndo, onClear }: Props) {
  const setAnnotateMode = useAppStore(s => s.setAnnotateMode);
  const [, forceUpdate] = React.useReducer(x => x + 1, 0);

  const update = (partial: Partial<AnnotationSettings>) => {
    Object.assign(settings.current, partial);
    onSettingsChange(partial);
    forceUpdate();
  };

  const s = settings.current;

  return (
    <div style={{
      position: 'absolute', top: 8, right: 8, zIndex: 30,
      background: '#fff', border: '0.5px solid #d0d9e8',
      borderRadius: 10, padding: '10px 12px',
      display: 'flex', flexDirection: 'column', gap: 8,
      width: 172, boxShadow: '0 4px 16px rgba(0,0,0,.12)',
    }}>
      {/* Header */}
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between',
        borderBottom:'0.5px solid #f0f0f0', paddingBottom: 7 }}>
        <span style={{ fontSize:12, fontWeight:600, color:'#111827' }}>✏ Annotate</span>
        <button onClick={() => setAnnotateMode(false)} style={{
          background:'transparent', border:'none', color:'#6b7280',
          cursor:'pointer', fontSize:14, lineHeight:1, padding:'0 2px',
        }}>✕</button>
      </div>

      {/* Tools */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:4 }}>
        {TOOLS.map(t => (
          <button key={t.id} onClick={() => update({ tool: t.id })} style={{
            height: 28, borderRadius: 4, border: `1px solid ${s.tool === t.id ? '#f59e0b' : '#d0d9e8'}`,
            background: s.tool === t.id ? '#fffbeb' : '#f9fafb',
            color: s.tool === t.id ? '#92400e' : '#374151',
            cursor: 'pointer', fontSize: 10, fontWeight: s.tool === t.id ? 600 : 400,
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 3,
            transition: 'all .1s',
          }}>
            {t.icon}{t.label}
          </button>
        ))}
      </div>

      {/* Colour */}
      <div style={{ borderTop:'0.5px solid #f0f0f0', paddingTop:6 }}>
        <div style={{ fontSize:10, color:'#9ca3af', marginBottom:4 }}>Colour</div>
        <div style={{ display:'flex', gap:5, flexWrap:'wrap' }}>
          {COLORS.map(col => (
            <div key={col} onClick={() => update({ color: col })} style={{
              width:18, height:18, borderRadius:'50%', background: col, cursor:'pointer',
              border: `2px solid ${s.color === col ? '#111' : 'transparent'}`,
              transform: s.color === col ? 'scale(1.15)' : 'scale(1)',
              transition: 'all .1s',
            }}/>
          ))}
        </div>
      </div>

      {/* Size */}
      <div style={{ borderTop:'0.5px solid #f0f0f0', paddingTop:6 }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:4 }}>
          <span style={{ fontSize:10, color:'#9ca3af' }}>Size</span>
          <span style={{ fontSize:10, color:'#374151', fontWeight:500 }}>{s.size}px</span>
        </div>
        <input type="range" min="1" max="12" value={s.size} style={{ width:'100%', accentColor:'#2a4054' }}
          onChange={e => update({ size: parseInt(e.target.value) })} />
      </div>

      {/* Opacity */}
      <div style={{ borderTop:'0.5px solid #f0f0f0', paddingTop:6 }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:4 }}>
          <span style={{ fontSize:10, color:'#9ca3af' }}>Opacity</span>
          <span style={{ fontSize:10, color:'#374151', fontWeight:500 }}>{s.opacity}%</span>
        </div>
        <input type="range" min="10" max="100" value={s.opacity} style={{ width:'100%', accentColor:'#2a4054' }}
          onChange={e => update({ opacity: parseInt(e.target.value) })} />
      </div>

      {/* Actions */}
      <div style={{ display:'flex', gap:4, borderTop:'0.5px solid #f0f0f0', paddingTop:8 }}>
        <button onClick={onUndo} style={{
          flex:1, height:26, borderRadius:4, border:'1px solid #d0d9e8',
          background:'#f0f4f8', color:'#374151', fontSize:10, cursor:'pointer',
        }}>↩ Undo</button>
        <button onClick={onClear} style={{
          flex:1, height:26, borderRadius:4, border:'1px solid #fca5a5',
          background:'#fef2f2', color:'#b91c1c', fontSize:10, cursor:'pointer',
        }}>🗑 Clear</button>
      </div>

      <div style={{
        padding:'5px 8px', background:'#fffbeb', borderRadius:4,
        border:'0.5px solid #fcd34d', fontSize:10, color:'#92400e', lineHeight:1.4,
      }}>
        Annotations are baked in on Download.
      </div>
    </div>
  );
}
