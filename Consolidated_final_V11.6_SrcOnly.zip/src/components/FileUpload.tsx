import React, { useCallback, useRef, useState } from 'react';
import { useAppStore } from '../store/appStore';
import { detectFormat } from '../adapters/types';

const ACCEPT_EXTS = '.pdf,.tif,.tiff,.bmp,.jpeg,.jpg,.png,.xls,.xlsx,.csv';

const FORMAT_ICONS: Record<string, string> = {
  pdf:         '📄',
  image:       '🖼️',
  spreadsheet: '📊',
  unknown:     '❓',
};

const FORMAT_LABELS: Record<string, string> = {
  pdf:         'PDF Document',
  image:       'Image File',
  spreadsheet: 'Spreadsheet',
  unknown:     'Unknown Format',
};

export function FileUpload() {
  const openFile = useAppStore(s => s.openFile);
  const [isDragging, setIsDragging] = useState(false);
  const [hover, setHover] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = useCallback((file: File) => {
    openFile(file);
  }, [openFile]);

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  }, [handleFile]);

  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const onDragLeave = () => setIsDragging(false);

  const onInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
    e.target.value = '';
  };

  return (
    <div className="flex items-center justify-center h-full w-full bg-[#060d1a]">
      <div className="flex flex-col items-center gap-8 max-w-lg w-full px-6">

        {/* Brand */}
        <div className="text-center">
          <div className="flex items-center justify-center gap-3 mb-2">
            <svg width="36" height="36" viewBox="0 0 36 36" fill="none">
              <rect width="36" height="36" rx="8" fill="#0a84ff" fillOpacity="0.15"/>
              <path d="M10 8h10l8 8v12a2 2 0 01-2 2H10a2 2 0 01-2-2V10a2 2 0 012-2z"
                stroke="#0a84ff" strokeWidth="1.5" fill="none"/>
              <path d="M20 8v8h8" stroke="#0a84ff" strokeWidth="1.5" fill="none"/>
              <path d="M13 19h10M13 23h7" stroke="#0a84ff" strokeWidth="1.5"
                strokeLinecap="round"/>
            </svg>
            <span className="text-2xl font-bold tracking-tight text-white">
              Document Viewer
            </span>
          </div>
          {/* <p className="text-[#8899aa] text-sm">
            Universal document annotation and field capture
          </p> */}
        </div>

        {/* Drop zone */}
        <div
          onClick={() => inputRef.current?.click()}
          onDrop={onDrop}
          onDragOver={onDragOver}
          onDragLeave={onDragLeave}
          onMouseEnter={() => setHover(true)}
          onMouseLeave={() => setHover(false)}
          className={`
            relative w-full rounded-2xl border-2 border-dashed cursor-pointer
            transition-all duration-200 select-none
            flex flex-col items-center justify-center gap-4
            py-14 px-8
            ${isDragging
              ? 'border-[#0a84ff] bg-[#0a84ff]/10 scale-[1.01]'
              : hover
                ? 'border-[#0a84ff]/60 bg-[#0a84ff]/05'
                : 'border-[#334155] bg-[#0d1829]'
            }
          `}
        >
          <input
            ref={inputRef}
            type="file"
            accept={ACCEPT_EXTS}
            className="hidden"
            onChange={onInputChange}
          />

          {/* Upload icon */}
          <div className={`
            w-16 h-16 rounded-2xl flex items-center justify-center
            transition-colors duration-200
            ${isDragging ? 'bg-[#0a84ff]/25' : 'bg-[#1a2740]'}
          `}>
            <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
              <path d="M16 20V10M16 10l-4 4M16 10l4 4"
                stroke={isDragging ? '#0a84ff' : '#4a6280'}
                strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M6 24h20"
                stroke={isDragging ? '#0a84ff' : '#4a6280'}
                strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </div>

          <div className="text-center">
            <p className={`font-semibold text-base transition-colors duration-200 ${
              isDragging ? 'text-[#0a84ff]' : 'text-white'
            }`}>
              {isDragging ? 'Drop to open' : 'Drop a document or click to browse'}
            </p>
            <p className="text-[#8899aa] text-sm mt-1">
              PDF · TIF/TIFF · BMP · JPEG · PNG · XLS · XLSX · CSV
            </p>
          </div>
        </div>

        {/* Format grid */}
        <div className="grid grid-cols-3 gap-3 w-full">
          {[
            { label: 'PDF', desc: 'With text layer', icon: '📄', color: '#ff453a' },
            { label: 'Images', desc: 'TIF/TIFF/BMP/JPEG/PNG', icon: '🖼️', color: '#32d74b' },
            { label: 'Sheets', desc: 'XLS/XLSX/CSV', icon: '📊', color: '#0a84ff' },
          ].map(f => (
            <div key={f.label}
              className="bg-[#0d1829] border border-[#1e2d45] rounded-xl p-3 flex flex-col gap-1"
            >
              <div className="flex items-center gap-2">
                <span className="text-lg">{f.icon}</span>
                <span className="text-white text-sm font-medium">{f.label}</span>
              </div>
              <span className="text-[#607080] text-xs">{f.desc}</span>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
}
