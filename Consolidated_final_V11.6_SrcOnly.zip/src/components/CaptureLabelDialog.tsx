import React, { useState, useEffect, useRef } from 'react';

interface CaptureLabelDialogProps {
  capturedText: string;
  onConfirm: (label: string, value: string) => void;
  onCancel: () => void;
}

export function CaptureLabelDialog({
  capturedText, onConfirm, onCancel,
}: CaptureLabelDialogProps) {
  const [label, setLabel] = useState('');
  const [value, setValue] = useState(capturedText);
  const labelRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    labelRef.current?.focus();
  }, []);

  const handleConfirm = () => {
    if (!label.trim()) return;
    onConfirm(label.trim(), value.trim() || capturedText);
  };

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleConfirm();
    if (e.key === 'Escape') onCancel();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center"
      style={{ background: 'rgba(0,0,0,0.7)' }}
      onClick={e => { if (e.target === e.currentTarget) onCancel(); }}
    >
      <div
        className="bg-[#0d1829] border border-[#1e2d45] rounded-xl shadow-2xl p-5 w-80"
        onKeyDown={handleKey}
      >
        <div className="text-white text-sm font-semibold mb-1">Label this capture</div>
        <div className="text-[#607080] text-xs mb-4 truncate">
          Captured: <span className="text-[#8899aa]">{capturedText}</span>
        </div>

        <div className="mb-3">
          <label className="text-[10px] text-[#607080] uppercase tracking-wide block mb-1">
            Label *
          </label>
          <input
            ref={labelRef}
            value={label}
            onChange={e => setLabel(e.target.value)}
            placeholder="e.g. Invoice Number"
            className="w-full bg-[#060d1a] border border-[#1e2d45] rounded-lg px-2.5 py-1.5
              text-sm text-white placeholder-[#3a4a5a]
              focus:outline-none focus:border-[#0a84ff]/60"
          />
        </div>

        <div className="mb-4">
          <label className="text-[10px] text-[#607080] uppercase tracking-wide block mb-1">
            Value
          </label>
          <input
            value={value}
            onChange={e => setValue(e.target.value)}
            placeholder={capturedText}
            className="w-full bg-[#060d1a] border border-[#1e2d45] rounded-lg px-2.5 py-1.5
              text-sm text-white placeholder-[#3a4a5a]
              focus:outline-none focus:border-[#0a84ff]/60"
          />
        </div>

        <div className="flex gap-2">
          <button
            onClick={onCancel}
            className="flex-1 py-1.5 rounded-lg text-xs text-[#607080] border border-[#1e2d45]
              hover:bg-[#1e2d45] transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleConfirm}
            disabled={!label.trim()}
            className="flex-1 py-1.5 rounded-lg text-xs font-medium
              bg-[#0a84ff] text-white
              hover:bg-[#0a84ff]/80 disabled:opacity-40 transition-colors"
          >
            Confirm
          </button>
        </div>
      </div>
    </div>
  );
}
