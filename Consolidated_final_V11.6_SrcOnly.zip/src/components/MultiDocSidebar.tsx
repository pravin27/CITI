// Inject spin keyframe once for loading spinner
if (typeof document !== 'undefined' && !document.getElementById('mds-spin')) {
  const s = document.createElement('style');
  s.id = 'mds-spin';
  s.textContent = '@keyframes spin { to { transform: rotate(360deg); } }';
  document.head.appendChild(s);
}

import { useState, useRef, useEffect, useCallback } from 'react';
import { getCachedBitmap, setCachedBitmap, hasCachedBitmap, THUMB_W_EXPORT as THUMB_W } from '../hooks/useThumbnailRenderer';
import { useAppStore } from '../store/appStore';
import type { MultiDocState, ResolvedCategory } from '../types/multiDoc';
import { buildPageCatMap } from '../types/multiDoc';
import { MultiDocOutline } from './MultiDocOutline';

// Accept both legacy ('single'/'multi') and new ('MultiDoc:SinglePage'/'MultiDoc:MultiPage') mode strings
function isSinglePage(mode: string): boolean { return mode === 'single' || mode === 'MultiDoc:SinglePage'; }
function isMultiPage(mode: string): boolean  { return mode === 'multi'  || mode === 'MultiDoc:MultiPage';  }


// ── Page thumbnail row (mode:multi thumbnail tab) ─────────────────────────────

// ── Full-size page thumbnail matching SingleDoc style ─────────────────────────
function PageThumbRow({ pageNum, isActive, cat, onClick, adapterKey }: {
  pageNum: number;
  isActive: boolean;
  cat: ResolvedCategory | undefined;
  onClick: () => void;
  adapterKey: string;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const paint = useCallback((bm: ImageBitmap) => {
    const cv = canvasRef.current;
    if (!cv) return;
    cv.width = bm.width; cv.height = bm.height;
    cv.getContext('2d')?.drawImage(bm, 0, 0);
  }, []);

  useEffect(() => {
    if (!adapterKey) return;
    if (hasCachedBitmap(adapterKey, pageNum)) {
      const bm = getCachedBitmap(adapterKey, pageNum);
      if (bm) { paint(bm); return; }
    }
    let cancelled = false;
    const doc = (window as any).__tovPdfDoc;
    if (!doc) return;
    const t = setTimeout(async () => {
      if (cancelled) return;
      try {
        const pdfPage   = await doc.getPage(pageNum);
        const vp0       = pdfPage.getViewport({ scale: 1 });
        const scale     = THUMB_W / vp0.width;
        const vp        = pdfPage.getViewport({ scale });
        const offscreen = new OffscreenCanvas(Math.round(vp.width), Math.round(vp.height));
        const ctx       = offscreen.getContext('2d') as OffscreenCanvasRenderingContext2D;
        await pdfPage.render({ canvasContext: ctx, viewport: vp, intent: 'display' }).promise;
        pdfPage.cleanup();
        const bm = offscreen.transferToImageBitmap();
        if (!cancelled) { setCachedBitmap(adapterKey, pageNum, bm); paint(bm); }
      } catch (_) {}
    }, 0);
    return () => { cancelled = true; clearTimeout(t); };
  }, [pageNum, adapterKey, paint]);

  return (
    <div
      onClick={onClick}
      style={{
        display:       'flex',
        flexDirection: 'column',
        width:         '100%',
        padding:       '10px 18px',   // exactly same as SingleDoc ThumbnailItem
        background:    isActive ? '#dbeafe' : 'transparent',
        borderLeft:    `2px solid ${isActive ? (cat?.color ?? '#2563eb') : 'transparent'}`,
        borderBottom:  '0.5px solid rgba(0,0,0,.05)',
        cursor:        'pointer',
        transition:    'background 0.1s',
        flexShrink:    0,
      }}
    >
      {/* Canvas wrapper — data-thumb-page for IntersectionObserver */}
      <div
        data-thumb-page={pageNum}
        style={{
          width:        '100%',
          maxWidth:     122,   // match SingleDoc: 160px sidebar - 36px padding - 2px borders
          margin:       '0 auto',  // centre within the padded row
          borderRadius: 4,
          overflow:     'hidden',
          border:       `1px solid ${isActive ? (cat?.color ?? '#2563eb') : '#dde3ea'}`,
          background:   '#fff',
          marginBottom: 6,
          position:     'relative',
          minHeight:    20,
        }}
      >
        {cat?.color && (
          <span style={{
            position: 'absolute', left: 0, top: 0, bottom: 0, width: 2,
            background: cat.color, zIndex: 1,
          }} />
        )}
        <canvas ref={canvasRef} style={{ width: '100%', display: 'block', minHeight: 20 }} />
        {/* Page number badge — top left, same as SingleDoc */}
        <div style={{
          position:   'absolute', top: 3, left: 4,
          fontSize:   9, fontWeight: 600, color: '#fff',
          background: 'rgba(30,40,60,.65)', borderRadius: 3,
          padding:    '1px 4px', lineHeight: 1.4, pointerEvents: 'none',
        }}>
          {pageNum}
        </div>
      </div>
    </div>
  );
}

// ── Doc thumbnail row (mode:single) ──────────────────────────────────────────

function DocThumbRow({ doc, isActive, cat, onClick }: {
  doc: { id: string; name: string };
  isActive: boolean;
  cat: ResolvedCategory | undefined;
  onClick: () => void;
}) {
  return (
    <div onClick={onClick} style={{
      display: 'flex', alignItems: 'center', gap: 8,
      padding: '5px 8px 5px 10px',
      borderLeft: `3px solid ${isActive ? (cat?.color ?? '#1a7fd4') : 'transparent'}`,
      borderBottom: '0.5px solid rgba(0,0,0,.05)',
      background: isActive ? '#ddeeff' : undefined,
      cursor: 'pointer', transition: 'background 0.1s',
    }}>
      <div style={{
        width: 32, height: 42, background: '#fff', borderRadius: 2,
        border: '0.5px solid #ccc', flexShrink: 0, overflow: 'hidden',
        position: 'relative', display: 'flex', flexDirection: 'column',
        gap: 2, padding: '4px 4px 3px',
      }}>
        <span style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 2.5, background: cat?.color ?? '#888' }} />
        {[65,100,50,100,75,55].map((w,i) => (
          <div key={i} style={{ height: 2.5, borderRadius: 1, background: i===0?'#c5cdd6':'#e0e4e8', width:`${w}%` }} />
        ))}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 9.5, fontWeight: 500, color: '#1a2a3a', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{doc.name}</div>
        <div style={{ fontSize: 8, color: '#6a7a8a', marginTop: 2 }}>{cat?.label ?? ''}</div>
      </div>
    </div>
  );
}

// ── Main sidebar ──────────────────────────────────────────────────────────────

export interface MultiDocSidebarProps {
  state: MultiDocState;
  isLoading: boolean;
  loadError: string | null;
  adapter?: unknown; // accepted but not used — layout uses compact rows not canvas thumbnails
  onSelectDoc: (docId: string, page?: number) => void;
  onSelectPage: (page: number) => void;
  onClose?: () => void;
}

export function MultiDocSidebar({ state, isLoading, loadError, onSelectDoc, onSelectPage, onClose }: MultiDocSidebarProps) {
  const [tab, setTab] = useState<'thumb'|'outline'>('thumb');
  // Track which category sections are collapsed (none by default — all open)
  const [collapsedCats, setCollapsedCats] = useState<Set<string>>(new Set());
  const toggleCat = (catId: string) => setCollapsedCats(s => {
    const n = new Set(s); n.has(catId) ? n.delete(catId) : n.add(catId); return n;
  });

  const { documents, categories, activeDocId, activePage, mode } = state;

  // Build adapter cache key reactively — updates when doc switches
  const adAdapter   = useAppStore(s => s.adapter);
  const adFileName  = useAppStore(s => s.fileName);
  const adFileSize  = useAppStore(s => s.file?.size ?? 0);
  const adPageCount = useAppStore(s => s.adapter?.pageCount ?? 0);
  const adapterKey  = adAdapter
    ? `${adAdapter.constructor.name}:${adFileName}:${adFileSize}:${adPageCount}`
    : '';

  // Keep showing previous doc during load — no blank flash
  const lastLoadedDocId = { current: activeDocId };

  const catById   = Object.fromEntries(categories.map(c => [c.id, c]));
  const activeDoc = documents.find(d => d.id === activeDocId);
  const activeIdx = activeDocId ? documents.findIndex(d => d.id === activeDocId) : -1;

  // mode:single — group docs by category
  const catGroups: Record<string, typeof documents> = {};
  if (isSinglePage(mode)) {
    documents.forEach(d => {
      const cid = d.categoryId ?? '__none__';
      if (!catGroups[cid]) catGroups[cid] = [];
      catGroups[cid].push(d);
    });
  }

  // mode:multi thumbnail tab — page→category map for active doc
  const pagesByCat: Record<string, number[]> = {};
  const OTHERS_KEY = '__others__';
  if (isMultiPage(mode) && activeDoc?.pageCategories) {
    activeDoc.pageCategories.forEach(pc => {
      pagesByCat[pc.category] = [...pc.pages].sort((a,b) => a-b);
    });
    // Collect pages not listed in any pageCategories entry → "Others"
    const totalPages = activeDoc.totalPages ?? 0;
    if (totalPages > 0) {
      const allListedPages = new Set<number>();
      activeDoc.pageCategories.forEach(pc => pc.pages.forEach(p => allListedPages.add(p)));
      const others: number[] = [];
      for (let p = 1; p <= totalPages; p++) {
        if (!allListedPages.has(p)) others.push(p);
      }
      if (others.length) pagesByCat[OTHERS_KEY] = others;
    }
  }

  const pageCatMap = (isMultiPage(mode) && activeDoc?.pageCategories)
    ? buildPageCatMap(activeDoc.pageCategories)
    : new Map<number,string>();

  return (
    <div style={{ width: 196, flexShrink: 0, display: 'flex', flexDirection: 'column', background: '#eef2f7', borderRight: '1px solid #c8d4e0', height: '100%' }}>

      {/* Header */}
      <div style={{ padding: '8px 10px 6px', borderBottom: '0.5px solid #d0d9e8', background: '#eef2f7', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <div style={{ fontSize: 13, color: '#111827', fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1 }}>
            {isMultiPage(mode) && activeDoc ? activeDoc.name : 'Documents'}
          </div>
          {onClose && (
            <button onClick={onClose} title="Exit multi-doc mode"
              style={{ background: 'transparent', border: 'none', color: '#6b7280', cursor: 'pointer', fontSize: 14, lineHeight: 1, padding: '0 2px', flexShrink: 0 }}
            >✕</button>
          )}
        </div>
        <div style={{ fontSize: 10, color: '#374151', fontWeight: 500, marginTop: 2 }}>
          {isMultiPage(mode)
            ? `Doc ${activeIdx+1} of ${documents.length} · ${activeDoc?.totalPages ?? 0} pages`
            : `${documents.length} docs · ${categories.length} categories`}
        </div>
      </div>

      {/* Prev / Next doc — mode:multi only */}
      {isMultiPage(mode) && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '6px 8px', borderBottom: '0.5px solid #d0d9e8', background: '#eef2f7', flexShrink: 0 }}>
          <button
            disabled={activeIdx <= 0}
            onClick={() => { const p=documents[activeIdx-1]; if(p) onSelectDoc(p.id, p.pageCategories?.[0]?.pages?.[0] ?? 1); }}
            style={{ background:'#dce6f0', border:'0.5px solid #c0cfe0', color:'#374151', borderRadius:5, width:28, height:26, cursor:'pointer', fontSize:16, display:'flex', alignItems:'center', justifyContent:'center', opacity:activeIdx<=0?.3:1 }}
          >‹</button>
          <div style={{ flex:1, textAlign:'center', fontSize:11, color:'#111827', fontWeight:600, background:'#e0eaf5', borderRadius:4, padding:'3px 0' }}>
            {activeIdx>=0?`${activeIdx+1} / ${documents.length}`:`— / ${documents.length}`}
          </div>
          <button
            disabled={activeIdx>=documents.length-1}
            onClick={() => { const n=documents[activeIdx+1]; if(n) onSelectDoc(n.id, n.pageCategories?.[0]?.pages?.[0] ?? 1); }}
            style={{ background:'#dce6f0', border:'0.5px solid #c0cfe0', color:'#374151', borderRadius:5, width:28, height:26, cursor:'pointer', fontSize:16, display:'flex', alignItems:'center', justifyContent:'center', opacity:activeIdx>=documents.length-1?.3:1 }}
          >›</button>
        </div>
      )}

      {/* Tabs — mode:multi only */}
      {isMultiPage(mode) && (
        <div style={{ display: 'flex', borderBottom: '0.5px solid #d0d9e8', flexShrink: 0, background: '#eef2f7' }}>
          {(['thumb','outline'] as const).map(t => (
            <div key={t} onClick={() => setTab(t)} style={{
              flex:1, padding:'6px 0', fontSize:10, fontWeight:500,
              color: tab===t?'#1a5fa0':'#6b7280',
              textAlign:'center', cursor:'pointer',
              borderBottom: tab===t?'2px solid #1a7fd4':'2px solid transparent',
              transition:'color 0.12s',
            }}>{t==='thumb'?'Thumbnails':'Documents'}</div>
          ))}
        </div>
      )}

      {/* Loading / error — overlay style so no layout shift */}
      <div style={{ flex:1, overflowY:'auto', background:'#f2f4f6', position:'relative' }}>

        {isLoading && (
          <div style={{ position:'absolute', inset:0, zIndex:20, background:'rgba(242,244,246,0.8)', display:'flex', alignItems:'center', justifyContent:'center' }}>
            <div style={{ width:18, height:18, borderRadius:'50%', border:'2px solid #d0d9e8', borderTopColor:'#1a7fd4', animation:'spin 0.7s linear infinite' }} />
          </div>
        )}
        {loadError && (
          <div style={{ padding:'8px 10px', fontSize:10, color:'#f87171', borderBottom:'0.5px solid #2a2020' }}>{loadError}</div>
        )}

        {/* ── SINGLE: compact doc list grouped by category ── */}
        {isSinglePage(mode) && categories.map(cat => {
          const catDocs = catGroups[cat.id] ?? [];
          if (!catDocs.length) return null;
          return (
            <div key={cat.id}>
              {/* Accordion header — opaque bg, sticky, collapsible */}
              <button
                onClick={() => toggleCat(cat.id)}
                style={{
                  width:'100%', display:'flex', alignItems:'center', gap:6,
                  padding:'7px 10px 6px 8px', cursor:'pointer', userSelect:'none',
                  background: cat.color,
                  border:'none', borderLeft:`4px solid ${cat.color}`,
                  borderBottom:'0.5px solid rgba(0,0,0,.15)', textAlign:'left',
                  position:'sticky', top:0, zIndex:10, outline:'none',
                }}>
                <span style={{
                  display:'flex', flexShrink:0, color:'rgba(255,255,255,.9)',
                  transform: collapsedCats.has(cat.id) ? 'rotate(0deg)' : 'rotate(90deg)',
                  transition:'transform 0.18s ease',
                }}>
                  <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
                    <path d="M3 2l4 3-4 3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </span>
                <span style={{ width:7, height:7, borderRadius:'50%', background:'rgba(255,255,255,0.6)', flexShrink:0 }} />
                <span style={{ fontSize:11, fontWeight:500, color:'#fff', flex:1, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                  {cat.label}
                </span>
                <span style={{ fontSize:10, padding:'1px 6px', borderRadius:10, background:'rgba(255,255,255,0.2)', color:'#fff', fontWeight:500, flexShrink:0 }}>
                  {catDocs.length}
                </span>
              </button>
              {!collapsedCats.has(cat.id) && catDocs.map(d => (
                <DocThumbRow key={d.id} doc={d} isActive={d.id===activeDocId} cat={cat} onClick={() => onSelectDoc(d.id, 1)} />
              ))}
            </div>
          );
        })}

        {/* ── MULTI thumbnail tab: pages of active doc grouped by category ── */}
        {isMultiPage(mode) && tab === 'thumb' && (
          activeDocId ? (
            <>
              {categories.map(cat => {
                const pages = pagesByCat[cat.id];
                if (!pages?.length) return null;
                return (
                  <div key={cat.id}>
                    <button
                      onClick={() => toggleCat(`multi:${cat.id}`)}
                      style={{
                        width:'100%', display:'flex', alignItems:'center', gap:6,
                        padding:'7px 10px 6px 8px', cursor:'pointer', userSelect:'none',
                        background: cat.color,
                        border:'none', borderLeft:`4px solid ${cat.color}`,
                        borderBottom:'0.5px solid rgba(0,0,0,.15)', textAlign:'left',
                        position:'sticky', top:0, zIndex:10, outline:'none',
                      }}>
                      <span style={{
                        display:'flex', flexShrink:0, color:'rgba(255,255,255,.9)',
                        transform: collapsedCats.has(`multi:${cat.id}`) ? 'rotate(0deg)' : 'rotate(90deg)',
                        transition:'transform 0.18s ease',
                      }}>
                        <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
                          <path d="M3 2l4 3-4 3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      </span>
                      <span style={{ width:7, height:7, borderRadius:'50%', background:'rgba(255,255,255,0.6)', flexShrink:0 }} />
                      <span style={{ fontSize:11, fontWeight:500, color:'#fff', flex:1, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                        {cat.label}
                      </span>
                      <span style={{ fontSize:10, padding:'1px 6px', borderRadius:10, background:'rgba(255,255,255,0.2)', color:'#fff', fontWeight:500, flexShrink:0 }}>
                        {pages.length} pg
                      </span>
                    </button>
                    {!collapsedCats.has(`multi:${cat.id}`) && pages.map(pg => {
                      const catId = pageCatMap.get(pg);
                      return (
                        <PageThumbRow
                          key={pg}
                          pageNum={pg}
                          isActive={pg === activePage}
                          cat={catId ? catById[catId] : undefined}
                          onClick={() => onSelectPage(pg)}
                          adapterKey={adapterKey}
                        />
                      );
                    })}
                  </div>
                );
              })}
              {/* Others — pages not listed in any category */}
              {pagesByCat[OTHERS_KEY]?.length ? (() => {
                const pages = pagesByCat[OTHERS_KEY];
                const key = `multi:${OTHERS_KEY}`;
                return (
                  <div key={OTHERS_KEY}>
                    <button
                      onClick={() => toggleCat(key)}
                      style={{
                        width:'100%', display:'flex', alignItems:'center', gap:6,
                        padding:'7px 10px 6px 8px', cursor:'pointer', userSelect:'none',
                        background: '#4b5563',
                        border:'none', borderLeft:'4px solid #4b5563',
                        borderBottom:'0.5px solid rgba(0,0,0,.15)', textAlign:'left',
                        position:'sticky', top:0, zIndex:10, outline:'none',
                      }}>
                      <span style={{
                        display:'flex', flexShrink:0, color:'rgba(255,255,255,.9)',
                        transform: collapsedCats.has(key) ? 'rotate(0deg)' : 'rotate(90deg)',
                        transition:'transform 0.18s ease',
                      }}>
                        <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
                          <path d="M3 2l4 3-4 3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      </span>
                      <span style={{ width:7, height:7, borderRadius:'50%', background:'rgba(255,255,255,0.6)', flexShrink:0 }} />
                      <span style={{ fontSize:11, fontWeight:500, color:'#fff', flex:1 }}>Others</span>
                      <span style={{ fontSize:10, padding:'1px 6px', borderRadius:10, background:'rgba(255,255,255,0.2)', color:'#fff', fontWeight:500, flexShrink:0 }}>
                        {pages.length} pg
                      </span>
                    </button>
                    {!collapsedCats.has(key) && pages.map(pg => (
                      <PageThumbRow
                        key={pg}
                        pageNum={pg}
                        isActive={pg === activePage}
                        cat={undefined}
                        onClick={() => onSelectPage(pg)}
                        adapterKey={adapterKey}
                      />
                    ))}
                  </div>
                );
              })() : null}
            </>
          ) : (
            <div style={{ padding:'16px 10px', fontSize:10, color:'#6b7280', textAlign:'center' }}>Select a document to view pages</div>
          )
        )}

        {/* ── MULTI outline tab ── */}
        {isMultiPage(mode) && tab === 'outline' && (
          <MultiDocOutline state={state} onSelectDoc={onSelectDoc} onSelectPage={onSelectPage} />
        )}
      </div>
    </div>
  );
}
