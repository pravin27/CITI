import React, { useRef, useCallback } from 'react';
import { useAppStore } from '../store/appStore';
import { PDFViewer } from './PDFViewer';
import { ImageViewer } from './ImageViewer';
import { SpreadsheetViewer } from './SpreadsheetViewer';
import { useBoxCapture } from '../hooks/useBoxCapture';
import { useAnnotation } from '../hooks/useAnnotation';
import { AnnotationPanel } from './AnnotationPanel';
import { isEmbedded } from '../hooks/useEventBridge';
import type { EventBridgeAPI } from '../hooks/useEventBridge';
import { RenderLoader } from './RenderLoader';
import type { AnnotationSettings } from '../hooks/useAnnotation';
import { useHighlightCanvas } from '../hooks/useHighlightCanvas';
import { useWordSpanInjector } from '../hooks/useWordSpanInjector';
import type { PDFAdapter } from '../adapters/PDFAdapter';
import type { ImageAdapter } from '../adapters/ImageAdapter';
import type { SpreadsheetAdapter } from '../adapters/SpreadsheetAdapter';
import type { DocAdapter } from '../adapters/DocAdapter';
import type { CaptureResult } from '../hooks/useBoxCapture';

// ── No-file placeholder ───────────────────────────────────────────────────────
function NoPreview() {
  const isLoading = useAppStore(s => s.isLoading);
  const loadError = useAppStore(s => s.loadError);




  if (isLoading) return (
    <div className="flex-1 flex items-center justify-center bg-[#e8e8e8]">
      <div className="text-center">
        <div className="w-10 h-10 border-2 border-[#0a84ff] border-t-transparent rounded-full animate-spin mx-auto mb-3" />
        <p className="text-[#8899aa] text-sm">Loading document…</p>
      </div>
    </div>
  );

  if (loadError) return (
    <div className="flex-1 flex items-center justify-center bg-[#e8e8e8]">
      <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-6 max-w-sm text-center">
        <div className="text-red-400 text-xl mb-2">⚠</div>
        <div className="text-white font-semibold mb-1 text-sm">Failed to open</div>
        <div className="text-red-400 text-xs">{loadError}</div>
      </div>
    </div>
  );

  return (
    <div className="flex-1 select-none" style={{ position: 'relative', overflow: 'hidden', background: '#e8e9eb' }}>

      {/* Dot-grid background */}
      <svg style={{ position:'absolute', inset:0, width:'100%', height:'100%', opacity:.22 }}
        xmlns="http://www.w3.org/2000/svg">
        <defs>
          <pattern id="np-dots" x="0" y="0" width="24" height="24" patternUnits="userSpaceOnUse">
            <circle cx="1" cy="1" r="1" fill="#94a3b8"/>
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#np-dots)"/>
      </svg>

      {/* Centred content */}
      <div style={{
        position: 'absolute', inset: 0,
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center', gap: 20,
      }}>
        {/* Stacked pages illustration */}
        <div style={{ position: 'relative', width: 96, height: 118 }}>
          {/* Back page */}
          <div style={{
            position: 'absolute', left: 0, top: 14, width: 72, height: 92,
            background: '#d1dae4', borderRadius: 4, transform: 'rotate(-6deg)',
          }}/>
          {/* Mid page */}
          <div style={{
            position: 'absolute', left: 8, top: 7, width: 72, height: 92,
            background: '#dde5ed', borderRadius: 4, transform: 'rotate(-2deg)',
          }}/>
          {/* Front page */}
          <div style={{
            position: 'absolute', left: 16, top: 0, width: 72, height: 92,
            background: '#fff', borderRadius: 4,
            border: '0.5px solid #c8d4e0',
            display: 'flex', flexDirection: 'column',
            padding: '10px 9px', gap: 5,
          }}>
            <div style={{ height: 8, background: '#d0dce8', borderRadius: 2, width: '80%' }}/>
            <div style={{ height: 6, background: '#eaeff5', borderRadius: 2 }}/>
            <div style={{ height: 6, background: '#eaeff5', borderRadius: 2, width: '90%' }}/>
            <div style={{ height: 6, background: '#eaeff5', borderRadius: 2, width: '70%' }}/>
            <div style={{ height: 6, background: '#eaeff5', borderRadius: 2, width: '85%' }}/>
          </div>
        </div>

        {/* Heading only — no subtext */}
        <p style={{ fontSize: 16, fontWeight: 700, color: '#1e293b', letterSpacing: '-.01em' }}>
          No preview available
        </p>
      </div>
    </div>
  );
}

// ── Main pane ─────────────────────────────────────────────────────────────────
export function ViewerPane({ multiDocLoading = false, bridge }: {
  multiDocLoading?: boolean;
  bridge?: EventBridgeAPI;
}) {
  const file             = useAppStore(s => s.file);
  const format           = useAppStore(s => s.format);
  const adapter          = useAppStore(s => s.adapter);
  const zoom             = useAppStore(s => s.zoom);
  const setPendingCapture = useAppStore(s => s.setPendingCapture);
  const annotateMode = useAppStore(s => s.annotateMode);
  const currentPage  = useAppStore(s => s.currentPage);
  const setPreviewRect    = useAppStore(s => s.setPreviewRect);

  const containerRef = useRef<HTMLDivElement>(null);
  const annotationSettings = useRef<AnnotationSettings>({
    tool: 'pencil', color: '#e74c3c', size: 2, opacity: 100,
  });
  const { undo, clear } = useAnnotation(
    containerRef as React.RefObject<HTMLElement>,
    annotationSettings
  );

  const handleCapture = useCallback((result: CaptureResult) => {
    // Set preview immediately (shows the capture panel)
    setPendingCapture({ text: result.text, page: result.page,
      x: result.x, y: result.y, width: result.width, height: result.height,
      _textField: result._textField,
      sourceFormat: result.sourceFormat });
    setPreviewRect({ page: result.page, x: result.x, y: result.y,
      width: result.width, height: result.height });

    // In embedded mode: delegate to bridge.handleCaptureResult — centralised in useEventBridge.
    // Fires CAPTURE_PREVIEW to parent, waits for CAPTURE_ACK, then adds capture with real ID.
    // If parent doesn't ACK in 15s → preview clears, nothing saved.
    if (isEmbedded && bridge) {
      const file = useAppStore.getState().file;

      // Send raw coords back to parent if available (round-trip fidelity).
      // When word_index was received as { x:14, y:144, width:30, height:9 },
      // we normalise internally to 0-1 but store originals in _rawX etc.
      // Use raw if present, otherwise send the normalised 0-1 values.
      const r = result as any;
      const sendX = r._rawX      !== undefined ? r._rawX      : result.x;
      const sendY = r._rawY      !== undefined ? r._rawY      : result.y;
      const sendW = r._rawWidth  !== undefined ? r._rawWidth  : result.width;
      const sendH = r._rawHeight !== undefined ? r._rawHeight : result.height;

      // Deactivate any current active highlight before emitting
      useAppStore.getState().setActiveField(null);

      bridge.handleCaptureResult({
        tempId: '',
        text:   result.text,
        page:   result.page,
        x:      sendX,
        y:      sendY,
        width:  sendW,
        height: sendH,
        docId:  (file as any)?.__docId,
      }).then(realId => {
        const pending = useAppStore.getState().pendingCapture;
        if (!pending) return;

        // Build new item from result coords (always 0-1 internally)
        const newItem: import('../adapters/types').CaptureItem = {
          id:           realId,
          label:        result.text,
          value:        result.text,
          page:         result.page,
          x:            result.x,
          y:            result.y,
          width:        result.width,
          height:       result.height,
          sourceFormat: result.sourceFormat,
          _textField:   result._textField,
          _rawX:        r._rawX, _rawY: r._rawY,
          _rawWidth:    r._rawWidth, _rawHeight: r._rawHeight,
          _rawUnit:     r._rawUnit,
        };

        const st = useAppStore.getState();
        const existing = st.captures.find(c => c.id === realId);

        if (existing) {
          // ID already in captures → replace (no duplicate)
          st.replaceCapture(newItem);
        } else {
          st.addCapture(newItem);
        }

        // Deactivate highlight — new capture added, nothing should be active
        st.setActiveField(null);
        st.clearPendingCapture();
        st.clearPreviewRect();
      }).catch(() => {
        useAppStore.getState().clearPendingCapture();
        useAppStore.getState().clearPreviewRect();
      });
    }
  }, [setPendingCapture, setPreviewRect, bridge]);

  useBoxCapture(containerRef as React.RefObject<HTMLElement>, handleCapture);
  useHighlightCanvas(containerRef as React.RefObject<HTMLElement>);
  useWordSpanInjector(containerRef as React.RefObject<HTMLElement>);

  const hasFile = !!file && !!adapter;

  return (
    <div className="flex flex-col flex-1 overflow-hidden">
      <div ref={containerRef} className="flex-1 flex flex-col overflow-hidden relative">
        {/* Multi-doc loading overlay — shown while fetching a document */}
        {multiDocLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-[#1e2d3d]/80 z-20">
            <div className="text-center">
              <div className="w-8 h-8 border-2 border-[#1a7fd4] border-t-transparent rounded-full animate-spin mx-auto mb-2" />
              <p className="text-[#8ab0c8] text-xs">Loading document…</p>
            </div>
          </div>
        )}
        {!hasFile && !multiDocLoading && <NoPreview />}
        {/* Render progress bar + skeleton — shown while PDF is rendering */}
        {hasFile && format === 'pdf' && <RenderLoader />}
        {hasFile && format === 'pdf' && (
          <PDFViewer file={file!} adapter={adapter as PDFAdapter} zoom={zoom} />
        )}
        {hasFile && (format === 'image' || format === 'document') && (
          <ImageViewer adapter={adapter as unknown as ImageAdapter} zoom={zoom} />
        )}
        {hasFile && format === 'spreadsheet' && (
          <SpreadsheetViewer adapter={adapter as SpreadsheetAdapter} />
        )}
        {/* Annotation floating panel — shown when annotateMode active */}
        {annotateMode && (
          <AnnotationPanel
            settings={annotationSettings}
            onSettingsChange={() => {}}
            onUndo={undo}
            onClear={clear}
          />
        )}
      </div>
    </div>
  );
}
