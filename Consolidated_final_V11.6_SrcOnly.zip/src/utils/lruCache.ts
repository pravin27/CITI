export class LRUCache<K, V> {
  _map  = new Map<K, V>();
  _keys: K[] = [];
  _cap: number;
  _onEvict?: (k: K, v: V) => void;

  constructor(capacity: number, onEvict?: (k: K, v: V) => void) {
    this._cap = capacity;
    this._onEvict = onEvict;
  }

  get(key: K): V | undefined {
    const v = this._map.get(key);
    if (v === undefined) return undefined;
    this._keys = this._keys.filter(k => k !== key);
    this._keys.push(key);
    return v;
  }

  set(key: K, value: V) {
    if (this._map.has(key)) {
      this._onEvict?.(key, this._map.get(key)!);
      this._keys = this._keys.filter(k => k !== key);
    }
    while (this._keys.length >= this._cap) {
      const lru = this._keys.shift()!;
      this._onEvict?.(lru, this._map.get(lru)!);
      this._map.delete(lru);
    }
    this._map.set(key, value);
    this._keys.push(key);
  }

  has(key: K)   { return this._map.has(key); }
  get size()    { return this._map.size; }
  values()      { return this._map.values(); }
  entries()     { return this._map.entries(); }

  delete(key: K) {
    if (!this._map.has(key)) return;
    this._onEvict?.(key, this._map.get(key)!);
    this._map.delete(key);
    this._keys = this._keys.filter(k => k !== key);
  }

  clear() {
    for (const [k, v] of this._map) this._onEvict?.(k, v);
    this._map.clear();
    this._keys = [];
  }
}
