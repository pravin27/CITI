// ─────────────────────────────────────────────────────────────────────────────
// Color resolution utilities
// Offscreen canvas created ONCE per unique color, never per frame.
// ─────────────────────────────────────────────────────────────────────────────

const rgbaCache = new Map<string, string>();
const hexCache = new Map<string, string>(); // raw color → #rrggbb

/** Convert any CSS color + alpha to rgba() string. Cached. */
export function colorToRgba(color: string, alpha: number): string {
  const key = `${color}:${alpha}`;
  if (rgbaCache.has(key)) return rgbaCache.get(key)!;

  const hex = resolveToHex(color);
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  const result = `rgba(${r},${g},${b},${alpha})`;
  rgbaCache.set(key, result);
  return result;
}

/** Resolve any CSS color string to #rrggbb. Cached. */
function resolveToHex(color: string): string {
  if (hexCache.has(color)) return hexCache.get(color)!;

  let result = '#888888';

  // 3-digit hex
  if (/^#[0-9a-fA-F]{3}$/.test(color)) {
    const [, r, g, b] = color;
    result = `#${r}${r}${g}${g}${b}${b}`;
  }
  // 6-digit hex
  else if (/^#[0-9a-fA-F]{6}$/.test(color)) {
    result = color.toLowerCase();
  }
  // rgb(...) or named color → offscreen canvas
  else {
    try {
      const canvas = document.createElement('canvas');
      canvas.width = 1;
      canvas.height = 1;
      const ctx = canvas.getContext('2d')!;
      ctx.fillStyle = color;
      ctx.fillRect(0, 0, 1, 1);
      const [r, g, b] = ctx.getImageData(0, 0, 1, 1).data;
      result = `#${byteHex(r)}${byteHex(g)}${byteHex(b)}`;
    } catch {
      // fallback to grey
    }
  }

  hexCache.set(color, result);
  return result;
}

function byteHex(n: number): string {
  return n.toString(16).padStart(2, '0');
}

/** Strip leading/trailing punctuation from a word for matching. */
export function stripPunct(word: string): string {
  return word.toLowerCase().replace(/^[^\w]+|[^\w]+$/g, '').trim();
}

/** Escape a string for use in a RegExp */
export function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
