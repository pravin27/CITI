// parseHighlightPayload — normalise a HIGHLIGHT payload from the parent
// into a CaptureItem ready to add to the store.
//
// The parent may send coords in any format that parseJson / handleConfirm accepts:
//   • flat:            { x, y, width, height }            (0–1 fractions)
//   • bbox_relative:   { bbox_relative: [x,y,w,h] }
//   • bbox:            { bbox: [x1,y1,x2,y2] }
//   • rectangle:       { rectangle: [x1,y1,x2,y2] }
//   • coordinates:     { coordinates: [y1,x1,y2,x2] }
//   • pixel/point:     any of the above with raw pixel/pt values (auto-detected)
//
// Uses the same extractRawCoords + normaliseCoords pipeline as FieldsPanel.

import type { CaptureItem } from '../adapters/types';
import { extractRawCoords, normaliseCoords } from './coords';
import type { ViewerAdapter } from '../adapters/types';
import type { HighlightPayload } from '../hooks/useEventBridge';

export interface ParsedHighlight {
  item: CaptureItem;
  error?: never;
}
export interface ParseHighlightError {
  item?: never;
  error: string;
}

export function parseHighlightPayload(
  payload: HighlightPayload,
  adapter: ViewerAdapter | null,
): ParsedHighlight | ParseHighlightError {
  const { id, label, value, page, color, sourceFormat } = payload;

  if (!id) return { error: 'HIGHLIGHT payload missing "id"' };
  if (!page || page < 1) return { error: 'HIGHLIGHT payload missing valid "page"' };

  // Build a synthetic JSON object that extractRawCoords understands
  // so we can reuse the exact same normalisation pipeline as handleConfirm
  const synthetic: Record<string, unknown> = {
    id, label, value, page, color,
    x: payload.x, y: payload.y,
    width: payload.width, height: payload.height,
  };

  // If parent sent a structured coord format, preserve it
  if ((payload as any).bbox_relative) synthetic.bbox_relative = (payload as any).bbox_relative;
  if ((payload as any).bbox)          synthetic.bbox          = (payload as any).bbox;
  if ((payload as any).rectangle)     synthetic.rectangle     = (payload as any).rectangle;
  if ((payload as any).coordinates)   synthetic.coordinates   = (payload as any).coordinates;

  // Extract raw coords using the same utility as parseJson in FieldsPanel
  const rc = extractRawCoords(synthetic);
  if (!rc) return { error: 'HIGHLIGHT payload has no recognisable coordinate fields' };

  let [x, y, w, h] = rc;

  // Detect sourceFormat from whichever key is present (same logic as parseJson)
  let detectedFormat: CaptureItem['sourceFormat'] = sourceFormat ?? 'flat';
  if (!sourceFormat) {
    if ('bbox_relative' in synthetic) detectedFormat = 'bbox_relative';
    else if ('bbox'       in synthetic) detectedFormat = 'bbox';
    else if ('rectangle'  in synthetic) detectedFormat = 'rectangle';
    else if ('coordinates'in synthetic) detectedFormat = 'coordinates';
  }

  // Normalise if coords are NOT already 0–1 fractions
  // (same condition as handleConfirm: x > 1 || y > 1 || w > 1 || h > 1)
  if (x > 1 || y > 1 || w > 1 || h > 1) {
    try {
      [x, y, w, h] = normaliseCoords(rc, synthetic, page, adapter as any, null);
    } catch (err) {
      return { error: `Coord normalisation failed: ${err}` };
    }
  }

  const item: CaptureItem = {
    id:           String(id),
    label:        label ? String(label) : String(id),
    value:        value !== undefined ? String(value) : '',
    page,
    x, y,
    width:  w,
    height: h,
    color:  color ? String(color) : undefined,
    sourceFormat: detectedFormat,
  };

  return { item };
}
