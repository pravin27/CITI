// annotationDownload — flatten annotation strokes onto documents before download
//
// KEY INSIGHT: The annotation canvas covers the ENTIRE viewer container.
// Strokes are stored in container-relative coordinates.
// The PDF page is centred within the container — strokes need to be
// offset-corrected and scaled to map from container coords → page coords.

import { redrawAnnotations } from '../hooks/useAnnotation';
import type { Stroke } from '../hooks/useAnnotation';

// ── Helpers ───────────────────────────────────────────────────────────────────

function triggerDownload(url: string, name: string, revokeMs = 2000) {
  const a = document.createElement('a');
  a.href = url; a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(url), revokeMs);
}

async function canvasToBlob(canvas: HTMLCanvasElement, mime = 'image/png', quality?: number): Promise<Uint8Array> {
  return new Promise((res, rej) =>
    canvas.toBlob(
      b => b ? b.arrayBuffer().then(ab => res(new Uint8Array(ab))).catch(rej) : rej(new Error('toBlob failed')),
      mime, quality
    )
  );
}

function ext(fileName: string) {
  return fileName.split('.').pop()?.toLowerCase() ?? '';
}

// Extract strokes for a specific page — keys are "...adapterKey...:pageNum"
function getPageStrokes(allStrokes: Map<string, Stroke[]>, page: number): Stroke[] {
  const suffix = `:${page}`;
  for (const [key, strokes] of allStrokes) {
    if (key.endsWith(suffix) && strokes.length > 0) return strokes;
  }
  return [];
}

// Build annotation canvas for a page.
// Strokes are in container coordinates. We crop to the page area by:
// 1. Creating a canvas the size of the PAGE (pw × ph)
// 2. Translating by (-offsetX, -offsetY) so page-origin aligns with canvas-origin
// 3. Drawing strokes in original container coordinates (they naturally clip)
function buildPageAnnotationCanvas(
  allStrokes: Map<string, Stroke[]>,
  page: number,
  pageW: number, pageH: number,
  offsetX: number, offsetY: number,
): HTMLCanvasElement | null {
  const strokes = getPageStrokes(allStrokes, page);
  if (!strokes.length) return null;

  const cv = document.createElement('canvas');
  cv.width = pageW; cv.height = pageH;
  const ctx = cv.getContext('2d')!;

  // Translate so that container-coord (offsetX, offsetY) maps to canvas (0,0)
  ctx.save();
  ctx.translate(-offsetX, -offsetY);
  redrawAnnotations(cv, strokes, 1, 1, ctx); // pass ctx with translation applied
  ctx.restore();

  return cv;
}

// ── Public entry point ────────────────────────────────────────────────────────

export async function downloadWithAnnotations(
  file: File,
  format: string,
  allStrokes: Map<string, Stroke[]>,
  pageCount: number,
  getViewportSize: (page: number) => { w: number; h: number; containerW: number; containerH: number } | null
) {
  const fileExt = ext(file.name);
  const isTif   = fileExt === 'tif' || fileExt === 'tiff';
  const isJpeg  = fileExt === 'jpg' || fileExt === 'jpeg';

  if (format === 'pdf') {
    await downloadPDF(file, allStrokes, pageCount, getViewportSize);
  } else if (format === 'image') {
    if (isTif && pageCount > 1) {
      await downloadMultiFrameAsPDF(file, allStrokes, pageCount, getViewportSize);
    } else {
      await downloadSingleImage(file, allStrokes, getViewportSize, isJpeg);
    }
  } else {
    // DOC/XLS — not rasterisable
    triggerDownload(URL.createObjectURL(file), file.name, 1000);
  }
}

// ── PDF ───────────────────────────────────────────────────────────────────────

async function downloadPDF(
  file: File,
  allStrokes: Map<string, Stroke[]>,
  pageCount: number,
  getViewportSize: (page: number) => { w: number; h: number; containerW: number; containerH: number } | null
) {
  try {
    const { PDFDocument } = await import('pdf-lib');
    const pdfDoc  = await PDFDocument.load(await file.arrayBuffer());
    const pages   = pdfDoc.getPages();
    const viewer  = (window as any).__tovPdfViewer;
    const annotEl = document.querySelector<HTMLCanvasElement>('[data-annotation-canvas]');

    for (let i = 0; i < pageCount; i++) {
      const pageNum = i + 1;
      const strokes = getPageStrokes(allStrokes, pageNum);
      if (!strokes.length) continue;

      // Get the pdfjs page canvas to determine position within viewer
      let pageW = 0, pageH = 0, offsetX = 0, offsetY = 0;

      if (viewer) {
        try {
          const pv = viewer.getPageView(i);
          if (pv?.canvas) {
            const pRect = pv.canvas.getBoundingClientRect();
            const aRect = annotEl?.getBoundingClientRect();
            pageW   = pv.canvas.offsetWidth  || pv.canvas.clientWidth  || pv.canvas.width;
            pageH   = pv.canvas.offsetHeight || pv.canvas.clientHeight || pv.canvas.height;
            offsetX = aRect ? pRect.left - aRect.left : 0;
            offsetY = aRect ? pRect.top  - aRect.top  : 0;
          } else if (pv?.viewport) {
            pageW = Math.round(pv.viewport.width);
            pageH = Math.round(pv.viewport.height);
          }
        } catch (_) {}
      }

      if (!pageW || !pageH) {
        const vp = getViewportSize(pageNum);
        if (!vp) continue;
        pageW = vp.w; pageH = vp.h;
        offsetX = 0; offsetY = 0;
      }

      console.log(`[Bake] page ${pageNum}: canvas ${pageW}x${pageH} offset ${Math.round(offsetX)},${Math.round(offsetY)} strokes=${strokes.length}`);

      // Render strokes onto a canvas sized to the page, offset-corrected
      const annCv = document.createElement('canvas');
      annCv.width = pageW; annCv.height = pageH;
      const ctx = annCv.getContext('2d')!;
      ctx.save();
      ctx.translate(-offsetX, -offsetY);
      redrawAnnotations(annCv, strokes, 1, 1, ctx);
      ctx.restore();

      // Embed into PDF
      const pngBytes = await canvasToBlob(annCv, 'image/png');
      const pngImage = await pdfDoc.embedPng(pngBytes);
      const pdfPage  = pages[i];
      const { width: pdfW, height: pdfH } = pdfPage.getSize();

      // PDF coords: y=0 is bottom. drawImage with y=0 and height=pdfH flips correctly
      // because the PNG covers the full page top-to-bottom
      pdfPage.drawImage(pngImage, { x: 0, y: 0, width: pdfW, height: pdfH });
    }

    const saved = await pdfDoc.save();
    const blob  = new Blob([saved as unknown as BlobPart], { type: 'application/pdf' });
    triggerDownload(URL.createObjectURL(blob), file.name.replace(/\.pdf$/i, '_annotated.pdf'));
  } catch (err) {
    console.error('[Annotation] PDF bake failed:', err);
    triggerDownload(URL.createObjectURL(file), file.name, 1000);
  }
}

// ── Single-page image ─────────────────────────────────────────────────────────

async function downloadSingleImage(
  file: File,
  allStrokes: Map<string, Stroke[]>,
  getViewportSize: (page: number) => { w: number; h: number; containerW: number; containerH: number } | null,
  preferJpeg: boolean
) {
  try {
    const vp = getViewportSize(1);
    const strokes = getPageStrokes(allStrokes, 1);
    if (!strokes.length || !vp) { triggerDownload(URL.createObjectURL(file), file.name, 1000); return; }

    const blobUrl = URL.createObjectURL(file);
    const img = await new Promise<HTMLImageElement>((res, rej) => {
      const im = new Image(); im.onload = () => res(im); im.onerror = rej; im.src = blobUrl;
    });
    URL.revokeObjectURL(blobUrl);

    const out = document.createElement('canvas');
    out.width = img.naturalWidth; out.height = img.naturalHeight;
    const ctx = out.getContext('2d')!;
    ctx.drawImage(img, 0, 0);

    // Scale strokes from viewport (display) coords to natural image coords
    const sx = img.naturalWidth  / vp.w;
    const sy = img.naturalHeight / vp.h;
    const annCv = document.createElement('canvas');
    annCv.width = vp.w; annCv.height = vp.h;
    redrawAnnotations(annCv, strokes);
    ctx.save(); ctx.scale(sx, sy); ctx.drawImage(annCv, 0, 0); ctx.restore();

    const mime  = preferJpeg ? 'image/jpeg' : 'image/png';
    const outExt = preferJpeg ? '.jpg' : '.png';
    const bytes = await canvasToBlob(out, mime, preferJpeg ? 0.92 : undefined);
    const blob  = new Blob([bytes as unknown as BlobPart], { type: mime });
    triggerDownload(URL.createObjectURL(blob), file.name.replace(/\.[^.]+$/, `_annotated${outExt}`));
  } catch (err) {
    console.error('[Annotation] Image bake failed:', err);
    triggerDownload(URL.createObjectURL(file), file.name, 1000);
  }
}

// ── Multi-page TIF → PDF ──────────────────────────────────────────────────────

async function downloadMultiFrameAsPDF(
  file: File,
  allStrokes: Map<string, Stroke[]>,
  pageCount: number,
  getViewportSize: (page: number) => { w: number; h: number; containerW: number; containerH: number } | null
) {
  try {
    const { PDFDocument } = await import('pdf-lib');
    const { useAppStore }  = await import('../store/appStore');
    const adapter = useAppStore.getState().adapter as any;
    const outDoc  = await PDFDocument.create();

    for (let page = 1; page <= pageCount; page++) {
      const frame = await adapter?.getFrameAsync?.(page);
      if (!frame) continue;

      const base = document.createElement('canvas');
      base.width = frame.bitmap.width; base.height = frame.bitmap.height;
      base.getContext('2d')!.drawImage(frame.bitmap, 0, 0);

      const strokes = getPageStrokes(allStrokes, page);
      if (strokes.length) {
        const vp = getViewportSize(page);
        if (vp) {
          const annCv = document.createElement('canvas');
          annCv.width = vp.w; annCv.height = vp.h;
          redrawAnnotations(annCv, strokes);
          const sx = frame.bitmap.width / vp.w;
          const sy = frame.bitmap.height / vp.h;
          const ctx = base.getContext('2d')!;
          ctx.save(); ctx.scale(sx, sy); ctx.drawImage(annCv, 0, 0); ctx.restore();
        }
      }

      const pngBytes = await canvasToBlob(base, 'image/png');
      const pngImg   = await outDoc.embedPng(pngBytes);
      const pdfPage  = outDoc.addPage([frame.bitmap.width, frame.bitmap.height]);
      pdfPage.drawImage(pngImg, { x: 0, y: 0, width: frame.bitmap.width, height: frame.bitmap.height });
    }

    const saved = await outDoc.save();
    const blob  = new Blob([saved as unknown as BlobPart], { type: 'application/pdf' });
    triggerDownload(URL.createObjectURL(blob), file.name.replace(/\.tiff?$/i, '_annotated.pdf'));
  } catch (err) {
    console.error('[Annotation] Multi-frame TIF bake failed:', err);
    triggerDownload(URL.createObjectURL(file), file.name, 1000);
  }
}
