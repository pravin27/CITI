// Thumbnail rendering Web Worker
// Runs entirely off the main thread using pdfjs + OffscreenCanvas.
// Main thread sends: { type:'render', page, pdfData, thumbW, docKey }
// Worker replies:    { type:'done', page, bitmap } | { type:'error', page }

import * as pdfjsLib from 'pdfjs-dist';

// Disable pdfjs sub-worker inside this worker — we ARE the worker
(pdfjsLib.GlobalWorkerOptions as any).workerSrc = '';

let cachedDoc: any = null;
let cachedKey = '';
let loading: Promise<any> | null = null;

self.onmessage = async (e: MessageEvent) => {
  const { type, page, pdfData, thumbW, docKey } = e.data;

  if (type === 'clear') {
    try { cachedDoc?.destroy?.(); } catch (_) {}
    cachedDoc = null; cachedKey = ''; loading = null;
    return;
  }

  if (type !== 'render') return;

  try {
    // Load/reuse document
    if (docKey !== cachedKey || !cachedDoc) {
      if (loading) { await loading; }
      if (docKey !== cachedKey || !cachedDoc) {
        try { cachedDoc?.destroy?.(); } catch (_) {}
        cachedDoc = null; cachedKey = docKey;
        loading = pdfjsLib.getDocument({ data: pdfData }).promise;
        cachedDoc = await loading;
        loading = null;
      }
    }

    const pdfPage = await cachedDoc.getPage(page);
    const vp0 = pdfPage.getViewport({ scale: 1 });
    const scale = thumbW / vp0.width;
    const vp = pdfPage.getViewport({ scale });
    const w = Math.round(vp.width);
    const h = Math.round(vp.height);

    const canvas = new OffscreenCanvas(w, h);
    const ctx = canvas.getContext('2d') as OffscreenCanvasRenderingContext2D;
    await pdfPage.render({ canvasContext: ctx, viewport: vp, intent: 'display' }).promise;
    pdfPage.cleanup();

    const bitmap = canvas.transferToImageBitmap();
    (self as any).postMessage({ type: 'done', page, bitmap }, [bitmap]);

  } catch (err) {
    (self as any).postMessage({ type: 'error', page, error: String(err) });
  }
};
