import { Injectable, signal, computed } from '@angular/core';
import {
  InputField,
  WordCoordinate,
  HighlightRect,
} from '../models/pdf-capture.models';

@Injectable({ providedIn: 'root' })
export class PdfCaptureService {

  // ── Signals ────────────────────────────────────────────────────────────────
  readonly fields        = signal<InputField[]>([]);
  readonly activeFieldId = signal<string | null>(null);
  readonly externalCoords= signal<WordCoordinate[]>([]);
  readonly click2pickMode= signal<boolean>(false);

  /**
   * Pending capture — set when user clicks/double-clicks a word.
   * Holds the word payload BEFORE the user confirms it.
   * Cleared when confirmed (captureWordToActiveField) or when field loses focus.
   * Structure: { fieldId, payload } so we know which field it belongs to.
   */
  readonly pendingCapture = signal<{
    fieldId: string;
    payload: { text: string; page: number; x: number; y: number; width: number; height: number };
  } | null>(null);

  // ── Pre-indexed highlights: Map<pageNum, HighlightRect[]> ─────────────────
  // Rebuilt only when fields / externalCoords change — O(n) once, then O(1) per page.
  readonly highlightIndex = computed<Map<number, HighlightRect[]>>(() => {
    const index  = new Map<number, HighlightRect[]>();
    const fields = this.fields();
    const ext    = this.externalCoords();

    const add = (page: number, rect: HighlightRect) => {
      let arr = index.get(page);
      if (!arr) { arr = []; index.set(page, arr); }
      arr.push(rect);
    };

    // External coords
    for (const c of ext) {
      add(c.page, {
        page: c.page, x: c.x, y: c.y, width: c.width, height: c.height,
        type: 'external', label: c.text,
      });
    }

    // Field captures — only fields that have a captured word
    for (const f of fields) {
      if (!f.capturedWord) continue;
      const cw = f.capturedWord;
      add(cw.page, {
        page: cw.page, x: cw.x, y: cw.y, width: cw.width, height: cw.height,
        type: 'primary', fieldId: f.id, label: f.label,
      });
    }

    return index;
  });

  // ── Quick lookup: fieldId → captured word text (lower-case) ───────────────
  // Used by the viewer's draw loop to avoid O(n) field.find() per highlight.
  readonly fieldTextIndex = computed<Map<string, string>>(() => {
    const m = new Map<string, string>();
    for (const f of this.fields()) {
      if (f.capturedWord) m.set(f.id, f.capturedWord.text.toLowerCase());
    }
    return m;
  });

  // ── Active word text (derived, no extra subscription needed) ──────────────
  readonly activeWordText = computed<string | null>(() => {
    const id = this.activeFieldId();
    if (!id) return null;
    const f = this.fields().find(f => f.id === id);
    return f?.capturedWord?.text?.toLowerCase() ?? null;
  });

  // Legacy: allHighlights as flat array (kept for any external consumers)
  readonly allHighlights = computed<HighlightRect[]>(() => {
    const all: HighlightRect[] = [];
    this.highlightIndex().forEach((rects: HighlightRect[]) => all.push(...rects));
    return all;
  });

  // ── O(1) page lookup ──────────────────────────────────────────────────────
  getHighlightsForPage(page: number): HighlightRect[] {
    return this.highlightIndex().get(page) ?? [];
  }

  // ── Field Management ───────────────────────────────────────────────────────
  initFields(fields: InputField[]) {
    this.fields.set(fields);
  }

  /**
   * Load pre-captured fields from _captured_fields.json.
   * Each entry must have normalised (0-1) coords already.
   * Sets value + capturedWord so they render as grey highlights immediately.
   * Existing field definitions (label/id) are preserved; only matching ids get values.
   */
  loadCapturedFieldsFromJson(jsonFields: Array<{
    id: string; label: string; value: string;
    page: number; x: number; y: number; width: number; height: number;
    sourceFormat?: string;
  }>): void {
    const incoming = new Map(jsonFields.map(f => [f.id, f]));
    this.fields.update(fields =>
      fields.map(f => {
        const jf = incoming.get(f.id);
        if (!jf || !jf.value) return f;
        return {
          ...f,
          value:        jf.value,
          fromJson:     true,
          sourceFormat: jf.sourceFormat as any,
          capturedWord: {
            text:    jf.value,
            page:    jf.page,
            x:       jf.x,
            y:       jf.y,
            width:   jf.width,
            height:  jf.height,
            fieldId: f.id,
          },
        };
      })
    );
  }

  /**
   * Export all current field captures as a JSON array.
   * Includes both pre-loaded (fromJson) and newly captured fields.
   * Format: { id, label, value, page, x, y, width, height }
   */
  getCapturedFieldsJson(): Array<{
    id: string; label: string; value: string;
    page: number; x: number; y: number; width: number; height: number;
    fromJson: boolean; sourceFormat: string;
  }> {
    return this.fields()
      .filter(f => f.capturedWord && f.value)
      .map(f => ({
        id:           f.id,
        label:        f.label,
        value:        f.value,
        page:         f.capturedWord!.page,
        x:            f.capturedWord!.x,
        y:            f.capturedWord!.y,
        width:        f.capturedWord!.width,
        height:       f.capturedWord!.height,
        fromJson:     !!f.fromJson,
        sourceFormat: (f as any).sourceFormat || 'flat',
      }));
  }

  setActiveField(fieldId: string | null) {
    this.activeFieldId.set(fieldId);
  }

  getActiveField(): InputField | null {
    const id = this.activeFieldId();
    return this.fields().find((f: InputField) => f.id === id) ?? null;
  }

  /**
   * Stage a pending capture — sets value in the input immediately
   * so the user can see what will be captured, but does NOT update
   * capturedWord or the highlight. Requires confirmCapture() to persist.
   */
  setPendingCapture(word: {
    text: string; page: number;
    x: number; y: number; width: number; height: number;
  }): void {
    const id = this.activeFieldId();
    if (!id) return;
    // Stage: update value only (not capturedWord)
    this.fields.update(fields =>
      fields.map((f: InputField) => f.id !== id ? f : { ...f, value: word.text })
    );
    // Store pending payload linked to this field
    this.pendingCapture.set({ fieldId: id, payload: word });
  }

  /**
   * Confirm the pending capture for the active field.
   * This is what triggers the green highlight and updates the JSON.
   * Called when user clicks the "✓ Confirm" button on the field card.
   */
  confirmCapture(): void {
    const pending = this.pendingCapture();
    if (!pending) return;
    const { fieldId, payload } = pending;

    console.log('[CAPTURE CONFIRMED] fieldId:', fieldId, '| payload:', JSON.stringify(payload, null, 2));

    this.fields.update(fields =>
      fields.map((f: InputField) => f.id !== fieldId ? f : {
        ...f,
        value:        payload.text,
        fromJson:     false,
        capturedWord: { ...payload, fieldId },
      })
    );
    this.pendingCapture.set(null);
  }

  /**
   * Discard the pending capture — clears the staged value.
   * Called when field loses focus or user clicks elsewhere without confirming.
   */
  discardPendingCapture(): void {
    const pending = this.pendingCapture();
    if (!pending) return;
    // Restore previous value (from capturedWord if it existed, else empty)
    this.fields.update(fields =>
      fields.map((f: InputField) => f.id !== pending.fieldId ? f : {
        ...f,
        value: f.capturedWord?.text ?? '',
      })
    );
    this.pendingCapture.set(null);
  }

  captureWordToActiveField(word: {
    text: string; page: number;
    x: number; y: number; width: number; height: number;
  }) {
    const id = this.activeFieldId();
    if (!id) return;
    this.fields.update(fields =>
      fields.map((f: InputField) => f.id !== id ? f : {
        ...f, value: word.text,
        capturedWord: { ...word, fieldId: id },
      })
    );
  }

  clearField(fieldId: string) {
    this.fields.update(fields =>
      fields.map((f: InputField) => f.id !== fieldId ? f : { ...f, value: '', capturedWord: null })
    );
  }

  updateFieldValue(fieldId: string, value: string) {
    this.fields.update(fields =>
      fields.map((f: InputField) => f.id === fieldId ? { ...f, value } : f)
    );
  }

  // ── External Coordinates ──────────────────────────────────────────────────
  loadExternalCoordinates(coords: WordCoordinate[]) {
    this.externalCoords.set(coords);
  }

  // ── Click2Pick Mode ───────────────────────────────────────────────────────
  toggleClick2PickMode() { this.click2pickMode.update((v: boolean) => !v); }
  setClick2PickMode(on: boolean) { this.click2pickMode.set(on); }
}