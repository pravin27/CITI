import {
  Component,
  Input,
  Output,
  EventEmitter,
  ChangeDetectionStrategy,
  signal,
  computed,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { InputField } from '../../models/pdf-capture.models';
import { PdfCaptureService } from '../../services/pdf-capture.service';

@Component({
  selector: 'app-fields-panel',
  standalone: true,
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="fields-panel">
      <!-- Header -->
      <div class="panel-header">
        <div class="header-title">
          <span class="header-icon">⬡</span>
          <h2>Field Capture</h2>
        </div>
        <div class="header-actions">
          <button
            class="btn-pick"
            [class.active]="captureService.click2pickMode()"
            (click)="captureService.toggleClick2PickMode()"
            [title]="captureService.click2pickMode() ? 'Click2Pick ON' : 'Click2Pick OFF'"
          >
            <span class="pick-dot" [class.on]="captureService.click2pickMode()"></span>
            Click2Pick
          </button>
        </div>
      </div>

      <!-- Active field indicator -->
      <div class="active-indicator" *ngIf="captureService.activeFieldId()">
        <span class="ai-arrow">▶</span>
        Capturing into:
        <strong>{{ getActiveFieldLabel() }}</strong>
      </div>
      <div class="active-indicator idle" *ngIf="!captureService.activeFieldId()">
        <span class="ai-arrow">○</span>
        Focus a field, then click a word in the PDF
      </div>

      <!-- Fields List -->
      <div class="fields-scroll">
        <div
          class="field-card"
          *ngFor="let field of captureService.fields(); trackBy: trackById"
          [class.focused]="captureService.activeFieldId() === field.id"
          [class.captured]="!!field.capturedWord"
        >
          <div class="field-meta">
            <label [for]="field.id" class="field-label">{{ field.label }}</label>
            <div class="field-badges">
              <span
                class="badge badge-captured clickable"
                *ngIf="field.capturedWord"
                [title]="'Jump to page ' + field.capturedWord.page"
                (click)="onGoToWord(field)"
              >
                ⌖ pg {{ field.capturedWord.page }}
              </span>
              <button
                class="btn-clear"
                *ngIf="field.capturedWord"
                (click)="onClear(field.id)"
                title="Clear capture"
              >✕</button>
            </div>
          </div>

          <div class="input-row">
            <input
              [id]="field.id"
              type="text"
              class="field-input"
              [value]="field.value"
              [placeholder]="'Focus field → double-click or Click2Pick a word'"
              (focus)="onFocus(field.id)"
              (blur)="onBlur(field.id)"
              (input)="onInput(field.id, $event)"
              autocomplete="off"
              spellcheck="false"
            />
            <!-- Confirm button: appears when a word is staged (pending) for this field -->
            <button
              class="btn-confirm"
              *ngIf="isPending(field.id)"
              (click)="onConfirm()"
              title="Confirm capture — saves highlight and updates JSON"
            >✓</button>
            <button
              class="btn-goto"
              *ngIf="field.capturedWord && !isPending(field.id)"
              (click)="onGoToWord(field)"
              title="Navigate to captured word (Page {{ field.capturedWord.page }})"
            >⌖</button>
          </div>

          <!-- Coordinate info -->
          <div class="coord-info" *ngIf="field.capturedWord"
               [title]="'Page ' + field.capturedWord.page +
                        ' | x:' + (field.capturedWord.x | number:'1.4-4') +
                        ' y:'   + (field.capturedWord.y | number:'1.4-4') +
                        ' w:'   + (field.capturedWord.width  | number:'1.4-4') +
                        ' h:'   + (field.capturedWord.height | number:'1.4-4')">
            <span class="coord-chip">
              "{{ field.capturedWord.text }}"
            </span>
            <span class="coord-pos">
              pg:{{ field.capturedWord.page }}
              &nbsp;({{ (field.capturedWord.x * 100) | number:'1.0-0' }}%,{{ (field.capturedWord.y * 100) | number:'1.0-0' }}%)
            </span>
          </div>
        </div>
      </div>

      <!-- Legend -->
      <div class="legend">
        <div class="legend-title">Highlight Legend</div>
        <div class="legend-items">
          <div class="legend-item">
            <span class="swatch active"></span>
            <span>Active / Just Captured</span>
          </div>
          <div class="legend-item">
            <span class="swatch previous"></span>
            <span>Previously Captured</span>
          </div>
          <div class="legend-item">
            <span class="swatch duplicate"></span>
            <span>Duplicate Word</span>
          </div>
          <div class="legend-item">
            <span class="swatch external"></span>
            <span>External Coords</span>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: flex;
      flex-direction: column;
      height: 100%;
    }

    .fields-panel {
      display: flex;
      flex-direction: column;
      height: 100%;
      background: #0d1b2a;
      color: #e2e8f0;
      font-family: 'DM Sans', sans-serif;
      overflow: hidden;
    }

    /* ── Header ── */
    .panel-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 14px 18px;
      background: #111827;
      border-bottom: 1px solid rgba(255,255,255,0.07);
      flex-shrink: 0;
    }

    .header-title {
      display: flex;
      align-items: center;
      gap: 10px;

      .header-icon {
        font-size: 20px;
        color: #00d4aa;
        line-height: 1;
      }

      h2 {
        margin: 0;
        font-size: 16px;
        font-weight: 700;
        letter-spacing: -0.3px;
        color: #f1f5f9;
      }
    }

    .btn-pick {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 6px 14px;
      border: 1.5px solid #334155;
      border-radius: 20px;
      background: transparent;
      color: #94a3b8;
      font-family: inherit;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s;
      letter-spacing: 0.3px;

      &.active {
        border-color: #00d4aa;
        color: #00d4aa;
        background: rgba(0, 212, 170, 0.08);
        animation: glow-btn 2s ease-in-out infinite;
      }

      &:hover {
        border-color: #64748b;
        color: #e2e8f0;
      }
    }

    @keyframes glow-btn {
      0%, 100% { box-shadow: 0 0 0 0 rgba(0,212,170,0.2); }
      50% { box-shadow: 0 0 0 4px rgba(0,212,170,0.15); }
    }

    .pick-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: #334155;
      transition: background 0.2s;

      &.on {
        background: #00d4aa;
        box-shadow: 0 0 6px #00d4aa;
        animation: blink 1.4s ease-in-out infinite;
      }
    }

    @keyframes blink {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.4; }
    }

    /* ── Active Indicator ── */
    .active-indicator {
      padding: 10px 18px;
      font-size: 12px;
      color: #00d4aa;
      background: rgba(0, 212, 170, 0.06);
      border-bottom: 1px solid rgba(0, 212, 170, 0.15);
      display: flex;
      align-items: center;
      gap: 6px;
      flex-shrink: 0;

      &.idle {
        color: #64748b;
        background: rgba(255,255,255,0.02);
        border-bottom-color: rgba(255,255,255,0.05);
      }

      strong {
        color: #00d4aa;
        font-weight: 700;
      }

      .ai-arrow {
        font-size: 10px;
      }
    }

    /* ── Fields Scroll ── */
    .fields-scroll {
      flex: 1;
      overflow-y: auto;
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 10px;
      scrollbar-width: thin;
      scrollbar-color: #1e293b transparent;

      &::-webkit-scrollbar { width: 4px; }
      &::-webkit-scrollbar-thumb { background: #1e293b; border-radius: 2px; }
    }

    /* ── Field Card ── */
    .field-card {
      background: #111827;
      border: 1.5px solid #1e293b;
      border-radius: 10px;
      padding: 12px 14px;
      transition: border-color 0.2s, box-shadow 0.2s;

      &.focused {
        border-color: #00d4aa;
        box-shadow: 0 0 0 3px rgba(0, 212, 170, 0.12), 0 2px 12px rgba(0,0,0,0.3);
      }

      &.captured:not(.focused) {
        border-color: #3b82f6;
      }
    }

    .field-meta {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 8px;
    }

    .field-label {
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.8px;
      color: #64748b;
      cursor: pointer;
    }

    .field-card.focused .field-label {
      color: #00d4aa;
    }

    .field-badges {
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .badge {
      padding: 2px 8px;
      border-radius: 10px;
      font-size: 10px;
      font-weight: 700;
      letter-spacing: 0.5px;
    }

    .badge-captured {
      background: rgba(59, 130, 246, 0.15);
      color: #60a5fa;
      border: 1px solid rgba(59, 130, 246, 0.3);

      &.clickable {
        cursor: pointer;
        transition: background 0.15s, color 0.15s;
        &:hover {
          background: rgba(59,130,246,0.3);
          color: #93c5fd;
        }
      }
    }

    .btn-clear {
      width: 20px;
      height: 20px;
      border: none;
      background: rgba(239, 68, 68, 0.12);
      color: #f87171;
      border-radius: 50%;
      font-size: 10px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background 0.15s;

      &:hover { background: rgba(239, 68, 68, 0.25); }
    }

    .input-row {
      display: flex;
      gap: 6px;
      align-items: center;
    }

    .field-input {
      flex: 1;
      background: #0d1b2a;
      border: 1.5px solid #1e293b;
      border-radius: 6px;
      padding: 8px 12px;
      color: #f1f5f9;
      font-family: 'JetBrains Mono', monospace;
      font-size: 13px;
      outline: none;
      transition: border-color 0.2s;

      &::placeholder { color: #334155; }

      &:focus {
        border-color: #00d4aa;
      }
    }

    .btn-confirm {
      width: 32px;
      height: 32px;
      border: 2px solid rgba(0,200,100,0.6);
      background: rgba(0,200,100,0.12);
      color: #00c864;
      border-radius: 6px;
      font-size: 16px;
      font-weight: 700;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.15s;
      flex-shrink: 0;
      animation: confirm-pulse 1.2s ease-in-out infinite;

      &:hover {
        background: rgba(0,200,100,0.28);
        border-color: #00c864;
        box-shadow: 0 0 8px rgba(0,200,100,0.4);
        transform: scale(1.05);
      }
    }

    @keyframes confirm-pulse {
      0%,100% { box-shadow: 0 0 0 0 rgba(0,200,100,0.0); }
      50%      { box-shadow: 0 0 0 4px rgba(0,200,100,0.25); }
    }

    .btn-goto {
      width: 32px;
      height: 32px;
      border: 1.5px solid #334155;
      background: transparent;
      color: #64748b;
      border-radius: 6px;
      font-size: 16px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.15s;
      flex-shrink: 0;

      &:hover {
        border-color: #00d4aa;
        color: #00d4aa;
        background: rgba(0,212,170,0.08);
      }
    }

    .coord-info {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-top: 8px;
    }

    .coord-chip {
      font-family: 'JetBrains Mono', monospace;
      font-size: 11px;
      color: #00d4aa;
      background: rgba(0,212,170,0.08);
      padding: 2px 8px;
      border-radius: 4px;
      max-width: 140px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .coord-pos {
      font-family: 'JetBrains Mono', monospace;
      font-size: 10px;
      color: #475569;
    }

    /* ── Legend ── */
    .legend {
      padding: 12px 18px;
      border-top: 1px solid rgba(255,255,255,0.06);
      background: #080f1a;
      flex-shrink: 0;
    }

    .legend-title {
      font-size: 10px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 1px;
      color: #475569;
      margin-bottom: 8px;
    }

    .legend-items {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 6px;
    }

    .legend-item {
      display: flex;
      align-items: center;
      gap: 7px;
      font-size: 11px;
      color: #64748b;
    }

    .swatch {
      width: 14px;
      height: 14px;
      border-radius: 3px;
      flex-shrink: 0;

      &.active {
        background: rgba(0,200,100,0.25);
        border: 2px solid rgb(0,200,100);
      }
      &.previous {
        background: rgba(150,150,150,0.18);
        border: 2px solid rgba(120,120,120,0.7);
      }
      &.duplicate {
        background: rgba(250,204,21,0.30);
        border: 2px solid rgb(234,179,8);
      }
      &.external {
        background: rgba(139,92,246,0.25);
        border: 2px solid #8b5cf6;
      }
    }
  `],
})
export class FieldsPanelComponent {
  @Output() fieldFocused    = new EventEmitter<string>();
  @Output() goToWord        = new EventEmitter<InputField>();
  @Output() confirmCapture  = new EventEmitter<void>();

  constructor(public captureService: PdfCaptureService) {}

  trackById(_: number, f: InputField) {
    return f.id;
  }

  getActiveFieldLabel(): string {
    return this.captureService.getActiveField()?.label ?? '';
  }

  onFocus(fieldId: string) {
    this.captureService.setActiveField(fieldId);
    this.fieldFocused.emit(fieldId);
  }

  onBlur(_fieldId: string) {
    // Keep active for click2pick continuity — deactivate only on next focus elsewhere
  }

  onInput(fieldId: string, event: Event) {
    const val = (event.target as HTMLInputElement).value;
    this.captureService.updateFieldValue(fieldId, val);
  }

  onClear(fieldId: string) {
    this.captureService.clearField(fieldId);
  }

  onGoToWord(field: InputField) {
    this.goToWord.emit(field);
  }

  /** Returns true when this field has a pending (unconfirmed) capture staged. */
  isPending(fieldId: string): boolean {
    const p = this.captureService.pendingCapture();
    return p?.fieldId === fieldId;
  }

  /** Emit confirm event — app component calls captureService.confirmCapture(). */
  onConfirm() {
    this.confirmCapture.emit();
  }
}