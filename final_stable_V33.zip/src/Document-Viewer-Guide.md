# DocCapture Viewer — Integration Guide

## Table of Contents
1. [Setup](#setup)
2. [Events: Parent → Viewer](#parent-to-viewer)
3. [Events: Viewer → Parent](#viewer-to-parent)
4. [Coordinate Formats](#coordinate-formats)
5. [Complete Examples](#complete-examples)

---

## Setup

```html
<iframe
  id="doc-viewer"
  src="https://your-viewer-url"
  title="Document Viewer"
  style="width:100%; height:100%; border:none;"
/>
```

```ts
const iframe = document.getElementById('doc-viewer') as HTMLIFrameElement;

// Helper to send events to viewer
function send(data: object) {
  iframe.contentWindow!.postMessage(data, '*');
}

// Listen for events from viewer
window.addEventListener('message', (e) => {
  const { type, ...payload } = e.data;
  console.log('From viewer:', type, payload);
});
```

---

## Events: Parent → Viewer

---

### `LOAD_SINGLEDOC`
Load a single document into the viewer.

**Buffer sources — pick one:**

```ts
// ── From File input
const buffer = await file.arrayBuffer();

// ── From Uint8Array / Node Buffer
const buffer = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);

// ── From number[] array
const buffer = new Uint8Array(bytes).buffer;

// ── From base64 string
function base64ToBuffer(b64: string): ArrayBuffer {
  const bin = atob(b64);
  const u8  = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return u8.buffer;
}

// ── From URL (viewer fetches it)
// No buffer needed — pass url instead
```

**Full event shape:**

```ts
iframe.contentWindow.postMessage({
  // ── REQUIRED ────────────────────────────────────────────────────────────
  type:     'LOAD_SINGLEDOC',

  // ── FILE SOURCE (one required) ───────────────────────────────────────────
  buffer:   ArrayBuffer,     // raw file bytes
  url:      string,          // OR: blob: or https: URL (viewer fetches it)

  fileName: string,          // required — determines viewer type by extension
                             // .pdf, .xlsx, .xls, .csv, .docx, .txt,
                             // .jpg, .png, .tif, .tiff, .webp, .bmp

  // ── COORDINATE SPACE ─────────────────────────────────────────────────────
  coordinateSpace: 'norm' | 'px' | 'pt',
  // 'norm' — coords are 0–1 fractions of page (default)
  // 'px'   — coords are absolute pixels
  // 'pt'   — coords are points (PDF points)
  // Auto-detected from captures format when omitted.

  // ── PRE-CAPTURED FIELDS ──────────────────────────────────────────────────
  captures: [
    // Format A — normalised 0–1
    { id: 'f1', label: 'Invoice No', value: 'INV-001',
      page: 1, x: 0.12, y: 0.08, width: 0.30, height: 0.03,
      color: 'blue' },

    // Format B — pixel coords
    { id: 'f2', label: 'Date', value: '01/02/2024',
      page: 1, x: 98, y: 84, width: 245, height: 31 },

    // Format C — corner points (xmin/ymin/xmax/ymax)
    { id: 'f3', label: 'Name',
      page: 1, xmin: 0.10, ymin: 0.20, xmax: 0.40, ymax: 0.24 },

    // Format D — Gemini bbox [page, x, y, w, h] on 0–1000 grid
    { id: 'f4', label: 'Amount',
      bbox: [1, 183, 84, 300, 30] },
  ],

  // ── OCR / WORD INDEX ─────────────────────────────────────────────────────
  fullPageOCR: Record<number, WordEntry[]>, // enables Click2Pick text selection
  wordIndex:   Record<number, WordEntry[]>, // @deprecated — use fullPageOCR

  // ── PAGE CATEGORIES (thumbnail accordion) ───────────────────────────────
  categories: [
    { label: 'Invoice',   color: 'blue',   pages: [1, 2] },
    { label: 'Annexure',  color: 'teal',   pages: [3, 4, 5] },
    { label: 'Permit',    color: 'purple', pages: [6] },
  ],
  // Available colors: 'blue' | 'teal' | 'amber' | 'gray' |
  //                   'purple' | 'coral' | 'green' | 'red'

  // ── UI FLAGS ─────────────────────────────────────────────────────────────
  Click2Pick:        boolean, // enable box-capture mode immediately. Default: false
  debugArea:         boolean, // show right-side fields panel. Default: false
  showFieldsPanel:   boolean, // alias for debugArea
  showAnnotation:    boolean, // show annotation/draw button. Default: false
  showThumbnailView: boolean, // show thumbnail sidebar. Default: true
  showSplitMerge:    boolean, // show scissors icon for Split & Merge. Default: false
  isSplitScreen:     boolean, // viewer is in split-screen with SM. Default: false
  openThumbnail:     boolean, // auto-open sidebar on load. Default: false

  // ── ZOOM ─────────────────────────────────────────────────────────────────
  initialZoom: 'page-fit' | 'page-width' | 'actual' | number,
  // 'page-fit'   — fit full page (default)
  // 'page-width' — fit width, scroll vertically
  // 'actual'     — 100% zoom
  //  1.5         — explicit multiplier (1.0 = 100%)

  // ── HIGHLIGHT BEHAVIOUR ──────────────────────────────────────────────────
  persistHighlights: boolean,
  // false (default) — transient mode:
  //   HIGHLIGHT event shows yellow for active only, clears previous
  //   Click2Pick shows yellow for current capture only, no grey boxes
  //   Duplicate coords show as light pink
  // true — persist mode:
  //   Captures stay as grey boxes between HIGHLIGHT events
  //   Click2Pick adds permanent grey boxes
}, '*', [buffer]); // pass buffer in transfer array for zero-copy
```

---

### `LOAD_MANIFEST`
Load multiple documents (MultiDoc mode).

```ts
iframe.contentWindow.postMessage({
  // ── REQUIRED ────────────────────────────────────────────────────────────
  type: 'LOAD_MANIFEST',

  manifest: {
    // ── MODE ──────────────────────────────────────────────────────────────
    mode: 'MultiDoc:SinglePage' | 'MultiDoc:MultiPage' | 'SingleDoc',
    // 'MultiDoc:SinglePage' — each doc is one page, grouped by category
    // 'MultiDoc:MultiPage'  — one doc with pages split across categories
    // 'SingleDoc'           — single doc with category accordion (same as LOAD_SINGLEDOC)

    // ── CATEGORIES (optional — auto-derived when omitted) ──────────────────
    categories: [
      { id: 'invoice',  label: 'Invoice',   color: 'blue'   },
      { id: 'annexure', label: 'Annexure',  color: 'teal'   },
      { id: 'permit',   label: 'Permit',    color: 'purple' },
    ],

    // ── DOCUMENTS (MultiDoc:SinglePage) ───────────────────────────────────
    documents: [
      {
        id:       'doc-001',         // unique doc id
        name:     'invoice_001.pdf', // display name
        category: 'invoice',         // matches categories[].id

        // Data source — pick one, or omit to use DOC_REQUEST flow
        src:     'https://example.com/docs/invoice.pdf', // URL
        dataUrl: 'data:application/pdf;base64,...',      // data URL
        base64:  'JVBERi0xLjQ...',                       // raw base64
      },
      {
        id:       'doc-002',
        name:     'annexure_001.pdf',
        category: 'annexure',
        src:      '/docs/annexure.pdf',
      },
    ],

    // ── DOCUMENTS (MultiDoc:MultiPage — one doc, pages split by category) ──
    documents: [
      {
        id:   'main-doc',
        name: 'combined.pdf',
        pageCategories: [
          { category: 'invoice',  pages: [1, 2, 3] },
          { category: 'annexure', pages: [4, 5]    },
          { category: 'permit',   pages: [6]        },
        ],
      }
    ],

    // ── SingleDoc mode with category accordion ─────────────────────────────
    singleDocCategories: [
      { label: 'Invoice',  color: 'blue',  pages: [1, 2] },
      { label: 'Annexure', color: 'teal',  pages: [3, 4] },
    ],
  },

  // ── ACTIVE DOC (MultiDoc — which doc to open first) ───────────────────────
  activeDocId: 'doc-001',

  // ── BUFFER for active doc (if not using src/dataUrl/base64) ───────────────
  activeBuffer: ArrayBuffer,

  // ── ALL PROPS FROM LOAD_SINGLEDOC ALSO APPLY ─────────────────────────────
  coordinateSpace:   'norm' | 'px' | 'pt',
  captures:          CaptureItem[],
  fullPageOCR:       Record<number, WordEntry[]>,
  categories:        Category[],        // SingleDoc accordion categories
  Click2Pick:        boolean,
  debugArea:         boolean,
  showAnnotation:    boolean,
  showThumbnailView: boolean,
  showSplitMerge:    boolean,
  isSplitScreen:     boolean,
  openThumbnail:     boolean,
  initialZoom:       string | number,
  persistHighlights: boolean,

}, '*');
```

---

### `HIGHLIGHT`
Highlight a field in the viewer.

```ts
iframe.contentWindow.postMessage({
  type: 'HIGHLIGHT',
  payload: {
    id:     'field-001',  // required
    page:   1,            // required (not needed for FORMAT D)
    x:      0.12,         // } required — one coord format
    y:      0.08,         // }
    width:  0.30,         // }
    height: 0.03,         // }

    // OR corner points:
    xmin: 0.10, ymin: 0.08, xmax: 0.40, ymax: 0.11,

    // OR Gemini bbox (page embedded):
    bbox: [1, 183, 84, 300, 30],  // [page, x, y, w, h] on 0–1000 grid

    // Optional:
    label:  string,  // field label
    value:  string,  // field value
    color:  string,  // palette color
    docId:  string,  // MultiDoc — target doc id
  }
}, '*');
```

---

### `CAPTURE_ACK`
Respond to a `CAPTURE_PREVIEW` with the real field ID.

```ts
iframe.contentWindow.postMessage({
  type:   'CAPTURE_ACK',
  tempId: 'tmp-abc123',  // must match tempId from CAPTURE_PREVIEW
  id:     'real-field-1', // your permanent field ID (alias: realId)

  // Optional — override coords (viewer will update stored coords)
  x: 0.12, y: 0.08, width: 0.30, height: 0.03,

  // Optional — delete instead of confirm
  delete: true,          // discard this capture (no realId needed)
}, '*');
```

---

### `SET_CAPTURES`
Replace or append captures without reloading the document.

```ts
iframe.contentWindow.postMessage({
  type:     'SET_CAPTURES',
  mode:     'replace' | 'append',  // default: 'replace'
  captures: [ /* same format as LOAD_SINGLEDOC captures */ ],
  docId:    'doc-001',  // MultiDoc only
}, '*');
```

---

### `DELETE_CAPTURE`
Remove a specific capture.

```ts
iframe.contentWindow.postMessage({
  type: 'DELETE_CAPTURE',
  id:   'field-001',
}, '*');
```

---

### `RESET_VIEWER`
Reset viewer to initial load state (restores original categories).

```ts
iframe.contentWindow.postMessage({ type: 'RESET_VIEWER' }, '*');
```

---

### `EXPORT_CAPTURES`
Request all current captures to be sent back.

```ts
iframe.contentWindow.postMessage({ type: 'EXPORT_CAPTURES' }, '*');
// Viewer responds with CAPTURES_DATA event
```

---

### `DOC_RESPONSE`
Send a document buffer in response to a `DOC_REQUEST` (MultiDoc flow).

```ts
iframe.contentWindow.postMessage({
  type:   'DOC_RESPONSE',
  docId:  'doc-001',
  buffer: ArrayBuffer,
}, '*', [buffer]);
```

---

### `READY_CONFIG`
Send configuration in response to the viewer's `READY` event.

```ts
iframe.contentWindow.postMessage({
  type:      'READY_CONFIG',
  // same props as LOAD_SINGLEDOC — viewer applies them on mount
}, '*');
```

---

## Events: Viewer → Parent

---

### `READY`
Viewer mounted and listening for events.

```ts
{ type: 'READY' }
```

---

### `DOC_LOADED`
Document successfully loaded and rendered.

```ts
{
  type:       'DOC_LOADED',
  fileName:   'invoice.pdf',
  pageCount:  5,
  docId:      'doc-001' | null,  // MultiDoc only
}
```

---

### `DOC_LOAD_ERROR`
Document failed to load.

```ts
{
  type:     'DOC_LOAD_ERROR',
  code:     'INVALID_BUFFER' | 'CORRUPT_FILE' | 'UNSUPPORTED_FORMAT' |
            'DOC_REQUEST_TIMEOUT' | 'RENDER_FAILED' | 'UNKNOWN',
  reason:   string,   // human-readable error description
  fileName: string,
  docId:    string | null,
}
```

---

### `CAPTURE_PREVIEW`
User completed a Click2Pick / box capture. **Parent must respond with `CAPTURE_ACK` within 15 seconds.**

```ts
// When coordinateSpace: 'norm' or captures sent as x/y/w/h
{
  type:    'CAPTURE_PREVIEW',
  tempId:  'tmp-abc123',     // use this in CAPTURE_ACK
  text:    'INV-2024-001',   // captured text
  page:    1,
  x:       0.12,             // 0–1 fraction
  y:       0.08,
  width:   0.30,
  height:  0.03,
  docId:   'doc-001' | undefined,
}

// When captures were sent as Gemini bbox format
{
  type:    'CAPTURE_PREVIEW',
  tempId:  'tmp-abc123',
  text:    'INV-2024-001',
  page:    1,
  bbox:    [1, 183, 84, 300, 30],  // same format as sent in LOAD_SINGLEDOC
  docId:   'doc-001' | undefined,
}
```

---

### `DOC_REQUEST`
Viewer needs a document buffer (MultiDoc — when no src/dataUrl/base64 provided).

```ts
{
  type:  'DOC_REQUEST',
  docId: 'doc-001',
}
// Respond with DOC_RESPONSE
```

---

### `CAPTURES_DATA`
Response to `EXPORT_CAPTURES` — all current captures.

```ts
{
  type:     'CAPTURES_DATA',
  captures: CaptureItem[],
}
```

---

## Coordinate Formats

### Summary

| Format | Sent in LOAD_SINGLEDOC | CAPTURE_PREVIEW returned |
|---|---|---|
| Normalised `x,y,w,h` | `{ page, x, y, width, height }` 0–1 | `{ page, x, y, width, height }` 0–1 |
| Pixel `x,y,w,h` | `{ page, x, y, width, height }` pixels | `{ page, x, y, width, height }` pixels |
| Corner points | `{ page, xmin, ymin, xmax, ymax }` | `{ page, x, y, width, height }` |
| Gemini bbox | `{ bbox: [page,x,y,w,h] }` 0–1000 | `{ bbox: [page,x,y,w,h] }` 0–1000 |

### Setting return format explicitly

```ts
// Viewer always returns captures in the same format you sent them.
// For Click2Pick on a fresh doc with no captures, set coordinateSpace:
coordinateSpace: 'norm'   // → returns 0–1 fractions
coordinateSpace: 'px'     // → returns absolute pixels
```

---

## Complete Examples

### Example 1 — Load PDF, normalised coords, categories

```ts
const buffer = await file.arrayBuffer();

iframe.contentWindow.postMessage({
  type:            'LOAD_SINGLEDOC',
  buffer,
  fileName:        'invoice.pdf',
  coordinateSpace: 'norm',
  persistHighlights: false,
  initialZoom:     'page-width',
  showThumbnailView: true,
  Click2Pick:      true,

  categories: [
    { label: 'Invoice',  color: 'blue', pages: [1, 2] },
    { label: 'Annexure', color: 'teal', pages: [3] },
  ],

  captures: [
    { id: 'inv-no',   label: 'Invoice No',   value: 'INV-001',
      page: 1, x: 0.12, y: 0.08, width: 0.30, height: 0.03 },
    { id: 'inv-date', label: 'Invoice Date', value: '01/01/2024',
      page: 1, x: 0.60, y: 0.08, width: 0.20, height: 0.03 },
    { id: 'total',    label: 'Total',        value: '$1,250.00',
      page: 2, x: 0.70, y: 0.85, width: 0.20, height: 0.03 },
  ],
}, '*', [buffer]);
```

---

### Example 2 — Load PDF, Gemini bbox format

```ts
iframe.contentWindow.postMessage({
  type:     'LOAD_SINGLEDOC',
  buffer,
  fileName: 'invoice.pdf',
  // No coordinateSpace — auto-detected from bbox format

  captures: [
    { id: 'inv-no',   label: 'Invoice No',   value: 'INV-001',
      bbox: [1, 120, 80, 300, 30] },   // [page, x, y, w, h] on 0–1000 grid
    { id: 'inv-date', label: 'Invoice Date', value: '01/01/2024',
      bbox: [1, 600, 80, 200, 30] },
    { id: 'total',    label: 'Total',        value: '$1,250.00',
      bbox: [2, 700, 850, 200, 30] },
  ],
}, '*', [buffer]);
```

---

### Example 3 — MultiDoc:SinglePage with DOC_REQUEST flow

```ts
// Step 1: Load manifest (no buffers — viewer will request each doc)
iframe.contentWindow.postMessage({
  type: 'LOAD_MANIFEST',
  manifest: {
    mode: 'MultiDoc:SinglePage',
    categories: [
      { id: 'invoice',  label: 'Invoice',  color: 'blue' },
      { id: 'annexure', label: 'Annexure', color: 'teal' },
    ],
    documents: [
      { id: 'doc-001', name: 'invoice_001.pdf',  category: 'invoice'  },
      { id: 'doc-002', name: 'invoice_002.pdf',  category: 'invoice'  },
      { id: 'doc-003', name: 'annexure_001.pdf', category: 'annexure' },
    ],
  },
  activeDocId:      'doc-001',
  persistHighlights: false,
  showThumbnailView: true,
}, '*');

// Step 2: Respond to DOC_REQUEST events
window.addEventListener('message', async (e) => {
  if (e.data.type === 'DOC_REQUEST') {
    const { docId } = e.data;
    const buffer = await fetchDocumentBuffer(docId); // your API call
    iframe.contentWindow.postMessage({
      type: 'DOC_RESPONSE',
      docId,
      buffer,
    }, '*', [buffer]);
  }
});
```

---

### Example 4 — MultiDoc:MultiPage

```ts
iframe.contentWindow.postMessage({
  type: 'LOAD_MANIFEST',
  manifest: {
    mode: 'MultiDoc:MultiPage',
    categories: [
      { id: 'invoice',  label: 'Invoice',  color: 'blue'   },
      { id: 'annexure', label: 'Annexure', color: 'teal'   },
      { id: 'permit',   label: 'Permit',   color: 'purple' },
    ],
    documents: [
      {
        id:   'main',
        name: 'combined_document.pdf',
        pageCategories: [
          { category: 'invoice',  pages: [1, 2, 3] },
          { category: 'annexure', pages: [4, 5]    },
          { category: 'permit',   pages: [6]        },
        ],
      },
    ],
  },
  activeDocId:  'main',
  activeBuffer: buffer,    // pass buffer for the doc directly
  coordinateSpace: 'norm',
}, '*', [buffer]);
```

---

### Example 5 — Click2Pick with CAPTURE_PREVIEW / ACK

```ts
// Step 1: Load with Click2Pick enabled
iframe.contentWindow.postMessage({
  type:            'LOAD_SINGLEDOC',
  buffer,
  fileName:        'form.pdf',
  Click2Pick:      true,
  coordinateSpace: 'norm',     // viewer returns 0–1 normalised coords
  persistHighlights: false,    // transient — no grey boxes
}, '*', [buffer]);

// Step 2: Listen for CAPTURE_PREVIEW
window.addEventListener('message', (e) => {
  if (e.data.type === 'CAPTURE_PREVIEW') {
    const { tempId, text, page, x, y, width, height, bbox } = e.data;

    // Save to your system and get a real ID
    const realId = yourAPI.saveField({ text, page, x, y, width, height });

    // ACK back within 15 seconds
    iframe.contentWindow.postMessage({
      type:   'CAPTURE_ACK',
      tempId,           // must match exactly
      id:     realId,   // your real field ID
    }, '*');
  }

  if (e.data.type === 'DOC_LOADED') {
    console.log('Loaded:', e.data.fileName, e.data.pageCount, 'pages');
  }

  if (e.data.type === 'DOC_LOAD_ERROR') {
    console.error('Load failed:', e.data.code, e.data.reason);
  }
});
```

---

### Example 6 — Highlight a field after load

```ts
// Highlight with normalised coords
iframe.contentWindow.postMessage({
  type: 'HIGHLIGHT',
  payload: { id: 'inv-no', page: 1, x: 0.12, y: 0.08, width: 0.30, height: 0.03 }
}, '*');

// Highlight by id only (if already in captures)
iframe.contentWindow.postMessage({
  type: 'HIGHLIGHT',
  payload: { id: 'inv-no', page: 1, x: 0, y: 0, width: 0, height: 0 }
}, '*');

// Highlight with Gemini bbox
iframe.contentWindow.postMessage({
  type: 'HIGHLIGHT',
  payload: { id: 'inv-no', bbox: [1, 120, 80, 300, 30] }
}, '*');
```
