/**
 * types-palette.test.ts
 * Tests for PALETTE_MAP, PALETTE_COLORS, and categoryColor hash function.
 * categoryColor was added in session changes — tests validate the djb2 hash contract.
 */

import { describe, it, expect } from 'vitest';
import { PALETTE_COLORS, PALETTE_MAP } from '../../adapters/types';

// ── Inline the categoryColor implementation for isolated testing ──────────────
// This matches exactly what was added to types.ts in our sessions.
// If categoryColor is exported from types.ts in your build, replace this
// with: import { categoryColor } from '../../adapters/types';
function categoryColor(label: string): typeof PALETTE_COLORS[number] {
  let hash = 5381;
  for (let i = 0; i < label.length; i++) {
    hash = Math.imul(hash, 33) ^ label.charCodeAt(i);
  }
  return PALETTE_COLORS[Math.abs(hash) % PALETTE_COLORS.length];
}

// ─────────────────────────────────────────────────────────────────────────────
// PALETTE_COLORS
// ─────────────────────────────────────────────────────────────────────────────
describe('PALETTE_COLORS', () => {
  it('has exactly 8 colors', () => {
    expect(PALETTE_COLORS).toHaveLength(8);
  });

  it('contains expected color keys', () => {
    expect(PALETTE_COLORS).toContain('blue');
    expect(PALETTE_COLORS).toContain('teal');
    expect(PALETTE_COLORS).toContain('amber');
    expect(PALETTE_COLORS).toContain('gray');
    expect(PALETTE_COLORS).toContain('purple');
    expect(PALETTE_COLORS).toContain('coral');
    expect(PALETTE_COLORS).toContain('green');
    expect(PALETTE_COLORS).toContain('red');
  });

  it('has no duplicate entries', () => {
    const unique = new Set(PALETTE_COLORS);
    expect(unique.size).toBe(PALETTE_COLORS.length);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// PALETTE_MAP
// ─────────────────────────────────────────────────────────────────────────────
describe('PALETTE_MAP', () => {
  it('has an entry for every PALETTE_COLOR', () => {
    for (const color of PALETTE_COLORS) {
      expect(PALETTE_MAP[color]).toBeDefined();
    }
  });

  it('each entry has bg, text, divBg, divText fields', () => {
    for (const color of PALETTE_COLORS) {
      const entry = PALETTE_MAP[color];
      expect(entry.bg).toBeDefined();
      expect(entry.text).toBeDefined();
      expect(entry.divBg).toBeDefined();
      expect(entry.divText).toBeDefined();
    }
  });

  it('bg values are rgba strings', () => {
    for (const color of PALETTE_COLORS) {
      expect(PALETTE_MAP[color].bg).toMatch(/rgba?\(/);
    }
  });

  it('divText values are hex color strings', () => {
    for (const color of PALETTE_COLORS) {
      expect(PALETTE_MAP[color].divText).toMatch(/^#[0-9a-fA-F]{6}$/);
    }
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// categoryColor — djb2 hash determinism
// ─────────────────────────────────────────────────────────────────────────────
describe('categoryColor', () => {
  it('returns a valid PaletteColor', () => {
    const result = categoryColor('Invoice');
    expect(PALETTE_COLORS).toContain(result);
  });

  it('same label always returns same color (deterministic)', () => {
    const label = 'Invoice';
    expect(categoryColor(label)).toBe(categoryColor(label));
  });

  it('same label returns same color on repeated calls (no state)', () => {
    const label = 'Bill Of Lading';
    const colors = Array.from({ length: 10 }, () => categoryColor(label));
    expect(new Set(colors).size).toBe(1);
  });

  it('two different labels can return different colors', () => {
    // Not guaranteed by hash, but very likely for unrelated labels
    const allSame = ['Invoice', 'Annexure', 'Bill Of Lading', 'Draft', 'Supporting Documents']
      .map(categoryColor)
      .every((c, _, arr) => c === arr[0]);
    // At least one should differ (otherwise hash is broken)
    expect(allSame).toBe(false);
  });

  it('returns valid color for empty string', () => {
    const result = categoryColor('');
    expect(PALETTE_COLORS).toContain(result);
  });

  it('returns valid color for very long label', () => {
    const result = categoryColor('A'.repeat(1000));
    expect(PALETTE_COLORS).toContain(result);
  });

  it('returns valid color for unicode label', () => {
    const result = categoryColor('请求 Fatura 請求書');
    expect(PALETTE_COLORS).toContain(result);
  });

  it('returns valid color for single character', () => {
    expect(PALETTE_COLORS).toContain(categoryColor('A'));
    expect(PALETTE_COLORS).toContain(categoryColor('z'));
  });

  it('category with same label in any doc always maps to same color', () => {
    // Critical regression test — the fix for sequential-index bug
    const color1 = categoryColor('Invoice');
    const color2 = categoryColor('Invoice');
    expect(color1).toBe(color2);

    // Simulate different positions in array (old bug: [i % 8] changed color)
    // Now label → color is position-independent
    expect(categoryColor('Bill Of Lading')).toBe(categoryColor('Bill Of Lading'));
  });
});
