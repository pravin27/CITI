/**
 * appStore.test.ts
 * Unit tests for Zustand appStore actions.
 * Tests capture CRUD, highlight index, navigateAndHighlight, persistHighlights.
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';
import { useAppStore } from '../../store/appStore';
import type { CaptureItem } from '../../adapters/types';

// ── Helper — reset store to clean state before each test ─────────────────────
beforeEach(() => {
  useAppStore.setState({
    captures:       [],
    activeFieldId:  null,
    previewRect:    null,
    highlightIndex: new Map(),
    categories:     [],
    originalCategories: null,
    originalDocuments:  null,
    hasReclassification: false,
    persistHighlights: false,
    isSplitScreen: false,
    adapter: null,
  });
});

// ── Helper — build a test CaptureItem ────────────────────────────────────────
const makeCapture = (overrides: Partial<CaptureItem> = {}): CaptureItem => ({
  id:     'cap-1',
  label:  'Invoice No',
  value:  'INV-001',
  page:   1,
  x:      0.10,
  y:      0.20,
  width:  0.30,
  height: 0.05,
  sourceFormat: 'flat',
  ...overrides,
});

// ─────────────────────────────────────────────────────────────────────────────
// addCaptureWithId
// ─────────────────────────────────────────────────────────────────────────────
describe('addCaptureWithId', () => {
  it('adds a new capture to the store', () => {
    const cap = makeCapture();
    useAppStore.getState().addCaptureWithId(cap);
    expect(useAppStore.getState().captures).toHaveLength(1);
    expect(useAppStore.getState().captures[0].id).toBe('cap-1');
  });

  it('sets activeFieldId to the new capture id', () => {
    useAppStore.getState().addCaptureWithId(makeCapture());
    expect(useAppStore.getState().activeFieldId).toBe('cap-1');
  });

  it('sets previewRect matching capture coords', () => {
    const cap = makeCapture({ x: 0.1, y: 0.2, width: 0.3, height: 0.05, page: 1 });
    useAppStore.getState().addCaptureWithId(cap);
    const pr = useAppStore.getState().previewRect;
    expect(pr).not.toBeNull();
    expect(pr!.page).toBe(1);
    expect(pr!.x).toBeCloseTo(0.1);
  });

  it('upserts existing capture by id (no duplicate)', () => {
    const cap = makeCapture({ value: 'OLD' });
    useAppStore.getState().addCaptureWithId(cap);
    useAppStore.getState().addCaptureWithId({ ...cap, value: 'NEW' });
    const { captures } = useAppStore.getState();
    expect(captures).toHaveLength(1);
    expect(captures[0].value).toBe('NEW');
  });

  it('accumulates multiple different captures', () => {
    useAppStore.getState().addCaptureWithId(makeCapture({ id: 'cap-1' }));
    useAppStore.getState().addCaptureWithId(makeCapture({ id: 'cap-2' }));
    useAppStore.getState().addCaptureWithId(makeCapture({ id: 'cap-3' }));
    expect(useAppStore.getState().captures).toHaveLength(3);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// _rebuildHighlightIndex
// ─────────────────────────────────────────────────────────────────────────────
describe('_rebuildHighlightIndex', () => {
  it('builds index with one page entry', () => {
    useAppStore.setState({ captures: [makeCapture({ page: 1 })] });
    useAppStore.getState()._rebuildHighlightIndex();
    const index = useAppStore.getState().highlightIndex;
    expect(index.has(1)).toBe(true);
    expect(index.get(1)).toHaveLength(1);
  });

  it('groups multiple captures on same page', () => {
    useAppStore.setState({
      captures: [
        makeCapture({ id: 'a', page: 1 }),
        makeCapture({ id: 'b', page: 1 }),
        makeCapture({ id: 'c', page: 1 }),
      ],
    });
    useAppStore.getState()._rebuildHighlightIndex();
    expect(useAppStore.getState().highlightIndex.get(1)).toHaveLength(3);
  });

  it('creates separate entries for different pages', () => {
    useAppStore.setState({
      captures: [
        makeCapture({ id: 'a', page: 1 }),
        makeCapture({ id: 'b', page: 2 }),
        makeCapture({ id: 'c', page: 3 }),
      ],
    });
    useAppStore.getState()._rebuildHighlightIndex();
    const index = useAppStore.getState().highlightIndex;
    expect(index.has(1)).toBe(true);
    expect(index.has(2)).toBe(true);
    expect(index.has(3)).toBe(true);
    expect(index.size).toBe(3);
  });

  it('produces empty Map for empty captures', () => {
    useAppStore.setState({ captures: [] });
    useAppStore.getState()._rebuildHighlightIndex();
    expect(useAppStore.getState().highlightIndex.size).toBe(0);
  });

  it('stores correct x/y/width/height in index entries', () => {
    const cap = makeCapture({ x: 0.1, y: 0.2, width: 0.3, height: 0.05, page: 1 });
    useAppStore.setState({ captures: [cap] });
    useAppStore.getState()._rebuildHighlightIndex();
    const rect = useAppStore.getState().highlightIndex.get(1)![0];
    expect(rect.x).toBeCloseTo(0.1);
    expect(rect.y).toBeCloseTo(0.2);
    expect(rect.width).toBeCloseTo(0.3);
    expect(rect.height).toBeCloseTo(0.05);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// navigateAndHighlight
// ─────────────────────────────────────────────────────────────────────────────
describe('navigateAndHighlight', () => {
  it('returns false when id not found in captures', () => {
    const result = useAppStore.getState().navigateAndHighlight('nonexistent');
    expect(result).toBe(false);
  });

  it('returns true when id found', () => {
    useAppStore.setState({ captures: [makeCapture({ id: 'cap-1' })] });
    const result = useAppStore.getState().navigateAndHighlight('cap-1');
    expect(result).toBe(true);
  });

  it('sets activeFieldId when found', () => {
    useAppStore.setState({ captures: [makeCapture({ id: 'cap-1' })] });
    useAppStore.getState().navigateAndHighlight('cap-1');
    expect(useAppStore.getState().activeFieldId).toBe('cap-1');
  });

  it('sets previewRect when found', () => {
    const cap = makeCapture({ id: 'cap-1', page: 2, x: 0.5, y: 0.6 });
    useAppStore.setState({ captures: [cap] });
    useAppStore.getState().navigateAndHighlight('cap-1');
    const pr = useAppStore.getState().previewRect;
    expect(pr).not.toBeNull();
    expect(pr!.page).toBe(2);
    expect(pr!.x).toBeCloseTo(0.5);
  });

  it('does not change state when id not found', () => {
    useAppStore.setState({ activeFieldId: 'existing', captures: [] });
    useAppStore.getState().navigateAndHighlight('nonexistent');
    // activeFieldId unchanged
    expect(useAppStore.getState().activeFieldId).toBe('existing');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// setActiveField
// ─────────────────────────────────────────────────────────────────────────────
describe('setActiveField', () => {
  it('sets activeFieldId to provided id', () => {
    useAppStore.getState().setActiveField('cap-5');
    expect(useAppStore.getState().activeFieldId).toBe('cap-5');
  });

  it('sets activeFieldId to null', () => {
    useAppStore.setState({ activeFieldId: 'cap-5' });
    useAppStore.getState().setActiveField(null);
    expect(useAppStore.getState().activeFieldId).toBeNull();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// setPreviewRect
// ─────────────────────────────────────────────────────────────────────────────
describe('setPreviewRect', () => {
  it('sets previewRect', () => {
    const rect = { page: 1, x: 0.1, y: 0.2, width: 0.3, height: 0.05 };
    useAppStore.getState().setPreviewRect(rect);
    expect(useAppStore.getState().previewRect).toEqual(rect);
  });

  it('clears previewRect with null', () => {
    useAppStore.setState({ previewRect: { page: 1, x: 0, y: 0, width: 0.1, height: 0.1 } });
    useAppStore.getState().setPreviewRect(null);
    expect(useAppStore.getState().previewRect).toBeNull();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// persistHighlights
// ─────────────────────────────────────────────────────────────────────────────
describe('persistHighlights', () => {
  it('defaults to false', () => {
    expect(useAppStore.getState().persistHighlights).toBe(false);
  });

  it('setPersistHighlights(true) updates state', () => {
    useAppStore.getState().setPersistHighlights(true);
    expect(useAppStore.getState().persistHighlights).toBe(true);
  });

  it('setPersistHighlights(false) updates state', () => {
    useAppStore.getState().setPersistHighlights(true);
    useAppStore.getState().setPersistHighlights(false);
    expect(useAppStore.getState().persistHighlights).toBe(false);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// categories and originalCategories
// ─────────────────────────────────────────────────────────────────────────────
describe('categories and snapshots', () => {
  const cats = [
    { id: 'invoice', label: 'Invoice', color: 'blue', pages: [1, 2] },
    { id: 'annexure', label: 'Annexure', color: 'teal', pages: [3] },
  ];

  it('setCategories updates categories', () => {
    useAppStore.getState().setCategories(cats as any);
    expect(useAppStore.getState().categories).toHaveLength(2);
  });

  it('setOriginalCategories saves snapshot', () => {
    useAppStore.getState().setOriginalCategories(cats as any);
    expect(useAppStore.getState().originalCategories).toHaveLength(2);
  });

  it('setCategories does NOT overwrite originalCategories', () => {
    useAppStore.getState().setOriginalCategories(cats as any);
    const modified = [{ ...cats[0], label: 'Changed' }];
    useAppStore.getState().setCategories(modified as any);
    // snapshot should be untouched
    expect(useAppStore.getState().originalCategories![0].label).toBe('Invoice');
  });

  it('resetting via setState restores originalCategories', () => {
    useAppStore.getState().setOriginalCategories(cats as any);
    useAppStore.getState().setCategories([{ id: 'other', label: 'Other', pages: [] }] as any);
    // Simulate reset
    const orig = useAppStore.getState().originalCategories;
    useAppStore.setState({ categories: orig as any });
    expect(useAppStore.getState().categories[0].label).toBe('Invoice');
  });

  it('setOriginalCategories(null) clears snapshot', () => {
    useAppStore.getState().setOriginalCategories(cats as any);
    useAppStore.getState().setOriginalCategories(null);
    expect(useAppStore.getState().originalCategories).toBeNull();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// hasReclassification + isSplitScreen
// ─────────────────────────────────────────────────────────────────────────────
describe('hasReclassification and isSplitScreen', () => {
  it('hasReclassification defaults to false', () => {
    expect(useAppStore.getState().hasReclassification).toBe(false);
  });

  it('setHasReclassification(true) updates state', () => {
    useAppStore.getState().setHasReclassification(true);
    expect(useAppStore.getState().hasReclassification).toBe(true);
  });

  it('isSplitScreen defaults to false', () => {
    expect(useAppStore.getState().isSplitScreen).toBe(false);
  });

  it('setIsSplitScreen(true) updates state', () => {
    useAppStore.getState().setIsSplitScreen(true);
    expect(useAppStore.getState().isSplitScreen).toBe(true);
  });

  it('setIsSplitScreen(false) after true resets correctly', () => {
    useAppStore.getState().setIsSplitScreen(true);
    useAppStore.getState().setIsSplitScreen(false);
    expect(useAppStore.getState().isSplitScreen).toBe(false);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// addCaptureWithId + _rebuildHighlightIndex integration
// ─────────────────────────────────────────────────────────────────────────────
describe('addCaptureWithId + highlightIndex integration', () => {
  it('highlightIndex updated after addCaptureWithId', () => {
    useAppStore.getState().addCaptureWithId(makeCapture({ id: 'a', page: 1 }));
    expect(useAppStore.getState().highlightIndex.has(1)).toBe(true);
  });

  it('highlightIndex has correct id in rect', () => {
    useAppStore.getState().addCaptureWithId(makeCapture({ id: 'myfield', page: 2 }));
    const rects = useAppStore.getState().highlightIndex.get(2);
    expect(rects?.some(r => r.id === 'myfield')).toBe(true);
  });

  it('highlightIndex updated after upsert', () => {
    useAppStore.getState().addCaptureWithId(makeCapture({ id: 'a', page: 1, x: 0.1 }));
    useAppStore.getState().addCaptureWithId(makeCapture({ id: 'a', page: 1, x: 0.5 }));
    const rects = useAppStore.getState().highlightIndex.get(1);
    expect(rects).toHaveLength(1);
    expect(rects![0].x).toBeCloseTo(0.5);
  });
});
