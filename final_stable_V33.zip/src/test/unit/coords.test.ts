/**
 * coords.test.ts
 * Unit tests for extractRawCoords, normaliseBatch, normaliseCoords
 * These had real production bugs — high coverage is critical.
 */

import { describe, it, expect, beforeEach } from 'vitest';
import {
  extractRawCoords,
  normaliseBatch,
  normaliseCoords,
  getExtractedPage,
} from '../../utils/coords';

// ── Helper to create a fresh item (avoids mutation between tests) ─────────────
const item = (fields: Record<string, unknown>) => ({ ...fields });

// ─────────────────────────────────────────────────────────────────────────────
// extractRawCoords
// ─────────────────────────────────────────────────────────────────────────────
describe('extractRawCoords', () => {

  // FORMAT 1 — flat { x, y, width, height }
  describe('FORMAT 1 — { x, y, width, height }', () => {
    it('returns [x, y, width, height] when all present', () => {
      const result = extractRawCoords(item({ x: 0.1, y: 0.2, width: 0.3, height: 0.05 }));
      expect(result).toEqual([0.1, 0.2, 0.3, 0.05]);
    });

    it('accepts w/h aliases for width/height', () => {
      const result = extractRawCoords(item({ x: 0.1, y: 0.2, w: 0.3, h: 0.05 }));
      expect(result).toEqual([0.1, 0.2, 0.3, 0.05]);
    });

    it('works with pixel values', () => {
      const result = extractRawCoords(item({ x: 100, y: 200, width: 150, height: 30 }));
      expect(result).toEqual([100, 200, 150, 30]);
    });

    it('returns null when x is missing', () => {
      expect(extractRawCoords(item({ y: 0.2, width: 0.3, height: 0.05 }))).toBeNull();
    });

    it('returns null when width is missing', () => {
      expect(extractRawCoords(item({ x: 0.1, y: 0.2, height: 0.05 }))).toBeNull();
    });
  });

  // FORMAT 6 — { xmin, ymin, xmax, ymax }
  describe('FORMAT 6 — { xmin, ymin, xmax, ymax }', () => {
    it('converts to [x, y, w, h]', () => {
      const result = extractRawCoords(item({ xmin: 0.1, ymin: 0.2, xmax: 0.4, ymax: 0.25 }));
      expect(result).toEqual([0.1, 0.2, 0.3, 0.05]);
    });

    it('works with pixel corner coords', () => {
      const result = extractRawCoords(item({ xmin: 100, ymin: 200, xmax: 300, ymax: 250 }));
      expect(result).toEqual([100, 200, 200, 50]);
    });
  });

  // FORMAT 10 — { bbox: [page, x, y, w, h] }
  describe('FORMAT 10 — { bbox: [page, x, y, w, h] }', () => {
    it('returns [x, y, w, h] for normal values', () => {
      const i = item({ bbox: [1, 183, 240, 90, 15] });
      const result = extractRawCoords(i);
      expect(result).toEqual([183, 240, 90, 15]);
    });

    it('sets __extractedPage on the item', () => {
      const i = item({ bbox: [1, 183, 240, 90, 15] });
      extractRawCoords(i);
      expect((i as any).__extractedPage).toBe(1);
    });

    it('sets __extractedPage = 3 for page 3', () => {
      const i = item({ bbox: [3, 50, 100, 200, 20] });
      extractRawCoords(i);
      expect((i as any).__extractedPage).toBe(3);
    });

    it('works with already-normalised 0-1 values', () => {
      const i = item({ bbox: [1, 0.183, 0.240, 0.090, 0.015] });
      const result = extractRawCoords(i);
      expect(result).toEqual([0.183, 0.240, 0.090, 0.015]);
    });

    it('returns null when bbox[0] is 0 (invalid page)', () => {
      const result = extractRawCoords(item({ bbox: [0, 183, 240, 90, 15] }));
      expect(result).toBeNull();
    });

    it('returns null when bbox[0] is not an integer', () => {
      const result = extractRawCoords(item({ bbox: [1.5, 183, 240, 90, 15] }));
      expect(result).toBeNull();
    });

    it('returns null when bbox has length != 5', () => {
      expect(extractRawCoords(item({ bbox: [1, 183, 240, 90] }))).toBeNull();
      expect(extractRawCoords(item({ bbox: [183, 240, 90, 15] }))).toBeNull();
    });

    it('falls through to FORMAT 2 when heuristic fails', () => {
      // bbox length 5 but page heuristic fails → tries FORMAT 2 interpretation
      // [1, 1, 1, 1, 1] — pg=1 but all coords equal 1 (could be either)
      // The main point: doesn't crash
      const result = extractRawCoords(item({ bbox: [1, 0.1, 0.1, 0.1, 0.1] }));
      // Either interpreted as FORMAT 10 or null — just shouldn't throw
      expect(() => extractRawCoords(item({ bbox: [1, 0.1, 0.1, 0.1, 0.1] }))).not.toThrow();
    });
  });

  // FORMAT 2 — bbox: [x, y, w, h]
  describe('FORMAT 2 — bbox: [x, y, w, h]', () => {
    it('extracts 4-element bbox', () => {
      const result = extractRawCoords(item({ bbox: [0.1, 0.2, 0.3, 0.05] }));
      expect(result).toEqual([0.1, 0.2, 0.3, 0.05]);
    });
  });

  // FORMAT 3 — bbox_relative
  describe('FORMAT 3 — bbox_relative: [x,y,w,h]', () => {
    it('extracts bbox_relative', () => {
      const result = extractRawCoords(item({ bbox_relative: [0.1, 0.2, 0.3, 0.05] }));
      expect(result).toEqual([0.1, 0.2, 0.3, 0.05]);
    });
  });

  // Unknown format
  describe('unknown format', () => {
    it('returns null for empty object', () => {
      expect(extractRawCoords({})).toBeNull();
    });

    it('returns null for unrecognised keys', () => {
      expect(extractRawCoords(item({ foo: 1, bar: 2 }))).toBeNull();
    });

    it('returns null for string values', () => {
      expect(extractRawCoords(item({ x: '0.1', y: '0.2', width: '0.3', height: '0.05' }))).toBeNull();
    });
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// getExtractedPage
// ─────────────────────────────────────────────────────────────────────────────
describe('getExtractedPage', () => {
  it('returns __extractedPage when set', () => {
    const i = { __extractedPage: 3 };
    expect(getExtractedPage(i, 1)).toBe(3);
  });

  it('returns fallback when __extractedPage not set', () => {
    expect(getExtractedPage({}, 1)).toBe(1);
    expect(getExtractedPage({}, 5)).toBe(5);
  });

  it('returns fallback when __extractedPage is 0', () => {
    expect(getExtractedPage({ __extractedPage: 0 }, 1)).toBe(1);
  });

  it('returns fallback when __extractedPage is negative', () => {
    expect(getExtractedPage({ __extractedPage: -1 }, 1)).toBe(1);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// normaliseBatch
// ─────────────────────────────────────────────────────────────────────────────
describe('normaliseBatch', () => {
  const mockAdapter = {
    getPageDimensions: (page: number) => ({ width: 816, height: 1056 }),
    pageCount: 5,
  };

  it('returns empty array for empty input', () => {
    const result = normaliseBatch([], () => 1);
    expect(result).toEqual([]);
  });

  it('passes through already-normalised 0-1 coords', () => {
    const items = [item({ x: 0.1, y: 0.2, width: 0.3, height: 0.05, page: 1 })];
    const result = normaliseBatch(items, (i) => (i.page as number) ?? 1);
    expect(result[0].coords).toEqual([0.1, 0.2, 0.3, 0.05]);
  });

  it('returns null coords for items with no coords', () => {
    const items = [item({ label: 'no coords', page: 1 })];
    const result = normaliseBatch(items, () => 1);
    expect(result[0].coords).toBeNull();
  });

  it('normalises pixel coords using adapter page dims', () => {
    const items = [item({ x: 81.6, y: 105.6, width: 163.2, height: 21.12, page: 1 })];
    const result = normaliseBatch(items, () => 1, mockAdapter as any);
    // 81.6/816 = 0.1, 105.6/1056 = 0.1
    expect(result[0].coords![0]).toBeCloseTo(0.1, 5);
    expect(result[0].coords![1]).toBeCloseTo(0.1, 5);
  });

  it('handles FORMAT 10 items — reads page from __extractedPage', () => {
    const i = item({ bbox: [2, 183, 240, 90, 15] });
    // normaliseBatch calls extractRawCoords which sets __extractedPage
    const getPage = (it: Record<string, unknown>) => {
      const ep = (it as any).__extractedPage;
      return typeof ep === 'number' ? ep : ((it.page as number) ?? 1);
    };
    normaliseBatch([i], getPage, mockAdapter as any);
    expect((i as any).__extractedPage).toBe(2);
  });

  it('preserves raw item reference in result', () => {
    const i = item({ x: 0.1, y: 0.2, width: 0.3, height: 0.05, page: 1 });
    const result = normaliseBatch([i], () => 1);
    expect(result[0].raw).toBe(i);
  });

  it('handles multiple items on different pages', () => {
    const items = [
      item({ x: 0.1, y: 0.2, width: 0.1, height: 0.05, page: 1 }),
      item({ x: 0.5, y: 0.6, width: 0.1, height: 0.05, page: 2 }),
    ];
    const result = normaliseBatch(items, (i) => (i.page as number) ?? 1);
    expect(result).toHaveLength(2);
    expect(result[0].coords).not.toBeNull();
    expect(result[1].coords).not.toBeNull();
  });

  it('works without adapter (no pixel normalisation)', () => {
    // Without adapter, pixel coords can't be normalised — returns them as-is or null
    const items = [item({ x: 0.1, y: 0.2, width: 0.3, height: 0.05, page: 1 })];
    const result = normaliseBatch(items, () => 1, null);
    expect(result[0].coords).toBeDefined();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// normaliseCoords
// ─────────────────────────────────────────────────────────────────────────────
describe('normaliseCoords', () => {
  const adapter = {
    getPageDimensions: () => ({ width: 816, height: 1056 }),
    pageCount: 1,
  };

  it('returns 0-1 coords unchanged when already fractional', () => {
    const raw: [number, number, number, number] = [0.1, 0.2, 0.3, 0.05];
    const result = normaliseCoords(raw, {}, 1, adapter as any, null);
    expect(result).toEqual([0.1, 0.2, 0.3, 0.05]);
  });

  it('normalises pixel coords to 0-1 using page dims', () => {
    const raw: [number, number, number, number] = [81.6, 105.6, 163.2, 52.8];
    const result = normaliseCoords(raw, {}, 1, adapter as any, null);
    expect(result[0]).toBeCloseTo(0.1, 5); // 81.6/816
    expect(result[1]).toBeCloseTo(0.1, 5); // 105.6/1056
    expect(result[2]).toBeCloseTo(0.2, 5); // 163.2/816
    expect(result[3]).toBeCloseTo(0.05, 5); // 52.8/1056
  });

  it('clamps result to [0, 1]', () => {
    const raw: [number, number, number, number] = [0.0, 0.0, 1.5, 1.5];
    const result = normaliseCoords(raw, {}, 1, adapter as any, null);
    expect(result[0]).toBeGreaterThanOrEqual(0);
    expect(result[2]).toBeLessThanOrEqual(1);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// FORMAT 10 — double-division prevention (__geminiNormalised cache)
// ─────────────────────────────────────────────────────────────────────────────
describe('FORMAT 10 double-division prevention', () => {
  it('does not double-divide when extractRawCoords called twice', () => {
    const i = item({ id: '1', value: 'test', bbox: [1, 200, 300, 150, 20] });

    const first  = extractRawCoords(i);
    const second = extractRawCoords(i); // simulates normaliseBatch Pass 2

    // Both calls must return same result
    expect(first).toEqual(second);
    // Values must be raw (not divided) — FORMAT 10 is raw Gemini grid (0-1000)
    // so result should be [200, 300, 150, 20] — division is done at batch level
    expect(first).toEqual([200, 300, 150, 20]);
  });

  it('sets __extractedPage correctly on repeated calls', () => {
    const i = item({ bbox: [3, 100, 200, 50, 10] });
    extractRawCoords(i); // first
    extractRawCoords(i); // second
    expect((i as any).__extractedPage).toBe(3);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Edge cases — robustness
// ─────────────────────────────────────────────────────────────────────────────
describe('edge cases', () => {
  it('extractRawCoords handles null gracefully', () => {
    expect(() => extractRawCoords({})).not.toThrow();
  });

  it('extractRawCoords handles undefined values gracefully', () => {
    expect(() => extractRawCoords({ x: undefined, y: undefined })).not.toThrow();
  });

  it('normaliseBatch handles items where extractRawCoords returns null', () => {
    const items = [item({ garbage: 'data' }), item({ x: 0.1, y: 0.2, width: 0.3, height: 0.05, page: 1 })];
    const result = normaliseBatch(items, () => 1);
    expect(result[0].coords).toBeNull();
    expect(result[1].coords).not.toBeNull();
  });

  it('FORMAT 10 page 9999 is valid upper bound', () => {
    const i = item({ bbox: [9999, 100, 200, 50, 10] });
    const result = extractRawCoords(i);
    expect(result).not.toBeNull();
    expect((i as any).__extractedPage).toBe(9999);
  });

  it('FORMAT 10 page 10000 is out of range — falls through', () => {
    const result = extractRawCoords(item({ bbox: [10000, 100, 200, 50, 10] }));
    // Falls through to FORMAT 2 interpretation or null
    expect(() => extractRawCoords(item({ bbox: [10000, 100, 200, 50, 10] }))).not.toThrow();
  });
});
