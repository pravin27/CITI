import '@testing-library/jest-dom';
import { vi, beforeEach, afterEach } from 'vitest';

// ── Canvas mock ───────────────────────────────────────────────────────────────
const mockCtx = {
  clearRect:    vi.fn(),
  fillRect:     vi.fn(),
  strokeRect:   vi.fn(),
  fillText:     vi.fn(),
  strokeText:   vi.fn(),
  measureText:  vi.fn(() => ({ width: 50 })),
  scale:        vi.fn(),
  drawImage:    vi.fn(),
  save:         vi.fn(),
  restore:      vi.fn(),
  beginPath:    vi.fn(),
  closePath:    vi.fn(),
  moveTo:       vi.fn(),
  lineTo:       vi.fn(),
  arc:          vi.fn(),
  arcTo:        vi.fn(),
  quadraticCurveTo: vi.fn(),
  bezierCurveTo: vi.fn(),
  fill:         vi.fn(),
  stroke:       vi.fn(),
  clip:         vi.fn(),
  setTransform: vi.fn(),
  resetTransform: vi.fn(),
  createLinearGradient: vi.fn(() => ({ addColorStop: vi.fn() })),
  createRadialGradient: vi.fn(() => ({ addColorStop: vi.fn() })),
  putImageData: vi.fn(),
  getImageData: vi.fn(() => ({ data: new Uint8ClampedArray(4) })),
  createImageData: vi.fn(() => ({ data: new Uint8ClampedArray(4) })),
  shadowColor: '',
  shadowBlur: 0,
  fillStyle: '',
  strokeStyle: '',
  lineWidth: 1,
  font: '',
  textBaseline: 'alphabetic',
  textAlign: 'left',
  globalAlpha: 1,
  canvas: { width: 816, height: 1056 },
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
HTMLCanvasElement.prototype.getContext = vi.fn(() => mockCtx) as any;

// ── IntersectionObserver mock ─────────────────────────────────────────────────
global.IntersectionObserver = vi.fn().mockImplementation(() => ({
  observe:    vi.fn(),
  unobserve:  vi.fn(),
  disconnect: vi.fn(),
})) as unknown as typeof IntersectionObserver;

// ── ResizeObserver mock ───────────────────────────────────────────────────────
global.ResizeObserver = vi.fn().mockImplementation(() => ({
  observe:    vi.fn(),
  unobserve:  vi.fn(),
  disconnect: vi.fn(),
})) as unknown as typeof ResizeObserver;

// ── matchMedia mock ───────────────────────────────────────────────────────────
Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: vi.fn().mockImplementation((query: string) => ({
    matches:             false,
    media:               query,
    onchange:            null,
    addListener:         vi.fn(),
    removeListener:      vi.fn(),
    addEventListener:    vi.fn(),
    removeEventListener: vi.fn(),
    dispatchEvent:       vi.fn(),
  })),
});

// ── scrollTo mock ─────────────────────────────────────────────────────────────
Element.prototype.scrollTo = vi.fn() as unknown as typeof Element.prototype.scrollTo;
window.scrollTo = vi.fn() as unknown as typeof window.scrollTo;

// ── requestAnimationFrame mock ────────────────────────────────────────────────
global.requestAnimationFrame = vi.fn((cb: FrameRequestCallback) => {
  cb(0);
  return 0;
});

// ── Reset mocks after each test ───────────────────────────────────────────────
afterEach(() => {
  vi.clearAllMocks();
});

// ── Silence console.warn/error in tests (optional — comment out to debug) ─────
beforeEach(() => {
  vi.spyOn(console, 'warn').mockImplementation(() => {});
  vi.spyOn(console, 'error').mockImplementation(() => {});
});
