/**
 * MultiDocSidebar.component.test.tsx
 *
 * Component tests for MultiDocSidebar.
 * Tests document list rendering, category grouping, doc selection callbacks,
 * and isDocActive gating for thumbnail rendering.
 */

import React from 'react';
import { describe, it, expect, beforeEach, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { MultiDocSidebar } from '../../components/MultiDocSidebar';
import { useAppStore } from '../../store/appStore';
import type { MultiDocState } from '../../types/multiDoc';

// ── MultiDocSidebar depends on appStore for PALETTE_MAP ───────────────────────
beforeEach(() => {
  useAppStore.setState({
    currentPage:   1,
    isSplitScreen: false,
    sidebarTab:    'thumbnails',
  });
  vi.clearAllMocks();
});

// ── Fixtures ──────────────────────────────────────────────────────────────────
const makeSinglePageState = (activeDocId = 'doc1'): MultiDocState => ({
  mode: 'MultiDoc:SinglePage',
  categories: [
    { id: 'invoice',  label: 'Invoice',  color: 'blue' },
    { id: 'annexure', label: 'Annexure', color: 'teal' },
  ],
  documents: [
    { id: 'doc1', name: 'invoice_001.pdf',  categoryId: 'invoice'  },
    { id: 'doc2', name: 'invoice_002.pdf',  categoryId: 'invoice'  },
    { id: 'doc3', name: 'annexure_001.pdf', categoryId: 'annexure' },
  ],
  activeDocId,
  activePage: 1,
});

const makeMultiPageState = (): MultiDocState => ({
  mode: 'MultiDoc:MultiPage',
  categories: [
    { id: 'invoice',  label: 'Invoice',  color: 'blue' },
    { id: 'annexure', label: 'Annexure', color: 'teal' },
  ],
  documents: [
    {
      id: 'doc1', name: 'combined.pdf', categoryId: undefined as any,
      pageCategories: [
        { category: 'invoice',  pages: [1, 2, 3] },
        { category: 'annexure', pages: [4, 5]    },
      ],
      totalPages: 5,
    },
  ],
  activeDocId: 'doc1',
  activePage: 1,
});

// ── Default props ─────────────────────────────────────────────────────────────
const defaultProps = {
  isLoading:    false,
  loadError:    null,
  onSelectDoc:  vi.fn(),
  onSelectPage: vi.fn(),
  onClose:      vi.fn(),
};

// ─────────────────────────────────────────────────────────────────────────────
// Loading state
// ─────────────────────────────────────────────────────────────────────────────
describe('MultiDocSidebar — loading state', () => {

  it('shows loading indicator when isLoading=true', () => {
    render(
      <MultiDocSidebar
        {...defaultProps}
        state={makeSinglePageState()}
        isLoading={true}
      />
    );
    expect(
      screen.queryByText(/loading/i) ||
      screen.queryByRole('progressbar') ||
      document.querySelector('[class*="spin"]') ||
      document.querySelector('[data-loading]')
    ).toBeTruthy();
  });

  it('renders without error when isLoading=false', () => {
    expect(() =>
      render(<MultiDocSidebar {...defaultProps} state={makeSinglePageState()} isLoading={false} />)
    ).not.toThrow();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Error state
// ─────────────────────────────────────────────────────────────────────────────
describe('MultiDocSidebar — error state', () => {

  it('shows error message when loadError provided', () => {
    render(
      <MultiDocSidebar
        {...defaultProps}
        state={makeSinglePageState()}
        loadError="Failed to load document"
      />
    );
    expect(screen.queryByText(/failed/i) || screen.queryByText(/error/i)).toBeTruthy();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// SinglePage mode — document list
// ─────────────────────────────────────────────────────────────────────────────
describe('MultiDocSidebar — SinglePage mode', () => {

  it('renders document names', () => {
    render(<MultiDocSidebar {...defaultProps} state={makeSinglePageState()} />);
    expect(screen.getByText('invoice_001.pdf')).toBeTruthy();
    expect(screen.getByText('invoice_002.pdf')).toBeTruthy();
    expect(screen.getByText('annexure_001.pdf')).toBeTruthy();
  });

  it('renders category labels', () => {
    render(<MultiDocSidebar {...defaultProps} state={makeSinglePageState()} />);
    expect(screen.getByText('Invoice')).toBeTruthy();
    expect(screen.getByText('Annexure')).toBeTruthy();
  });

  it('groups documents by category', () => {
    render(<MultiDocSidebar {...defaultProps} state={makeSinglePageState()} />);
    // Both invoice docs should appear in one group
    const invoiceDocs = screen.getAllByText(/invoice_\d+\.pdf/);
    expect(invoiceDocs).toHaveLength(2);
  });

  it('calls onSelectDoc when document clicked', () => {
    const onSelectDoc = vi.fn();
    render(
      <MultiDocSidebar
        {...defaultProps}
        state={makeSinglePageState()}
        onSelectDoc={onSelectDoc}
      />
    );
    fireEvent.click(screen.getByText('invoice_001.pdf'));
    expect(onSelectDoc).toHaveBeenCalledWith('doc1', expect.anything());
  });

  it('calls onSelectDoc with correct docId', () => {
    const onSelectDoc = vi.fn();
    render(
      <MultiDocSidebar
        {...defaultProps}
        state={makeSinglePageState()}
        onSelectDoc={onSelectDoc}
      />
    );
    fireEvent.click(screen.getByText('annexure_001.pdf'));
    expect(onSelectDoc).toHaveBeenCalledWith('doc3', expect.anything());
  });

  it('shows document count in header', () => {
    render(<MultiDocSidebar {...defaultProps} state={makeSinglePageState()} />);
    // Header should show "3 docs" or similar
    expect(screen.getByText(/3.*doc/i) || screen.getByText(/docs/i)).toBeTruthy();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// MultiPage mode
// ─────────────────────────────────────────────────────────────────────────────
describe('MultiDocSidebar — MultiPage mode', () => {

  it('renders without crashing in MultiPage mode', () => {
    expect(() =>
      render(<MultiDocSidebar {...defaultProps} state={makeMultiPageState()} />)
    ).not.toThrow();
  });

  it('renders category accordion groups for multipage', () => {
    render(<MultiDocSidebar {...defaultProps} state={makeMultiPageState()} />);
    expect(screen.getByText('Invoice')).toBeTruthy();
    expect(screen.getByText('Annexure')).toBeTruthy();
  });

  it('shows page counts for multipage categories', () => {
    render(<MultiDocSidebar {...defaultProps} state={makeMultiPageState()} />);
    // Invoice has 3 pages, Annexure has 2 pages
    expect(screen.getByText(/3/)).toBeTruthy();
    expect(screen.getByText(/2/)).toBeTruthy();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Active document highlighting
// ─────────────────────────────────────────────────────────────────────────────
describe('MultiDocSidebar — active document', () => {

  it('renders with doc1 as active', () => {
    const state = makeSinglePageState('doc1');
    expect(() =>
      render(<MultiDocSidebar {...defaultProps} state={state} />)
    ).not.toThrow();
  });

  it('renders with doc2 as active (switching)', () => {
    const state = makeSinglePageState('doc2');
    expect(() =>
      render(<MultiDocSidebar {...defaultProps} state={state} />)
    ).not.toThrow();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Retrigger bar visibility
// ─────────────────────────────────────────────────────────────────────────────
describe('MultiDocSidebar — Retrigger bar', () => {

  it('Retrigger bar hidden when isSplitScreen=false', () => {
    useAppStore.setState({ isSplitScreen: false });
    render(<MultiDocSidebar {...defaultProps} state={makeSinglePageState()} />);
    expect(screen.queryByText(/w\/o IDP/i)).toBeNull();
  });

  it('Retrigger bar visible when isSplitScreen=true', () => {
    useAppStore.setState({ isSplitScreen: true });
    render(<MultiDocSidebar {...defaultProps} state={makeSinglePageState()} />);
    expect(screen.queryByText(/w\/o IDP/i) || screen.queryByText(/retrigger/i)).toBeTruthy();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Empty state
// ─────────────────────────────────────────────────────────────────────────────
describe('MultiDocSidebar — empty state', () => {

  it('handles empty documents array gracefully', () => {
    const state: MultiDocState = {
      ...makeSinglePageState(),
      documents: [],
    };
    expect(() =>
      render(<MultiDocSidebar {...defaultProps} state={state} />)
    ).not.toThrow();
  });

  it('handles empty categories array gracefully', () => {
    const state: MultiDocState = {
      ...makeSinglePageState(),
      categories: [],
      documents: [],
    };
    expect(() =>
      render(<MultiDocSidebar {...defaultProps} state={state} />)
    ).not.toThrow();
  });
});
