/**
 * ThumbnailSidebar.component.test.tsx
 *
 * Component tests for ThumbnailSidebar.
 * Tests flat (no categories) and accordion (with categories) modes,
 * page click navigation, and retrigger bar visibility.
 */

import React from 'react';
import { describe, it, expect, beforeEach, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { ThumbnailSidebar } from '../../components/ThumbnailSidebar';
import { useAppStore } from '../../store/appStore';

// ── Mock heavy dependencies ───────────────────────────────────────────────────
vi.mock('../../hooks/useThumbnailRenderer', () => ({
  useThumbnailRenderer: () => ({
    registerThumb:   vi.fn(),
    unregisterThumb: vi.fn(),
    pauseRendering:  vi.fn(),
  }),
}));

const mockNavigatePdfPage = vi.fn();
vi.mock('../../components/PDFViewer', () => ({
  navigatePdfPage: (...args: unknown[]) => mockNavigatePdfPage(...args),
  PDFViewer: () => <div>PDFViewer</div>,
}));

// ── Minimal mock adapter ──────────────────────────────────────────────────────
const mockAdapter = {
  pageCount: 5,
  navigateToPage: vi.fn(),
  getPageDimensions: vi.fn(() => ({ width: 816, height: 1056 })),
  registerPageElement: vi.fn(),
  unregisterPageElement: vi.fn(),
  constructor: { name: 'PDFAdapter' },
};

// ── Reset store before each test ──────────────────────────────────────────────
beforeEach(() => {
  useAppStore.setState({
    adapter:       null,
    file:          null,
    format:        'pdf',
    categories:    [],
    currentPage:   1,
    pageCount:     0,
    isSplitScreen: false,
    sidebarTab:    'thumbnails',
    hasReclassification: false,
  });
  vi.clearAllMocks();
});

// ── Helper — set up store for a loaded doc ────────────────────────────────────
function setLoadedDoc(overrides: Record<string, unknown> = {}) {
  useAppStore.setState({
    adapter:     mockAdapter as any,
    file:        new File([''], 'test.pdf'),
    format:      'pdf',
    currentPage: 1,
    pageCount:   5,
    ...overrides,
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// Basic rendering
// ─────────────────────────────────────────────────────────────────────────────
describe('ThumbnailSidebar — basic rendering', () => {

  it('renders without crashing', () => {
    expect(() => render(<ThumbnailSidebar />)).not.toThrow();
  });

  it('renders nothing meaningful when no document loaded', () => {
    const { container } = render(<ThumbnailSidebar />);
    // Should render empty or minimal state — no page thumbs
    expect(container).toBeTruthy();
  });

  it('renders page count when document loaded', () => {
    setLoadedDoc({ pageCount: 5 });
    render(<ThumbnailSidebar />);
    expect(screen.getByText(/5/)).toBeTruthy();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Accordion mode (with categories)
// ─────────────────────────────────────────────────────────────────────────────
describe('ThumbnailSidebar — with categories (accordion mode)', () => {

  const categories = [
    { id: 'inv', label: 'Invoice', color: 'blue', pages: [1, 2] },
    { id: 'ann', label: 'Annexure', color: 'teal', pages: [3, 4, 5] },
  ];

  it('renders category labels when categories set', () => {
    setLoadedDoc({ categories });
    render(<ThumbnailSidebar />);
    expect(screen.getByText('Invoice')).toBeTruthy();
    expect(screen.getByText('Annexure')).toBeTruthy();
  });

  it('renders page count per category', () => {
    setLoadedDoc({ categories });
    render(<ThumbnailSidebar />);
    // Each accordion should show its page count
    expect(screen.getByText(/2/)).toBeTruthy(); // Invoice: 2 pg
    expect(screen.getByText(/3/)).toBeTruthy(); // Annexure: 3 pg
  });

  it('renders type count in header', () => {
    setLoadedDoc({ categories });
    render(<ThumbnailSidebar />);
    // Should show "2 types" or similar
    expect(screen.getByText(/2.*type/i) || screen.getByText(/types/i)).toBeTruthy();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Flat mode (no categories)
// ─────────────────────────────────────────────────────────────────────────────
describe('ThumbnailSidebar — flat mode (no categories)', () => {

  it('does not show category labels when no categories', () => {
    setLoadedDoc({ categories: [] });
    render(<ThumbnailSidebar />);
    expect(screen.queryByText('Invoice')).toBeNull();
    expect(screen.queryByText('Annexure')).toBeNull();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Retrigger bar visibility
// ─────────────────────────────────────────────────────────────────────────────
describe('ThumbnailSidebar — Retrigger bar', () => {

  it('Retrigger bar hidden when isSplitScreen=false', () => {
    setLoadedDoc();
    useAppStore.setState({ isSplitScreen: false });
    render(<ThumbnailSidebar />);
    expect(screen.queryByText(/retrigger/i) || screen.queryByText(/w\/o IDP/i)).toBeNull();
  });

  it('Retrigger bar visible when isSplitScreen=true', () => {
    setLoadedDoc();
    useAppStore.setState({ isSplitScreen: true });
    render(<ThumbnailSidebar />);
    // Bar should be visible with Retrigger label or buttons
    const retrigger = screen.queryByText(/⇅.*retrigger/i) ||
                      screen.queryByText(/retrigger/i) ||
                      screen.queryByText(/w\/o IDP/i);
    expect(retrigger).toBeTruthy();
  });

  it('shows w/o IDP and with IDP buttons when isSplitScreen=true', () => {
    setLoadedDoc();
    useAppStore.setState({ isSplitScreen: true });
    render(<ThumbnailSidebar />);
    expect(screen.queryByText(/w\/o IDP/i)).toBeTruthy();
    expect(screen.queryByText(/with IDP/i)).toBeTruthy();
  });

  it('Retrigger bar hidden when isSplitScreen goes from true to false', () => {
    setLoadedDoc();
    useAppStore.setState({ isSplitScreen: true });
    const { rerender } = render(<ThumbnailSidebar />);
    expect(screen.queryByText(/w\/o IDP/i)).toBeTruthy();

    useAppStore.setState({ isSplitScreen: false });
    rerender(<ThumbnailSidebar />);
    expect(screen.queryByText(/w\/o IDP/i)).toBeNull();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Sidebar tab switching
// ─────────────────────────────────────────────────────────────────────────────
describe('ThumbnailSidebar — tab state', () => {

  it('renders on thumbnails tab', () => {
    setLoadedDoc();
    useAppStore.setState({ sidebarTab: 'thumbnails' });
    expect(() => render(<ThumbnailSidebar />)).not.toThrow();
  });
});
