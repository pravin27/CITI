/**
 * resetSnapshot.integration.test.ts
 *
 * Tests the snapshot save → SM reclassify → Reset restore flow.
 * This is the most critical stateful flow in the app.
 *
 * Flow:
 *   1. LOAD_SINGLEDOC/MANIFEST → originalCategories/originalDocuments saved
 *   2. SM_RECLASSIFY → categories updated (snapshot NOT touched)
 *   3. Reset → Yes → restored from snapshot, DISCARD_CLICKED fired
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';
import { useAppStore } from '../../store/appStore';

// ── Reset store before each test ──────────────────────────────────────────────
beforeEach(() => {
  useAppStore.setState({
    captures:            [],
    categories:          [],
    originalCategories:  null,
    originalDocuments:   null,
    hasReclassification: false,
    isSplitScreen:       false,
    activeFieldId:       null,
    previewRect:         null,
    highlightIndex:      new Map(),
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Snapshot save on LOAD_SINGLEDOC
// ─────────────────────────────────────────────────────────────────────────────
describe('snapshot save — LOAD_SINGLEDOC', () => {
  const originalCats = [
    { label: 'Invoice', color: 'blue', pages: [1, 2] },
    { label: 'Annexure', color: 'teal', pages: [3] },
  ];

  it('setOriginalCategories saves the snapshot', () => {
    useAppStore.setState({ originalCategories: originalCats as any });
    expect(useAppStore.getState().originalCategories).toHaveLength(2);
    expect(useAppStore.getState().originalCategories![0].label).toBe('Invoice');
  });

  it('snapshot survives a setCategories call', () => {
    useAppStore.setState({ originalCategories: originalCats as any });
    useAppStore.setState({ categories: [{ label: 'Other', pages: [] }] as any });

    // Snapshot untouched
    expect(useAppStore.getState().originalCategories![0].label).toBe('Invoice');
    // Active categories updated
    expect(useAppStore.getState().categories[0].label).toBe('Other');
  });

  it('snapshot survives multiple setCategories calls', () => {
    useAppStore.setState({ originalCategories: originalCats as any });
    for (let i = 0; i < 5; i++) {
      useAppStore.setState({ categories: [{ label: `Cat ${i}`, pages: [] }] as any });
    }
    expect(useAppStore.getState().originalCategories).toHaveLength(2);
  });

  it('second LOAD clears and resets snapshot', () => {
    useAppStore.setState({ originalCategories: originalCats as any });
    // Simulate new LOAD resetting snapshot
    const newCats = [{ label: 'New Category', color: 'purple', pages: [1] }];
    useAppStore.setState({ originalCategories: newCats as any });
    expect(useAppStore.getState().originalCategories).toHaveLength(1);
    expect(useAppStore.getState().originalCategories![0].label).toBe('New Category');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// SM_RECLASSIFY — does NOT overwrite snapshot
// ─────────────────────────────────────────────────────────────────────────────
describe('SM_RECLASSIFY — snapshot protection', () => {
  const originalCats = [
    { label: 'Invoice', color: 'blue', pages: [1, 2] },
    { label: 'Annexure', color: 'teal', pages: [3] },
  ];

  it('setCategories (SM update) does not overwrite originalCategories', () => {
    // 1. Save snapshot on load
    useAppStore.setState({ originalCategories: originalCats as any });

    // 2. SM_RECLASSIFY updates categories
    const smUpdated = [{ label: 'Invoice', color: 'blue', pages: [1] }]; // reduced pages
    useAppStore.setState({ categories: smUpdated as any });
    useAppStore.setState({ hasReclassification: true });

    // 3. Snapshot must still show original 2 pages for Invoice
    const snap = useAppStore.getState().originalCategories;
    expect(snap).not.toBeNull();
    expect(snap!.find((c: any) => c.label === 'Invoice')?.pages).toEqual([1, 2]);
  });

  it('hasReclassification:true marks state for Reset visibility', () => {
    useAppStore.setState({ hasReclassification: true });
    expect(useAppStore.getState().hasReclassification).toBe(true);
  });

  it('categories show SM changes while snapshot holds original', () => {
    useAppStore.setState({ originalCategories: originalCats as any });
    useAppStore.setState({ categories: [
      { label: 'Invoice Modified', color: 'blue', pages: [1] },
    ] as any });

    expect(useAppStore.getState().categories[0].label).toBe('Invoice Modified');
    expect(useAppStore.getState().originalCategories![0].label).toBe('Invoice');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Reset flow — restores from snapshot
// ─────────────────────────────────────────────────────────────────────────────
describe('Reset flow — restore from snapshot', () => {
  const originalCats = [
    { label: 'Invoice', color: 'blue', pages: [1, 2] },
    { label: 'Annexure', color: 'teal', pages: [3] },
  ];

  function simulateReset() {
    const origCats = useAppStore.getState().originalCategories;
    if (origCats?.length) {
      useAppStore.setState({ categories: origCats as any });
    }
    useAppStore.setState({ hasReclassification: false, isSplitScreen: false });
  }

  it('restores categories from originalCategories', () => {
    useAppStore.setState({ originalCategories: originalCats as any });
    useAppStore.setState({ categories: [{ label: 'Invoice Modified', pages: [1] }] as any });
    useAppStore.setState({ hasReclassification: true });

    simulateReset();

    expect(useAppStore.getState().categories).toHaveLength(2);
    expect(useAppStore.getState().categories[0].label).toBe('Invoice');
    expect(useAppStore.getState().categories[0].pages).toEqual([1, 2]);
  });

  it('sets hasReclassification to false after reset', () => {
    useAppStore.setState({ hasReclassification: true });
    simulateReset();
    expect(useAppStore.getState().hasReclassification).toBe(false);
  });

  it('sets isSplitScreen to false after reset', () => {
    useAppStore.setState({ isSplitScreen: true });
    simulateReset();
    expect(useAppStore.getState().isSplitScreen).toBe(false);
  });

  it('snapshot is not null after reset (can reset again)', () => {
    useAppStore.setState({ originalCategories: originalCats as any });
    simulateReset();
    // Snapshot remains available for subsequent resets
    expect(useAppStore.getState().originalCategories).not.toBeNull();
  });

  it('reset with no snapshot is a no-op for categories', () => {
    useAppStore.setState({ originalCategories: null });
    useAppStore.setState({ categories: [{ label: 'SM Cat', pages: [] }] as any });

    simulateReset();

    // No snapshot → categories unchanged
    expect(useAppStore.getState().categories[0].label).toBe('SM Cat');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// originalDocuments — MultiDoc snapshot
// ─────────────────────────────────────────────────────────────────────────────
describe('originalDocuments — MultiDoc snapshot', () => {
  const originalDocs = [
    { id: 'doc1', name: 'invoice.pdf', category: 'invoice' },
    { id: 'doc2', name: 'annexure.pdf', category: 'annexure' },
  ];

  it('setOriginalDocuments saves MultiDoc snapshot', () => {
    useAppStore.setState({ originalDocuments: originalDocs as any });
    expect(useAppStore.getState().originalDocuments).toHaveLength(2);
    expect(useAppStore.getState().originalDocuments![0].category).toBe('invoice');
  });

  it('LOAD_SINGLEDOC sets originalDocuments to null', () => {
    useAppStore.setState({ originalDocuments: originalDocs as any });
    // Simulating LOAD_SINGLEDOC which clears MultiDoc snapshot
    useAppStore.setState({ originalDocuments: null });
    expect(useAppStore.getState().originalDocuments).toBeNull();
  });

  it('originalDocuments survives category changes', () => {
    useAppStore.setState({ originalDocuments: originalDocs as any });
    useAppStore.setState({ categories: [{ label: 'X', pages: [] }] as any });
    expect(useAppStore.getState().originalDocuments).toHaveLength(2);
  });

  it('originalDocuments holds category field for restore', () => {
    useAppStore.setState({ originalDocuments: originalDocs as any });
    const snap = useAppStore.getState().originalDocuments!;
    expect(snap[0].category).toBe('invoice');
    expect(snap[1].category).toBe('annexure');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Full round-trip — load → SM change → reset
// ─────────────────────────────────────────────────────────────────────────────
describe('full round-trip: load → SM reclassify → reset', () => {

  it('restores exact original state after SM modification', () => {
    const original = [
      { label: 'Form 15CA', color: 'blue', pages: [1, 2] },
      { label: 'Annexure', color: 'teal', pages: [3, 4] },
    ];

    // Step 1: Load saves snapshot
    useAppStore.setState({ categories: original as any });
    useAppStore.setState({ originalCategories: original as any });

    // Step 2: SM sends 1 page instead of 2 for Form 15CA
    const smVersion = [
      { label: 'Form 15CA', color: 'blue', pages: [1] }, // reduced
      { label: 'Annexure', color: 'teal', pages: [3, 4] },
    ];
    useAppStore.setState({ categories: smVersion as any });
    useAppStore.setState({ hasReclassification: true });

    // Verify SM change is visible
    expect(useAppStore.getState().categories.find((c: any) => c.label === 'Form 15CA')?.pages).toEqual([1]);

    // Step 3: Reset
    const origCats = useAppStore.getState().originalCategories;
    useAppStore.setState({ categories: origCats as any });
    useAppStore.setState({ hasReclassification: false });

    // Verify restoration
    const restoredA = useAppStore.getState().categories.find((c: any) => c.label === 'Form 15CA');
    expect(restoredA?.pages).toEqual([1, 2]);
    expect(useAppStore.getState().hasReclassification).toBe(false);
  });
});
