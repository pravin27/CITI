/**
 * useEventBridge.integration.test.ts
 *
 * Integration tests for the message-bus layer.
 * Strategy: dispatch real window MessageEvents, assert on callbacks and store state.
 *
 * We do NOT render the full App — we call useEventBridge directly with mock callbacks,
 * simulating exactly what App.tsx does, so the bridge logic is tested in isolation.
 */

import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { useEventBridge }  from '../../hooks/useEventBridge';
import { useAppStore }     from '../../store/appStore';
import type { EventBridgeCallbacks, SingleDocMeta } from '../../hooks/useEventBridge';
import type { DocumentManifest } from '../../types/multiDoc';

// ── Helpers ───────────────────────────────────────────────────────────────────

/** Dispatch a postMessage event as the parent would */
function sendMessage(data: unknown) {
  act(() => {
    window.dispatchEvent(new MessageEvent('message', {
      data,
      origin: window.location.origin,
    }));
  });
}

/** Build a minimal valid ArrayBuffer (empty PDF magic bytes) */
function makeBuffer(): ArrayBuffer {
  const arr = new Uint8Array([0x25, 0x50, 0x44, 0x46]); // %PDF
  return arr.buffer;
}

/** Build default mock callbacks */
function makeCallbacks(overrides: Partial<EventBridgeCallbacks> = {}): EventBridgeCallbacks {
  return {
    onLoadSingleDoc: vi.fn(),
    onLoadManifest:  vi.fn(),
    onHighlight:     vi.fn(),
    onCaptureAck:    vi.fn(),
    ...overrides,
  };
}

// ── Reset store before each test ──────────────────────────────────────────────
beforeEach(() => {
  useAppStore.setState({
    captures:            [],
    activeFieldId:       null,
    previewRect:         null,
    highlightIndex:      new Map(),
    categories:          [],
    originalCategories:  null,
    hasReclassification: false,
    persistHighlights:   false,
    isSplitScreen:       false,
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// LOAD_SINGLEDOC
// ─────────────────────────────────────────────────────────────────────────────
describe('LOAD_SINGLEDOC message', () => {

  it('calls onLoadSingleDoc callback with buffer and fileName', () => {
    const callbacks = makeCallbacks();
    renderHook(() => useEventBridge(callbacks));

    const buf = makeBuffer();
    sendMessage({ type: 'LOAD_SINGLEDOC', buffer: buf, fileName: 'invoice.pdf' });

    expect(callbacks.onLoadSingleDoc).toHaveBeenCalledOnce();
    const [, fileName] = (callbacks.onLoadSingleDoc as ReturnType<typeof vi.fn>).mock.calls[0];
    expect(fileName).toBe('invoice.pdf');
  });

  it('passes meta.categories in the callback', () => {
    const callbacks = makeCallbacks();
    renderHook(() => useEventBridge(callbacks));

    sendMessage({
      type:       'LOAD_SINGLEDOC',
      buffer:     makeBuffer(),
      fileName:   'doc.pdf',
      categories: [{ id: 'inv', label: 'Invoice', pages: [1, 2] }],
    });

    const [, , meta] = (callbacks.onLoadSingleDoc as ReturnType<typeof vi.fn>).mock.calls[0];
    expect(meta.categories).toHaveLength(1);
    expect(meta.categories[0].label).toBe('Invoice');
  });

  it('passes meta.captures in the callback', () => {
    const callbacks = makeCallbacks();
    renderHook(() => useEventBridge(callbacks));

    const captures = [
      { id: 'f1', value: 'INV-001', page: 1, x: 0.1, y: 0.2, width: 0.3, height: 0.05 },
    ];
    sendMessage({ type: 'LOAD_SINGLEDOC', buffer: makeBuffer(), fileName: 'doc.pdf', captures });

    const [, , meta] = (callbacks.onLoadSingleDoc as ReturnType<typeof vi.fn>).mock.calls[0];
    expect(meta.captures).toHaveLength(1);
    expect(meta.captures[0].id).toBe('f1');
  });

  it('passes persistHighlights:true when provided', () => {
    const callbacks = makeCallbacks();
    renderHook(() => useEventBridge(callbacks));

    sendMessage({ type: 'LOAD_SINGLEDOC', buffer: makeBuffer(), persistHighlights: true });

    const [, , meta] = (callbacks.onLoadSingleDoc as ReturnType<typeof vi.fn>).mock.calls[0];
    expect(meta.persistHighlights).toBe(true);
  });

  it('persistHighlights defaults to false when not provided', () => {
    const callbacks = makeCallbacks();
    renderHook(() => useEventBridge(callbacks));

    sendMessage({ type: 'LOAD_SINGLEDOC', buffer: makeBuffer() });

    const [, , meta] = (callbacks.onLoadSingleDoc as ReturnType<typeof vi.fn>).mock.calls[0];
    // undefined means not sent → App treats as false
    expect(meta.persistHighlights).toBeFalsy();
  });

  it('passes isSplitScreen:true when provided', () => {
    const callbacks = makeCallbacks();
    renderHook(() => useEventBridge(callbacks));

    sendMessage({ type: 'LOAD_SINGLEDOC', buffer: makeBuffer(), isSplitScreen: true });

    const [, , meta] = (callbacks.onLoadSingleDoc as ReturnType<typeof vi.fn>).mock.calls[0];
    expect(meta.isSplitScreen).toBe(true);
  });

  it('does not call callback when no buffer or url provided', () => {
    const callbacks = makeCallbacks();
    renderHook(() => useEventBridge(callbacks));

    sendMessage({ type: 'LOAD_SINGLEDOC', fileName: 'doc.pdf' });
    // Should fire DOC_LOAD_ERROR but not onLoadSingleDoc without buffer
    // Callback may or may not be called depending on implementation
    // Key: should not throw
    expect(() =>
      sendMessage({ type: 'LOAD_SINGLEDOC', fileName: 'doc.pdf' })
    ).not.toThrow();
  });

  it('defaults fileName to "document.pdf" when not provided', () => {
    const callbacks = makeCallbacks();
    renderHook(() => useEventBridge(callbacks));

    sendMessage({ type: 'LOAD_SINGLEDOC', buffer: makeBuffer() });

    const [, fileName] = (callbacks.onLoadSingleDoc as ReturnType<typeof vi.fn>).mock.calls[0];
    expect(fileName).toBe('document.pdf');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// LOAD_MANIFEST
// ─────────────────────────────────────────────────────────────────────────────
describe('LOAD_MANIFEST message', () => {

  const makeManifest = (): DocumentManifest => ({
    mode: 'MultiDoc:SinglePage',
    documents: [
      { id: 'doc1', name: 'invoice.pdf', category: 'invoice' },
      { id: 'doc2', name: 'annexure.pdf', category: 'annexure' },
    ],
    categories: [
      { id: 'invoice',  label: 'Invoice' },
      { id: 'annexure', label: 'Annexure' },
    ],
  });

  it('calls onLoadManifest with the manifest object', () => {
    const callbacks = makeCallbacks();
    renderHook(() => useEventBridge(callbacks));

    const manifest = makeManifest();
    sendMessage({ type: 'LOAD_MANIFEST', manifest });

    expect(callbacks.onLoadManifest).toHaveBeenCalledOnce();
    const [receivedManifest] = (callbacks.onLoadManifest as ReturnType<typeof vi.fn>).mock.calls[0];
    expect(receivedManifest.mode).toBe('MultiDoc:SinglePage');
    expect(receivedManifest.documents).toHaveLength(2);
  });

  it('does not call onLoadManifest when manifest is missing', () => {
    const callbacks = makeCallbacks();
    renderHook(() => useEventBridge(callbacks));

    sendMessage({ type: 'LOAD_MANIFEST' });
    expect(callbacks.onLoadManifest).not.toHaveBeenCalled();
  });

  it('passes persistHighlights in meta when provided', () => {
    const callbacks = makeCallbacks();
    renderHook(() => useEventBridge(callbacks));

    sendMessage({ type: 'LOAD_MANIFEST', manifest: makeManifest(), persistHighlights: true });

    const [, , , meta] = (callbacks.onLoadManifest as ReturnType<typeof vi.fn>).mock.calls[0];
    expect(meta?.persistHighlights).toBe(true);
  });

  it('passes isSplitScreen in meta when provided', () => {
    const callbacks = makeCallbacks();
    renderHook(() => useEventBridge(callbacks));

    sendMessage({ type: 'LOAD_MANIFEST', manifest: makeManifest(), isSplitScreen: true });

    const [, , , meta] = (callbacks.onLoadManifest as ReturnType<typeof vi.fn>).mock.calls[0];
    expect(meta?.isSplitScreen).toBe(true);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// HIGHLIGHT event
// ─────────────────────────────────────────────────────────────────────────────
describe('HIGHLIGHT message', () => {

  it('calls onHighlight with the payload', () => {
    const callbacks = makeCallbacks();
    renderHook(() => useEventBridge(callbacks));

    sendMessage({
      type:    'HIGHLIGHT',
      payload: { id: 'f1', page: 1, x: 0.1, y: 0.2, width: 0.3, height: 0.05 },
    });

    expect(callbacks.onHighlight).toHaveBeenCalledOnce();
    const [payload] = (callbacks.onHighlight as ReturnType<typeof vi.fn>).mock.calls[0];
    expect(payload.id).toBe('f1');
  });

  it('does not call onHighlight when payload is missing', () => {
    const callbacks = makeCallbacks();
    renderHook(() => useEventBridge(callbacks));

    sendMessage({ type: 'HIGHLIGHT' });
    expect(callbacks.onHighlight).not.toHaveBeenCalled();
  });

  it('does not call onHighlight when id is empty string', () => {
    const callbacks = makeCallbacks();
    renderHook(() => useEventBridge(callbacks));

    sendMessage({ type: 'HIGHLIGHT', payload: { id: '', page: 1, x: 0.1, y: 0.2, width: 0.1, height: 0.1 } });
    expect(callbacks.onHighlight).not.toHaveBeenCalled();
  });

  it('does not call onHighlight when id is missing', () => {
    const callbacks = makeCallbacks();
    renderHook(() => useEventBridge(callbacks));

    sendMessage({ type: 'HIGHLIGHT', payload: { page: 1, x: 0.1 } });
    expect(callbacks.onHighlight).not.toHaveBeenCalled();
  });

  it('passes FORMAT 10 bbox payload through unchanged', () => {
    const callbacks = makeCallbacks();
    renderHook(() => useEventBridge(callbacks));

    sendMessage({
      type:    'HIGHLIGHT',
      payload: { id: 'f1', bbox: [1, 200, 300, 150, 20] },
    });

    expect(callbacks.onHighlight).toHaveBeenCalledOnce();
    const [payload] = (callbacks.onHighlight as ReturnType<typeof vi.fn>).mock.calls[0];
    expect(payload.bbox).toEqual([1, 200, 300, 150, 20]);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// RESET_VIEWER event
// ─────────────────────────────────────────────────────────────────────────────
describe('RESET_VIEWER message', () => {

  it('calls onReset callback when provided', () => {
    const onReset = vi.fn();
    const callbacks = makeCallbacks({ onReset });
    renderHook(() => useEventBridge(callbacks));

    sendMessage({ type: 'RESET_VIEWER' });
    expect(onReset).toHaveBeenCalledOnce();
  });

  it('does not throw when onReset not provided', () => {
    const callbacks = makeCallbacks({ onReset: undefined });
    renderHook(() => useEventBridge(callbacks));

    expect(() => sendMessage({ type: 'RESET_VIEWER' })).not.toThrow();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// CAPTURE_ACK event
// ─────────────────────────────────────────────────────────────────────────────
describe('CAPTURE_ACK message', () => {

  it('calls onCaptureAck with tempId and realId', () => {
    const callbacks = makeCallbacks();
    renderHook(() => useEventBridge(callbacks));

    sendMessage({ type: 'CAPTURE_ACK', tempId: 'tmp-1', realId: 'real-abc' });

    expect(callbacks.onCaptureAck).toHaveBeenCalledWith('tmp-1', 'real-abc');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Unknown message types — should not crash
// ─────────────────────────────────────────────────────────────────────────────
describe('unknown message types', () => {

  it('ignores unknown message type without throwing', () => {
    const callbacks = makeCallbacks();
    renderHook(() => useEventBridge(callbacks));

    expect(() => sendMessage({ type: 'UNKNOWN_EVENT', data: 123 })).not.toThrow();
    expect(callbacks.onLoadSingleDoc).not.toHaveBeenCalled();
    expect(callbacks.onHighlight).not.toHaveBeenCalled();
  });

  it('ignores non-object messages', () => {
    const callbacks = makeCallbacks();
    renderHook(() => useEventBridge(callbacks));

    expect(() => {
      window.dispatchEvent(new MessageEvent('message', { data: 'raw string' }));
      window.dispatchEvent(new MessageEvent('message', { data: 42 }));
      window.dispatchEvent(new MessageEvent('message', { data: null }));
    }).not.toThrow();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Multiple listeners — cleanup
// ─────────────────────────────────────────────────────────────────────────────
describe('listener cleanup', () => {

  it('does not leak listeners across hook remounts', () => {
    const callbacks = makeCallbacks();
    const { unmount } = renderHook(() => useEventBridge(callbacks));

    // First mount handles message
    sendMessage({ type: 'LOAD_SINGLEDOC', buffer: makeBuffer() });
    expect(callbacks.onLoadSingleDoc).toHaveBeenCalledTimes(1);

    // Unmount — listener removed
    unmount();
    vi.clearAllMocks();

    // After unmount — callback should NOT be called
    sendMessage({ type: 'LOAD_SINGLEDOC', buffer: makeBuffer() });
    expect(callbacks.onLoadSingleDoc).toHaveBeenCalledTimes(0);
  });
});
