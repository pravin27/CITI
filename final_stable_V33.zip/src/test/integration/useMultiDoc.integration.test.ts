/**
 * useMultiDoc.integration.test.ts
 *
 * Integration tests for the MultiDoc state machine.
 * Tests loadManifest, selectDoc, selectPage, clearMultiDoc,
 * and updateDocuments category mapping.
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { useMultiDoc } from '../../hooks/useMultiDoc';
import type { DocumentManifest } from '../../types/multiDoc';

// ── Minimal manifest fixtures ─────────────────────────────────────────────────
const singlePageManifest: DocumentManifest = {
  mode: 'MultiDoc:SinglePage',
  documents: [
    { id: 'doc1', name: 'invoice.pdf',  category: 'invoice'  },
    { id: 'doc2', name: 'annexure.pdf', category: 'annexure' },
    { id: 'doc3', name: 'permit.pdf',   category: 'invoice'  }, // same category
  ],
  categories: [
    { id: 'invoice',  label: 'Invoice'  },
    { id: 'annexure', label: 'Annexure' },
  ],
};

const multiPageManifest: DocumentManifest = {
  mode: 'MultiDoc:MultiPage',
  documents: [
    {
      id: 'doc1', name: 'mixed.pdf',
      pageCategories: [
        { category: 'invoice',  pages: [1, 2, 3] },
        { category: 'annexure', pages: [4, 5]    },
      ],
    },
  ],
};

// ─────────────────────────────────────────────────────────────────────────────
// loadManifest — SinglePage mode
// ─────────────────────────────────────────────────────────────────────────────
describe('loadManifest — MultiDoc:SinglePage', () => {

  it('populates state with documents', () => {
    const { result } = renderHook(() => useMultiDoc());
    act(() => { result.current.loadManifest(singlePageManifest); });

    expect(result.current.state).not.toBeNull();
    expect(result.current.state!.documents).toHaveLength(3);
  });

  it('sets mode correctly', () => {
    const { result } = renderHook(() => useMultiDoc());
    act(() => { result.current.loadManifest(singlePageManifest); });

    expect(result.current.state!.mode).toBe('MultiDoc:SinglePage');
  });

  it('maps document category to categoryId', () => {
    const { result } = renderHook(() => useMultiDoc());
    act(() => { result.current.loadManifest(singlePageManifest); });

    const doc1 = result.current.state!.documents.find(d => d.id === 'doc1');
    expect(doc1?.categoryId).toBe('invoice');
  });

  it('resolves categories from manifest.categories', () => {
    const { result } = renderHook(() => useMultiDoc());
    act(() => { result.current.loadManifest(singlePageManifest); });

    const cats = result.current.state!.categories;
    expect(cats).toHaveLength(2);
    expect(cats.find(c => c.id === 'invoice')?.label).toBe('Invoice');
  });

  it('auto-derives categories when not provided', () => {
    const { result } = renderHook(() => useMultiDoc());
    const manifestNoCats: DocumentManifest = {
      mode: 'MultiDoc:SinglePage',
      documents: [
        { id: 'd1', name: 'f.pdf', category: 'cat-a' },
        { id: 'd2', name: 'g.pdf', category: 'cat-b' },
      ],
      // no categories array
    };
    act(() => { result.current.loadManifest(manifestNoCats); });

    const cats = result.current.state!.categories;
    expect(cats.some(c => c.id === 'cat-a')).toBe(true);
    expect(cats.some(c => c.id === 'cat-b')).toBe(true);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// loadManifest — MultiPage mode
// ─────────────────────────────────────────────────────────────────────────────
describe('loadManifest — MultiDoc:MultiPage', () => {

  it('loads multiPage manifest correctly', () => {
    const { result } = renderHook(() => useMultiDoc());
    act(() => { result.current.loadManifest(multiPageManifest); });

    expect(result.current.state!.mode).toBe('MultiDoc:MultiPage');
    expect(result.current.state!.documents).toHaveLength(1);
  });

  it('preserves pageCategories on each document', () => {
    const { result } = renderHook(() => useMultiDoc());
    act(() => { result.current.loadManifest(multiPageManifest); });

    const doc = result.current.state!.documents[0];
    expect(doc.pageCategories).toBeDefined();
    expect(doc.pageCategories!.find(pc => pc.category === 'invoice')?.pages).toContain(1);
    expect(doc.pageCategories!.find(pc => pc.category === 'invoice')?.pages).toContain(3);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// selectPage
// ─────────────────────────────────────────────────────────────────────────────
describe('selectPage', () => {

  it('updates activePage in state', () => {
    const { result } = renderHook(() => useMultiDoc());
    act(() => { result.current.loadManifest(singlePageManifest); });
    act(() => { result.current.selectPage(3); });

    expect(result.current.state!.activePage).toBe(3);
  });

  it('activePage defaults to 1 after loadManifest', () => {
    const { result } = renderHook(() => useMultiDoc());
    act(() => { result.current.loadManifest(singlePageManifest); });

    expect(result.current.state!.activePage).toBe(1);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// clearMultiDoc
// ─────────────────────────────────────────────────────────────────────────────
describe('clearMultiDoc', () => {

  it('sets state to null after clear', () => {
    const { result } = renderHook(() => useMultiDoc());
    act(() => { result.current.loadManifest(singlePageManifest); });
    act(() => { result.current.clearMultiDoc(); });

    expect(result.current.state).toBeNull();
  });

  it('clears activeFile after clear', () => {
    const { result } = renderHook(() => useMultiDoc());
    act(() => { result.current.loadManifest(singlePageManifest); });
    act(() => { result.current.clearMultiDoc(); });

    expect(result.current.activeFile).toBeNull();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// updateDocuments — category mapping
// ─────────────────────────────────────────────────────────────────────────────
describe('updateDocuments — category mapping', () => {

  it('maps "category" field to "categoryId" on documents', () => {
    const { result } = renderHook(() => useMultiDoc());
    act(() => { result.current.loadManifest(singlePageManifest); });

    // updateDocuments receives raw manifest format with "category" field
    act(() => {
      result.current.updateDocuments?.([
        { id: 'doc1', name: 'invoice.pdf',  category: 'annexure' }, // changed
        { id: 'doc2', name: 'annexure.pdf', category: 'invoice'  }, // changed
        { id: 'doc3', name: 'permit.pdf',   category: 'invoice'  },
      ]);
    });

    const doc1 = result.current.state!.documents.find(d => d.id === 'doc1');
    expect(doc1?.categoryId).toBe('annexure');
  });

  it('only updates documents that exist by id', () => {
    const { result } = renderHook(() => useMultiDoc());
    act(() => { result.current.loadManifest(singlePageManifest); });

    act(() => {
      result.current.updateDocuments?.([
        { id: 'doc1', name: 'invoice.pdf', category: 'annexure' },
        // doc2, doc3 not in update list
      ]);
    });

    // doc1 updated
    const doc1 = result.current.state!.documents.find(d => d.id === 'doc1');
    expect(doc1?.categoryId).toBe('annexure');
    // doc2 unchanged
    const doc2 = result.current.state!.documents.find(d => d.id === 'doc2');
    expect(doc2?.categoryId).toBe('annexure');
  });

  it('updateDocuments with empty array is safe', () => {
    const { result } = renderHook(() => useMultiDoc());
    act(() => { result.current.loadManifest(singlePageManifest); });

    expect(() => {
      act(() => { result.current.updateDocuments?.([]); });
    }).not.toThrow();

    expect(result.current.state!.documents).toHaveLength(3);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Reloading manifest
// ─────────────────────────────────────────────────────────────────────────────
describe('manifest reload', () => {

  it('second loadManifest replaces state', () => {
    const { result } = renderHook(() => useMultiDoc());
    act(() => { result.current.loadManifest(singlePageManifest); });
    act(() => { result.current.loadManifest(multiPageManifest); });

    expect(result.current.state!.mode).toBe('MultiDoc:MultiPage');
    expect(result.current.state!.documents).toHaveLength(1);
  });
});
