/**
 * persistHighlights.integration.test.ts
 *
 * Tests the persistHighlights flag behaviour end-to-end through the store.
 * Validates the two-mode system:
 *   persist=true  → captures stored permanently, grey boxes, yellow on active
 *   persist=false → transient only, yellow on active, light pink for dupes
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';
import { useAppStore } from '../../store/appStore';
import { parseHighlightPayload } from '../../utils/parseHighlightPayload';
import type { CaptureItem } from '../../adapters/types';

const mockAdapter = {
  getPageDimensions: () => ({ width: 816, height: 1056 }),
  pageCount: 5,
  navigateToPage: vi.fn(),
};

const makeCapture = (overrides: Partial<CaptureItem> = {}): CaptureItem => ({
  id:     'field-1',
  label:  'Invoice No',
  value:  'INV-001',
  page:   1,
  x:      0.1,
  y:      0.2,
  width:  0.3,
  height: 0.05,
  sourceFormat: 'flat',
  ...overrides,
});

// ── Simulate onHighlight handler (mirrors App.tsx logic) ──────────────────────
function simulateOnHighlight(
  payload: Record<string, unknown>,
  options: { persist: boolean } = { persist: false },
) {
  const store = useAppStore.getState();
  const persist = options.persist;

  store.setActiveField(null);
  store.setPreviewRect(null);

  if (persist) {
    // Persist mode: store + grey
    const found = store.navigateAndHighlight(payload.id as string);
    if (found) return;
    const result = parseHighlightPayload(payload as any, mockAdapter as any);
    if ('error' in result) return;
    store.addCaptureWithId(result.item);
  } else {
    // Transient mode: yellow only, no grey
    const result = parseHighlightPayload(payload as any, mockAdapter as any);
    if ('error' in result) return;
    const item = result.item;
    const existing = store.captures;
    const PINK = '#ffb3c1';
    const duplicates = existing.filter(c =>
      Math.abs(c.x - item.x) < 0.003 &&
      Math.abs(c.y - item.y) < 0.003 &&
      c.page === item.page
    );
    const index = new Map<number, { x:number; y:number; width:number; height:number; id:string; color?:string }[]>();
    // Active item (yellow)
    if (!index.has(item.page)) index.set(item.page, []);
    index.get(item.page)!.push({ x: item.x, y: item.y, width: item.width, height: item.height, id: item.id });
    // Duplicates (pink)
    for (const d of duplicates.filter(d => d.id !== item.id)) {
      if (!index.has(d.page)) index.set(d.page, []);
      index.get(d.page)!.push({ x: d.x, y: d.y, width: d.width, height: d.height, id: d.id, color: PINK });
    }
    useAppStore.setState({
      captures:       [item, ...duplicates.filter(d => d.id !== item.id).map(c => ({ ...c, color: PINK }))],
      highlightIndex: index,
      activeFieldId:  item.id,
    });
    store.setPreviewRect({ page: item.page, x: item.x, y: item.y, width: item.width, height: item.height });
  }
}

beforeEach(() => {
  useAppStore.setState({
    captures:            [],
    activeFieldId:       null,
    previewRect:         null,
    highlightIndex:      new Map(),
    persistHighlights:   false,
  });
  vi.clearAllMocks();
});

// ─────────────────────────────────────────────────────────────────────────────
// persist=true mode
// ─────────────────────────────────────────────────────────────────────────────
describe('persist=true (grey boxes)', () => {

  it('adds capture to store on first HIGHLIGHT', () => {
    simulateOnHighlight(
      { id: 'f1', page: 1, x: 0.1, y: 0.2, width: 0.3, height: 0.05 },
      { persist: true }
    );
    expect(useAppStore.getState().captures).toHaveLength(1);
    expect(useAppStore.getState().captures[0].id).toBe('f1');
  });

  it('accumulates multiple highlights as grey captures', () => {
    simulateOnHighlight({ id: 'f1', page: 1, x: 0.1, y: 0.2, width: 0.3, height: 0.05 }, { persist: true });
    simulateOnHighlight({ id: 'f2', page: 1, x: 0.5, y: 0.6, width: 0.2, height: 0.04 }, { persist: true });
    simulateOnHighlight({ id: 'f3', page: 2, x: 0.1, y: 0.1, width: 0.1, height: 0.03 }, { persist: true });

    expect(useAppStore.getState().captures).toHaveLength(3);
  });

  it('sets activeFieldId to the latest highlighted field', () => {
    simulateOnHighlight({ id: 'f1', page: 1, x: 0.1, y: 0.2, width: 0.3, height: 0.05 }, { persist: true });
    simulateOnHighlight({ id: 'f2', page: 1, x: 0.5, y: 0.6, width: 0.2, height: 0.04 }, { persist: true });

    expect(useAppStore.getState().activeFieldId).toBe('f2');
  });

  it('navigates to existing capture by id without adding duplicate', () => {
    // Pre-load a capture
    useAppStore.setState({ captures: [makeCapture({ id: 'f1' })] });
    useAppStore.getState()._rebuildHighlightIndex();

    simulateOnHighlight({ id: 'f1', page: 1, x: 0.1, y: 0.2, width: 0.3, height: 0.05 }, { persist: true });

    // Should not add a second entry
    expect(useAppStore.getState().captures).toHaveLength(1);
    expect(useAppStore.getState().activeFieldId).toBe('f1');
  });

  it('highlightIndex contains all persisted captures', () => {
    simulateOnHighlight({ id: 'f1', page: 1, x: 0.1, y: 0.2, width: 0.3, height: 0.05 }, { persist: true });
    simulateOnHighlight({ id: 'f2', page: 1, x: 0.5, y: 0.6, width: 0.2, height: 0.04 }, { persist: true });

    const rects = useAppStore.getState().highlightIndex.get(1);
    expect(rects).toHaveLength(2);
  });

  it('previous captures remain in store after new highlight', () => {
    simulateOnHighlight({ id: 'f1', page: 1, x: 0.1, y: 0.2, width: 0.3, height: 0.05 }, { persist: true });
    simulateOnHighlight({ id: 'f2', page: 1, x: 0.5, y: 0.6, width: 0.2, height: 0.04 }, { persist: true });

    const ids = useAppStore.getState().captures.map(c => c.id);
    expect(ids).toContain('f1');
    expect(ids).toContain('f2');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// persist=false mode (transient)
// ─────────────────────────────────────────────────────────────────────────────
describe('persist=false (transient, yellow only)', () => {

  it('does NOT accumulate captures across multiple HIGHLIGHTs', () => {
    simulateOnHighlight({ id: 'f1', page: 1, x: 0.1, y: 0.2, width: 0.3, height: 0.05 }, { persist: false });
    simulateOnHighlight({ id: 'f2', page: 1, x: 0.5, y: 0.6, width: 0.2, height: 0.04 }, { persist: false });
    simulateOnHighlight({ id: 'f3', page: 2, x: 0.1, y: 0.1, width: 0.1, height: 0.03 }, { persist: false });

    // Only the last highlight should be in captures
    expect(useAppStore.getState().captures).toHaveLength(1);
    expect(useAppStore.getState().captures[0].id).toBe('f3');
  });

  it('active item is in highlightIndex for yellow canvas rendering', () => {
    simulateOnHighlight({ id: 'f1', page: 1, x: 0.1, y: 0.2, width: 0.3, height: 0.05 }, { persist: false });

    const rects = useAppStore.getState().highlightIndex.get(1);
    expect(rects).toBeDefined();
    expect(rects!.some(r => r.id === 'f1')).toBe(true);
  });

  it('active item in highlightIndex has no color (painter uses yellow)', () => {
    simulateOnHighlight({ id: 'f1', page: 1, x: 0.1, y: 0.2, width: 0.3, height: 0.05 }, { persist: false });

    const rects = useAppStore.getState().highlightIndex.get(1)!;
    const activeRect = rects.find(r => r.id === 'f1');
    expect(activeRect).toBeDefined();
    expect(activeRect!.color).toBeUndefined(); // no color = yellow via isAct = id===activeFieldId
  });

  it('sets activeFieldId to highlighted field', () => {
    simulateOnHighlight({ id: 'f1', page: 1, x: 0.1, y: 0.2, width: 0.3, height: 0.05 }, { persist: false });
    expect(useAppStore.getState().activeFieldId).toBe('f1');
  });

  it('sets previewRect for yellow pulse overlay', () => {
    simulateOnHighlight({ id: 'f1', page: 2, x: 0.5, y: 0.6, width: 0.2, height: 0.04 }, { persist: false });
    const pr = useAppStore.getState().previewRect;
    expect(pr).not.toBeNull();
    expect(pr!.page).toBe(2);
    expect(pr!.x).toBeCloseTo(0.5);
  });

  it('duplicate at same coords gets pink color in highlightIndex', () => {
    // Pre-load a capture with same coords
    const dup = makeCapture({ id: 'dup-1', x: 0.1, y: 0.2, width: 0.3, height: 0.05, page: 1 });
    useAppStore.setState({ captures: [dup] });

    // Highlight a new field at the same coords
    simulateOnHighlight({ id: 'f-new', page: 1, x: 0.1, y: 0.2, width: 0.3, height: 0.05 }, { persist: false });

    const rects = useAppStore.getState().highlightIndex.get(1)!;
    const pinkRect = rects.find(r => r.id === 'dup-1');
    expect(pinkRect?.color).toBe('#ffb3c1');
  });

  it('replacing captures clears previous items', () => {
    simulateOnHighlight({ id: 'old', page: 1, x: 0.1, y: 0.2, width: 0.1, height: 0.05 }, { persist: false });
    simulateOnHighlight({ id: 'new', page: 1, x: 0.5, y: 0.6, width: 0.1, height: 0.05 }, { persist: false });

    const ids = useAppStore.getState().captures.map(c => c.id);
    expect(ids).not.toContain('old');
    expect(ids).toContain('new');
  });

  it('highlightIndex cleared for old page when navigating to new page', () => {
    simulateOnHighlight({ id: 'f1', page: 1, x: 0.1, y: 0.2, width: 0.1, height: 0.05 }, { persist: false });
    simulateOnHighlight({ id: 'f2', page: 2, x: 0.5, y: 0.6, width: 0.1, height: 0.05 }, { persist: false });

    // Page 1 should no longer have f1 (replaced)
    const page1Rects = useAppStore.getState().highlightIndex.get(1);
    const hasOldF1 = page1Rects?.some(r => r.id === 'f1');
    expect(hasOldF1).toBeFalsy();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Switching between persist modes
// ─────────────────────────────────────────────────────────────────────────────
describe('switching persist modes', () => {

  it('setPersistHighlights(true) → addCaptureWithId stores permanently', () => {
    useAppStore.getState().setPersistHighlights(true);
    expect(useAppStore.getState().persistHighlights).toBe(true);
  });

  it('setPersistHighlights(false) → store cleared to transient', () => {
    useAppStore.getState().setPersistHighlights(true);
    useAppStore.getState().setPersistHighlights(false);
    expect(useAppStore.getState().persistHighlights).toBe(false);
  });
});
