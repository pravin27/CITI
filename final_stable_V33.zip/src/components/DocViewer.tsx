// DocViewer — DOCX/DOC viewer. Renders docx-preview HTML directly.
// Zoom: sets explicit pixel widths (like PDFViewer) — no CSS transform.
// Scroll: natural browser scroll — scrollHeight reflects real content.
// Pagination: scrollTop / pageH gives current page accurately.

import React, { useEffect, useRef, useCallback, useState } from 'react';
import { useAppStore } from '../store/appStore';
import { colorToRgba } from '../utils/color';
import type { DocAdapter } from '../adapters/DocAdapter';

const RADIUS  = 2.5;
const PAD_TOP = 16;
const PAD_BOT = 40;

function rr(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  if (w < 2 || h < 2) return;
  r = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x+r,y); ctx.lineTo(x+w-r,y); ctx.arcTo(x+w,y,x+w,y+r,r);
  ctx.lineTo(x+w,y+h-r); ctx.arcTo(x+w,y+h,x+w-r,y+h,r);
  ctx.lineTo(x+r,y+h); ctx.arcTo(x,y+h,x,y+h-r,r);
  ctx.lineTo(x,y+r); ctx.arcTo(x,y,x+r,y,r);
  ctx.closePath();
}

interface DocViewerProps { adapter: DocAdapter; zoom: number; }

export function DocViewer({ adapter, zoom }: DocViewerProps) {
  const containerRef   = useRef<HTMLDivElement>(null);
  const hlCanvasRef    = useRef<HTMLCanvasElement | null>(null);
  const timerRef       = useRef<ReturnType<typeof setTimeout> | null>(null);
  const nPagesRef      = useRef(1);
  const pageHRef       = useRef(1056);
  const pageWRef       = useRef(816);
  const isScrollingRef = useRef(false); // true while scroll-to-page animation runs
  const setCurrentPage = useAppStore(s => s.setCurrentPage);
  const [mounted, setMounted] = useState(false);

  // ── Main render effect (re-runs on adapter or zoom change) ───────────────
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // ── TXT path: render canvases directly ──────────────────────────────────
    if ((adapter as any).isTxt?.()) {
      container.innerHTML = '';
      const canvases: HTMLCanvasElement[] = (adapter as any).getCanvases?.() ?? [];
      if (!canvases.length) {
        container.innerHTML = '<div style="padding:40px;color:#666;font:14px sans-serif">Empty text file.</div>';
        return;
      }
      const txtPageW = canvases[0]?.width  || 816;
      const txtPageH = canvases[0]?.height || 1056;
      const scaledTxtW = Math.round(txtPageW * zoom);
      const scaledTxtH = Math.round(txtPageH * zoom);
      pageWRef.current = txtPageW;
      pageHRef.current = txtPageH;

      const wrap = document.createElement('div');
      wrap.style.cssText = `position:relative;display:flex;flex-direction:column;align-items:center;padding:${PAD_TOP}px 0 ${PAD_BOT}px;gap:16px;`;

      canvases.forEach((canvas, i) => {
        const pageWrap = document.createElement('div');
        pageWrap.style.cssText = 'position:relative;box-shadow:0 2px 8px rgba(0,0,0,0.18);background:#fff;';
        pageWrap.dataset.pageNumber = String(i + 1);
        const scaled = document.createElement('canvas');
        scaled.width  = scaledTxtW;
        scaled.height = scaledTxtH;
        scaled.style.cssText = 'display:block;';
        const sctx = scaled.getContext('2d')!;
        sctx.scale(zoom, zoom);
        sctx.drawImage(canvas, 0, 0);
        pageWrap.appendChild(scaled);
        wrap.appendChild(pageWrap);
      });

      // Highlight overlay canvas — one canvas over all pages
      const hlCanvas = document.createElement('canvas');
      hlCanvas.width  = txtPageW;
      hlCanvas.height = txtPageH * canvases.length;
      hlCanvas.style.cssText =
        'position:absolute;top:' + PAD_TOP + 'px;left:50%;' +
        'margin-left:' + Math.round(-scaledTxtW / 2) + 'px;' +
        'width:' + scaledTxtW + 'px;' +
        'height:' + (txtPageH * canvases.length * zoom) + 'px;' +
        'pointer-events:none;z-index:10;';
      wrap.appendChild(hlCanvas);
      hlCanvasRef.current = hlCanvas;

      container.appendChild(wrap);
      nPagesRef.current = canvases.length;
      useAppStore.setState({ pageCount: canvases.length });

      // Register pages for navigation
      for (let p = 1; p <= canvases.length; p++) {
        adapter.registerPageElement?.(p, container);
        adapter.notifyPageRendered?.(p);
      }

      // Scroll → page tracking
      const onTxtScroll = () => {
        const scrolled = Math.max(0, container.scrollTop - PAD_TOP);
        const cur = Math.max(1, Math.min(canvases.length, Math.floor(scrolled / (scaledTxtH + 16)) + 1));
        setCurrentPage(cur);
      };
      container.addEventListener('scroll', onTxtScroll, { passive: true });

      setCurrentPage(1);
      setMounted(true);
      // Trigger initial highlight paint
      setTimeout(() => repaintAll(), 50);
      return;
    }

    // ── DOCX/DOC path ─────────────────────────────────────────────────────
    const host = adapter.getRenderedHost?.();
    if (!host) return;

    const htmlContent = host.innerHTML;
    if (!htmlContent || htmlContent.trim().length < 10) {
      container.innerHTML = '<div style="padding:40px;color:#666;font:14px sans-serif">Document rendered empty.</div>';
      return;
    }

    const dims  = adapter.getPageDimensions(1);
    const pageH = dims.height;   // natural page height in CSS px (e.g. 1056)
    const pageW = dims.width;    // natural page width in CSS px  (e.g. 816)
    const scaledW = Math.round(pageW * zoom);   // zoomed width in px
    const scaledH = Math.round(pageH * zoom);   // zoomed height per page
    pageHRef.current = pageH;
    pageWRef.current = pageW;

    // ── CSS injected into the HTML copy ─────────────────────────────────
    // Key: set section width to scaledW so the browser lays out content
    // at the zoomed size naturally — no transform needed, scroll works correctly.
    const css =
      '.docx-wrapper {' +
      '  background:#ffffff !important;' +
      '  padding:0 !important;' +
      '  display:block !important;' +
      '  width:' + scaledW + 'px !important;' +
      '}' +
      '.docx-wrapper > section {' +
      '  width:' + scaledW + 'px !important;' +
      '  min-height:' + scaledH + 'px !important;' +
      '  box-sizing:border-box !important;' +
      '  margin:0 auto 0 auto !important;' +
      '  box-shadow:0 2px 8px rgba(0,0,0,0.18);' +
      '  display:block !important;' +
      '  font-size:' + Math.round(zoom * 100) + '% !important;' +
      '}' +
      '.docx-wrapper section * {' +
      '  -webkit-print-color-adjust:exact !important;' +
      '  print-color-adjust:exact !important;' +
      '}';

    const styleEl = document.createElement('style');
    styleEl.textContent = css;

    // Content div — holds the docx-preview HTML
    const content = document.createElement('div');
    content.innerHTML = htmlContent;
    content.appendChild(styleEl);

    // Centring wrapper — centres content horizontally in the scroll container
    const centreWrap = document.createElement('div');
    centreWrap.style.cssText =
      'display:flex;justify-content:center;' +
      'padding:' + PAD_TOP + 'px 0 ' + PAD_BOT + 'px;' +
      'min-width:' + (scaledW + 40) + 'px;';
    centreWrap.appendChild(content);

    container.innerHTML = '';
    container.appendChild(centreWrap);
    container.style.position = 'relative';

    // Force layout reflow
    void container.offsetHeight;

    // ── Measure page count from actual rendered height ────────────────────
    const wrapperEl = container.querySelector<HTMLElement>('.docx-wrapper');
    const rawH      = Math.max(
      (wrapperEl?.scrollHeight ?? 0),
      (wrapperEl?.offsetHeight ?? 0),
      scaledH
    );
    const nPages = Math.max(1, Math.round(rawH / scaledH));
    nPagesRef.current = nPages;

    useAppStore.setState({ pageCount: nPages });

    // ── Highlight canvas ──────────────────────────────────────────────────
    // Canvas is in zoomed pixels — same coordinate space as the laid-out HTML.
    // One canvas covers all pages vertically.
    const hlCanvas = document.createElement('canvas');
    hlCanvas.width  = pageW;           // unscaled — we scale via CSS
    hlCanvas.height = pageH * nPages;  // total unscaled height
    hlCanvas.style.cssText =
      'position:absolute;' +
      'top:' + PAD_TOP + 'px;' +
      'left:50%;' +
      'margin-left:' + Math.round(-scaledW / 2) + 'px;' +
      'width:' + scaledW + 'px;' +         // CSS scaled width
      'height:' + (pageH * nPages * zoom) + 'px;' + // CSS scaled height
      'pointer-events:none;z-index:10;';
    container.appendChild(hlCanvas);
    hlCanvasRef.current = hlCanvas;

    // ── Navigate-to-page ─────────────────────────────────────────────────
    // scrolledH per page = scaledH (zoomed CSS pixels, which IS the scroll unit)
    (adapter as any).__docViewerScrollTo = (page: number) => {
      const p = Math.max(1, Math.min(nPagesRef.current, page));
      // Set flag so the scroll handler doesn't trigger another page-change
      isScrollingRef.current = true;
      container.scrollTo({
        top: PAD_TOP + (p - 1) * scaledH,
        behavior: 'smooth',
      });
      // Clear flag after scroll animation completes (smooth scroll ≈ 500ms)
      setTimeout(() => { isScrollingRef.current = false; }, 600);
    };

    for (let p = 1; p <= nPages; p++) {
      adapter.registerPageElement(p, container);
      adapter.notifyPageRendered(p);
    }

    // ── Scroll → current page ─────────────────────────────────────────────
    const onScroll = () => {
      // Mark that currentPage is about to change FROM scroll
      // so the subscription knows not to trigger another scrollTo
      isScrollingRef.current = true;
      const scrolled = Math.max(0, container.scrollTop - PAD_TOP);
      const cur = Math.max(1, Math.min(nPages, Math.floor(scrolled / scaledH) + 1));
      setCurrentPage(cur);
      // Reset after a tick — next external change will be allowed
      clearTimeout(timerRef.current ?? undefined);
      timerRef.current = setTimeout(() => { isScrollingRef.current = false; }, 150);
    };
    container.addEventListener('scroll', onScroll, { passive: true });

    setMounted(true);
    return () => container.removeEventListener('scroll', onScroll);
  }, [adapter, zoom, setCurrentPage]);

  // ── currentPage changes from toolbar Next/Prev → scroll ──────────────────
  useEffect(() => {
    const unsub = useAppStore.subscribe((n, p) => {
      // Only programmatically scroll when currentPage changes from OUTSIDE
      // (toolbar next/prev, thumbnail click). If the change came from our own
      // scroll handler, isScrollingRef.current is true — skip to avoid loop.
      if (n.currentPage !== p.currentPage && !isScrollingRef.current) {
        const fn = (adapter as any).__docViewerScrollTo;
        if (fn) fn(n.currentPage);
      }
    });
    return unsub;
  }, [adapter]);

  // ── Highlight painting ────────────────────────────────────────────────────
  const repaintAll = useCallback(() => {
    const canvas = hlCanvasRef.current;
    if (!canvas || !canvas.width || !canvas.height) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const s    = useAppStore.getState();
    const fwc  = new Map<string, string>();
    for (const c of s.captures) fwc.set(c.id, c.value.toLowerCase().trim());
    const aid  = s.activeFieldId;
    const aTxt = aid ? (fwc.get(aid) ?? '') : '';

    // Canvas coords are in natural (unscaled) page pixels.
    // Highlights use 0-1 fractions × natural page dims.
    const pageW = pageWRef.current;
    const pageH = pageHRef.current;

    for (const [pageNum, rects] of s.highlightIndex) {
      const yBase = (pageNum - 1) * pageH;
      for (const rect of rects) {
        const isAct = rect.id === aid;
        const isDup = !isAct && !!aTxt && (fwc.get(rect.id) ?? '') === aTxt;
        ctx.save();
        if (isAct) {
          ctx.shadowColor='rgba(220,180,0,.5)'; ctx.shadowBlur=8;
          ctx.fillStyle='rgba(255,230,0,.35)'; ctx.strokeStyle='rgb(200,160,0)'; ctx.lineWidth=2.5;
        } else if (isDup) {
          ctx.fillStyle='rgba(255,182,193,.5)'; ctx.strokeStyle='rgba(220,80,120,.95)'; ctx.lineWidth=2.5;
        } else if ((rect as any).type==='external') {
          ctx.fillStyle='rgba(139,92,246,.22)'; ctx.strokeStyle='rgba(139,92,246,.85)'; ctx.lineWidth=1.5;
        } else if (rect.color) {
          ctx.fillStyle=colorToRgba(rect.color,.07); ctx.strokeStyle=colorToRgba(rect.color,.95); ctx.lineWidth=2.5;
        } else {
          ctx.fillStyle='rgba(150,150,150,.10)'; ctx.strokeStyle='rgba(80,80,80,.90)'; ctx.lineWidth=2.0;
        }
        rr(ctx, rect.x*pageW, yBase+rect.y*pageH, rect.width*pageW, rect.height*pageH, RADIUS);
        ctx.fill(); ctx.stroke(); ctx.restore();
      }
    }

    if (s.previewRect) {
      const pr = s.previewRect;
      const yBase = (pr.page - 1) * pageH;
      ctx.save();
      // Yellow style — same as active capture so previewRect is always visible
      ctx.shadowColor='rgba(220,180,0,.5)'; ctx.shadowBlur=8;
      ctx.fillStyle='rgba(255,230,0,.35)'; ctx.strokeStyle='rgb(200,160,0)'; ctx.lineWidth=2.5;
      rr(ctx, pr.x*pageW, yBase+pr.y*pageH, pr.width*pageW, pr.height*pageH, RADIUS);
      ctx.fill(); ctx.stroke(); ctx.restore();
    }
  }, []);

  useEffect(() => {
    const unsub = useAppStore.subscribe((n, p) => {
      if (n.captures!==p.captures || n.activeFieldId!==p.activeFieldId ||
          n.highlightIndex!==p.highlightIndex || n.previewRect!==p.previewRect) {
        if (timerRef.current) clearTimeout(timerRef.current);
        timerRef.current = setTimeout(() => { timerRef.current=null; repaintAll(); }, 16);
      }
    });
    return () => { unsub(); if (timerRef.current) clearTimeout(timerRef.current); };
  }, [repaintAll]);

  useEffect(() => { if (mounted) repaintAll(); }, [mounted, repaintAll]);

  return (
    <div
      ref={containerRef}
      className="flex-1 overflow-y-auto overflow-x-auto bg-[#e8e8e8]"
      data-viewer-scroll="1"
      style={{ position: 'relative' }}
    />
  );
}
