// ─────────────────────────────────────────────────────────────────────────────
// DocAdapter — DOCX / DOC / TXT viewer
//
// RENDERING STRATEGY (docx-preview, direct HTML):
//   • docx-preview.renderAsync() renders OOXML into HTML with full fidelity
//   • DocViewer displays that HTML directly — NO html2canvas, NO screenshots
//   • This gives pixel-perfect rendering: colors, borders, fonts, images, tables
//   • Word positions extracted from DOM using Range.getBoundingClientRect()
//   • Click2pick and highlights work via overlay canvas on top of the HTML
//
// TXT: rendered to canvas pages as before (no HTML needed for plain text).
//
// Public interface identical to original — getPageCanvas() still works
// for thumbnails (screenshots individual sections for thumbnail renderer).
// ─────────────────────────────────────────────────────────────────────────────

import type { ViewerAdapter } from './types';

const DEFAULT_W  = 816;
const DEFAULT_H  = 1056;
const MARGIN     = 72;
const CONTENT_W  = DEFAULT_W - MARGIN * 2;
const LINES_TXT  = 52;
const LINE_H_TXT = 19;

export interface DocWordEntry {
  text:   string;
  page:   number;
  x:      number;
  y:      number;
  width:  number;
  height: number;
}

function makeCanvas(w = DEFAULT_W, h = DEFAULT_H): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, w, h);
  return [c, ctx];
}

export class DocAdapter implements ViewerAdapter {
  pageCount = 0;

  private _host:      HTMLElement | null = null;   // live docx-preview DOM
  private _sections:  HTMLElement[]      = [];     // one per docx-preview section
  private _pageDims:  Array<{width:number;height:number}> = [];
  private _wordIndex: DocWordEntry[]     = [];
  private _canvases:  HTMLCanvasElement[] = [];    // for thumbnails only
  private _pageEls    = new Map<number, HTMLElement>();
  private _rendCbs:   Array<(p: number) => void> = [];
  private _readyCbs:  Array<() => void>           = [];
  private _isReady    = false;
  private _isTxt      = false;

  // ── Public entry point ────────────────────────────────────────────────────

  async loadFile(file: File): Promise<void> {
    const ext = file.name.split('.').pop()?.toLowerCase() ?? '';
    try {
      if (ext === 'txt') {
        this._isTxt = true;
        await this._loadTxt(file);
      } else {
        await this._loadDocx(file);
      }
    } catch (err) {
      console.error('[DocAdapter] load failed:', err);
      const [c, ctx] = makeCanvas();
      ctx.font = '14px sans-serif'; ctx.fillStyle = '#cc3333';
      ctx.fillText('Failed to load document: ' + String(err), MARGIN, MARGIN + 20);
      this._canvases = [c];
      this._pageDims = [{ width: DEFAULT_W, height: DEFAULT_H }];
    }
    this.pageCount = this._isTxt ? this._canvases.length : this._sections.length;
    this._isReady  = true;
    this._readyCbs.forEach(cb => cb());
    this._readyCbs = [];
  }

  // ── Rendered HTML for DocViewer ───────────────────────────────────────────

  getRenderedHost(): HTMLElement | null { return this._host; }
  isTxt(): boolean { return this._isTxt; }
  getCanvases(): HTMLCanvasElement[] { return this._canvases; }

  getSections(): HTMLElement[] { return this._sections; }

  // ── TXT loader ────────────────────────────────────────────────────────────

  private async _loadTxt(file: File): Promise<void> {
    const text  = await file.text();
    const lines = text.split('\n');
    const chunks: string[][] = [];
    for (let i = 0; i < lines.length; i += LINES_TXT) chunks.push(lines.slice(i, i + LINES_TXT));
    if (!chunks.length) chunks.push(['']);

    this._canvases = chunks.map((chunk, pi) => {
      const [canvas, ctx] = makeCanvas(DEFAULT_W, DEFAULT_H);
      ctx.font = '13px monospace'; ctx.fillStyle = '#1a1a1a'; ctx.textBaseline = 'top';
      chunk.forEach((line, li) => {
        const y = MARGIN + li * LINE_H_TXT;
        if (y > DEFAULT_H - MARGIN) return;
        ctx.fillText(line, MARGIN, y, CONTENT_W);
        let cx = MARGIN;
        for (const w of line.split(/(\s+)/)) {
          const ww = ctx.measureText(w).width;
          if (w.trim()) this._wordIndex.push({
            text: w, page: pi + 1,
            x: cx / DEFAULT_W, y: y / DEFAULT_H,
            width: ww / DEFAULT_W, height: LINE_H_TXT / DEFAULT_H,
          });
          cx += ww;
        }
      });
      this._pageDims.push({ width: DEFAULT_W, height: DEFAULT_H });
      return canvas;
    });
  }

  // ── DOCX loader ───────────────────────────────────────────────────────────

  private async _loadDocx(file: File): Promise<void> {
    const { renderAsync } = await import('docx-preview');
    const buffer = await file.arrayBuffer();

    // Create a persistent host element — DocViewer will mount it directly
    // It lives off-screen until DocViewer mounts it into the visible container
    const host = document.createElement('div');
    host.style.cssText = 'position:fixed;top:0;left:0;opacity:0.001;pointer-events:none;z-index:-9999;background:#ffffff;';
    document.body.appendChild(host);

    await renderAsync(buffer, host, undefined, {
      className:                   'docx',
      inWrapper:                   true,
      breakPages:                  true,
      renderHeaders:               true,
      renderFooters:               true,
      renderFootnotes:             true,
      renderEndnotes:              true,
      renderComments:              false,
      ignoreLastRenderedPageBreak: false,
      useBase64URL:                true,
    });

    void host.offsetHeight;

    // Override grey wrapper background
    const wrapper = host.querySelector<HTMLElement>('.docx-wrapper');
    if (wrapper) {
      wrapper.style.background = '#ffffff';
      wrapper.style.padding    = '0';
    }

    // Gather sections — one per docx-preview page group
    let sections = Array.from(host.querySelectorAll<HTMLElement>('.docx-wrapper > section'));
    if (!sections.length) sections = [wrapper ?? host];

    this._host     = host;
    this._sections = sections;

    // Compute page dimensions and extract word positions for each section
    sections.forEach((section, i) => {
      const minHStr = section.style.minHeight || '';
      const pH = minHStr ? Math.round(parseFloat(minHStr)) : DEFAULT_H;
      const pW = section.offsetWidth || DEFAULT_W;
      // We split content into logical pages: measure real height
      section.style.overflow  = 'visible';
      section.style.minHeight = 'unset';
      section.style.height    = 'auto';
      void section.offsetHeight;
      const contentH = Math.max(section.scrollHeight || 0, section.offsetHeight || 0, pH);
      const numPages = Math.max(1, Math.ceil(contentH / pH));

      for (let p = 0; p < numPages; p++) {
        this._pageDims.push({ width: pW, height: pH });
        this._extractWords(section, this._pageDims.length, pW, pH, p * pH);
      }
      // Restore section styles — minHeight is the full page height from pgSz.
      // This must be restored so the innerHTML copy retains the full page dimensions.
      section.style.overflow  = '';
      section.style.height    = '';
      section.style.minHeight = pH + 'px';  // restore declared page height
    });

    // Keep host in DOM (off-screen at opacity:0.001) so sections retain layout.
    // DocViewer will extract the content and re-mount it in the visible container.
    // host is removed in dispose().
    this._host = host; // store reference for dispose()
  }

  // ── Word position extraction ───────────────────────────────────────────────

  private _extractWords(section: HTMLElement, pageNum: number, W: number, H: number, yOffset = 0): void {
    if (!W || !H) return;
    const walker = document.createTreeWalker(section, NodeFilter.SHOW_TEXT, {
      acceptNode: (node) => {
        const p = node.parentElement;
        if (!p) return NodeFilter.FILTER_REJECT;
        const t = p.tagName.toLowerCase();
        if (t === 'script' || t === 'style') return NodeFilter.FILTER_REJECT;
        if (!node.textContent?.trim()) return NodeFilter.FILTER_SKIP;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    const range = document.createRange();
    let node: Text | null;
    while ((node = walker.nextNode() as Text | null)) {
      const text = node.textContent ?? '';
      const words = text.split(/\s+/).filter(w => w.length > 0);
      let charOffset = 0;
      for (const word of words) {
        const wordStart = text.indexOf(word, charOffset);
        if (wordStart < 0) { charOffset += word.length; continue; }
        try {
          range.setStart(node, wordStart);
          range.setEnd(node, wordStart + word.length);
          const rect = range.getBoundingClientRect();
          const sectionRect = section.getBoundingClientRect();
          const xPx = rect.left - sectionRect.left;
          const yPx = rect.top  - sectionRect.top;
          if (yPx < yOffset || yPx > yOffset + H) { charOffset = wordStart + word.length; continue; }
          if (rect.width > 0 && rect.height > 0) {
            const x = xPx / W, y = (yPx - yOffset) / H;
            const w = rect.width / W, h = rect.height / H;
            if (x >= 0 && y >= 0) {
              this._wordIndex.push({
                text: word, page: pageNum,
                x: Math.max(0, x), y: Math.max(0, y),
                width: Math.min(1 - x, w), height: Math.min(1 - y, h),
              });
            }
          }
        } catch (_) {}
        charOffset = wordStart + word.length;
      }
    }
  }

  // ── Thumbnail canvas (screenshots sections for thumbnail sidebar) ──────────

  async buildThumbnailCanvas(page: number): Promise<HTMLCanvasElement | null> {
    if (this._isTxt) return this._canvases[page - 1] ?? null;
    if (!this._sections.length) return null;

    // Find which section+offset this page belongs to
    let sectionIdx = 0, pageOffset = 0, acc = 0;
    for (let i = 0; i < this._sections.length; i++) {
      const s = this._sections[i];
      const pH = this._pageDims[acc]?.height || DEFAULT_H;
      const pW = this._pageDims[acc]?.width  || DEFAULT_W;
      const contentH = Math.max(s.scrollHeight || 0, s.offsetHeight || 0, pH);
      const num = Math.max(1, Math.ceil(contentH / pH));
      if (acc + num > page - 1) { sectionIdx = i; pageOffset = page - 1 - acc; break; }
      acc += num;
    }

    // Simple canvas thumbnail — just white with page number for now
    // Real thumbnail would require html2canvas which we've abandoned
    const [c, ctx] = makeCanvas(DEFAULT_W, DEFAULT_H);
    ctx.font = '16px sans-serif'; ctx.fillStyle = '#666';
    ctx.fillText(`Page ${page}`, DEFAULT_W / 2 - 30, DEFAULT_H / 2);
    return c;
  }

  // ── ViewerAdapter implementation ──────────────────────────────────────────

  getWordIndex(): DocWordEntry[] { return this._wordIndex; }

  getPageDimensions(page: number) {
    return this._pageDims[page - 1] ?? { width: DEFAULT_W, height: DEFAULT_H };
  }

  getPageCanvas(page: number): HTMLCanvasElement | null {
    if (this._isTxt) return this._canvases[page - 1] ?? null;
    // For DOCX thumbnails: return cached or null (thumbnail renderer handles fallback)
    return this._canvases[page - 1] ?? null;
  }

  navigateToPage(page: number): void {
    // DocViewer attaches a scroll helper directly — use it when available
    // (it accounts for zoom and scaler padding correctly)
    const scrollFn = (this as any).__docViewerScrollTo;
    if (scrollFn) { scrollFn(page); return; }
    // Fallback for non-DocViewer contexts
    const el = this._pageEls.get(page);
    if (!el) return;
    const sc = el.closest('[data-viewer-scroll]') as HTMLElement | null;
    if (sc) sc.scrollTop = el.getBoundingClientRect().top - sc.getBoundingClientRect().top + sc.scrollTop - 8;
    else el.scrollIntoView({ behavior: 'instant' as ScrollBehavior, block: 'start' });
  }

  registerPageElement(page: number, el: HTMLElement | null) {
    if (el) this._pageEls.set(page, el); else this._pageEls.delete(page);
  }

  getPageElement(page: number): HTMLElement | null { return this._pageEls.get(page) ?? null; }
  getRenderedPages(): Set<number> { return new Set(this._pageEls.keys()); }
  notifyPageRendered(page: number) { this._rendCbs.forEach(cb => cb(page)); }
  onReady(cb: () => void)          { if (this._isReady) cb(); else this._readyCbs.push(cb); }
  onPageRendered(cb: (p:number) => void)  { this._rendCbs.push(cb); }
  offPageRendered(cb: (p:number) => void) {
    const i = this._rendCbs.indexOf(cb); if (i !== -1) this._rendCbs.splice(i, 1);
  }

  dispose() {
    if (this._host && this._host.parentElement) {
      try { this._host.parentElement.removeChild(this._host); } catch (_) {}
    }
    this._host = null; this._sections = []; this._canvases = [];
    this._wordIndex = []; this._pageDims = []; this._pageEls.clear();
    this._rendCbs = []; this._readyCbs = []; this._isReady = false; this.pageCount = 0;
  }
}
