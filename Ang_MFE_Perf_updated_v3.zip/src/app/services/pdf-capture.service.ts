import { Injectable, signal, computed } from '@angular/core';
import {
  InputField,
  WordCoordinate,
  HighlightRect,
} from '../models/pdf-capture.models';

@Injectable({ providedIn: 'root' })
export class PdfCaptureService {

  // ── Signals ────────────────────────────────────────────────────────────────
  readonly fields        = signal<InputField[]>([]);
  readonly activeFieldId = signal<string | null>(null);
  readonly externalCoords= signal<WordCoordinate[]>([]);
  readonly click2pickMode= signal<boolean>(false);

  // ── Pre-indexed highlights: Map<pageNum, HighlightRect[]> ─────────────────
  // Rebuilt only when fields / externalCoords change — O(n) once, then O(1) per page.
  readonly highlightIndex = computed<Map<number, HighlightRect[]>>(() => {
    const index  = new Map<number, HighlightRect[]>();
    const fields = this.fields();
    const ext    = this.externalCoords();

    const add = (page: number, rect: HighlightRect) => {
      let arr = index.get(page);
      if (!arr) { arr = []; index.set(page, arr); }
      arr.push(rect);
    };

    // External coords
    for (const c of ext) {
      add(c.page, {
        page: c.page, x: c.x, y: c.y, width: c.width, height: c.height,
        type: 'external', label: c.text,
      });
    }

    // Field captures — only fields that have a captured word
    for (const f of fields) {
      if (!f.capturedWord) continue;
      const cw = f.capturedWord;
      add(cw.page, {
        page: cw.page, x: cw.x, y: cw.y, width: cw.width, height: cw.height,
        type: 'primary', fieldId: f.id, label: f.label,
      });
    }

    return index;
  });

  // ── Quick lookup: fieldId → captured word text (lower-case) ───────────────
  // Used by the viewer's draw loop to avoid O(n) field.find() per highlight.
  readonly fieldTextIndex = computed<Map<string, string>>(() => {
    const m = new Map<string, string>();
    for (const f of this.fields()) {
      if (f.capturedWord) m.set(f.id, f.capturedWord.text.toLowerCase());
    }
    return m;
  });

  // ── Active word text (derived, no extra subscription needed) ──────────────
  readonly activeWordText = computed<string | null>(() => {
    const id = this.activeFieldId();
    if (!id) return null;
    const f = this.fields().find(f => f.id === id);
    return f?.capturedWord?.text?.toLowerCase() ?? null;
  });

  // Legacy: allHighlights as flat array (kept for any external consumers)
  readonly allHighlights = computed<HighlightRect[]>(() => {
    const all: HighlightRect[] = [];
    this.highlightIndex().forEach(rects => all.push(...rects));
    return all;
  });

  // ── O(1) page lookup ──────────────────────────────────────────────────────
  getHighlightsForPage(page: number): HighlightRect[] {
    return this.highlightIndex().get(page) ?? [];
  }

  // ── Field Management ───────────────────────────────────────────────────────
  initFields(fields: InputField[]) {
    this.fields.set(fields);
  }

  setActiveField(fieldId: string | null) {
    this.activeFieldId.set(fieldId);
  }

  getActiveField(): InputField | null {
    const id = this.activeFieldId();
    return this.fields().find(f => f.id === id) ?? null;
  }

  captureWordToActiveField(word: {
    text: string; page: number;
    x: number; y: number; width: number; height: number;
  }) {
    const id = this.activeFieldId();
    if (!id) return;
    this.fields.update(fields =>
      fields.map(f => f.id !== id ? f : {
        ...f, value: word.text,
        capturedWord: { ...word, fieldId: id },
      })
    );
  }

  clearField(fieldId: string) {
    this.fields.update(fields =>
      fields.map(f => f.id !== fieldId ? f : { ...f, value: '', capturedWord: null })
    );
  }

  updateFieldValue(fieldId: string, value: string) {
    this.fields.update(fields =>
      fields.map(f => f.id === fieldId ? { ...f, value } : f)
    );
  }

  // ── External Coordinates ──────────────────────────────────────────────────
  loadExternalCoordinates(coords: WordCoordinate[]) {
    this.externalCoords.set(coords);
  }

  // ── Click2Pick Mode ───────────────────────────────────────────────────────
  toggleClick2PickMode() { this.click2pickMode.update(v => !v); }
  setClick2PickMode(on: boolean) { this.click2pickMode.set(on); }
}