/**
 * All x, y, width, height values are stored as FRACTIONS (0–1) of the
 * page's rendered dimensions.  This makes them zoom-independent.
 *
 * To convert to canvas pixels at draw time:
 *   canvasX = x * canvas.width
 *   canvasY = y * canvas.height
 *
 * To convert from an external pixel coordinate system (e.g. PDF points):
 *   x_frac = x_px / pageWidthPx
 *   y_frac = y_px / pageHeightPx
 */

export interface WordCoordinate {
  id: string;
  text: string;
  page: number;
  /** Fractional left position (0–1) relative to rendered page width */
  x: number;
  /** Fractional top position (0–1) relative to rendered page height */
  y: number;
  /** Fractional width (0–1) relative to rendered page width */
  width: number;
  /** Fractional height (0–1) relative to rendered page height */
  height: number;
}

export interface InputField {
  id: string;
  label: string;
  value: string;
  capturedWord: CapturedWord | null;
  isFocused: boolean;
}

export interface CapturedWord {
  text: string;
  page: number;
  /** All coords are 0–1 fractions of page size — zoom-independent */
  x: number;
  y: number;
  width: number;
  height: number;
  fieldId: string;
}

export interface HighlightRect {
  page: number;
  /** 0–1 fraction coords stored in service; multiplied by canvas size at draw time */
  x: number;
  y: number;
  width: number;
  height: number;
  type: 'primary' | 'duplicate' | 'external';
  fieldId?: string;
  label?: string;
}

export type HighlightMode = 'click2pick' | 'field-focus' | 'external';