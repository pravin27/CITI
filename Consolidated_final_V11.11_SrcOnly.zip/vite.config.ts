import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [react(), tailwindcss()],
  optimizeDeps: {
    exclude: ['pdfjs-dist'],
  },
  worker: { format: 'es' },
  build: {
    rollupOptions: {
      external: [],
    }
  },
  // Long-lived cache headers for static PDF.js resources (fonts, cmaps, worker)
  // These files are versioned/content-addressed so max-age=1year is safe.
  // This eliminates per-page network round-trips for font/cmap fetches.
  server: {
    headers: {
      'Cache-Control': 'public, max-age=31536000, immutable',
    },
  },
  preview: {
    headers: {
      'Cache-Control': 'public, max-age=31536000, immutable',
    },
  },
})
