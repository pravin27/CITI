// ─────────────────────────────────────────────────────────────────────────────
// COORDINATE NORMALISATION
//
// Internal storage: always 0–1 fractions of page dimensions.
//
// Input coordinates can arrive in ANY unit:
//   • 0–1 fractions        (already normalised — pass through)
//   • PDF points           (A4=595×842, Letter=612×792, …)
//   • Inches               (A4=8.27×11.69, Letter=8.5×11, …)
//   • Centimetres          (A4=21×29.7, Letter=21.59×27.94, …)
//   • Pixels at 72dpi      (same as points)
//   • Pixels at 96dpi      (A4=794×1123, Letter=816×1056, …)
//   • Pixels at 150dpi     (A4=1240×1754, Letter=1275×1650, …)
//   • Pixels at 200dpi     (A4=1654×2339, Letter=1700×2200, …)
//   • Pixels at 300dpi     (A4=2480×3508, Letter=2550×3300, …)
//
// Priority chain for page dimensions:
//   1. Per-item pageWidth/page_width + pageHeight/page_height
//   2. Adapter real dimensions (from rendered page)
//   3. Batch per-page max extent (from normaliseBatch — most accurate for abs)
//   4. Multi-table standard size lookup (pts, inches, cm, px@96, px@150, px@300)
//   5. Per-page max extent used directly (fallback when no standard matches)
// ─────────────────────────────────────────────────────────────────────────────

import type { ViewerAdapter } from '../adapters/types';

// ── Standard page size tables ─────────────────────────────────────────────────
// Each entry: [width, height, label] — width < height (portrait orientation).
// Landscape handled by swapping w/h in the lookup.

// PDF points (1pt = 1/72 inch)
const PAGE_SIZES_PTS: [number, number][] = [
  [595,  842],   // A4
  [612,  792],   // Letter
  [612, 1008],   // Legal
  [842, 1191],   // A3
  [792, 1224],   // Tabloid
  [499,  709],   // A5
  [420,  595],   // A6
  [684,  864],   // Executive
  [522,  756],   // Half Letter
];

// Inches (1pt = 1/72 in → page width in inches)
const PAGE_SIZES_IN: [number, number][] = [
  [8.27,  11.69],  // A4
  [8.5,   11.0],   // Letter
  [8.5,   14.0],   // Legal
  [11.69, 16.54],  // A3
  [11.0,  17.0],   // Tabloid
  [5.83,   8.27],  // A5
  [4.13,   5.83],  // A6
  [7.25,   10.5],  // Executive
  [5.5,    8.5],   // Half Letter
];

// Centimetres
const PAGE_SIZES_CM: [number, number][] = [
  [21.0,   29.7],   // A4
  [21.59,  27.94],  // Letter
  [21.59,  35.56],  // Legal
  [29.7,   42.0],   // A3
  [27.94,  43.18],  // Tabloid
  [14.8,   21.0],   // A5
  [10.5,   14.8],   // A6
  [18.41,  26.67],  // Executive
  [13.97,  21.59],  // Half Letter
];

// Pixels at common DPIs — generated from pts table
function pxTable(dpi: number): [number, number][] {
  return PAGE_SIZES_PTS.map(([w, h]) => [
    Math.round(w * dpi / 72),
    Math.round(h * dpi / 72),
  ]);
}

const PAGE_SIZES_PX96  = pxTable(96);   // screen resolution
const PAGE_SIZES_PX150 = pxTable(150);  // low scan
const PAGE_SIZES_PX200 = pxTable(200);  // medium scan
const PAGE_SIZES_PX300 = pxTable(300);  // high-quality scan
const PAGE_SIZES_PX600 = pxTable(600);  // archival scan

// All tables — pts first (most common), then increasing pixel densities, then real-world units.
// Each table is tried in order; first match wins for that coordinate range.
const ALL_TABLES = [
  PAGE_SIZES_PTS,   // PDF points (595,842 etc) — most common source
  PAGE_SIZES_PX96,  // screen pixels
  PAGE_SIZES_PX150, // low-res scan
  PAGE_SIZES_PX200, // medium scan
  PAGE_SIZES_PX300, // high-res scan
  PAGE_SIZES_PX600, // archival scan
  PAGE_SIZES_IN,    // inches (small values: 8.5, 11)
  PAGE_SIZES_CM,    // centimetres (21, 29.7)
];

// ── Page size inference ───────────────────────────────────────────────────────
// Given the maximum x+w and y+h observed across all items on a page,
// find the standard page size that best fits (with 8% tolerance).
// Checks both portrait and landscape orientations.
// Returns null if no standard size matches — caller falls back to max-extent directly.
export function inferPageSizeFromAbsCoords(
  maxX: number, maxY: number,
): { width: number; height: number } | null {
  const TOL = 0.05; // 5% tolerance — tight enough to distinguish Letter vs A4

  for (const table of ALL_TABLES) {
    for (const [w, h] of table) {
      // Portrait
      if (maxX <= w * (1 + TOL) && maxY <= h * (1 + TOL) &&
          maxX >= w * (1 - TOL) && maxY >= h * (1 - TOL)) {
        return { width: w, height: h };
      }
      // Landscape
      if (maxX <= h * (1 + TOL) && maxY <= w * (1 + TOL) &&
          maxX >= h * (1 - TOL) && maxY >= w * (1 - TOL)) {
        return { width: h, height: w };
      }
    }
  }
  return null;
}

// Looser inference: just find the smallest standard size that contains the coords.
// Used as a second-pass fallback when tight inference fails.
function inferPageSizeLoose(
  maxX: number, maxY: number,
): { width: number; height: number } | null {
  for (const table of ALL_TABLES) {
    for (const [w, h] of table) {
      if (maxX <= w * 1.15 && maxY <= h * 1.15) return { width: w, height: h };
      if (maxX <= h * 1.15 && maxY <= w * 1.15) return { width: h, height: w };
    }
  }
  return null;
}

// ── Coordinate extraction ─────────────────────────────────────────────────────

/**
 * Extract raw [x, y, w, h] from any supported coordinate format.
 * Returns raw values — may be absolute (pts/inches/cm/px) or 0–1 fractions.
 *
 * FORMAT 1 — flat:          {x, y, width|w, height|h}
 * FORMAT 2 — bbox:          {bbox: [x, y, w, h]}
 * FORMAT 3 — rectangle w/h: {rectangle: [x, y, w, h]}
 * FORMAT 4 — rectangle pts: {rectangle: [x1, y1, x2, y2]}
 * FORMAT 5 — coordinates:   {coordinates: [ymin, xmin, ymax, xmax]}
 * FORMAT 6 — flat min/max:  {xmin, ymin, xmax, ymax}
 * FORMAT 7 — bbox_relative: {bbox_relative: [[x,y],[x,y],[x,y],[x,y]]}
 */
export function extractRawCoords(
  item: Record<string, unknown>
): [number, number, number, number] | null {

  // FORMAT 1 — flat
  if (typeof item.x === 'number' && typeof item.y === 'number' &&
      (typeof item.width === 'number' || typeof item.w === 'number') &&
      (typeof item.height === 'number' || typeof item.h === 'number')) {
    return [item.x, item.y,
            (item.width ?? item.w) as number,
            (item.height ?? item.h) as number];
  }

  // FORMAT 6 — flat min/max
  if (typeof item.xmin === 'number' && typeof item.ymin === 'number' &&
      typeof item.xmax === 'number' && typeof item.ymax === 'number') {
    const x = item.xmin as number, y = item.ymin as number;
    return [x, y, (item.xmax as number) - x, (item.ymax as number) - y];
  }

  // FORMAT 2 — bbox array
  if (Array.isArray(item.bbox) && item.bbox.length >= 4) {
    const [a, b, c, d] = item.bbox as number[];
    return [a, b, c, d];
  }

  // FORMAT 3 / 4 — rectangle
  if (Array.isArray(item.rectangle) && item.rectangle.length >= 4) {
    const [a, b, c, d] = item.rectangle as number[];
    // Detect corner-point form: c > a AND d > b AND any value > 1 (not all fractional)
    if (c > a && d > b && (a > 1 || b > 1 || c > 1 || d > 1)) {
      return [a, b, c - a, d - b]; // FORMAT 4
    }
    return [a, b, c, d]; // FORMAT 3
  }

  // FORMAT 5 — coordinates [ymin, xmin, ymax, xmax]
  if (Array.isArray(item.coordinates) && item.coordinates.length >= 4) {
    const [ymin, xmin, ymax, xmax] = item.coordinates as number[];
    return [xmin, ymin, xmax - xmin, ymax - ymin];
  }

  // FORMAT 7 — bbox_relative polygon corners → AABB
  if (Array.isArray(item.bbox_relative) && item.bbox_relative.length >= 3) {
    const pts = item.bbox_relative as [number, number][];
    if (pts.every(p => Array.isArray(p) && p.length >= 2 &&
        typeof p[0] === 'number' && typeof p[1] === 'number')) {
      const xs = pts.map(p => p[0]);
      const ys = pts.map(p => p[1]);
      const minX = Math.min(...xs), maxX = Math.max(...xs);
      const minY = Math.min(...ys), maxY = Math.max(...ys);
      return [minX, minY, maxX - minX, maxY - minY];
    }
  }

  return null;
}

// ── Core normaliser ───────────────────────────────────────────────────────────

/**
 * Normalise raw [x, y, w, h] to 0–1 fractions.
 *
 * Priority for page dimensions:
 *   1. item.pageWidth/page_width + pageHeight/page_height
 *   2. adapter.getPageDimensions(page)
 *   3. batchInferredSize (computed by normaliseBatch from all items on the page)
 *   4. Standard size lookup (tight 8% tolerance, then loose 15%)
 *   5. Raw max extent passed as batchInferredSize when no standard matches
 */
export function normaliseCoords(
  raw: [number, number, number, number],
  item: Record<string, unknown>,
  page: number,
  adapter?: ViewerAdapter | null,
  batchInferredSize?: { width: number; height: number } | null,
): [number, number, number, number] {
  const [x, y, w, h] = raw;

  // ── Already fractional (all values 0–1) ──────────────────────────────────
  if (x >= 0 && x <= 1 && y >= 0 && y <= 1 &&
      w >= 0 && w <= 1 && h >= 0 && h <= 1) {
    return clamp4([x, y, w, h]);
  }

  // ── Need page dimensions ─────────────────────────────────────────────────

  // Priority 1: explicit per-item page dims
  let pw: number | undefined;
  let ph: number | undefined;
  if (typeof item.pageWidth   === 'number') pw = item.pageWidth as number;
  if (typeof item.page_width  === 'number') pw = item.page_width as number;
  if (typeof item.pageHeight  === 'number') ph = item.pageHeight as number;
  if (typeof item.page_height === 'number') ph = item.page_height as number;
  if (pw && ph) return clamp4([x/pw, y/ph, w/pw, h/ph]);

  // Priority 2: adapter real dimensions
  if (adapter) {
    const dims = adapter.getPageDimensions(page);
    if (dims?.width && dims?.height) {
      // Adapter gives PDF points — check units match
      // If raw values are << adapter dims, this is the right space
      if (x <= dims.width * 1.1 && y <= dims.height * 1.1) {
        return clamp4([x/dims.width, y/dims.height, w/dims.width, h/dims.height]);
      }
    }
  }

  // Priority 3: batch-inferred size (from normaliseBatch or Format A two-pass)
  if (batchInferredSize?.width && batchInferredSize?.height) {
    return clamp4([
      x / batchInferredSize.width,
      y / batchInferredSize.height,
      w / batchInferredSize.width,
      h / batchInferredSize.height,
    ]);
  }

  // Priority 4: standard size lookup (tight, then loose)
  const maxX = x + w, maxY = y + h;
  const tight = inferPageSizeFromAbsCoords(maxX, maxY);
  if (tight) return clamp4([x/tight.width, y/tight.height, w/tight.width, h/tight.height]);

  const loose = inferPageSizeLoose(maxX, maxY);
  if (loose) return clamp4([x/loose.width, y/loose.height, w/loose.width, h/loose.height]);

  // Priority 5: use max extent as page dims (last resort for single items)
  // Handles exotic coordinate systems — imprecise for single items but better than clamp
  if (maxX > 1 || maxY > 1) {
    const pw2 = maxX > 1 ? maxX : 1;
    const ph2 = maxY > 1 ? maxY : 1;
    return clamp4([x/pw2, y/ph2, w/pw2, h/ph2]);
  }

  return clamp4([x, y, w, h]);
}

function clamp4([x, y, w, h]: [number,number,number,number]): [number,number,number,number] {
  const c = (v: number) => Math.max(0, Math.min(1, v));
  return [c(x), c(y), c(w), c(h)];
}

// ── Batch normaliser ──────────────────────────────────────────────────────────

/**
 * Two-pass O(n) normalisation for an array of items (Format B word_index).
 *
 * Pass 1: compute per-page max extent from all absolute-coord items.
 *         This gives the best estimate of page dimensions in the source unit.
 * Pass 2: normalise every entry using:
 *         a) Standard size lookup (tight → loose)
 *         b) Raw max extent when no standard matches (inch/cm/exotic systems)
 */
export function normaliseBatch(
  items: Record<string, unknown>[],
  getPage: (item: Record<string, unknown>) => number,
  adapter?: ViewerAdapter | null,
): Array<{ raw: Record<string, unknown>; coords: [number,number,number,number] | null }> {

  // Pass 1 — per-page max extent across all non-fractional items
  const pageMaxExtent = new Map<number, { maxX: number; maxY: number }>();
  for (const item of items) {
    const raw = extractRawCoords(item);
    if (!raw) continue;
    const [x, y, w, h] = raw;
    if (x >= 0 && x <= 1 && y >= 0 && y <= 1 && w <= 1 && h <= 1) continue;
    const pg = getPage(item);
    const cur = pageMaxExtent.get(pg) ?? { maxX: 0, maxY: 0 };
    pageMaxExtent.set(pg, {
      maxX: Math.max(cur.maxX, x + w),
      maxY: Math.max(cur.maxY, y + h),
    });
  }

  // Resolve per-page inferred size: tight standard → loose standard → raw extent
  const resolvedSizes = new Map<number, { width: number; height: number } | null>();
  for (const [pg, { maxX, maxY }] of pageMaxExtent) {
    const tight = inferPageSizeFromAbsCoords(maxX, maxY);
    if (tight) { resolvedSizes.set(pg, tight); continue; }
    const loose = inferPageSizeLoose(maxX, maxY);
    if (loose) { resolvedSizes.set(pg, loose); continue; }
    // No standard match — use max extent directly (e.g. inch coords with few entries)
    resolvedSizes.set(pg, maxX > 1 || maxY > 1 ? { width: maxX, height: maxY } : null);
  }

  // Pass 2 — normalise each item
  return items.map(item => {
    const raw = extractRawCoords(item);
    if (!raw) return { raw: item, coords: null };
    const pg = getPage(item);
    return {
      raw: item,
      coords: normaliseCoords(raw, item, pg, adapter, resolvedSizes.get(pg) ?? null),
    };
  });
}
