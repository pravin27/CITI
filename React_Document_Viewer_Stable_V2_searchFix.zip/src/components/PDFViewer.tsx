// ─────────────────────────────────────────────────────────────────────────────
// PDFViewer — native pdfjs-dist engine
//
// HIGHLIGHT STRATEGY (final, correct approach):
//   Highlights are drawn INSIDE the pdfjs 'pagerendered' event handler.
//   At that moment we have:
//     • pv.div       — the page DOM element (guaranteed live)
//     • pv.viewport  — real CSS pixel dimensions (no clientWidth needed)
//     • pv.canvas    — the rendered pdfjs canvas (guaranteed painted)
//   We create one overlay <canvas> per page div and draw into it immediately.
//   When pdfjs re-renders a page (zoom, scroll-back), pagerendered fires again
//   and we re-draw — highlights always match the current page state.
//
//   Store changes (new capture, active field change) → drawAllVisible()
//   which re-draws all currently rendered pages by iterating pdfjs page views.
// ─────────────────────────────────────────────────────────────────────────────

import React, { useEffect, useRef } from 'react';
import * as pdfjsLib from 'pdfjs-dist';
import {
  EventBus, PDFViewer as PdfjsPDFViewer,
  PDFLinkService, PDFFindController,
} from 'pdfjs-dist/web/pdf_viewer.mjs';
import { useAppStore } from '../store/appStore';
import type { PDFAdapter } from '../adapters/PDFAdapter';
import { colorToRgba, stripPunct } from '../utils/color';
import type { CaptureItem, WordEntry } from '../adapters/types';

// ── pdfjs setup ───────────────────────────────────────────────────────────────
if (typeof document !== 'undefined' && !document.getElementById('pdfjs-viewer-css')) {
  const link = document.createElement('link');
  link.id = 'pdfjs-viewer-css'; link.rel = 'stylesheet'; link.href = '/pdf_viewer.css';
  document.head.appendChild(link);
}
pdfjsLib.GlobalWorkerOptions.workerSrc = '/pdf.worker.min.mjs';
const MAX_CANVAS_PIXELS = 4_194_304;

// ── CSS pulse animation ───────────────────────────────────────────────────────
let _cssInjected = false;
function injectPulseCSS() {
  if (_cssInjected || typeof document === 'undefined') return;
  _cssInjected = true;
  const s = document.createElement('style');
  s.textContent = `
    @keyframes tov-pulse{0%,100%{opacity:.3;box-shadow:0 0 6px 2px rgba(6,182,212,.4);}50%{opacity:.6;box-shadow:0 0 14px 5px rgba(6,182,212,.7);}}
    .tov-pulse-box{position:absolute;border-radius:3px;pointer-events:none;z-index:20;
      border:2px solid rgba(6,182,212,.9);background:rgba(6,182,212,.12);
      animation:tov-pulse 1.2s ease-in-out infinite;}
  `;
  document.head.appendChild(s);
}

// ── Core drawing ──────────────────────────────────────────────────────────────
const RADIUS = 2.5;
type Ctx2D = CanvasRenderingContext2D;

function rr(ctx: Ctx2D, x: number, y: number, w: number, h: number, r: number) {
  if (w < 1 || h < 1) return;
  r = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x+r,y); ctx.lineTo(x+w-r,y); ctx.arcTo(x+w,y,x+w,y+r,r);
  ctx.lineTo(x+w,y+h-r); ctx.arcTo(x+w,y+h,x+w-r,y+h,r);
  ctx.lineTo(x+r,y+h); ctx.arcTo(x,y+h,x,y+h-r,r);
  ctx.lineTo(x,y+r); ctx.arcTo(x,y,x+r,y,r); ctx.closePath();
}

interface DrawState {
  captures:       CaptureItem[];
  activeFieldId:  string | null;
  highlightIndex: Map<number, Array<{x:number;y:number;width:number;height:number;id:string;color?:string;type?:'external'}>>;
  wordIndex:      Map<number, WordEntry[]>;
  previewRect:    {page:number;x:number;y:number;width:number;height:number} | null;
  searchResults:  Array<{page:number;x:number;y:number;width:number;height:number}>;
  searchCurrent:  number;
  searchHighAll:  boolean;
}

interface DrawCaches {
  fwc:    Map<string,string>;          // fieldId → stripped word
  cgc:    Array<{fill:string;stroke:string;ids:string[]}>;
  l3c:    Map<number,Map<string,Array<{x:number;y:number;w:number;h:number}>>>;
  awt:    string;                      // active field word text
  l3Key:  string;
}

function rebuildCaches(ds: DrawState, caches: DrawCaches) {
  const k = ds.captures.map(c=>`${c.id}:${c.value}:${c.color??''}`).sort().join('|');
  if (k !== caches.l3Key) {
    caches.l3Key = k;
    caches.fwc.clear();
    for (const c of ds.captures) caches.fwc.set(c.id, stripPunct(c.value));
    caches.l3c.clear();
    if (ds.wordIndex.size > 0) {
      const watch = new Set<string>();
      for (const wt of caches.fwc.values()) if (wt) watch.add(wt);
      for (const [pg, entries] of ds.wordIndex) {
        const pm = new Map<string,Array<{x:number;y:number;w:number;h:number}>>();
        for (const e of entries) {
          const wt = stripPunct(e.text); if (!watch.has(wt)) continue;
          if (!pm.has(wt)) pm.set(wt, []);
          pm.get(wt)!.push({x:e.x,y:e.y,w:e.width,h:e.height});
        }
        if (pm.size) caches.l3c.set(pg, pm);
      }
    }
  }
  // Always rebuild color groups (active field changes need this)
  const groups = new Map<string,{fill:string;stroke:string;ids:string[]}>();
  for (const c of ds.captures) {
    if (c.id === ds.activeFieldId) continue;
    const key = c.color ?? '__default__';
    if (!groups.has(key)) groups.set(key, {
      fill:   c.color ? colorToRgba(c.color, .18) : 'rgba(150,150,150,.18)',
      stroke: c.color ?? 'rgba(120,120,120,.70)', ids: [],
    });
    groups.get(key)!.ids.push(c.id);
  }
  caches.cgc = Array.from(groups.values());
  caches.awt = ds.activeFieldId ? (caches.fwc.get(ds.activeFieldId) ?? '') : '';
}

// Draw highlights onto a canvas.
// W, H = CSS display pixels (from pdfjs viewport — correct coordinate space)
function paintPage(ctx: Ctx2D, W: number, H: number, page: number,
  ds: DrawState, caches: DrawCaches) {
  ctx.clearRect(0, 0, W, H);

  const rects  = ds.highlightIndex.get(page) ?? [];
  const aid    = ds.activeFieldId;
  const aTxt   = aid ? (caches.fwc.get(aid) ?? '') : '';
  const hasWI  = ds.wordIndex.size > 0;

  // Search highlights
  const sr = ds.searchResults.filter(r => r.page === page);
  for (let i = 0; i < sr.length; i++) {
    const r = sr[i];
    const isCur = ds.searchResults.indexOf(r) === ds.searchCurrent;
    ctx.save();
    if (isCur) {
      ctx.fillStyle='rgba(255,140,0,.45)'; ctx.strokeStyle='rgba(255,100,0,.95)';
      ctx.lineWidth=2; ctx.shadowColor='rgba(255,140,0,.5)'; ctx.shadowBlur=6;
    } else if (ds.searchHighAll) {
      ctx.fillStyle='rgba(255,220,50,.28)'; ctx.strokeStyle='rgba(200,160,0,.65)'; ctx.lineWidth=1;
    } else { ctx.restore(); continue; }
    rr(ctx, r.x*W, r.y*H, r.width*W, r.height*H, RADIUS);
    ctx.fill(); ctx.stroke(); ctx.restore();
  }

  // Captured boxes
  for (const rect of rects) {
    const isAct = rect.id === aid;
    const isDup = !isAct && !!aTxt && (caches.fwc.get(rect.id)??'') === aTxt;
    ctx.save();
    if (isAct) {
      ctx.shadowColor='rgba(220,180,0,.5)'; ctx.shadowBlur=8;
      ctx.fillStyle='rgba(255,230,0,.35)'; ctx.strokeStyle='rgb(200,160,0)'; ctx.lineWidth=2.5;
    } else if (isDup) {
      ctx.fillStyle='rgba(255,182,193,.4)'; ctx.strokeStyle='rgba(220,80,120,.85)'; ctx.lineWidth=2;
    } else if (rect.type==='external') {
      ctx.fillStyle='rgba(139,92,246,.22)'; ctx.strokeStyle='rgba(139,92,246,.85)'; ctx.lineWidth=1.5;
    } else if (rect.color) {
      ctx.fillStyle=colorToRgba(rect.color,.20); ctx.strokeStyle=rect.color; ctx.lineWidth=1.5;
    } else {
      ctx.fillStyle='rgba(150,150,150,.18)'; ctx.strokeStyle='rgba(120,120,120,.70)'; ctx.lineWidth=1.5;
    }
    rr(ctx, rect.x*W, rect.y*H, rect.width*W, rect.height*H, RADIUS);
    ctx.fill(); ctx.stroke(); ctx.restore();
  }

  // Word occurrences (word index mode)
  if (!hasWI || !aid) return;
  const skip = new Set<number>();
  for (const r of rects) skip.add(Math.round(r.x*1000)*10000+Math.round(r.y*1000));
  const pl3 = caches.l3c.get(page);
  const occ = (wt:string, fill:string, stroke:string, lw:number) => {
    const es = pl3?.get(wt); if (!es?.length) return;
    ctx.fillStyle=fill; ctx.strokeStyle=stroke; ctx.lineWidth=lw;
    for (const e of es) {
      const k = Math.round(e.x*1000)*10000+Math.round(e.y*1000);
      if (skip.has(k)) continue; skip.add(k);
      rr(ctx, e.x*W, e.y*H, e.w*W, e.h*H, RADIUS); ctx.fill(); ctx.stroke();
    }
  };
  for (const g of caches.cgc) for (const id of g.ids) {
    const wt = caches.fwc.get(id) ?? ''; if (wt) occ(wt, g.fill, g.stroke, 1.2);
  }
  if (caches.awt) occ(caches.awt,'rgba(255,182,193,.4)','rgba(220,80,120,.8)',1.5);
}

// ─────────────────────────────────────────────────────────────────────────────

export function PDFViewer({
  file, adapter, zoom,
}: { file: File; adapter: PDFAdapter; zoom: number }) {
  injectPulseCSS();

  const setCurrentPage = useAppStore(s => s.setCurrentPage);
  const rotation       = useAppStore(s => s.rotation);
  const wordIndex      = useAppStore(s => s.wordIndex);
  const hasWordIndex   = wordIndex.size > 0;

  const containerRef = useRef<HTMLDivElement>(null);
  const viewerDivRef = useRef<HTMLDivElement>(null);
  const viewerRef    = useRef<PdfjsPDFViewer | null>(null);
  const eventBusRef  = useRef<EventBus | null>(null);
  const blobUrlRef   = useRef<string | null>(null);
  const didInit      = useRef(false);
  const zoomRef      = useRef(zoom);

  // Highlight state — kept in a ref so the pagerendered handler always has latest
  const dsRef     = useRef<DrawState>({
    captures: [], activeFieldId: null,
    highlightIndex: new Map(), wordIndex: new Map(),
    previewRect: null, searchResults: [], searchCurrent: 0, searchHighAll: false,
  });
  const cachesRef = useRef<DrawCaches>({
    fwc: new Map(), cgc: [], l3c: new Map(), awt: '', l3Key: '',
  });
  // Overlay canvases keyed by page number
  const overlayMap = useRef(new Map<number, HTMLCanvasElement>());
  // Pulse div
  const pulseRef   = useRef<HTMLDivElement | null>(null);

  // ── Snap store → dsRef ────────────────────────────────────────────────────
  function snapStore() {
    const s = useAppStore.getState();
    dsRef.current = {
      captures:      s.captures,
      activeFieldId: s.activeFieldId,
      highlightIndex:s.highlightIndex,
      wordIndex:     s.wordIndex,
      previewRect:   s.previewRect,
      searchResults: s.search.results,
      searchCurrent: s.search.currentIndex,
      searchHighAll: s.search.highlightAll,
    };
    rebuildCaches(dsRef.current, cachesRef.current);
  }

  // ── Draw one page overlay ─────────────────────────────────────────────────
  // pageDiv: the pdfjs .page div
  // W, H:   CSS display pixels from pdfjs viewport (accurate, no clientWidth)
  function drawPageOverlay(pageNum: number, pageDiv: HTMLElement, W: number, H: number) {
    const ds = dsRef.current;
    const hasCap  = (ds.highlightIndex.get(pageNum)?.length ?? 0) > 0;
    const hasSrch = ds.searchResults.some(r => r.page === pageNum);
    const hasWI   = ds.wordIndex.size > 0 && !!ds.activeFieldId;

    // Remove overlay if nothing to draw
    if (!hasCap && !hasSrch && !hasWI) {
      const ex = overlayMap.current.get(pageNum);
      if (ex) { ex.remove(); overlayMap.current.delete(pageNum); }
      updatePulse();
      return;
    }

    // Get or create overlay canvas
    let oc = overlayMap.current.get(pageNum);
    if (oc && !oc.isConnected) {
      // pdfjs destroyed and re-created the page div — our canvas is orphaned
      oc.remove();
      overlayMap.current.delete(pageNum);
      oc = undefined;
    }
    if (!oc) {
      oc = document.createElement('canvas');
      oc.dataset.hlCanvas = '1';
      oc.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:11;';
      pageDiv.style.position = 'relative';
      pageDiv.appendChild(oc);
      overlayMap.current.set(pageNum, oc);
    }

    const iW = Math.round(W), iH = Math.round(H);
    if (oc.width !== iW || oc.height !== iH) {
      oc.width = iW; oc.height = iH;
    }

    paintPage(oc.getContext('2d')!, iW, iH, pageNum, ds, cachesRef.current);
    updatePulse();
  }

  // ── Redraw all currently rendered pages ───────────────────────────────────
  function drawAllVisible() {
    const viewer = viewerRef.current;
    if (!viewer) return;
    const n = viewer.pagesCount || 0;
    for (let i = 0; i < n; i++) {
      const pv = viewer.getPageView(i);
      // Only draw pages that pdfjs has actually rendered (have a canvas)
      if (!pv?.div || !pv.canvas) continue;
      const vp = pv.viewport;
      // viewport.width/height are CSS display pixels — correct coordinate space
      drawPageOverlay(i + 1, pv.div, vp.width, vp.height);
    }
    updatePulse();
  }

  // ── CSS pulse overlay ─────────────────────────────────────────────────────
  function updatePulse() {
    const pr = dsRef.current.previewRect;
    if (!pr) { pulseRef.current?.remove(); pulseRef.current = null; return; }

    const viewer = viewerRef.current;
    if (!viewer) return;
    const pv = viewer.getPageView(pr.page - 1);
    if (!pv?.div) return;
    const vp = pv.viewport;
    const W = vp.width, H = vp.height;

    if (!pulseRef.current) {
      pulseRef.current = document.createElement('div');
      pulseRef.current.className = 'tov-pulse-box';
    }
    if (pulseRef.current.parentElement !== pv.div) {
      pv.div.style.position = 'relative';
      pv.div.appendChild(pulseRef.current);
    }
    const d = pulseRef.current;
    d.style.left   = (pr.x * W).toFixed(1) + 'px';
    d.style.top    = (pr.y * H).toFixed(1) + 'px';
    d.style.width  = (pr.width  * W).toFixed(1) + 'px';
    d.style.height = (pr.height * H).toFixed(1) + 'px';
  }

  // ── pdfjs init (runs once per file) ──────────────────────────────────────
  useEffect(() => {
    if (didInit.current) return;
    const container = containerRef.current;
    const viewerDiv = viewerDivRef.current;
    if (!container || !viewerDiv) return;
    didInit.current = true;

    const eventBus = new EventBus();
    eventBusRef.current = eventBus;
    const linkService = new PDFLinkService({ eventBus, externalLinkTarget: 2 });
    const findController = new PDFFindController({ linkService, eventBus });

    const pdfViewer = new PdfjsPDFViewer({
      container, viewer: viewerDiv, eventBus, linkService, findController,
      textLayerMode: 2, annotationMode: 0,
      removePageBorders: true, maxCanvasPixels: MAX_CANVAS_PIXELS,
    });
    viewerRef.current = pdfViewer;
    linkService.setViewer(pdfViewer);

    // Page change
    eventBus.on('pagechanging', (evt: any) => {
      setCurrentPage(evt.pageNumber);
    });

    // ── PAGE RENDERED — draw highlights immediately ────────────────────────
    // This is the only reliable place. We have pv.viewport (CSS dimensions)
    // and pv.div (live DOM element) — no timing issues, no clientWidth.
    eventBus.on('pagerendered', (evt: any) => {
      const pageNum = evt.pageNumber as number;
      const pv = pdfViewer.getPageView(pageNum - 1);
      if (!pv?.div) return;

      // Tag the page div for box capture and adapter
      pv.div.dataset.pageNumber = String(pageNum);
      adapter.registerPageElement(pageNum, pv.div);
      adapter.onPageRenderSuccess(pageNum);

      // Hide text layer when word_index is loaded
      if (hasWordIndex) {
        const tl = pv.div.querySelector('.textLayer') as HTMLElement | null;
        if (tl) { tl.style.pointerEvents = 'none'; tl.style.opacity = '0'; }
      }

      // Draw highlights — pv.viewport.width/height are CSS display pixels
      const vp = pv.viewport;
      snapStore(); // ensure latest state
      drawPageOverlay(pageNum, pv.div, vp.width, vp.height);
    });

    // Find results — only update store from pdfjs when word_index is NOT loaded.
    // When word_index IS loaded, our runSearch() populates results with correct
    // fractional coords from the word_index Map. pdfjs find count is irrelevant.
    eventBus.on('updatefindmatchescount', (evt: any) => {
      if (useAppStore.getState().wordIndex.size > 0) return; // word_index takes over
      const total   = evt.matchesCount?.total   ?? 0;
      const current = evt.matchesCount?.current ?? 1;
      useAppStore.setState(s => ({
        search: { ...s.search,
          results: Array.from({length: total}, ()=>({page:1,x:0,y:0,width:0,height:0,text:''})),
          currentIndex: Math.max(0, current - 1) },
      }));
    });

    eventBus.on('updatefindcontrolstate', (evt: any) => {
      if (useAppStore.getState().wordIndex.size > 0) return;
      if (evt.state === 1) {
        useAppStore.setState(s => ({ search: { ...s.search, results: [], currentIndex: -1 } }));
      }
    });

    // Load document
    const url = URL.createObjectURL(file);
    blobUrlRef.current = url;
    let loadCancelled = false;

    pdfjsLib.getDocument({ url, cMapUrl: '/cmaps/', cMapPacked: true })
      .promise.then(doc => {
        if (loadCancelled) { doc.destroy(); return; }
        adapter.onDocumentLoad(doc.numPages);
        pdfViewer.setDocument(doc);
        linkService.setDocument(doc);
        pdfViewer.currentScaleValue = String(zoomRef.current);

        adapter.navigateToPage = (page: number) => {
          const v = viewerRef.current;
          if (!v || !v.pagesCount) return;
          const clamped = Math.max(1, Math.min(page, v.pagesCount));
          v.currentPageNumber = clamped;
          setCurrentPage(clamped);
        };

        adapter['_isReady'] = true;
        (adapter['_readyCallbacks'] as Array<() => void>)?.forEach(cb => cb());
        adapter['_readyCallbacks'] = [];
      }).catch(err => {
        if (!loadCancelled) console.error('PDF load failed:', err);
      });

    return () => {
      loadCancelled = true;
      viewerRef.current = null; eventBusRef.current = null;
      // Delay revoke so any in-flight pdfjs fetch can complete
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      blobUrlRef.current = null;
      overlayMap.current.forEach(c => c.remove()); overlayMap.current.clear();
      pulseRef.current?.remove(); pulseRef.current = null;
      didInit.current = false;
    };
  }, [file]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Zoom ──────────────────────────────────────────────────────────────────
  useEffect(() => {
    zoomRef.current = zoom;
    if (viewerRef.current) viewerRef.current.currentScaleValue = String(zoom);
  }, [zoom]);

  // ── Rotation ──────────────────────────────────────────────────────────────
  useEffect(() => {
    if (viewerRef.current) viewerRef.current.pagesRotation = rotation;
  }, [rotation]);

  // ── Store subscription → redraw all visible pages ─────────────────────────
  // When captures/search/previewRect change, re-draw all pages pdfjs has rendered.
  useEffect(() => {
    snapStore();
    const unsub = useAppStore.subscribe((n, p) => {
      const changed =
        n.captures       !== p.captures       ||
        n.activeFieldId  !== p.activeFieldId  ||
        n.highlightIndex !== p.highlightIndex ||
        n.wordIndex      !== p.wordIndex      ||
        n.previewRect    !== p.previewRect    ||
        n.search.results !== p.search.results ||
        n.search.currentIndex !== p.search.currentIndex ||
        n.search.highlightAll !== p.search.highlightAll;
      if (!changed) return;
      snapStore();
      drawAllVisible();
    });
    return unsub;
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Search ────────────────────────────────────────────────────────────────
  // STRATEGY:
  //   • word_index loaded  → use our own runSearch() (fractional coords from
  //     word_index Map). pdfjs find controller is DISABLED — it uses the PDF
  //     text layer which may differ from word_index content and draws its own
  //     conflicting highlights on .textLayer .highlight elements.
  //   • no word_index      → delegate to pdfjs PDFFindController (searches
  //     all pages via worker, works across virtual-scroll pages).
  const search = useAppStore(s => s.search);

  useEffect(() => {
    const eb = eventBusRef.current; if (!eb) return;
    const wi = useAppStore.getState().wordIndex;

    if (wi.size > 0) {
      // word_index mode: always close pdfjs find so it draws NO highlights
      eb.dispatch('findbarclose', { source: window });
      return;
    }

    // pdfjs find mode (no word_index)
    if (!search.isOpen || !search.query.trim()) {
      eb.dispatch('findbarclose', { source: window }); return;
    }
    eb.dispatch('find', {
      source: window, type: '', query: search.query,
      caseSensitive: search.matchCase, entireWord: search.matchType === 'exact',
      highlightAll: search.highlightAll, findPrevious: false,
    });
  }, [search.query, search.matchCase, search.matchType, search.highlightAll, search.isOpen, hasWordIndex]);

  // Bridge searchNext/searchPrev toolbar buttons
  useEffect(() => {
    const wi = useAppStore.getState().wordIndex;

    if (wi.size > 0) {
      // word_index mode: next/prev already work correctly in appStore
      // (they update currentIndex and call navigateToPage + setPreviewRect)
      // Nothing to override here — store handles it.
      return;
    }

    // pdfjs find mode: override next/prev to call pdfjs find controller
    const go = (prev: boolean) => {
      const s = useAppStore.getState().search;
      if (!s.query.trim() || !eventBusRef.current) return;
      eventBusRef.current.dispatch('find', {
        source: window, type: 'again',
        query: s.query, caseSensitive: s.matchCase,
        entireWord: s.matchType === 'exact',
        highlightAll: s.highlightAll, findPrevious: prev,
      });
    };
    const on = useAppStore.getState().searchNext;
    const op = useAppStore.getState().searchPrev;
    useAppStore.setState({ searchNext: () => go(false), searchPrev: () => go(true) });
    return () => useAppStore.setState({ searchNext: on, searchPrev: op });
  }, [hasWordIndex]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Text layer + pdfjs find highlight visibility ─────────────────────────
  // When word_index is loaded:
  //   - text layer: hidden (we use word_index for hit-test, not DOM spans)
  //   - .textLayer .highlight: hidden (pdfjs find controller highlights — we
  //     draw our own search highlights on the overlay canvas)
  // Inject a style tag to suppress pdfjs highlights globally when word_index active.
  useEffect(() => {
    const styleId = 'tov-suppress-pdfjs-find';
    let styleEl = document.getElementById(styleId) as HTMLStyleElement | null;
    if (hasWordIndex) {
      if (!styleEl) {
        styleEl = document.createElement('style');
        styleEl.id = styleId;
        document.head.appendChild(styleEl);
      }
      // Hide pdfjs find highlights AND selection highlights
      styleEl.textContent = `.textLayer .highlight,.textLayer .selected{display:none!important;}`;
    } else {
      styleEl?.remove();
    }
  }, [hasWordIndex]);

  useEffect(() => {
    const c = containerRef.current; if (!c) return;
    c.querySelectorAll<HTMLElement>('.textLayer').forEach(el => {
      el.style.pointerEvents = hasWordIndex ? 'none' : '';
      el.style.opacity       = hasWordIndex ? '0'    : '';
    });
  }, [hasWordIndex]);

  return (
    <div ref={containerRef} data-viewer-scroll="1"
      className="flex-1 bg-[#1a1f2e]"
      style={{ position: 'absolute', inset: 0, overflow: 'auto' }}>
      <div ref={viewerDivRef} className="pdfViewer" />
    </div>
  );
}
