import {
  Component,
  OnInit,
  ViewChild,
  signal,
  ChangeDetectionStrategy,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { PdfViewerComponent, CapturedWordPayload } from './components/pdf-viewer/pdf-viewer.component';
import { FieldsPanelComponent } from './components/fields-panel/fields-panel.component';
import { PdfCaptureService } from './services/pdf-capture.service';
import { HttpClient } from '@angular/common/http';
import { InputField, WordCoordinate } from './models/pdf-capture.models';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, PdfViewerComponent, FieldsPanelComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="app-shell">
      <!-- Top Bar -->
      <header class="topbar">
        <div class="brand">
          <span class="brand-icon">◈</span>
          <span class="brand-name">PDF<span class="accent">Capture</span></span>
        </div>

        <div class="topbar-actions">
          <span class="coords-status" *ngIf="coordsLoadStatus()" [class.ok]="coordsLoadStatus().startsWith('✓')">
            {{ coordsLoadStatus() }}
          </span>
          <button class="btn-action" (click)="loadDemoExternalCoords()" title="Load coordinate JSON matching current PDF filename from assets/">
            <span>⊕</span> Load Coords
          </button>
          <button class="btn-action" (click)="clearAllFields()">
            <span>⊘</span> Clear All
          </button>
        </div>
      </header>

      <!-- Main Split Layout -->
      <div class="main-layout">
        <!-- LEFT: PDF Viewer (toolbar is self-contained inside the component) -->
        <div class="pane pane-pdf" [style.width]="leftWidth + '%'">
          <app-pdf-viewer
            #pdfViewer
            [src]="pdfSrc()"
            (wordCaptured)="onWordCaptured($event)"
            (pdfNameChange)="onPdfNameChange($event)"
            (boxCaptured)="onBoxCaptured($event)"
          ></app-pdf-viewer>
        </div>

        <!-- Resize Handle -->
        <div
          class="resize-handle"
          (mousedown)="startResize($event)"
          title="Drag to resize"
        >
          <div class="handle-line"></div>
        </div>

        <!-- RIGHT: Fields Panel -->
        <div class="pane pane-fields">
          <app-fields-panel
            (fieldFocused)="onFieldFocused($event)"
            (goToWord)="onGoToWord($event)"
          ></app-fields-panel>
        </div>
      </div>
    </div>
  `,
  styles: [`
    @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;600;700&display=swap');

    :host {
      display: block;
      height: 100vh;
      overflow: hidden;
    }

    .app-shell {
      display: flex;
      flex-direction: column;
      height: 100vh;
      background: #080f1a;
      font-family: 'DM Sans', sans-serif;
    }

    /* ── Top Bar ── */
    .topbar {
      height: 52px;
      flex-shrink: 0;
      background: #0d1b2a;
      border-bottom: 1px solid rgba(255,255,255,0.07);
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 20px;
      z-index: 100;
    }

    .brand {
      display: flex;
      align-items: center;
      gap: 10px;

      .brand-icon {
        font-size: 22px;
        color: #00d4aa;
        line-height: 1;
      }

      .brand-name {
        font-size: 17px;
        font-weight: 700;
        color: #f1f5f9;
        letter-spacing: -0.5px;

        .accent {
          color: #00d4aa;
        }
      }
    }

    .topbar-actions {
      display: flex;
      gap: 8px;
      align-items: center;

      .coords-status {
        font-size: 11px;
        color: #f87171;
        max-width: 280px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        &.ok { color: #4ade80; }
      }
    }

    .btn-action {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 6px 14px;
      background: rgba(255,255,255,0.04);
      border: 1.5px solid #1e293b;
      border-radius: 6px;
      color: #94a3b8;
      font-family: inherit;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.15s;
      letter-spacing: 0.2px;

      &:hover {
        border-color: #00d4aa;
        color: #00d4aa;
        background: rgba(0,212,170,0.06);
      }

    }

    /* ── Main Layout ── */
    .main-layout {
      flex: 1;
      display: flex;
      overflow: hidden;
      min-height: 0;
    }

    .pane {
      height: 100%;
      overflow: hidden;
      min-width: 0;
    }

    .pane-pdf {
      flex-shrink: 0;
    }

    .pane-fields {
      flex: 1;
      min-width: 320px;
      max-width: 500px;
    }

    /* ── Resize Handle ── */
    .resize-handle {
      width: 6px;
      cursor: col-resize;
      background: #0d1b2a;
      border-left: 1px solid rgba(255,255,255,0.06);
      border-right: 1px solid rgba(255,255,255,0.06);
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background 0.15s;
      flex-shrink: 0;

      &:hover {
        background: rgba(0,212,170,0.1);
        .handle-line { background: #00d4aa; }
      }

      .handle-line {
        width: 2px;
        height: 40px;
        background: #1e293b;
        border-radius: 2px;
        transition: background 0.15s;
      }
    }
  `],
})
export class AppComponent implements OnInit {
  @ViewChild('pdfViewer') pdfViewer!: PdfViewerComponent;

  pdfSrc = signal<string>('');
  currentPdfName = signal<string>('');
  coordsLoadStatus = signal<string>('');
  leftWidth = 65;

  private isResizing = false;
  private resizeStartX = 0;
  private resizeStartWidth = 0;

  // Demo PDF - replace with actual src
  private readonly DEMO_PDF = 'assets/sample.pdf';

  constructor(public captureService: PdfCaptureService, private http: HttpClient) {}

  ngOnInit() {
    // Initialize default fields - customize as needed
    const defaultFields: InputField[] = [
      { id: 'f1', label: 'Invoice Number', value: '', capturedWord: null, isFocused: false },
      { id: 'f2', label: 'Date', value: '', capturedWord: null, isFocused: false },
      { id: 'f3', label: 'Vendor Name', value: '', capturedWord: null, isFocused: false },
      { id: 'f4', label: 'Total Amount', value: '', capturedWord: null, isFocused: false },
      { id: 'f5', label: 'PO Number', value: '', capturedWord: null, isFocused: false },
      { id: 'f6', label: 'Tax Amount', value: '', capturedWord: null, isFocused: false },
      { id: 'f7', label: 'Payment Terms', value: '', capturedWord: null, isFocused: false },
      { id: 'f8', label: 'Ship To', value: '', capturedWord: null, isFocused: false },
    ];
    this.captureService.initFields(defaultFields);

    // Load default PDF and set its base name for coord matching
    this.pdfSrc.set(this.DEMO_PDF);
    const defaultName = this.DEMO_PDF.replace(/^assets\//, '').replace(/\.pdf$/i, '');
    this.currentPdfName.set(defaultName);
  }



  onWordCaptured(word: CapturedWordPayload) {
    this.captureService.captureWordToActiveField(word);
  }

  /**
   * Box-select emits the merged bounding-box payload of all selected words.
   * Capture the joined text + bounding coords into the active field.
   */
  onBoxCaptured(payload: CapturedWordPayload) {
    this.captureService.captureWordToActiveField(payload);
  }

  onFieldFocused(fieldId: string) {
    const field = this.captureService.fields().find(f => f.id === fieldId);
    if (field?.capturedWord) {
      // Navigate instantly to the page where the captured word lives
      this.pdfViewer?.navigateToPage(field.capturedWord.page);
      setTimeout(() => { if (this.pdfViewer) this.pdfViewer.scheduleRedraw(); }, 120);
    }
  }

  onGoToWord(field: InputField) {
    if (field.capturedWord) {
      this.captureService.setActiveField(field.id);
      this.pdfViewer?.navigateToPage(field.capturedWord.page);
    }
  }

  clearAllFields() {
    this.captureService.fields().forEach((f: import('./models/pdf-capture.models').InputField) => this.captureService.clearField(f.id));
    this.captureService.loadExternalCoordinates([]);
  }

  /**
   * Load Coords — matches the current PDF filename to a JSON file in assets/.
   *
   * Convention: if the PDF is "invoice.pdf", looks for "assets/invoice.json".
   * The JSON format is:
   *   [{ "id":"1","label":"Word","page":1,"bbox":[x,y,w,h] }, ...]
   * where bbox values are 0-1 fractions of page size (zoom-independent).
   *
   * Place coordinate JSON files in src/assets/ with the same base name as the PDF.
   */
  loadDemoExternalCoords() {
    const src = this.pdfSrc();
    if (!src) {
      this.coordsLoadStatus.set('⚠ No PDF loaded');
      return;
    }

    // Derive base name: "assets/foo.pdf" → "foo",  "blob:..." → use currentPdfName
    let baseName = this.currentPdfName();
    if (!baseName && src.startsWith('assets/')) {
      baseName = src.replace(/^assets\//, '').replace(/\.pdf$/i, '');
    }
    if (!baseName) {
      this.coordsLoadStatus.set('⚠ Cannot determine PDF filename');
      return;
    }

    // Strip path separators for safety
    baseName = baseName.split('/').pop()!.split('\\').pop()!.replace(/\.pdf$/i, '');
    const jsonUrl = `assets/${baseName}.json`;

    this.coordsLoadStatus.set(`Loading ${jsonUrl}…`);

    this.http.get<any[]>(jsonUrl).subscribe({
      next: (data) => {
        const coords: WordCoordinate[] = data.map((item) => this.normaliseCoord(item));
        this.captureService.loadExternalCoordinates(coords);
        this.coordsLoadStatus.set(`✓ Loaded ${coords.length} coords from ${jsonUrl}`);
      },
      error: (err) => {
        const msg = err.status === 404
          ? `⚠ No coords file found — place "${baseName}.json" in src/assets/`
          : `⚠ Failed to load ${jsonUrl}: ${err.message}`;
        this.coordsLoadStatus.set(msg);
        console.warn('Load Coords:', msg);
      }
    });
  }

  /** Called when the viewer's native open button loads a new PDF */
  onSrcChange(event: string | Uint8Array): void {
    // When a blob URL is used (native file open), we can't derive name from URL.
    // The name is captured separately via the viewer's file change event.
    this.captureService.loadExternalCoordinates([]); // clear old coords
    this.coordsLoadStatus.set('');
  }

  /** Called from the viewer when a file is opened via native toolbar */
  onPdfNameChange(name: string): void {
    // Strip path separators and extension — keep only the base filename
    const base = name.split('/').pop()?.split('\\').pop() ?? name;
    this.currentPdfName.set(base.replace(/\.pdf$/i, ''));
    // Clear old coords when a new PDF is opened
    this.captureService.loadExternalCoordinates([]);
    this.coordsLoadStatus.set('');
  }

  // ── Coordinate Normalisation ─────────────────────────────────────────────
  /**
   * Universal coordinate normaliser — converts any external bbox format into
   * our viewer's 0-1 fractional system (fraction of PDF page canvas size).
   *
   * Three formats are handled automatically with zero hardcoded magic numbers:
   *
   * FORMAT A — already fractional [x, y, w, h] all in 0-1 range:
   *   { bbox: [0.08, 0.16, 0.60, 0.02] }       ← our pdfplumber output
   *   { x, y, width, height }                   ← plain fractional fields
   *   Detection: bbox has 4 values, all ≤ 1
   *   Action: use as-is
   *
   * FORMAT B — absolute pixel [x1,y1,x2,y2] with rendered image dimensions:
   *   { pagewidth: 899, pageHeight: 1272, bbox: [206, 165, 635, 178] }
   *   These come from tools (Gemini, Stylus, AWS Textract, Google Vision, etc.)
   *   that render the PDF to a raster image and return pixel coordinates.
   *
   *   Universal formula (no magic constants):
   *     xFrac = x1 / pagewidth
   *     yFrac = y1 / pageHeight
   *     wFrac = (x2 - x1) / pagewidth
   *     hFrac = (y2 - y1) / pageHeight
   *
   *   If the tool adds UI chrome/margins around the page (making the image
   *   larger than the page content), we auto-detect this by finding the
   *   minimum x1 across all items on the same page — that minimum is the
   *   left edge of content. We subtract it to get content-relative coords.
   *   This works for ANY tool, ANY DPI, ANY page size.
   *
   * FORMAT C — [x1,y1,x2,y2] without page dimensions:
   *   { bbox: [206, 165, 635, 178] } (no pagewidth/pageHeight)
   *   We have no render scale, so treat as fractional (FORMAT A).
   *   If values > 1 they will be clamped — user should provide page dimensions.
   */
  private normaliseCoord(item: any): WordCoordinate {
    const id   = String(item.id    ?? item.label ?? '');
    const text = String(item.label ?? item.text  ?? item.id ?? '');
    const page = Number(item.page  ?? 1);

    const pw = Number(item.pagewidth  ?? item.pageWidth  ?? 0);
    const ph = Number(item.pageHeight ?? item.pageheight ?? 0);

    // ── FORMAT B: has page dimensions + absolute pixel bbox ──────────────────
    if (pw > 1 && ph > 1 && item.bbox && Array.isArray(item.bbox) && item.bbox.length === 4) {
      const [bx1, by1, bx2, by2] = (item.bbox as number[]).map(Number);

      if (bx1 > 1 || by1 > 1 || bx2 > 1 || by2 > 1) {
        // Direct ratio — works for any render DPI and any PDF page size
        return {
          id, text, page,
          x:      Math.min(1, Math.max(0, bx1 / pw)),
          y:      Math.min(1, Math.max(0, by1 / ph)),
          width:  Math.min(1, Math.max(0, (bx2 - bx1) / pw)),
          height: Math.min(1, Math.max(0, (by2 - by1) / ph)),
        };
      }
    }

    // ── Extract raw values ────────────────────────────────────────────────────
    let rawX: number, rawY: number, rawW: number, rawH: number;

    if (item.bbox && Array.isArray(item.bbox) && item.bbox.length === 4) {
      const [a, b, c, d] = (item.bbox as number[]).map(Number);
      // Detect [x1,y1,x2,y2] vs [x,y,w,h]:
      // In [x1,y1,x2,y2] the 3rd value > 1st (x2 > x1), width would be > 1 if treated as [x,y,w,h]
      // In [x,y,w,h] all four values should be ≤ 1 for a valid fraction
      if (a >= 0 && a <= 1 && b >= 0 && b <= 1 && c >= 0 && c <= 1 && d >= 0 && d <= 1) {
        // FORMAT A: genuine 0-1 fractions [x, y, w, h]
        rawX = a; rawY = b; rawW = c; rawH = d;
      } else if (c > a && d > b) {
        // Looks like [x1, y1, x2, y2] without page dims — normalise by max(x2,y2)
        // Best effort: use the larger axis value as the page dimension proxy
        const impliedW = Math.max(c, pw || c);
        const impliedH = Math.max(d, ph || d);
        rawX = a / impliedW; rawY = b / impliedH;
        rawW = (c - a) / impliedW; rawH = (d - b) / impliedH;
      } else {
        rawX = a; rawY = b; rawW = c; rawH = d;
      }
    } else {
      rawX = Number(item.x ?? 0);
      rawY = Number(item.y ?? 0);
      rawW = Number(item.width  ?? item.w ?? 0);
      rawH = Number(item.height ?? item.h ?? 0);
    }

    return {
      id, text, page,
      x:      Math.min(1, Math.max(0, rawX)),
      y:      Math.min(1, Math.max(0, rawY)),
      width:  Math.min(1, Math.max(0, rawW)),
      height: Math.min(1, Math.max(0, rawH)),
    };
  }

  // ── Resize Panel ─────────────────────────────────────────────────────────
  startResize(event: MouseEvent) {
    this.isResizing = true;
    this.resizeStartX = event.clientX;
    this.resizeStartWidth = this.leftWidth;

    const onMove = (e: MouseEvent) => {
      if (!this.isResizing) return;
      const delta = e.clientX - this.resizeStartX;
      const totalW = window.innerWidth;
      const newW = this.resizeStartWidth + (delta / totalW) * 100;
      this.leftWidth = Math.max(35, Math.min(75, newW));
    };

    const onUp = () => {
      this.isResizing = false;
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
    };

    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
    event.preventDefault();
  }
}