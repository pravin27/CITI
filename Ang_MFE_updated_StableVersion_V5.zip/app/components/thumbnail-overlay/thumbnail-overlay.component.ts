import {
  Component, OnInit, OnDestroy,
  ChangeDetectionStrategy, ChangeDetectorRef, NgZone, effect,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ThumbnailCategoryService, PALETTE, PaletteKey } from '../../services/thumbnail-category.service';

/**
 * ThumbnailOverlayComponent
 *
 * Renders the filter chip bar as a REAL Angular element using ::ng-deep
 * and absolute positioning to sit above the thumbnail sidebar content.
 *
 * Placement strategy:
 *   - The component itself renders as a zero-height host element
 *   - The filter bar uses position:fixed, aligned to the sidebar panel
 *   - It reads the sidebar position from the DOM once on init/resize
 *   - No DOM injection into ngx elements
 *
 * Section dividers:
 *   - Injected via a single safe MutationObserver on #thumbnailView
 *     with childList:true only (no subtree)
 *   - Disconnect before writing, reconnect after (prevents feedback loop)
 *   - Re-entry guard prevents any loop
 */
@Component({
  selector: 'app-thumbnail-overlay',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="tov-host" *ngIf="svc.categories().length">

      <!-- Filter chip bar — positioned over the sidebar -->
      <div class="tov-bar" id="tov-filter-bar-fixed" [class.tov-hidden]="!sidebarOpen">
        <!-- All chip -->
        <button
          class="tov-chip tov-all"
          [class.tov-on]="svc.activeFilter() === null"
          (click)="setFilter(null)"
        >
          All
          <span class="tov-cnt">{{ totalCount() }}</span>
        </button>

        <!-- Category chips -->
        <button
          *ngFor="let cat of svc.categories()"
          class="tov-chip"
          [class.tov-on]="svc.activeFilter() === cat.label"
          [style.--c-bg]="pal(cat.resolvedColor).divBg"
          [style.--c-text]="pal(cat.resolvedColor).divText"
          [style.--c-bg-on]="pal(cat.resolvedColor).bg"
          [style.--c-text-on]="pal(cat.resolvedColor).text"
          (click)="setFilter(cat.label)"
        >
          {{ cat.label }}
          <span class="tov-cnt">{{ cat.pages.length }}</span>
        </button>

        <!-- Other chip — only if unlabelled pages exist -->
        <button
          *ngIf="svc.otherCount() > 0"
          class="tov-chip"
          [class.tov-on]="svc.activeFilter() === 'Other'"
          [style.--c-bg]="pal('gray').divBg"
          [style.--c-text]="pal('gray').divText"
          [style.--c-bg-on]="pal('gray').bg"
          [style.--c-text-on]="pal('gray').text"
          (click)="setFilter('Other')"
        >
          Other
          <span class="tov-cnt">{{ svc.otherCount() }}</span>
        </button>
      </div>

    </div>
  `,
  styles: [`
    :host { display: block; position: relative; }

    .tov-host { }

    /* ── Filter bar — fixed over the sidebar thumbnail area ── */
    .tov-bar {
      position: fixed;
      /* positioned by JS after measuring sidebar */
      top: var(--tov-top, 90px);
      left: var(--tov-left, 0px);
      width: var(--tov-width, 190px);
      z-index: 1000;
      display: flex;
      flex-wrap: wrap;
      gap: 4px;
      padding: 5px 8px;
      background: var(--toolbar-bg, #f0f0ee);
      border-bottom: 1px solid rgba(0,0,0,0.14);
      box-sizing: border-box;
      transition: opacity .2s;
    }
    .tov-bar.tov-hidden { display: none !important; }

    /* Chips */
    .tov-chip {
      font-size: 10px;
      padding: 2px 8px;
      border-radius: 20px;
      cursor: pointer;
      border: 1px solid rgba(0,0,0,.15);
      background: rgba(255,255,255,.95);
      color: #444;
      display: inline-flex;
      align-items: center;
      gap: 3px;
      white-space: nowrap;
      font-family: inherit;
      line-height: 1.5;
      user-select: none;
      transition: all .15s;
    }
    .tov-chip:hover { opacity: .85; }

    /* Category chip inactive */
    .tov-chip:not(.tov-all) {
      background: var(--c-bg, #eee);
      color: var(--c-text, #333);
      border-color: color-mix(in srgb, var(--c-text, #333) 40%, transparent);
    }
    /* Category chip active */
    .tov-chip:not(.tov-all).tov-on {
      background: var(--c-bg-on, #185FA5);
      color: var(--c-text-on, #fff);
      border-color: var(--c-bg-on, #185FA5);
      font-weight: 700;
    }
    /* All chip inactive */
    .tov-all { background: #fff; color: #444; }
    /* All chip active */
    .tov-all.tov-on {
      background: #dbeafe;
      color: #1e40af;
      border-color: #93c5fd;
      font-weight: 700;
    }
    .tov-all.tov-on .tov-cnt { background: #1e40af; color: #dbeafe; }

    .tov-cnt {
      font-size: 8px;
      font-weight: 700;
      padding: 1px 4px;
      border-radius: 8px;
      background: rgba(0,0,0,.12);
      color: inherit;
    }
    
  `],
})
export class ThumbnailOverlayComponent implements OnInit, OnDestroy {

  sidebarOpen = false;
  private _posTimer: ReturnType<typeof setInterval> | null = null;
  private _thumbObs:  MutationObserver | null = null;
  private _isStamping = false;

  constructor(
    public svc: ThumbnailCategoryService,
    private cdr: ChangeDetectorRef,
    private zone: NgZone,
  ) {
    // Re-position + re-stamp when categories change
    effect(() => {
      svc.categories();
      this.zone.runOutsideAngular(() => {
        this._measureSidebar();
        this._stampDividers();
      });
    });
  }

  ngOnInit(): void {
    // Inject global style for badges + left borders on thumbnails
    this._injectBadgeStyles();

    // Poll sidebar position every 300ms — cheap check, handles:
    // sidebar open/close, tab switches, window resize
    // Uses requestAnimationFrame to avoid layout thrashing
    this._posTimer = setInterval(() => this._measureSidebar(), 300);

    // Watch #thumbnailView for new thumbnails (childList only, no subtree)
    this._connectThumbObserver();
  }

  ngOnDestroy(): void {
    if (this._posTimer) clearInterval(this._posTimer);
    this._thumbObs?.disconnect();
    document.getElementById('tov-badge-style')?.remove();
    document.querySelectorAll('.tov-badge, .tov-divider').forEach(el => el.remove());
    document.querySelectorAll<HTMLElement>('.thumbnail[data-tov-cat]').forEach(t => {
      t.style.borderLeft = '';
      t.removeAttribute('data-tov-cat');
    });
    // Remove padding-top we added
    const tv = document.querySelector<HTMLElement>('#thumbnailView');
    if (tv) tv.style.paddingTop = '';
    this.svc.clear();
  }

  // ── Template helpers ──────────────────────────────────────────────────────
  pal(key: PaletteKey) { return PALETTE[key]; }

  totalCount(): number {
    return this.svc.totalPages + this.svc.otherCount();
  }

  setFilter(label: string | null): void {
    this.svc.setFilter(label);
    this.cdr.markForCheck();
  }

  // ── Sidebar position measurement ──────────────────────────────────────────
  private _measureSidebar(): void {
    const thumbView = document.querySelector<HTMLElement>('#thumbnailView');
    if (!thumbView) return;

    // ── Detect if thumbnail tab is actually showing ───────────────────────
    // ngx hides non-active views using display:none on their container
    // OR hides the entire #sidebarContainer when sidebar is closed.
    // We check multiple signals:
    const sidebarContainer = document.querySelector<HTMLElement>('#sidebarContainer');
    const sidebarClosed = !sidebarContainer ||
      getComputedStyle(sidebarContainer).visibility === 'hidden' ||
      sidebarContainer.classList.contains('hidden') ||
      sidebarContainer.getAttribute('aria-hidden') === 'true';

    // Check thumbnail view specifically is the active tab
    // ngx sets display:none on inactive tab content
    const thumbStyle   = getComputedStyle(thumbView);
    const thumbHidden  = thumbStyle.display === 'none' || thumbStyle.visibility === 'hidden';

    // Also check via sidebar width — if sidebar is closed, width is ~0
    const sidebarRect  = sidebarContainer?.getBoundingClientRect();
    const sidebarWidth = sidebarRect?.width ?? 0;

    const visible = !sidebarClosed && !thumbHidden && sidebarWidth > 20;

    // ── Position the fixed bar flush with top of sidebarContent ────────────
    if (visible) {
      const posEl = document.querySelector<HTMLElement>('#sidebarContent') ?? thumbView;
      const rect  = posEl.getBoundingClientRect();
      const root  = document.documentElement;
      root.style.setProperty('--tov-top',   rect.top + 'px');
      root.style.setProperty('--tov-left',  rect.left + 'px');
      root.style.setProperty('--tov-width', rect.width + 'px');
    }

    // ── Reserve space: measure ACTUAL bar height, apply as paddingTop ─────
    // The bar uses flex-wrap so height depends on number of chips.
    // We read offsetHeight after the bar is rendered (next frame).
    if (visible) {
      // Use rAF so the bar has been painted before we measure it
      requestAnimationFrame(() => {
        const bar   = document.getElementById('tov-filter-bar-fixed');
        const barH  = bar ? bar.offsetHeight : 36;
        if (thumbView.style.paddingTop !== barH + 'px') {
          thumbView.style.paddingTop = barH + 'px';
          // Also update the --tov-height var so bar background fills correctly
          document.documentElement.style.setProperty('--tov-height', barH + 'px');
        }
      });
    } else {
      thumbView.style.paddingTop = '';
      document.documentElement.style.setProperty('--tov-height', '0px');
    }

    const wasOpen = this.sidebarOpen;
    this.sidebarOpen = visible;
    if (wasOpen !== visible) {
      this.zone.run(() => this.cdr.markForCheck());
    }
  }

  // ── Thumbnail observer for re-stamping on scroll/virtual-render ───────────
  private _connectThumbObserver(): void {
    const tryConnect = () => {
      const tv = document.querySelector('#thumbnailView');
      if (!tv) { setTimeout(tryConnect, 500); return; }
      if (this._thumbObs) return;
      this._thumbObs = new MutationObserver(() => {
        this.zone.runOutsideAngular(() => this._stampDividers());
      });
      this._thumbObs.observe(tv, { childList: true });
    };
    setTimeout(tryConnect, 600);

    // Watch bar height changes via ResizeObserver (fires when chips wrap/unwrap)
    // More accurate than polling for height
    const watchBar = () => {
      const bar = document.getElementById('tov-filter-bar-fixed');
      if (!bar) { setTimeout(watchBar, 300); return; }
      const ro = new ResizeObserver(() => {
        const thumbView = document.querySelector<HTMLElement>('#thumbnailView');
        if (!thumbView || !this.sidebarOpen) return;
        const h = bar.offsetHeight;
        if (thumbView.style.paddingTop !== h + 'px') {
          thumbView.style.paddingTop = h + 'px';
        }
      });
      ro.observe(bar);
    };
    setTimeout(watchBar, 800);
  }

  // ── Section dividers (coloured rows between category groups) ─────────────
  private _stampDividers(): void {
    if (this._isStamping) return;
    if (!this.svc.categories().length) return;
    const tv = document.querySelector<HTMLElement>('#thumbnailView');
    if (!tv) return;

    this._isStamping = true;
    this._thumbObs?.disconnect();

    try {
      // Remove old dividers
      tv.querySelectorAll('.tov-divider').forEach(el => el.remove());

      // Get ALL direct children of #thumbnailView that contain .thumbnail
      const children = Array.from(tv.children) as HTMLElement[];
      if (!children.length) return;

      const map = this.svc.pageMap();
      let lastLabel: string | null = null;

      for (const child of children) {
        if (child.classList.contains('tov-divider')) continue;

        // Find .thumbnail inside this direct child
        const thumb: HTMLElement | null =
          child.classList.contains('thumbnail')
            ? child
            : child.querySelector<HTMLElement>('.thumbnail[data-page-number]');

        if (!thumb) continue;

        const pageNum = parseInt(thumb.getAttribute('data-page-number') ?? '0', 10);
        if (!pageNum) continue;

        const cat   = map.get(pageNum);
        const label = cat?.label ?? 'Other';
        const pal   = PALETTE[cat?.resolvedColor ?? 'gray'];

        if (label !== lastLabel) {
          lastLabel = label;
          const div = document.createElement('div');
          div.className = 'tov-divider';
          div.dataset['tovDivLabel'] = label;
          // Build -------- LABEL -------- layout
          div.innerHTML =
            '<span class="tov-div-line"></span>' +
            '<span class="tov-div-text">' + label + '</span>' +
            '<span class="tov-div-line"></span>';
          div.style.cssText =
            'display:flex;align-items:center;gap:6px;' +
            'padding:3px 8px;box-sizing:border-box;width:100%;' +
            'pointer-events:none;';
          // Style the child elements
          const [l1, text, l2] = Array.from(div.children) as HTMLElement[];
          const lineStyle = 'flex:1;height:1px;background:' + pal.bg + ';opacity:.5;';
          l1.style.cssText = lineStyle;
          l2.style.cssText = lineStyle;
          text.style.cssText =
            'font-size:8px;font-weight:700;letter-spacing:.6px;' +
            'text-transform:uppercase;white-space:nowrap;' +
            'color:' + pal.divText + ';background:' + pal.divBg + ';' +
            'padding:1px 6px;border-radius:3px;flex-shrink:0;';
          tv.insertBefore(div, child);
        }
      }
    } finally {
      this._isStamping = false;
      const tv2 = document.querySelector('#thumbnailView');
      if (tv2 && this._thumbObs) {
        this._thumbObs.observe(tv2, { childList: true });
      }
    }
  }

  // ── Global styles for badges ──────────────────────────────────────────────
  private _injectBadgeStyles(): void {
    if (document.getElementById('tov-badge-style')) return;
    const s = document.createElement('style');
    s.id = 'tov-badge-style';
    s.textContent =
      '.thumbnail{position:relative !important;overflow:hidden !important;}' +
      '.tov-badge{' +
        'position:absolute;bottom:0;left:0;right:0;' +
        'font-size:9px;font-weight:700;text-align:center;padding:2px 4px;' +
        'pointer-events:none;z-index:10;letter-spacing:.2px;' +
        'white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-family:sans-serif;' +
      '}' +
      '.tov-divider{flex-shrink:0;}';
    document.head.appendChild(s);
  }
}