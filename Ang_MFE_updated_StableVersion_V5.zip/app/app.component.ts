import {
  Component,
  OnInit,
  ViewChild,
  signal,
  ChangeDetectionStrategy,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { PdfViewerComponent, CapturedWordPayload } from './components/pdf-viewer/pdf-viewer.component';
import { ThumbnailOverlayComponent } from './components/thumbnail-overlay/thumbnail-overlay.component';
import { ThumbnailCategoryService, CategoryConfig } from './services/thumbnail-category.service';
import { FieldsPanelComponent } from './components/fields-panel/fields-panel.component';
import { PdfCaptureService } from './services/pdf-capture.service';
import { HttpClient } from '@angular/common/http';
import { CapturedFieldJson, CapturedFieldFormat } from './models/pdf-capture.models';
import { CaptureItem } from './services/pdf-capture.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, PdfViewerComponent, FieldsPanelComponent, ThumbnailOverlayComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="app-shell">
      <!-- Top Bar -->
      <header class="topbar">
        <div class="brand">
          <span class="brand-icon">◈</span>
          <span class="brand-name">PDF<span class="accent">Capture</span></span>
        </div>

        <div class="topbar-actions">

          <button class="btn-action" (click)="clearAllFields()">
            <span>⊘</span> Clear All
          </button>
          <button class="btn-action btn-export" (click)="downloadCapturedFields()" title="Download all captured fields as JSON">
            <span>↓</span> Export JSON
          </button>
        </div>
      </header>

      <!-- Main Split Layout -->
      <div class="main-layout">
        <!-- LEFT: PDF Viewer -->
        <div class="pane pane-pdf" [style.width]="leftWidth + '%'">
          <app-pdf-viewer
            #pdfViewer
            [src]="pdfSrc()"
            [captureOnLoad]="true"
            (wordCaptured)="onWordCaptured($event)"
            (pdfNameChange)="onPdfNameChange($event)"
            (boxCaptured)="onBoxCaptured($event)"
            (thumbnailDrawn)="onThumbnailDrawn($event)"
          ></app-pdf-viewer>
        </div>

        <!-- Resize Handle -->
        <div
          class="resize-handle"
          (mousedown)="startResize($event)"
          title="Drag to resize"
        >
          <div class="handle-line"></div>
        </div>

        <!-- RIGHT: Fields Panel -->
        <div class="pane pane-fields">
          <app-fields-panel
            (goToWord)="onGoToWord($event)"
            (captureConfirmed)="onConfirmCapture()"
          ></app-fields-panel>
        </div>
      </div>
      <!-- Thumbnail overlay: renders nothing here, injects into sidebar DOM -->
      <app-thumbnail-overlay></app-thumbnail-overlay>
    </div>
  `,
  styles: [`
    @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;600;700&display=swap');

    :host {
      display: block;
      height: 100vh;
      overflow: hidden;
    }

    .app-shell {
      display: flex;
      flex-direction: column;
      height: 100vh;
      background: #080f1a;
      font-family: 'DM Sans', sans-serif;
    }

    /* ── Top Bar ── */
    .topbar {
      height: 52px;
      flex-shrink: 0;
      background: #0d1b2a;
      border-bottom: 1px solid rgba(255,255,255,0.07);
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 20px;
      z-index: 100;
    }

    .brand {
      display: flex;
      align-items: center;
      gap: 10px;

      .brand-icon {
        font-size: 22px;
        color: #00d4aa;
        line-height: 1;
      }

      .brand-name {
        font-size: 17px;
        font-weight: 700;
        color: #f1f5f9;
        letter-spacing: -0.5px;

        .accent {
          color: #00d4aa;
        }
      }
    }

    .topbar-actions {
      display: flex;
      gap: 8px;
      align-items: center;

      .coords-status {
        font-size: 11px;
        color: #f87171;
        max-width: 280px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        &.ok { color: #4ade80; }
      }
    }

    .btn-action {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 6px 14px;
      background: rgba(255,255,255,0.04);
      border: 1.5px solid #1e293b;
      border-radius: 6px;
      color: #94a3b8;
      font-family: inherit;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.15s;
      letter-spacing: 0.2px;

      &:hover {
        border-color: #00d4aa;
        color: #00d4aa;
        background: rgba(0,212,170,0.06);
      }

    }

    .btn-export {
      background: rgba(16,185,129,0.08);
      border-color: rgba(16,185,129,0.35);
      color: #10b981;
      &:hover { background: rgba(16,185,129,0.20); border-color: #10b981; color: #10b981; }
    }

    /* ── Main Layout ── */
    .main-layout {
      flex: 1;
      display: flex;
      overflow: hidden;
      min-height: 0;
    }

    .pane {
      height: 100%;
      overflow: hidden;
      min-width: 0;
    }

    .pane-pdf {
      flex-shrink: 0;
    }

    .pane-fields {
      flex: 1;
      min-width: 320px;
      max-width: 500px;
    }

    /* ── Resize Handle ── */
    .resize-handle {
      width: 6px;
      cursor: col-resize;
      background: #0d1b2a;
      border-left: 1px solid rgba(255,255,255,0.06);
      border-right: 1px solid rgba(255,255,255,0.06);
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background 0.15s;
      flex-shrink: 0;

      &:hover {
        background: rgba(0,212,170,0.1);
        .handle-line { background: #00d4aa; }
      }

      .handle-line {
        width: 2px;
        height: 40px;
        background: #1e293b;
        border-radius: 2px;
        transition: background 0.15s;
      }
    }
  `],
})
export class AppComponent implements OnInit {
  @ViewChild('pdfViewer') pdfViewer!: PdfViewerComponent;

  pdfSrc = signal<string | Uint8Array>('');
  currentPdfName = signal<string>('');

  leftWidth = 65;

  private isResizing = false;
  private resizeStartX = 0;
  private resizeStartWidth = 0;

  // Demo PDF - replace with actual src
  private readonly DEMO_PDF = 'assets/sample.pdf';

  constructor(
    public captureService: PdfCaptureService,
    private http: HttpClient,
    public thumbnailCatSvc: ThumbnailCategoryService,
  ) {}

  ngOnInit() {
    // Load default PDF and set its base name for coord matching
    this.pdfSrc.set(this.DEMO_PDF);
    const defaultName = this.DEMO_PDF.replace(/^assets\//, '').replace(/\.pdf$/i, '');
    this.currentPdfName.set(defaultName);
    // Silently load word index for the default PDF (500ms delay — viewer not ready yet)
    setTimeout(() => this.loadWordIndexSilently(defaultName), 500);
  }



  onWordCaptured(word: CapturedWordPayload) {
    this.captureService.storeRawCapture(word);
  }

  onBoxCaptured(payload: CapturedWordPayload) {
    this.captureService.storeRawCapture(payload);
  }

  /**
   * Called when user clicks "✓ Confirm" on the field card.
   * THIS is the moment the green highlight appears and the JSON is updated.
   */
  onConfirmCapture() {
    this.captureService.confirmCapture();
    // Now update highlights — capturedWord is set, effect will fire scheduleRedraw.
    setTimeout(() => this.pdfViewer?.scheduleRedraw(), 30);
  }

  onThumbnailDrawn(event: { pageNumber: number; thumbnail: HTMLElement }): void {
    // Primary path: event from ngx thumbnailDrawn — stamp individual thumbnail
    this.thumbnailCatSvc.stampThumbnail(event.pageNumber, event.thumbnail);
  }

  /** Called after all pages initialised — schedule fallback stamp runs */
  private scheduleThumbnailStamps(): void {
    // Stamp at multiple intervals — thumbnails render lazily (especially large docs).
    // Safe: stampAllThumbnails is idempotent (skips already-stamped thumbs).
    setTimeout(() => this.thumbnailCatSvc.stampAllThumbnails(), 500);
    setTimeout(() => this.thumbnailCatSvc.stampAllThumbnails(), 1500);
    setTimeout(() => this.thumbnailCatSvc.stampAllThumbnails(), 3500);
  }

  onFieldFocused(_fieldId: string) { /* no-op — fields panel removed */ }

  onGoToWord(item: CaptureItem) {
    this.captureService.setActiveField(item.id);
    this.pdfViewer?.navigateToPage(item.page);
  }

  clearAllFields() {
    this.captureService.fields().slice().forEach(f => this.captureService.deleteCapture(f.id));
    this.pdfViewer?.loadWordIndex(null);
    this.pdfViewer?.scheduleRedraw();
  }



  /** Called when the viewer's native open button loads a new PDF */
  onSrcChange(event: string | Uint8Array): void {
    this.pdfViewer?.loadWordIndex(null);
  }

  /**
   * Load a PDF from a URL as binary and set it into the viewer.
   * Use this when you need to load a PDF that requires auth headers,
   * or when you have a URL that returns raw PDF bytes.
   *
   * Usage: this.loadPdfBinary('https://api.example.com/docs/123')
   *        this.loadPdfBinary('/api/report', 'report.pdf')
   */
  loadPdfBinary(url: string, filename?: string): void {
    // No generic parameter — TypeScript infers ArrayBuffer from responseType overload
    this.http.get(url, { responseType: 'arraybuffer' as const }).subscribe({
      next: (buffer: ArrayBuffer) => {
        this.pdfSrc.set(new Uint8Array(buffer));
        // If caller provides filename, trigger word index + coord lookup
        if (filename) {
          this.onPdfNameChange(filename);
        }
      },
      error: (err) => {
        console.error('Failed to load PDF binary:', err);
      }
    });
  }

  /** Called from the viewer when a file is opened via native toolbar */
  onPdfNameChange(name: string): void {
    // Wire real page dimension getter into service so submit normalisation
    // uses actual PDF.js page sizes instead of the standard size fallback list.
    this.captureService._getPageDimsFn =
      (page: number) => this.pdfViewer?.getPageDimensionsPt(page) ?? null;

    const base = name.split('/').pop()?.split('\\').pop() ?? name;
    const baseName = base.replace(/\.pdf$/i, '');

    // Only reset everything if this is actually a NEW PDF (name changed)
    const isNewPdf = baseName !== this.currentPdfName();
    this.currentPdfName.set(baseName);

    if (isNewPdf) {
      this._loadingForPdf = '';

      this.pdfViewer?.loadWordIndex(null);
      // Load category JSON for thumbnail sidebar — only when PDF changes
      this.loadCategoryJsonSilently(baseName);
      // Schedule fallback stamp runs after thumbnails have had time to render
      this.scheduleThumbnailStamps();
    }

    // Always try to load word index (handles both new PDF and retry on same PDF).
    this.loadWordIndexSilently(baseName);

    // Try to load pre-captured fields JSON (e.g. assets/invoice_captured_fields.json).
    // If found: fields get pre-populated with values + grey highlights immediately.
    if (isNewPdf) this.loadCapturedFieldsSilently(baseName);
  }

  /**
   * Silently load assets/{baseName}_word_index.json and pass it to the viewer.
   *
   * The word index replaces PDF.js text layer spans with custom JSON-positioned
   * spans for precise click2pick / box-select on every word.
   *
   * Accepted file formats (auto-detected, all normalised to 0-1 fractions):
   *
   * FORMAT 1 — pdfplumber native (already fractional):
   *   { "version":1, "pages": { "1": [{t,x,y,w,h}, ...] } }
   *   Values are 0-1 fractions → passed to loadWordIndex() as-is.
   *
   * FORMAT 2 — flat entry array with any coord style:
   *   [ { "text":"Word", "page":1, "x":0.17, "y":0.12, "width":0.04, "height":0.015 } ]
   *   [ { "text":"Word", "page":1, "bbox":[0.17,0.12,0.04,0.015] } ]
   *   [ { "text":"Word", "page":1, "rectangle":[72,140,144,155], "pageWidth":595, "pageHeight":842 } ]
   *   Flat arrays are normalised then re-packed into the pdfplumber page-map format.
   *
   * Silent: no user-visible status — logs to console only.
   */
  private _loadingForPdf = '';
  private loadWordIndexSilently(baseName: string): void {
    if (!baseName) return;
    if (this._loadingForPdf === baseName) return;
    this._loadingForPdf = baseName;

    const url = `assets/${baseName}_word_index.json`;
    this.http.get<any>(url).subscribe({
      next: (data) => {
        this._loadingForPdf = '';
        const wi = this._normaliseWordIndex(data, baseName);
        this.pdfViewer?.loadWordIndex(wi);
        console.log('[WORD-INDEX] Loaded', url);
      },
      error: () => {
        this._loadingForPdf = '';
        this.pdfViewer?.loadWordIndex(null);
        console.log('[WORD-INDEX] Not found:', url, '(PDF.js text layer used instead)');
      },
    });
  }

  /**
   * Normalise any word-index format into the pdfplumber page-map structure:
   *   { version:1, pages:{ "1":[{t,x,y,w,h},...], "2":[...] } }
   *
   * Supports all three coord formats (values may be fractions 0-1 or absolute pts):
   *   flat:      { text|t, page, x, y, width|w, height|h }
   *   bbox:      { text|t, page, bbox:[x,y,w,h] }
   *   rectangle: { text|t, page, rectangle:[x,y,w,h] }  (may be [x1,y1,x2,y2] or [x,y,w,h])
   *
   * Absolute coords (values > 1) are auto-normalised using:
   *   1. Per-item pageWidth/pageHeight if present
   *   2. Smallest standard PDF page size that fits all content on that page
   *   3. PDF.js real page dimensions via getPageDimensionsPt()
   */
  private _normaliseWordIndex(
    data: any,
    baseName: string,
  ): { version: number; pages: Record<string, Array<{t:string;x:number;y:number;w:number;h:number}>> } {

    // ── Already in pdfplumber format? Pass through with fractional check ─────
    if (data && typeof data === 'object' && !Array.isArray(data) && data.pages) {
      return data as any;
    }

    // ── Flat array format — normalise each entry ──────────────────────────────
    if (!Array.isArray(data) || !data.length) {
      return { version: 1, pages: {} };
    }

    // Standard PDF page sizes in points for absolute coord inference
    const STD = [
      { w: 595.276, h: 841.890 }, { w: 841.890, h: 595.276 },
      { w: 612,     h: 792     }, { w: 792,     h: 612     },
      { w: 612,     h: 1008    }, { w: 1008,    h: 612     },
      { w: 841.890, h:1190.551 }, { w:1190.551, h: 841.890 },
      { w: 792,     h: 1224    }, { w: 1224,    h: 792     },
    ];

    // ── Pass 1: compute per-page max content extent (for abs coord inference) ─
    const pageDims = new Map<number, { w: number; h: number }>();
    for (const item of data) {
      const pg  = Number(item.page ?? 1);
      const ipw = Number(item.pageWidth ?? item.pagewidth ?? 0);
      const iph = Number(item.pageHeight ?? item.pageheight ?? 0);
      if (ipw > 1 && iph > 1) { pageDims.set(pg, { w: ipw, h: iph }); continue; }
      const [rx, ry, rw, rh] = this._extractRawCoords(item);
      const x2 = rx + rw, y2 = ry + rh;
      const cur = pageDims.get(pg);
      pageDims.set(pg, { w: Math.max(cur?.w ?? 0, x2), h: Math.max(cur?.h ?? 0, y2) });
    }

    // ── Infer standard page size from max extent per page ─────────────────────
    const inferSize = (maxX2: number, maxY2: number): { w: number; h: number } => {
      if (maxX2 <= 1 && maxY2 <= 1) return { w: 1, h: 1 }; // already fractional
      const fitting = STD.filter(s => maxX2 <= s.w && maxY2 <= s.h);
      if (!fitting.length) return { w: maxX2, h: maxY2 };
      const a4 = fitting.find(s => Math.abs(s.w - 595.276) < 1);
      return a4 ?? fitting.reduce((b, s) => s.w * s.h < b.w * b.h ? s : b);
    };

    const pageSizes = new Map<number, { w: number; h: number }>();
    pageDims.forEach((dims, pg) => pageSizes.set(pg, inferSize(dims.w, dims.h)));

    // ── Pass 2: normalise every entry to {t,x,y,w,h} fractions ───────────────
    const pages: Record<string, Array<{t:string;x:number;y:number;w:number;h:number}>> = {};

    for (const item of data) {
      const pg    = Number(item.page ?? 1);
      const text  = String(item.text ?? item.t ?? item.label ?? '');
      if (!text) continue;

      let [rx, ry, rw, rh] = this._extractRawCoords(item);

      // Normalise absolute coords
      if (rx > 1 || ry > 1 || rw > 1 || rh > 1) {
        const size = pageSizes.get(pg) ?? { w: 595.276, h: 841.890 };
        // Also try PDF.js real dimensions
        const real = this.pdfViewer?.getPageDimensionsPt(pg);
        const pw   = real?.widthPt  ?? size.w;
        const ph   = real?.heightPt ?? size.h;
        rx /= pw; ry /= ph; rw /= pw; rh /= ph;
      }

      const key = String(pg);
      if (!pages[key]) pages[key] = [];
      pages[key].push({
        t: text,
        x: Math.min(1, Math.max(0, rx)),
        y: Math.min(1, Math.max(0, ry)),
        w: Math.min(1, Math.max(0, rw)),
        h: Math.min(1, Math.max(0, rh)),
      });
    }

    return { version: 1, pages };
  }

  /** Extract raw [x,y,w,h] from any coord format (flat / bbox / rectangle) */
  private _extractRawCoords(item: any): [number, number, number, number] {
    // rectangle format: [x,y,w,h] or [x1,y1,x2,y2]
    if (Array.isArray(item.rectangle) && item.rectangle.length === 4) {
      const [a, b, c, d] = item.rectangle.map(Number);
      // Distinguish [x,y,w,h] from [x1,y1,x2,y2]: if c>a and d>b and both >1 → x2,y2
      if ((a > 1 || b > 1 || c > 1 || d > 1) && c > a && d > b) {
        return [a, b, c - a, d - b];
      }
      return [a, b, c, d];
    }
    // bbox format: [x,y,w,h]
    if (Array.isArray(item.bbox) && item.bbox.length === 4) {
      const [a, b, c, d] = item.bbox.map(Number);
      return [a, b, c, d];
    }
    // flat format: x, y, width/w, height/h
    return [
      Number(item.x      ?? 0),
      Number(item.y      ?? 0),
      Number(item.width  ?? item.w ?? 0),
      Number(item.height ?? item.h ?? 0),
    ];
  }

  // ── Captured Fields JSON ──────────────────────────────────────────────────

  /**
   * Try to load assets/{baseName}_captured_fields.json.
   * Accepts two coord formats:
   *   A) flat: { value, x, y, width, height, page }         — already 0-1 fractions
   *   B) bbox: { value, page, bbox:[x,y,w,h] }              — 0-1 fractions
   *   C) abs:  { value, x, y, width, height, page }         — absolute pts (auto-normalised)
   *            with optional pageWidth/pageHeight fields
   */
  private loadCapturedFieldsSilently(baseName: string): void {
    const url = `assets/${baseName}_captured_fields.json`;
    this.http.get<CapturedFieldJson[]>(url).subscribe({
      next: (data) => {
        if (!Array.isArray(data) || !data.length) return;
        const normalised = data
          .filter(f => f.value && (f.id || f.label))
          .map(f => this.normaliseCapturedField(f, data));
        if (normalised.length) {
          this.captureService.loadCapturedFieldsFromJson(normalised);
          setTimeout(() => this.pdfViewer?.scheduleRedraw(), 50);
        }
      },
      error: () => { /* no captured_fields.json — silent, normal */ },
    });
  }

  /**
   * Normalise a single captured-field JSON entry to 0-1 fractional coords.
   * Supports 3 coord formats — format is detected and stored for round-trip export:
   *   'flat'      → { x, y, width, height, page, label, value }
   *   'bbox'      → { bbox:[x,y,w,h], page, label, value }
   *   'rectangle' → { rectangle:[x,y,w,h], page, label, value }
   */
  private normaliseCapturedField(
    f: CapturedFieldJson,
    allFields: CapturedFieldJson[]
  ): { id: string; label: string; value: string; page: number;
       x: number; y: number; width: number; height: number;
       sourceFormat: CapturedFieldFormat } {
    const id    = f.id    || f.label || '';
    const label = f.label || f.id    || '';
    const value = f.value || '';
    const page  = Number(f.page ?? 1);

    // Detect coord format and extract raw values
    let rx: number, ry: number, rw: number, rh: number;
    let sourceFormat: CapturedFieldFormat;

    if (f.rectangle && Array.isArray(f.rectangle) && f.rectangle.length === 4) {
      // Format C: { rectangle:[x,y,w,h] }
      [rx, ry, rw, rh] = f.rectangle.map(Number);
      sourceFormat = 'rectangle';
    } else if (f.bbox && Array.isArray(f.bbox) && f.bbox.length === 4) {
      // Format B: { bbox:[x,y,w,h] }
      [rx, ry, rw, rh] = f.bbox.map(Number);
      sourceFormat = 'bbox';
    } else {
      // Format A: flat { x, y, width, height }
      rx = Number(f.x      ?? 0);
      ry = Number(f.y      ?? 0);
      rw = Number(f.width  ?? 0);
      rh = Number(f.height ?? 0);
      sourceFormat = 'flat';
    }

    // If values > 1: absolute pts — need page dimensions to normalise
    if (rx > 1 || ry > 1 || rw > 1 || rh > 1) {
      let pw = Number(f.pageWidth ?? f.pagewidth ?? 0);
      let ph = Number(f.pageHeight ?? f.pageheight ?? 0);

      // Priority 1: explicit pageWidth/pageHeight in the JSON entry
      // Priority 2: real dims from PDF.js (accurate for any paper size/DPI)
      // Priority 3: infer from max content extent + standard size list (fallback only)
      if (pw <= 1 || ph <= 1) {
        const realDims = this.pdfViewer?.getPageDimensionsPt(page);
        if (realDims) {
          pw = realDims.widthPt;
          ph = realDims.heightPt;
        } else {
          // Fallback: infer from max content extent across all fields on same page,
          // then match against standard PDF page sizes (points, per ISO 216 / ANSI).
          // This covers A4, Letter, Legal, A3, B4, Tabloid etc.
          const STD: [number, number][] = [
            [595.276, 841.890],  // A4 portrait
            [841.890, 595.276],  // A4 landscape
            [612,     792    ],  // US Letter portrait
            [792,     612    ],  // US Letter landscape
            [612,     1008   ],  // US Legal portrait
            [1008,    612    ],  // US Legal landscape
            [841.890, 1190.55],  // A3 portrait
            [1190.55, 841.890],  // A3 landscape
            [708.661, 1000.63],  // B4 portrait
            [792,     1224   ],  // US Tabloid portrait
            [1224,    792    ],  // US Tabloid landscape
          ];
          const pageFlds = allFields.filter(o => Number(o.page ?? 1) === page);
          let maxX2 = 0, maxY2 = 0;
          for (const o of pageFlds) {
            const coords = o.rectangle ?? o.bbox;
            const ox = coords ? coords[0] + coords[2] : Number(o.x ?? 0) + Number(o.width ?? 0);
            const oy = coords ? coords[1] + coords[3] : Number(o.y ?? 0) + Number(o.height ?? 0);
            if (ox > maxX2) maxX2 = ox;
            if (oy > maxY2) maxY2 = oy;
          }
          const fitting = STD.filter(([w, h]) => maxX2 <= w && maxY2 <= h);
          const a4 = fitting.find(([w]) => Math.abs(w - 595.276) < 1);
          const best = a4
            ?? (fitting.length
              ? fitting.reduce((b, s) => s[0] * s[1] < b[0] * b[1] ? s : b)
              : [maxX2 || 612, maxY2 || 792] as [number, number]);
          [pw, ph] = best;
        }
      }
      rx /= pw; ry /= ph; rw /= pw; rh /= ph;
    }

    return {
      id, label, value, page, sourceFormat,
      x: Math.min(1, Math.max(0, rx)),
      y: Math.min(1, Math.max(0, ry)),
      width:  Math.min(1, Math.max(0, rw)),
      height: Math.min(1, Math.max(0, rh)),
    };
  }

  /**
   * Load assets/{baseName}_categories.json for thumbnail sidebar labels.
   * File format:
   * {
   *   "categories": [
   *     { "pages": [1,2,3], "label": "Invoice",   "color": "blue"  },
   *     { "pages": [4,5],   "label": "Form 15CA", "color": "teal"  },
   *     { "pages": [6],     "label": "Form 15CB"                    }
   *   ]
   * }
   * color is optional — auto-assigned from palette if absent.
   */
  private loadCategoryJsonSilently(baseName: string): void {
    const url = `assets/${baseName}_categories.json`;
    this.http.get<CategoryConfig>(url).subscribe({
      next: (data) => {
        if (!data?.categories?.length) return;
        this.thumbnailCatSvc.load(data);
        console.log('[CATEGORY] Loaded from', url);
      },
      error: () => {
        // No categories file — clear any previous categories silently
        this.thumbnailCatSvc.clear();
      },
    });
  }

  /**
   * Download all current captured fields as JSON.
   * Each field is exported in its ORIGINAL input format:
   *   'rectangle' → { label, value, page, rectangle:[x,y,w,h] }
   *   'bbox'      → { label, value, page, bbox:[x,y,w,h] }
   *   'flat'      → { label, value, page, x, y, width, height }  (default for new captures)
   */
  downloadCapturedFields(): void {
    const data = this.captureService.getCapturedFieldsJson();
    if (!data.length) { alert('No fields captured yet.'); return; }

    const r6 = (n: number) => parseFloat(n.toFixed(6));

    const output = data.map(f => {
      const fmt = f.sourceFormat || 'flat';
      const coords: [number,number,number,number] = [r6(f.x), r6(f.y), r6(f.width), r6(f.height)];

      if (fmt === 'rectangle') {
        return { label: f.label, value: f.value, page: f.page, rectangle: coords };
      }
      if (fmt === 'bbox') {
        return { id: f.id, label: f.label, value: f.value, page: f.page, bbox: coords };
      }
      // Default: flat format (for new captures or original flat input)
      return {
        id:     f.id,
        label:  f.label,
        value:  f.value,
        page:   f.page,
        x:      coords[0],
        y:      coords[1],
        width:  coords[2],
        height: coords[3],
      };
    });

    const blob = new Blob([JSON.stringify(output, null, 2)], { type: 'application/json' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    const name = this.currentPdfName() || 'document';
    a.href     = url;
    a.download = `${name}_captured_fields.json`;
    a.click();
    URL.revokeObjectURL(url);
  }




  // ── Resize Panel ─────────────────────────────────────────────────────────
  startResize(event: MouseEvent) {
    this.isResizing = true;
    this.resizeStartX = event.clientX;
    this.resizeStartWidth = this.leftWidth;

    const onMove = (e: MouseEvent) => {
      if (!this.isResizing) return;
      const delta = e.clientX - this.resizeStartX;
      const totalW = window.innerWidth;
      const newW = this.resizeStartWidth + (delta / totalW) * 100;
      this.leftWidth = Math.max(35, Math.min(75, newW));
    };

    const onUp = () => {
      this.isResizing = false;
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
    };

    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
    event.preventDefault();
  }
}