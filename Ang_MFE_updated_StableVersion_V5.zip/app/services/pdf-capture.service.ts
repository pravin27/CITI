import { Injectable, signal, computed } from '@angular/core';
import { WordCoordinate, HighlightRect } from '../models/pdf-capture.models';

/** A single word capture — may or may not have id/label yet */
export interface CaptureItem {
  id:     string;   // empty until user provides it
  label:  string;   // empty until user provides it
  value:  string;   // the captured word text
  page:   number;
  x:      number;
  y:      number;
  width:  number;
  height: number;
  sourceFormat?: string;
  fromJson?: boolean;
}

@Injectable({ providedIn: 'root' })
export class PdfCaptureService {

  // ── Signals ────────────────────────────────────────────────────────────────
  /** All confirmed captures (id+label present) — drive green/grey highlights */
  readonly fields = signal<CaptureItem[]>([]);

  /** Last raw click/box capture — shown in JSON log, awaiting id+label submission */
  readonly lastRawCapture = signal<CaptureItem | null>(null);

  readonly externalCoords = signal<WordCoordinate[]>([]);
  readonly click2pickMode = signal<boolean>(false);
  readonly activeFieldId  = signal<string | null>(null);

  // ── Computed highlights ────────────────────────────────────────────────────
  readonly highlightIndex = computed<Map<number, HighlightRect[]>>(() => {
    const index = new Map<number, HighlightRect[]>();
    const add = (page: number, rect: HighlightRect) => {
      let arr = index.get(page);
      if (!arr) { arr = []; index.set(page, arr); }
      arr.push(rect);
    };
    for (const c of this.externalCoords()) {
      add(c.page, { page:c.page, x:c.x, y:c.y, width:c.width, height:c.height,
                    type:'external', label:c.text });
    }
    for (const f of this.fields()) {
      add(f.page, { page:f.page, x:f.x, y:f.y, width:f.width, height:f.height,
                    type:'primary', fieldId:f.id, label:f.label });
    }
    return index;
  });

  readonly fieldTextIndex = computed<Map<string, string>>(() => {
    const m = new Map<string, string>();
    for (const f of this.fields()) {
      m.set(f.id, f.value.toLowerCase());
    }
    return m;
  });

  readonly activeWordText = computed<string | null>(() => {
    const id = this.activeFieldId();
    if (!id) return null;
    return this.fields().find(f => f.id === id)?.value?.toLowerCase() ?? null;
  });

  readonly allHighlights = computed<HighlightRect[]>(() => {
    const all: HighlightRect[] = [];
    this.highlightIndex().forEach(rects => all.push(...rects));
    return all;
  });

  getHighlightsForPage(page: number): HighlightRect[] {
    return this.highlightIndex().get(page) ?? [];
  }

  // ── Raw capture (click / dblclick / box) ──────────────────────────────────
  /**
   * Called on every click2pick / dblclick / box-select.
   * Stores the raw capture (id='', label='') for display in the JSON log.
   * Does NOT create a highlight — user must submit id+label first.
   */
  storeRawCapture(word: {
    text: string; page: number;
    x: number; y: number; width: number; height: number;
  }): void {
    const item: CaptureItem = {
      id: '', label: '', value: word.text,
      page: word.page, x: word.x, y: word.y,
      width: word.width, height: word.height,
    };
    this.lastRawCapture.set(item);

    console.group('%c[RAW CAPTURE] storeRawCapture()', 'color:#06b6d4;font-weight:bold;font-size:13px');
    console.log('Function:  storeRawCapture(word)');
    console.log('Param:', JSON.stringify(item, null, 2));
    console.log('Status: pending — no id/label yet, not highlighted');
    console.groupEnd();
  }

  /**
   * Process a parsed JSON object from the free-text submission textarea.
   *
   * Rules:
   *   • No id OR no label → REJECT (console.warn, return 'rejected')
   *   • Has id+label, has valid coords (any of x/y/width/height or bbox or rectangle
   *     with at least one non-zero value) → ADD or REPLACE existing by id
   *   • Has id+label but NO coords / empty coords → DELETE matching id
   *
   * Returns: 'added' | 'replaced' | 'deleted' | 'rejected'
   */
  submitCapture(parsed: Record<string, any>): 'added' | 'replaced' | 'deleted' | 'rejected' {
    const id    = String(parsed['id']    ?? '').trim();
    const label = String(parsed['label'] ?? '').trim();

    if (!id || !label) {
      console.warn('[SUBMIT] Rejected — id and label are both required. Got:', parsed);
      return 'rejected';
    }

    // ── Detect coord format ────────────────────────────────────────────────
    const hasCoords = this._parsedHasCoords(parsed);

    if (!hasCoords) {
      // ── DELETE path ───────────────────────────────────────────────────────
      const existing = this.fields().find(f => f.id === id);
      if (!existing) {
        console.warn('[SUBMIT] DELETE — no match found for id="' + id + '"');
        return 'rejected';
      }
      console.group('%c[SUBMIT → DELETE] submitCapture()', 'color:#f87171;font-weight:bold;font-size:13px');
      console.log('Function:  submitCapture(parsed)');
      console.log('Param:', JSON.stringify(parsed, null, 2));
      console.log('Action:    DELETE — id+label present but no valid coords');
      console.log('Removing:', JSON.stringify(existing, null, 2));
      console.groupEnd();
      this.fields.update(items => items.filter(f => f.id !== id));
      if (this.activeFieldId() === id) this.activeFieldId.set(null);
      Promise.resolve().then(() => this.logCapturedState('DELETE', `id="${id}" removed`));
      return 'deleted';
    }

    // ── ADD / REPLACE path ────────────────────────────────────────────────
    // Normalise coords from whatever format is present
    const normalised = this._normaliseSubmitCoords(parsed);
    const raw = this.lastRawCapture();

    const item: CaptureItem = {
      id,
      label,
      value:        String(parsed['value'] ?? raw?.value ?? ''),
      page:         this._toNum(parsed['page'] ?? raw?.page ?? 1) || 1,
      x:            normalised.x,
      y:            normalised.y,
      width:        normalised.width,
      height:       normalised.height,
      sourceFormat: normalised.sourceFormat,
      fromJson:     false,
    };

    const existing  = this.fields().find(f => f.id === id);
    const op        = existing ? 'replaced' : 'added';
    const opLabel   = existing ? 'REPLACE' : 'ADD';

    console.group(`%c[SUBMIT → ${opLabel}] submitCapture()`, 'color:#00c864;font-weight:bold;font-size:13px');
    console.log('Function:  submitCapture(parsed)');
    console.log('Param:', JSON.stringify(parsed, null, 2));
    console.log('Action:   ', opLabel, '— normalised item:', JSON.stringify(item, null, 2));
    console.groupEnd();

    this.fields.update(items => [...items.filter(f => f.id !== id), item]);
    this.activeFieldId.set(id);
    this.lastRawCapture.set(null);

    Promise.resolve().then(() =>
      this.logCapturedState(existing ? 'UPDATE' : 'ADD',
        `id="${id}" label="${label}" value="${item.value}"`)
    );
    return op;
  }

  /** True when the parsed object carries at least one non-zero/non-empty coord value */
  /**
   * Safely convert any coord value to a number.
   * Handles: number, numeric string "1" / "0.5", empty string "", null, undefined.
   *   ""  / null / undefined → 0   (treated as absent → DELETE path)
   *   "1" / "0.5" / 50      → the numeric value (ADD/REPLACE path)
   */
  private _toNum(v: any): number {
    if (v === null || v === undefined) return 0;
    if (typeof v === 'string') {
      const s = v.trim();
      if (s === '') return 0;          // empty string → 0
      const n = Number(s);
      return isNaN(n) ? 0 : n;        // "1" → 1, "0.5" → 0.5, "abc" → 0
    }
    const n = Number(v);
    return isNaN(n) ? 0 : n;
  }

  private _parsedHasCoords(p: Record<string, any>): boolean {
    // rectangle: [x,y,w,h] — any element non-zero means coords are present
    if (Array.isArray(p['rectangle']) && p['rectangle'].length === 4) {
      return p['rectangle'].some((v: any) => this._toNum(v) !== 0);
    }
    // bbox: [x,y,w,h]
    if (Array.isArray(p['bbox']) && p['bbox'].length === 4) {
      return p['bbox'].some((v: any) => this._toNum(v) !== 0);
    }
    // flat: x, y, width, height
    const flatKeys = ['x', 'y', 'width', 'height'];
    const present  = flatKeys.some(k => k in p);
    if (!present) return false;
    // All absent/empty/zero → no coords → DELETE
    return flatKeys.some(k => this._toNum(p[k]) !== 0);
  }

  /** Normalise coords from any supported format to {x,y,width,height} fractions */
  private _normaliseSubmitCoords(p: Record<string, any>): {
    x: number; y: number; width: number; height: number; sourceFormat: string;
  } {
    let rx: number, ry: number, rw: number, rh: number, fmt: string;

    if (Array.isArray(p['rectangle']) && p['rectangle'].length === 4) {
      [rx, ry, rw, rh] = p['rectangle'].map((v: any) => this._toNum(v));
      fmt = 'rectangle';
    } else if (Array.isArray(p['bbox']) && p['bbox'].length === 4) {
      [rx, ry, rw, rh] = p['bbox'].map((v: any) => this._toNum(v));
      fmt = 'bbox';
    } else {
      rx = this._toNum(p['x']);
      ry = this._toNum(p['y']);
      rw = this._toNum(p['width']);
      rh = this._toNum(p['height']);
      fmt = 'flat';
    }

    // Absolute pts (> 1) — normalise using page dimensions
    if (rx > 1 || ry > 1 || rw > 1 || rh > 1) {
      let normW = this._toNum(p['pageWidth'] ?? p['pagewidth']);
      let normH = this._toNum(p['pageHeight'] ?? p['pageheight']);

      // Priority 1: explicit pageWidth/pageHeight in the submitted object
      // Priority 2: real dims from PDF.js via injected getter (set externally)
      // Priority 3: standard size inference (extended list covers A3, B4, Tabloid etc.)
      if (normW <= 1 || normH <= 1) {
        const realDims = this._getPageDimsFn ? this._getPageDimsFn(this._toNum(p['page'] ?? 1)) : null;
        if (realDims) {
          normW = realDims.widthPt;
          normH = realDims.heightPt;
        } else {
          const x2 = rx + rw, y2 = ry + rh;
          const STD: [number,number][] = [
            [595.276, 841.890], [841.890, 595.276],
            [612, 792],         [792, 612],
            [612, 1008],        [1008, 612],
            [841.890, 1190.55], [1190.55, 841.890],
            [708.661, 1000.63], [792, 1224], [1224, 792],
          ];
          const fitting = STD.filter(([w,h]) => x2 <= w && y2 <= h);
          const a4 = fitting.find(([w]) => Math.abs(w - 595.276) < 1);
          const best = a4 ?? (fitting.length
            ? fitting.reduce((b,s) => s[0]*s[1]<b[0]*b[1]?s:b)
            : [Math.max(x2,612), Math.max(y2,792)] as [number,number]);
          [normW, normH] = best;
        }
      }
      rx /= normW; ry /= normH; rw /= normW; rh /= normH;
    }

    return {
      x:      Math.min(1, Math.max(0, rx)),
      y:      Math.min(1, Math.max(0, ry)),
      width:  Math.min(1, Math.max(0, rw)),
      height: Math.min(1, Math.max(0, rh)),
      sourceFormat: fmt,
    };
  }

  /** Remove one confirmed capture by id */
  deleteCapture(id: string): void {
    const existing = this.fields().find(f => f.id === id);
    console.group('%c[DELETE CAPTURE] deleteCapture()', 'color:#f87171;font-weight:bold;font-size:13px');
    console.log('Function:  deleteCapture(id)');
    console.log('Param — id:', id);
    console.log('Removed:', existing ? JSON.stringify(existing, null, 2) : '(not found)');
    console.groupEnd();

    this.fields.update(items => items.filter(f => f.id !== id));
    if (this.activeFieldId() === id) this.activeFieldId.set(null);

    Promise.resolve().then(() =>
      this.logCapturedState('DELETE', `id="${id}" removed`)
    );
  }

  /** Load pre-captured fields from _captured_fields.json */
  loadCapturedFieldsFromJson(jsonFields: Array<{
    id: string; label: string; value: string;
    page: number; x: number; y: number; width: number; height: number;
    sourceFormat?: string;
  }>): void {
    const items: CaptureItem[] = jsonFields
      .filter(f => f.value && f.id && f.label)
      .map(f => ({ ...f, fromJson: true }));

    // Merge: keep existing items not present in JSON, add/replace JSON items
    this.fields.update(existing => {
      const jsonIds = new Set(items.map(i => i.id));
      return [...existing.filter(e => !jsonIds.has(e.id)), ...items];
    });

    console.log('[LOAD] loadCapturedFieldsFromJson — loaded', items.length, 'items from JSON');
  }

  /** Export all confirmed captures as JSON */
  getCapturedFieldsJson(): Array<CaptureItem & { fromJson: boolean; sourceFormat: string }> {
    return this.fields().map(f => ({
      ...f,
      fromJson:     !!f.fromJson,
      sourceFormat: f.sourceFormat || 'flat',
    }));
  }

  // ── Legacy compat (viewer uses these) ──────────────────────────────────────
  initFields(_f: any[]) { /* no-op — fields now managed by storeRawCapture/submitCapture */ }
  setActiveField(id: string | null) { this.activeFieldId.set(id); }
  getActiveField() { return this.fields().find(f => f.id === this.activeFieldId()) ?? null; }
  clearField(id: string) { this.deleteCapture(id); }
  captureWordToActiveField(_w: any) { /* no-op */ }
  setPendingCapture(word: any) { this.storeRawCapture(word); }
  confirmCapture() { /* handled by submitCapture now */ }
  discardPendingCapture() { this.lastRawCapture.set(null); }
  pendingCapture = signal<any>(null);

  /**
   * Injected by app.component after viewer is ready.
   * Returns real page dimensions in PDF points from PDF.js.
   * Set to null when viewer not available — normalisation falls back to STD list.
   */
  _getPageDimsFn: ((page: number) => { widthPt: number; heightPt: number } | null) | null = null;

  loadExternalCoordinates(coords: WordCoordinate[]) { this.externalCoords.set(coords); }
  toggleClick2PickMode() { this.click2pickMode.update(v => !v); }
  setClick2PickMode(on: boolean) { this.click2pickMode.set(on); }

  // ── Private helpers ────────────────────────────────────────────────────────
  private logCapturedState(op: 'ADD'|'UPDATE'|'DELETE', context: string): void {
    const snap = this.fields().map(f => ({
      id: f.id, label: f.label, value: f.value, page: f.page,
      x: parseFloat(f.x.toFixed(6)), y: parseFloat(f.y.toFixed(6)),
      width: parseFloat(f.width.toFixed(6)), height: parseFloat(f.height.toFixed(6)),
    }));
    const color = op === 'DELETE' ? 'color:#f87171' : 'color:#00c864';
    console.group(`%c[CAPTURED JSON] ${op}: ${context}`, `${color};font-weight:bold;font-size:13px`);
    console.log('Total confirmed captures:', snap.length);
    console.table(snap);
    console.log('Full JSON:', JSON.stringify(snap, null, 2));
    console.groupEnd();
  }
}