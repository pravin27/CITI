# Split & Merge Integration Guide

## Overview

The DocCapture viewer supports a **Split & Merge** mode where the entire viewer is
replaced by an external iframe (your Split & Merge app). When the user clicks the
scissors icon in the toolbar, the viewer hides itself and loads your SM app at full
size. When the SM app is done, it posts a message back and the viewer restores
its previous state.

---

## 1. Enabling the feature

### Step 1 — Set the SM URL in the viewer's environment file

The Split & Merge app URL is configured **inside the viewer** via an environment variable.
The parent app never sends the URL — it is deployment configuration.

**Create `.env` in the viewer project root** (copy from `.env.example`):
```bash
cp .env.example .env
```

**Edit `.env`:**
```env
# URL of your Split & Merge application
VITE_SPLIT_MERGE_URL=https://your-split-merge-app.com

# Optional: restrict parent postMessage origin (default: *)
VITE_PARENT_ORIGIN=https://your-angular-app.com
```

If `VITE_SPLIT_MERGE_URL` is empty, the feature is completely disabled — the icon
will never appear regardless of what the parent sends.

---

### Step 2 — Tell the viewer to show the icon (from parent)

The icon is **hidden by default**. The parent enables it per document load via
`showSplitMerge: true` in the load message. Three ways to enable:

**Option A — in `LOAD_SINGLEDOC`:**
```ts
iframeEl.contentWindow.postMessage({
  type:           'LOAD_SINGLEDOC',
  buffer:         arrayBuffer,
  fileName:       'invoice.pdf',
  showSplitMerge: true,   // ← enables the scissors icon
}, '*');
```

**Option B — in `LOAD_MANIFEST`:**
```ts
iframeEl.contentWindow.postMessage({
  type:           'LOAD_MANIFEST',
  showSplitMerge: true,   // ← enables the scissors icon
  documents: [...],
}, '*');
```

**Option C — in `READY_CONFIG`** (applies before any document loads):
```ts
iframeEl.contentWindow.postMessage({
  type:           'READY_CONFIG',
  showSplitMerge: true,
}, '*');
```

| Property        | Type    | Default | Where accepted |
|----------------|---------|---------|----------------|
| `showSplitMerge` | boolean | `false` | `LOAD_SINGLEDOC`, `LOAD_MANIFEST`, `READY_CONFIG` |

> The URL is **never** sent from the parent. It lives in the viewer's `.env` file.

---

## 2. What happens when the user clicks the icon

1. Viewer sets `__doccapture_sm_active = true` — all document-loading events from
   the parent are blocked (see section 4).
2. Viewer hides its own DOM (`display:none`) — state is fully preserved.
3. The SM iframe is shown at full height (toolbar + viewer both hidden).
4. Viewer posts `SPLIT_MERGE_OPEN` to the SM iframe with the current document data.
5. Viewer posts `SPLIT_MERGE_OPENED` to the parent Angular app.

---

## 3. Data sent to the SM iframe (`SPLIT_MERGE_OPEN`)

The viewer sends this message to the SM iframe's `contentWindow` immediately after
showing it:

```ts
{
  type:       'SPLIT_MERGE_OPEN',
  fileName:   'invoice_march.pdf',        // string — current file name
  pageCount:  21,                         // number — total pages
  mode:       'pdf',                      // 'pdf' | 'image' | 'document' | 'spreadsheet'
  buffer:     ArrayBuffer,               // the raw document bytes (transferred zero-copy)
  captures:   CaptureItem[],            // all captured fields currently in the viewer
  categories: Category[],               // category definitions (label, color, pages)
}
```

### How to receive this in your SM app

```ts
// In your Split & Merge app (the iframe)
window.addEventListener('message', (event) => {
  const data = event.data;
  if (data?.type !== 'SPLIT_MERGE_OPEN') return;

  const {
    fileName,    // string
    pageCount,   // number
    mode,        // 'pdf' | 'image' | 'document' | 'spreadsheet'
    buffer,      // ArrayBuffer — the raw document bytes
    captures,    // Array of captured fields
    categories,  // Array of category definitions
  } = data;

  // buffer is transferred — you now own it
  const blob = new Blob([buffer], { type: 'application/pdf' });
  const url  = URL.createObjectURL(blob);
  // Load into your PDF viewer, split/merge UI, etc.
  loadDocument(url, { fileName, pageCount, captures, categories });
});
```

> **Note:** `buffer` is sent via Transferable (zero-copy). Your SM app owns the
> ArrayBuffer after receipt. The viewer keeps its own copy for display purposes.

---

## 4. Events blocked while SM mode is active

While `__doccapture_sm_active = true`, the viewer ignores these events from the parent:

| Blocked event     | Reason |
|------------------|--------|
| `LOAD_SINGLEDOC` | Parent may be sending this to the SM iframe — viewer must not intercept |
| `LOAD_MANIFEST`  | Same |
| `DOC_RESPONSE`   | Same |
| `SET_CAPTURES`   | Same |
| `RESET_VIEWER`   | Would clear viewer state while user is in SM mode |
| `DELETE_CAPTURE` | Same |
| `CAPTURE_ACK`    | Same |

These events **still pass through** while SM is active:
`READY_CONFIG`, `HIGHLIGHT`, `SPLIT_MERGE_SAVE`, `SPLIT_MERGE_EXIT`

---

## 5. Returning from SM mode

Your SM app posts one of these messages to close SM mode:

### Save (document changed)
```ts
// Post from inside the SM iframe
window.parent.postMessage({
  type:     'SPLIT_MERGE_SAVE',
  buffer:   newArrayBuffer,     // optional — the modified document bytes
  fileName: 'invoice_split.pdf', // optional — new file name
}, '*');
```
The viewer will:
1. Hide the SM iframe
2. Show itself (same page, zoom, captures)
3. If `buffer` is provided: reload the document from the new bytes
4. Resume listening to all parent events
5. Post `SPLIT_MERGE_SAVED` to the parent Angular app

### Exit (no changes)
```ts
window.parent.postMessage({ type: 'SPLIT_MERGE_EXIT' }, '*');
```
The viewer restores its previous state unchanged and posts `SPLIT_MERGE_EXITED`
to the parent Angular app.

---

## 6. Events forwarded to parent Angular app

| Event type           | When                                      | Payload |
|---------------------|-------------------------------------------|---------|
| `SPLIT_MERGE_OPENED` | SM mode activated                         | `{ type, fileName }` |
| `SPLIT_MERGE_SAVED`  | SM saved — doc may have changed           | `{ type, fileName? }` |
| `SPLIT_MERGE_EXITED` | SM dismissed without changes              | `{ type }` |

```ts
// In Angular — listen for these
this.viewer.smOpened$.subscribe(() => { /* SM is now active */ });
this.viewer.smSaved$.subscribe(({ fileName }) => { /* doc was changed */ });
this.viewer.smExited$.subscribe(() => { /* no changes */ });
```

---

## 7. postMessage origin configuration

Currently the viewer accepts messages from `'*'` (any origin). To restrict:

In `useEventBridge.ts`, find `ALLOWED_ORIGIN` and update it, or make it configurable
via environment variable:

```ts
// src/hooks/useEventBridge.ts — top of file
const ALLOWED_SM_ORIGIN = import.meta.env.VITE_SM_ORIGIN ?? '*';
```

Then in the SM message listener in `App.tsx`:
```ts
if (event.origin !== ALLOWED_SM_ORIGIN && ALLOWED_SM_ORIGIN !== '*') return;
```

---

## 8. Icon position reference

The scissors icon appears in the toolbar **right side, first position** — before
rotation, before download/print. It uses the same `shrink-0` class as the rotation
icons so it is **always visible and never collapses into the ⋮ overflow menu**,
regardless of screen width.

```
[≡] [🔍] | [⟨] [1/21] [⟩] |    Page Fit ▾    | [✂] | [↺] [↻] | [⬇] [🖨] [✏]
                                                  ^^^
                                          Split & Merge (scissors)
                                          Always visible, amber tint
```

---

## 9. CaptureItem and Category types (for SM app reference)

```ts
interface CaptureItem {
  id:       string;
  label:    string;
  value:    string;
  page:     number;
  x:        number;   // 0-1 fraction of page width
  y:        number;   // 0-1 fraction of page height
  width:    number;
  height:   number;
  color?:   string;
}

interface Category {
  label:  string;
  color?: string;
  pages:  number[];   // 1-based page numbers
}
```
