## Quick manual patch (if not using the script)

In `src/App.tsx`, search for ALL occurrences of:
```
if (meta.categories) setCategories(meta.categories as any);
```

Replace each with:
```ts
if (meta.categories) {
  const PALETTE = ['blue','teal','amber','gray','purple','coral','green','red'];
  const withColors = (meta.categories as any[]).map((cat: any, i: number) => ({
    ...cat,
    color: cat.color ?? PALETTE[i % PALETTE.length],
  }));
  setCategories(withColors as any);
}
```
