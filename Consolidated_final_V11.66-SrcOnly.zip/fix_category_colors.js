// Run this with: node fix_category_colors.js
// Patches all occurrences of the setCategories call in App.tsx
const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, 'src', 'App.tsx');
let src = fs.readFileSync(filePath, 'utf8');

const OLD = `if (meta.categories) setCategories(meta.categories as any);`;
const NEW = `if (meta.categories) {
        // Auto-assign palette colours to categories that have no color.
        // Rotation: blue → teal → amber → gray → purple → coral → green → red
        const PALETTE = ['blue','teal','amber','gray','purple','coral','green','red'];
        const withColors = (meta.categories as any[]).map((cat: any, i: number) => ({
          ...cat,
          color: cat.color ?? PALETTE[i % PALETTE.length],
        }));
        setCategories(withColors as any);
      }`;

const count = (src.match(new RegExp(OLD.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g')) || []).length;
src = src.split(OLD).join(NEW);
fs.writeFileSync(filePath, src);
console.log(`✅ Replaced ${count} occurrence(s) in App.tsx`);
