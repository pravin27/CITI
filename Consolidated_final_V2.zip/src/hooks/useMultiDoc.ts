import { useState, useCallback, useRef } from 'react';
import type {
  DocumentManifest, MultiDocConfig, MultiDocState,
  DocSetItem, ResolvedCategory, ManifestDocument,
} from '../types/multiDoc';
import { totalPagesFromCategories } from '../types/multiDoc';

// ── Data resolution helpers ───────────────────────────────────────────────────

function base64ToUint8Array(b64: string): Uint8Array {
  const raw = b64.startsWith('data:') ? b64.split(',')[1] : b64;
  const bin = atob(raw);
  const arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return arr;
}

async function resolveToUrl(
  doc: DocSetItem,
  manifest: ManifestDocument,
  config: MultiDocConfig,
): Promise<string> {
  // 1. src: relative path, absolute URL, or blob:
  if (manifest.src) {
    if (manifest.src.startsWith('data:')) {
      const arr = base64ToUint8Array(manifest.src);
      return URL.createObjectURL(new Blob([arr.buffer as ArrayBuffer], { type: 'application/pdf' }));
    }
    return manifest.src; // blob: / http / relative — browser handles
  }
  // 2. dataUrl: "data:application/pdf;base64,..."
  if (manifest.dataUrl) {
    const arr = base64ToUint8Array(manifest.dataUrl);
    return URL.createObjectURL(new Blob([arr.buffer as ArrayBuffer], { type: 'application/pdf' }));
  }
  // 3. base64: raw string, no prefix
  if (manifest.base64) {
    const arr = base64ToUint8Array(manifest.base64);
    return URL.createObjectURL(new Blob([arr.buffer as ArrayBuffer], { type: 'application/pdf' }));
  }
  // 4. loadDocumentData() callback — your backend pipeline
  if (config.loadDocumentData) {
    const result = await config.loadDocumentData(doc.id);
    if (typeof result === 'string') {
      if (result.startsWith('blob:') || result.startsWith('http') || result.startsWith('/')) return result;
      const arr = base64ToUint8Array(result);
      return URL.createObjectURL(new Blob([arr.buffer as ArrayBuffer], { type: 'application/pdf' }));
    }
    const bytes = result instanceof Uint8Array ? result : new Uint8Array(result);
    return URL.createObjectURL(new Blob([bytes.buffer as ArrayBuffer], { type: 'application/pdf' }));
  }
  throw new Error(`No data source for document "${doc.id}"`);
}

// ── Hook ──────────────────────────────────────────────────────────────────────

export interface UseMultiDocReturn {
  state: MultiDocState | null;
  loadManifest: (manifest: DocumentManifest) => void;
  selectDoc: (docId: string, page?: number) => Promise<void>;
  selectPage: (page: number) => void;
  clearMultiDoc: () => void;
  activeFile: File | null;
  activeDocLoading: boolean;
  activeDocError: string | null;
  setConfig: (cfg: MultiDocConfig) => void;
}

export function useMultiDoc(): UseMultiDocReturn {
  const [state, setState] = useState<MultiDocState | null>(null);
  const [activeFile, setActiveFile] = useState<File | null>(null);
  const [activeDocLoading, setActiveDocLoading] = useState(false);
  const [activeDocError, setActiveDocError] = useState<string | null>(null);

  const manifestRef    = useRef<DocumentManifest | null>(null);
  const configRef      = useRef<MultiDocConfig>({});
  const urlCacheRef    = useRef<Map<string, string>>(new Map());
  const fileCacheRef   = useRef<Map<string, File>>(new Map());
  // Stable ref to selectDoc used by loadManifest auto-select (avoids stale closure)
  const selectDocRef   = useRef<(docId: string, page?: number) => Promise<void>>(async () => {});

  const setConfig = useCallback((cfg: MultiDocConfig) => {
    configRef.current = { ...configRef.current, ...cfg };
  }, []);

  const loadManifest = useCallback((manifest: DocumentManifest) => {
    manifestRef.current = manifest;
    const categories: ResolvedCategory[] = manifest.categories.map(c => ({
      id: c.id, label: c.label, color: c.color,
    }));
    const documents: DocSetItem[] = manifest.documents.map(d => {
      const totalPages = d.pageCategories
        ? totalPagesFromCategories(d.pageCategories)
        : undefined;
      return {
        id: d.id,
        name: d.name,
        categoryId: d.category,
        pageCategories: d.pageCategories,
        totalPages,
      };
    });
    setState({
      mode: manifest.mode,
      categories,
      documents,
      activeDocId: null,
      activePage: 1,
    });
    setActiveFile(null);
    // Auto-select first document so counter shows "1/N" immediately
    if (documents.length > 0) {
      // Use setTimeout to let setState flush first
      const firstDoc = documents[0];
      const firstPage = manifest.documents[0]?.pageCategories?.[0]?.pages?.[0] ?? 1;
      setTimeout(() => selectDocRef.current(firstDoc.id, firstPage), 0);
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const selectDoc = useCallback(async (docId: string, page = 1) => {
    if (!manifestRef.current) return;
    setState(s => s ? { ...s, activeDocId: docId, activePage: page } : s);
    setActiveDocError(null);

    // Cache hit — File object already resolved, zero cost
    if (fileCacheRef.current.has(docId)) {
      setActiveFile(fileCacheRef.current.get(docId)!);
      return;
    }

    setActiveDocLoading(true);
    try {
      const mDoc = manifestRef.current.documents.find(d => d.id === docId);
      if (!mDoc) throw new Error(`Document "${docId}" not in manifest`);

      // Resolve to URL (cached blob URLs reused)
      let blobUrl: string;
      if (urlCacheRef.current.has(docId)) {
        blobUrl = urlCacheRef.current.get(docId)!;
      } else {
        const state = { id: docId, name: mDoc.name };
        blobUrl = await resolveToUrl(state as DocSetItem, mDoc, configRef.current);
        if (blobUrl.startsWith('blob:')) urlCacheRef.current.set(docId, blobUrl);
      }

      // Materialise as File (PDFViewer takes File)
      let file: File;
      if (blobUrl.startsWith('blob:')) {
        const buf = await (await fetch(blobUrl)).arrayBuffer();
        file = new File([buf], `${mDoc.name}.pdf`, { type: 'application/pdf' });
      } else {
        const resp = await fetch(blobUrl);
        if (!resp.ok) throw new Error(`HTTP ${resp.status} fetching ${blobUrl}`);
        const buf = await resp.arrayBuffer();
        file = new File([buf], `${mDoc.name}.pdf`, { type: 'application/pdf' });
        // Cache the blob for subsequent visits
        const cached = URL.createObjectURL(new Blob([buf], { type: 'application/pdf' }));
        urlCacheRef.current.set(docId, cached);
      }

      fileCacheRef.current.set(docId, file);
      setActiveFile(file);
    } catch (err) {
      setActiveDocError(String(err));
    } finally {
      setActiveDocLoading(false);
    }
  }, []);

  // Keep ref in sync with latest selectDoc
  selectDocRef.current = selectDoc;

  const selectPage = useCallback((page: number) => {
    setState(s => s ? { ...s, activePage: page } : s);
  }, []);

  const clearMultiDoc = useCallback(() => {
    urlCacheRef.current.forEach(url => { try { URL.revokeObjectURL(url); } catch (_) {} });
    urlCacheRef.current.clear();
    fileCacheRef.current.clear();
    manifestRef.current = null;
    setState(null);
    setActiveFile(null);
    setActiveDocLoading(false);
    setActiveDocError(null);
  }, []);

  return { state, loadManifest, selectDoc, selectPage, clearMultiDoc, activeFile, activeDocLoading, activeDocError, setConfig };
}
