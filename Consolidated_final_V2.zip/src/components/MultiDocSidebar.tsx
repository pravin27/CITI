import { useState } from 'react';
import type { MultiDocState, ResolvedCategory } from '../types/multiDoc';
import { buildPageCatMap, pagesForCategory } from '../types/multiDoc';
import { MultiDocOutline } from './MultiDocOutline';

// ── Page thumbnail row (mode:multi thumbnail tab) ─────────────────────────────

function PageThumbRow({ pageNum, isActive, cat, onClick }: {
  pageNum: number;
  isActive: boolean;
  cat: ResolvedCategory | undefined;
  onClick: () => void;
}) {
  return (
    <div onClick={onClick} style={{
      display: 'flex', alignItems: 'center', gap: 7,
      padding: '5px 8px 5px 10px',
      borderLeft: `3px solid ${isActive ? (cat?.color ?? '#1a7fd4') : 'transparent'}`,
      borderBottom: '0.5px solid rgba(0,0,0,.05)',
      background: isActive ? '#ddeeff' : undefined,
      cursor: 'pointer', transition: 'background 0.1s',
    }}>
      <div style={{
        width: 30, height: 38, background: '#fff', borderRadius: 2,
        border: '0.5px solid #ccc', flexShrink: 0, overflow: 'hidden',
        position: 'relative', display: 'flex', flexDirection: 'column',
        gap: 2, padding: '3px 3px 2px',
      }}>
        <span style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 2, background: cat?.color ?? '#888' }} />
        {[70,100,50,100,60].map((w,i) => (
          <div key={i} style={{ height: 2, borderRadius: 1, background: i===0?'#c5cdd6':'#e0e4e8', width:`${w}%` }} />
        ))}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 9.5, fontWeight: 500, color: '#1a2a3a' }}>Page {pageNum}</div>
        <div style={{ fontSize: 8, color: '#6a7a8a', marginTop: 1 }}>{cat?.label ?? ''}</div>
      </div>
    </div>
  );
}

// ── Doc thumbnail row (mode:single) ──────────────────────────────────────────

function DocThumbRow({ doc, isActive, cat, onClick }: {
  doc: { id: string; name: string };
  isActive: boolean;
  cat: ResolvedCategory | undefined;
  onClick: () => void;
}) {
  return (
    <div onClick={onClick} style={{
      display: 'flex', alignItems: 'center', gap: 8,
      padding: '5px 8px 5px 10px',
      borderLeft: `3px solid ${isActive ? (cat?.color ?? '#1a7fd4') : 'transparent'}`,
      borderBottom: '0.5px solid rgba(0,0,0,.05)',
      background: isActive ? '#ddeeff' : undefined,
      cursor: 'pointer', transition: 'background 0.1s',
    }}>
      <div style={{
        width: 32, height: 42, background: '#fff', borderRadius: 2,
        border: '0.5px solid #ccc', flexShrink: 0, overflow: 'hidden',
        position: 'relative', display: 'flex', flexDirection: 'column',
        gap: 2, padding: '4px 4px 3px',
      }}>
        <span style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 2.5, background: cat?.color ?? '#888' }} />
        {[65,100,50,100,75,55].map((w,i) => (
          <div key={i} style={{ height: 2.5, borderRadius: 1, background: i===0?'#c5cdd6':'#e0e4e8', width:`${w}%` }} />
        ))}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 9.5, fontWeight: 500, color: '#1a2a3a', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{doc.name}</div>
        <div style={{ fontSize: 8, color: '#6a7a8a', marginTop: 2 }}>{cat?.label ?? ''}</div>
      </div>
    </div>
  );
}

// ── Main sidebar ──────────────────────────────────────────────────────────────

export interface MultiDocSidebarProps {
  state: MultiDocState;
  isLoading: boolean;
  loadError: string | null;
  onSelectDoc: (docId: string, page?: number) => void;
  onSelectPage: (page: number) => void;
  onClose?: () => void;
}

export function MultiDocSidebar({ state, isLoading, loadError, onSelectDoc, onSelectPage, onClose }: MultiDocSidebarProps) {
  const [tab, setTab] = useState<'thumb'|'outline'>('thumb');
  // Track which category sections are collapsed (none by default — all open)
  const [collapsedCats, setCollapsedCats] = useState<Set<string>>(new Set());
  const toggleCat = (catId: string) => setCollapsedCats(s => {
    const n = new Set(s); n.has(catId) ? n.delete(catId) : n.add(catId); return n;
  });
  const { documents, categories, activeDocId, activePage, mode } = state;

  const catById   = Object.fromEntries(categories.map(c => [c.id, c]));
  const activeDoc = documents.find(d => d.id === activeDocId);
  const activeIdx = activeDocId ? documents.findIndex(d => d.id === activeDocId) : -1;

  // mode:single — group docs by category
  const catGroups: Record<string, typeof documents> = {};
  if (mode === 'single') {
    documents.forEach(d => {
      const cid = d.categoryId ?? '__none__';
      if (!catGroups[cid]) catGroups[cid] = [];
      catGroups[cid].push(d);
    });
  }

  // mode:multi thumbnail tab — page→category map for active doc
  // Groups pages by category to render category-header + pages rows
  const pagesByCat: Record<string, number[]> = {};
  if (mode === 'multi' && activeDoc?.pageCategories) {
    activeDoc.pageCategories.forEach(pc => {
      pagesByCat[pc.category] = [...pc.pages].sort((a,b) => a-b);
    });
  }

  // For the active page, what category is it?
  const pageCatMap = (mode === 'multi' && activeDoc?.pageCategories)
    ? buildPageCatMap(activeDoc.pageCategories)
    : new Map<number,string>();

  return (
    <div style={{ width: 196, flexShrink: 0, display: 'flex', flexDirection: 'column', background: '#0d1829', borderRight: '1px solid #1a2740', height: '100%' }}>

      {/* Header */}
      <div style={{ padding: '8px 10px 6px', borderBottom: '1px solid #1a2740', background: '#080f1a', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <div style={{ fontSize: 11, color: '#e8f0f6', fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1 }}>
            {mode === 'multi' && activeDoc ? `${activeDoc.name}.pdf` : 'Documents'}
          </div>
          {onClose && (
            <button onClick={onClose} title="Exit multi-doc mode"
              style={{ background: 'transparent', border: 'none', color: '#4a6070', cursor: 'pointer', fontSize: 14, lineHeight: 1, padding: '0 2px', flexShrink: 0 }}
            >✕</button>
          )}
        </div>
        <div style={{ fontSize: 9, color: '#4a6070', marginTop: 1 }}>
          {mode === 'multi'
            ? `Doc ${activeIdx+1} of ${documents.length} · ${activeDoc?.totalPages ?? 0} pages`
            : `${documents.length} docs · ${categories.length} categories`}
        </div>
      </div>

      {/* Prev / Next doc — mode:multi only */}
      {mode === 'multi' && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '6px 8px', borderBottom: '1px solid #1a2740', background: '#0a1520', flexShrink: 0 }}>
          <button
            disabled={activeIdx <= 0}
            onClick={() => { const p=documents[activeIdx-1]; if(p) onSelectDoc(p.id, p.pageCategories?.[0]?.pages?.[0] ?? 1); }}
            style={{ background:'#1a2f47', border:'0.5px solid #2a4060', color:'#8ab0c8', borderRadius:5, width:28, height:26, cursor:'pointer', fontSize:16, display:'flex', alignItems:'center', justifyContent:'center', opacity:activeIdx<=0?.3:1 }}
          >‹</button>
          <div style={{ flex:1, textAlign:'center', fontSize:10, color:'#e8f0f6', fontWeight:500, background:'#142035', borderRadius:4, padding:'3px 0' }}>
            {activeIdx>=0?`${activeIdx+1} / ${documents.length}`:`— / ${documents.length}`}
          </div>
          <button
            disabled={activeIdx>=documents.length-1}
            onClick={() => { const n=documents[activeIdx+1]; if(n) onSelectDoc(n.id, n.pageCategories?.[0]?.pages?.[0] ?? 1); }}
            style={{ background:'#1a2f47', border:'0.5px solid #2a4060', color:'#8ab0c8', borderRadius:5, width:28, height:26, cursor:'pointer', fontSize:16, display:'flex', alignItems:'center', justifyContent:'center', opacity:activeIdx>=documents.length-1?.3:1 }}
          >›</button>
        </div>
      )}

      {/* Tabs — mode:multi only */}
      {mode === 'multi' && (
        <div style={{ display: 'flex', borderBottom: '1px solid #1a2740', flexShrink: 0 }}>
          {(['thumb','outline'] as const).map(t => (
            <div key={t} onClick={() => setTab(t)} style={{
              flex:1, padding:'6px 0', fontSize:10, fontWeight:500,
              color: tab===t?'#8ab0c8':'#4a6070',
              textAlign:'center', cursor:'pointer',
              borderBottom: tab===t?'2px solid #1a7fd4':'2px solid transparent',
              transition:'color 0.12s',
            }}>{t==='thumb'?'Thumbnails':'Doc outline'}</div>
          ))}
        </div>
      )}

      {/* Status */}
      {isLoading && <div style={{ padding:'12px 10px', fontSize:10, color:'#8ab0c8', textAlign:'center' }}>Loading…</div>}
      {loadError  && <div style={{ padding:'8px 10px',  fontSize:10, color:'#f87171', borderBottom:'0.5px solid #2a2020' }}>{loadError}</div>}

      {/* Scroll content */}
      <div style={{ flex:1, overflowY:'auto', background:'#f2f4f6' }}>

        {/* ── Case 1: single-page docs ─────────────────────────────────── */}
        {mode === 'single' && categories.map(cat => {
          const catDocs = catGroups[cat.id] ?? [];
          if (!catDocs.length) return null;
          return (
            <div key={cat.id}>
              {/* Accordion header — opaque bg, sticky, collapsible */}
              <button
                onClick={() => toggleCat(cat.id)}
                style={{
                  width:'100%', display:'flex', alignItems:'center', gap:6,
                  padding:'7px 10px 6px 8px', cursor:'pointer', userSelect:'none',
                  background: cat.color,
                  borderLeft: `4px solid ${cat.color}`,
                  border:'none', borderBottom:'0.5px solid rgba(0,0,0,.15)',
                  textAlign:'left',
                  position:'sticky', top:0, zIndex:10,
                }}>
                <span style={{
                  fontSize:9, color:'#fff', opacity:.85, display:'inline-block',
                  transform: collapsedCats.has(cat.id) ? 'rotate(0deg)' : 'rotate(90deg)',
                  transition:'transform 0.15s', flexShrink:0,
                }}>▶</span>
                <span style={{ width:7, height:7, borderRadius:'50%', background:'rgba(255,255,255,0.6)', flexShrink:0 }} />
                <span style={{ fontSize:11, fontWeight:500, color:'#fff', flex:1, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                  {cat.label}
                </span>
                <span style={{ fontSize:10, padding:'1px 6px', borderRadius:10, background:'rgba(255,255,255,0.2)', color:'#fff', fontWeight:500, flexShrink:0 }}>
                  {catDocs.length}
                </span>
              </button>
              {!collapsedCats.has(cat.id) && catDocs.map(d => (
                <DocThumbRow key={d.id} doc={d} isActive={d.id===activeDocId} cat={cat} onClick={() => onSelectDoc(d.id, 1)} />
              ))}
            </div>
          );
        })}

        {/* ── Case 2 thumbnail tab: pages of active doc ────────────────── */}
        {mode === 'multi' && tab === 'thumb' && (
          activeDocId ? (
            categories.map(cat => {
              const pages = pagesByCat[cat.id];
              if (!pages?.length) return null;
              return (
                <div key={cat.id}>
                  <button
                    onClick={() => toggleCat(`multi:${cat.id}`)}
                    style={{
                      width:'100%', display:'flex', alignItems:'center', gap:6,
                      padding:'7px 10px 6px 8px', cursor:'pointer', userSelect:'none',
                      background: cat.color,
                      borderLeft: `4px solid ${cat.color}`,
                      border:'none', borderBottom:'0.5px solid rgba(0,0,0,.15)',
                      textAlign:'left',
                      position:'sticky', top:0, zIndex:10,
                    }}>
                    <span style={{
                      fontSize:9, color:'#fff', opacity:.85, display:'inline-block',
                      transform: collapsedCats.has(`multi:${cat.id}`) ? 'rotate(0deg)' : 'rotate(90deg)',
                      transition:'transform 0.15s', flexShrink:0,
                    }}>▶</span>
                    <span style={{ width:7, height:7, borderRadius:'50%', background:'rgba(255,255,255,0.6)', flexShrink:0 }} />
                    <span style={{ fontSize:11, fontWeight:500, color:'#fff', flex:1, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                      {cat.label}
                    </span>
                    <span style={{ fontSize:10, padding:'1px 6px', borderRadius:10, background:'rgba(255,255,255,0.2)', color:'#fff', fontWeight:500, flexShrink:0 }}>
                      {pages.length} pg
                    </span>
                  </button>
                  {!collapsedCats.has(`multi:${cat.id}`) && pages.map(pg => {
                    const catId = pageCatMap.get(pg);
                    return (
                      <PageThumbRow
                        key={pg}
                        pageNum={pg}
                        isActive={pg === activePage}
                        cat={catId ? catById[catId] : undefined}
                        onClick={() => onSelectPage(pg)}
                      />
                    );
                  })}
                </div>
              );
            })
          ) : (
            <div style={{ padding:'16px 10px', fontSize:10, color:'#4a6070', textAlign:'center' }}>Select a document to view pages</div>
          )
        )}

        {/* ── Case 2 outline tab ───────────────────────────────────────── */}
        {mode === 'multi' && tab === 'outline' && (
          <MultiDocOutline state={state} onSelectDoc={onSelectDoc} onSelectPage={onSelectPage} />
        )}
      </div>
    </div>
  );
}
