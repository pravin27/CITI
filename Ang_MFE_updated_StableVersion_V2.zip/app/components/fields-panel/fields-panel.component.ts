import {
  Component, Output, EventEmitter, ChangeDetectionStrategy,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PdfCaptureService, CaptureItem } from '../../services/pdf-capture.service';

@Component({
  selector: 'app-fields-panel',
  standalone: true,
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="capture-panel">

      <!-- ── Header ── -->
      <div class="panel-header">
        <div class="header-title">
          <span class="header-icon">⬡</span>
          <h2>Field Capture</h2>
        </div>
        <div class="header-actions">
          <button
            class="btn-pick"
            [class.active]="svc.click2pickMode()"
            (click)="svc.toggleClick2PickMode()"
            [title]="svc.click2pickMode() ? 'Click2Pick ON' : 'Click2Pick OFF'"
          >
            <span class="pick-dot" [class.on]="svc.click2pickMode()"></span>
            Click2Pick
          </button>
        </div>
      </div>

      <!-- ── Status bar ── -->
      <div class="status-bar" [class.has-raw]="svc.lastRawCapture()">
        <ng-container *ngIf="svc.lastRawCapture(); else noCapture">
          <span class="status-dot pulse"></span>
          Captured: <strong>"{{ svc.lastRawCapture()!.value }}"</strong>
          &nbsp;pg {{ svc.lastRawCapture()!.page }}
          ({{ (svc.lastRawCapture()!.x * 100) | number:'1.0-0' }}%,{{ (svc.lastRawCapture()!.y * 100) | number:'1.0-0' }}%)
        </ng-container>
        <ng-template #noCapture>
          <span class="status-dot idle"></span>
          Click2Pick or draw a box on the viewer
        </ng-template>
      </div>

      <!-- ── Raw JSON preview (click/box result) ── -->
      <div class="section-block raw-section" *ngIf="svc.lastRawCapture()">
        <div class="section-label cyan">
          ◉ Last Capture &nbsp;<span class="hint">id &amp; label empty until submitted</span>
        </div>
        <pre class="json-block cyan-block">{{ rawJson() }}</pre>
      </div>

      <!-- ── Free-text JSON submission ── -->
      <div class="section-block submit-section">
        <div class="section-label">
          ✦ Submit JSON &nbsp;
          <span class="hint">paste / edit full object → Submit</span>
        </div>

        <!-- Rules hint -->
        <div class="rules-hint">
          <div class="rule">• <strong>id + label + coords</strong> → ADD or REPLACE highlight</div>
          <div class="rule">• <strong>id + label, no coords</strong> → DELETE from captured</div>
          <div class="rule">• <strong>missing id or label</strong> → ignored</div>
        </div>

        <textarea
          class="json-textarea"
          [(ngModel)]="jsonInput"
          placeholder='{
  "id": "inv-001",
  "label": "Invoice Number",
  "value": "Spirit",
  "page": 1,
  "x": 0.173206,
  "y": 0.123483,
  "width": 0.041418,
  "height": 0.015152
}'
          rows="9"
          spellcheck="false"
          autocomplete="off"
        ></textarea>

        <!-- Error / result feedback -->
        <div class="feedback error"   *ngIf="feedback.type === 'error'">   ✕ {{ feedback.msg }}</div>
        <div class="feedback success" *ngIf="feedback.type === 'success'"> ✓ {{ feedback.msg }}</div>
        <div class="feedback deleted" *ngIf="feedback.type === 'deleted'"> 🗑 {{ feedback.msg }}</div>

        <div class="btn-row">
          <button
            class="btn-prefill"
            *ngIf="svc.lastRawCapture()"
            (click)="prefillFromRaw()"
            title="Copy last capture into textarea"
          >⤵ Prefill from capture</button>
          <button
            class="btn-submit"
            [disabled]="!jsonInput.trim()"
            (click)="onSubmit()"
          >Submit</button>
        </div>
      </div>

      <!-- ── Confirmed captures list ── -->
      <div class="captures-header" *ngIf="svc.fields().length">
        <span>Confirmed ({{ svc.fields().length }})</span>
        <button class="btn-clear-all" (click)="onClearAll()">Clear All</button>
      </div>

      <div class="captures-scroll">
        <div
          class="capture-card"
          *ngFor="let item of svc.fields()"
          [class.active]="svc.activeFieldId() === item.id"
          (click)="onCardClick(item)"
        >
          <div class="card-top">
            <span class="card-id">{{ item.id }}</span>
            <span class="card-label-pill">{{ item.label }}</span>
            <div class="card-badges">
              <span class="badge-page">pg {{ item.page }}</span>
              <button class="btn-delete" (click)="onDelete(item.id, $event)" title="Remove">✕</button>
            </div>
          </div>
          <div class="card-value">"{{ item.value }}"</div>
          <div class="card-coords">
            x={{ (item.x * 100)|number:'1.1-1' }}%
            y={{ (item.y * 100)|number:'1.1-1' }}%
            w={{ (item.width * 100)|number:'1.1-1' }}%
            h={{ (item.height * 100)|number:'1.1-1' }}%
            &nbsp;·&nbsp;{{ item.fromJson ? '📂 json' : '✎ live' }}
          </div>
        </div>

        <div class="empty-state" *ngIf="!svc.fields().length">
          <div class="empty-icon">◎</div>
          <p>No confirmed captures.<br>Click a word, paste JSON with id &amp; label, then Submit.</p>
        </div>
      </div>

      <!-- ── Legend ── -->
      <div class="legend">
        <div class="legend-title">Highlight Legend</div>
        <div class="legend-items">
          <div class="legend-item"><span class="swatch active"></span>Active</div>
          <div class="legend-item"><span class="swatch previous"></span>Captured</div>
          <div class="legend-item"><span class="swatch duplicate"></span>Duplicate</div>
          <div class="legend-item"><span class="swatch external"></span>External</div>
        </div>
      </div>

    </div>
  `,
  styles: [`
    :host { display:flex; flex-direction:column; height:100%; }

    .capture-panel {
      display:flex; flex-direction:column; height:100%;
      background:#080f1a; color:#e2e8f0;
      font-family:'JetBrains Mono', monospace; overflow:hidden;
    }

    /* Header */
    .panel-header {
      display:flex; align-items:center; justify-content:space-between;
      padding:12px 16px 10px; border-bottom:1px solid rgba(255,255,255,.06); flex-shrink:0;
    }
    .header-title { display:flex; align-items:center; gap:8px; }
    .header-icon { font-size:16px; color:#00d4aa; }
    h2 { margin:0; font-size:13px; font-weight:700; letter-spacing:.5px; color:#f1f5f9; }
    .btn-pick {
      display:flex; align-items:center; gap:5px; padding:4px 10px;
      background:rgba(255,255,255,.04); border:1.5px solid #1e293b;
      border-radius:20px; color:#94a3b8; font-size:11px; font-weight:600;
      cursor:pointer; transition:all .15s; font-family:inherit;
      &.active { border-color:#00d4aa; color:#00d4aa; background:rgba(0,212,170,.08); }
    }
    .pick-dot {
      width:6px; height:6px; border-radius:50%; background:#475569; transition:background .15s;
      &.on { background:#00d4aa; box-shadow:0 0 5px #00d4aa; }
    }

    /* Status bar */
    .status-bar {
      padding:7px 14px; font-size:11px; color:#64748b;
      background:rgba(255,255,255,.02); border-bottom:1px solid rgba(255,255,255,.04);
      display:flex; align-items:center; gap:6px; flex-shrink:0; min-height:30px;
      &.has-raw { color:#e2e8f0; background:rgba(6,182,212,.06); border-color:rgba(6,182,212,.2); }
      strong { color:#06b6d4; }
    }
    .status-dot {
      width:6px; height:6px; border-radius:50%; flex-shrink:0;
      &.idle  { background:#334155; }
      &.pulse { background:#06b6d4; animation:dot-pulse 1.2s ease-in-out infinite; }
    }
    @keyframes dot-pulse {
      0%,100% { box-shadow:0 0 0 0 rgba(6,182,212,0); }
      50%      { box-shadow:0 0 0 4px rgba(6,182,212,.3); }
    }

    /* Section blocks */
    .section-block {
      margin:8px 12px 0; border-radius:7px;
      border:1px solid rgba(255,255,255,.07); flex-shrink:0;
    }
    .raw-section   { border-color:rgba(6,182,212,.28); background:rgba(6,182,212,.03); }
    .submit-section { background:rgba(255,255,255,.015); }

    .section-label {
      font-size:10px; font-weight:700; letter-spacing:.5px; text-transform:uppercase;
      color:#475569; padding:5px 10px 4px;
      border-bottom:1px solid rgba(255,255,255,.05);
      display:flex; align-items:center; gap:6px;
      &.cyan { color:#06b6d4; border-color:rgba(6,182,212,.12); }
    }
    .hint { font-weight:400; text-transform:none; letter-spacing:0; color:#334155; font-size:10px; }

    /* Raw JSON block */
    .json-block {
      margin:0; padding:7px 10px; font-size:10.5px; color:#94a3b8;
      line-height:1.55; overflow:auto; max-height:120px;
      white-space:pre; background:transparent;
    }

    /* Rules hint */
    .rules-hint {
      padding:5px 10px 0; font-size:10px; color:#475569; line-height:1.7;
      strong { color:#94a3b8; }
    }
    .rule { }

    /* Textarea */
    .json-textarea {
      width:100%; box-sizing:border-box;
      background:#050c17; border:none; border-top:1px solid rgba(255,255,255,.05);
      color:#94a3b8; font-family:'JetBrains Mono', monospace; font-size:11px;
      line-height:1.6; padding:8px 10px; resize:vertical; outline:none;
      border-radius:0; min-height:130px;
      &::placeholder { color:#1e293b; }
      &:focus { color:#e2e8f0; background:#070e1c; }
    }

    /* Feedback */
    .feedback {
      padding:5px 10px; font-size:11px; font-weight:600;
      &.error   { color:#f87171; background:rgba(248,113,113,.06); }
      &.success { color:#00c864; background:rgba(0,200,100,.06); }
      &.deleted { color:#fb923c; background:rgba(251,146,60,.06); }
    }

    /* Button row */
    .btn-row {
      display:flex; gap:6px; padding:7px 8px;
      border-top:1px solid rgba(255,255,255,.05); justify-content:flex-end;
    }
    .btn-prefill {
      font-size:11px; padding:5px 10px; border:1.5px solid #334155;
      background:transparent; color:#64748b; border-radius:5px;
      cursor:pointer; font-family:inherit; transition:all .15s;
      &:hover { border-color:#475569; color:#94a3b8; }
    }
    .btn-submit {
      font-size:11px; padding:5px 14px;
      background:rgba(0,212,170,.1); border:1.5px solid rgba(0,212,170,.4);
      color:#00d4aa; border-radius:5px; font-weight:700;
      cursor:pointer; font-family:inherit; transition:all .15s;
      &:hover:not(:disabled) { background:rgba(0,212,170,.2); box-shadow:0 0 8px rgba(0,212,170,.25); }
      &:disabled { opacity:.35; cursor:not-allowed; }
    }

    /* Captures list */
    .captures-header {
      display:flex; align-items:center; justify-content:space-between;
      padding:7px 14px 3px; font-size:10px; color:#475569;
      font-weight:700; letter-spacing:.5px; text-transform:uppercase; flex-shrink:0;
    }
    .btn-clear-all {
      font-size:10px; color:#f87171; background:none; border:none;
      cursor:pointer; font-family:inherit; opacity:.6;
      &:hover { opacity:1; }
    }
    .captures-scroll { flex:1; overflow-y:auto; padding:3px 10px 6px; }

    .capture-card {
      border:1.5px solid #1e293b; border-radius:7px; padding:7px 10px;
      margin-bottom:6px; background:rgba(255,255,255,.015); cursor:pointer; transition:all .15s;
      &:hover { border-color:#334155; }
      &.active { border-color:#00c864; background:rgba(0,200,100,.06); }
    }
    .card-top { display:flex; align-items:center; gap:5px; margin-bottom:3px; }
    .card-id   { font-size:10px; color:#60a5fa; font-weight:700; }
    .card-label-pill {
      font-size:10px; color:#94a3b8; background:rgba(255,255,255,.06);
      border-radius:3px; padding:1px 5px; flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;
    }
    .card-badges { display:flex; align-items:center; gap:4px; margin-left:auto; }
    .badge-page {
      font-size:10px; color:#64748b; background:rgba(255,255,255,.05);
      border-radius:3px; padding:1px 5px;
    }
    .btn-delete {
      width:16px; height:16px; border:none; background:rgba(239,68,68,.1);
      color:#f87171; border-radius:50%; font-size:8px; cursor:pointer;
      display:flex; align-items:center; justify-content:center; flex-shrink:0;
      &:hover { background:rgba(239,68,68,.25); }
    }
    .card-value  { font-size:12px; color:#00d4aa; margin-bottom:2px; }
    .card-coords { font-size:10px; color:#334155; }

    /* Empty */
    .empty-state { text-align:center; padding:20px 14px; color:#1e293b; }
    .empty-icon  { font-size:24px; margin-bottom:6px; opacity:.4; }
    .empty-state p { font-size:11px; line-height:1.6; margin:0; color:#334155; }

    /* Legend */
    .legend {
      padding:8px 14px; border-top:1px solid rgba(255,255,255,.05);
      background:#060d18; flex-shrink:0;
    }
    .legend-title {
      font-size:9px; font-weight:700; text-transform:uppercase;
      letter-spacing:1px; color:#334155; margin-bottom:5px;
    }
    .legend-items { display:grid; grid-template-columns:1fr 1fr; gap:4px; }
    .legend-item  { display:flex; align-items:center; gap:5px; font-size:10px; color:#475569; }
    .swatch {
      width:12px; height:12px; border-radius:2px; flex-shrink:0;
      &.active    { background:rgba(0,200,100,.25); border:2px solid rgb(0,200,100); }
      &.previous  { background:rgba(150,150,150,.18); border:2px solid rgba(120,120,120,.7); }
      &.duplicate { background:rgba(250,204,21,.30); border:2px solid rgb(234,179,8); }
      &.external  { background:rgba(139,92,246,.25); border:2px solid #8b5cf6; }
    }
  `],
})
export class FieldsPanelComponent {
  @Output() goToWord         = new EventEmitter<CaptureItem>();
  @Output() captureConfirmed = new EventEmitter<void>();

  jsonInput = '';
  feedback: { type: 'error'|'success'|'deleted'|''; msg: string } = { type:'', msg:'' };

  constructor(public svc: PdfCaptureService) {}

  // ── Raw JSON preview (last click/box capture, id+label empty) ─────────────
  rawJson(): string {
    const r = this.svc.lastRawCapture();
    if (!r) return '';
    return JSON.stringify({
      id: '', label: '', value: r.value, page: r.page,
      x:      parseFloat(r.x.toFixed(6)),
      y:      parseFloat(r.y.toFixed(6)),
      width:  parseFloat(r.width.toFixed(6)),
      height: parseFloat(r.height.toFixed(6)),
    }, null, 2);
  }

  // ── Prefill textarea from last raw capture ────────────────────────────────
  prefillFromRaw(): void {
    const r = this.svc.lastRawCapture();
    if (!r) return;
    this.jsonInput = JSON.stringify({
      id: '', label: '', value: r.value, page: r.page,
      x:      parseFloat(r.x.toFixed(6)),
      y:      parseFloat(r.y.toFixed(6)),
      width:  parseFloat(r.width.toFixed(6)),
      height: parseFloat(r.height.toFixed(6)),
    }, null, 2);
    this.feedback = { type:'', msg:'' };
  }

  // ── Submit free-text JSON ─────────────────────────────────────────────────
  onSubmit(): void {
    this.feedback = { type:'', msg:'' };
    const raw = this.jsonInput.trim();
    if (!raw) return;

    // Parse JSON — allow trailing commas by cleaning up common mistakes
    let parsed: Record<string, any>;
    try {
      parsed = JSON.parse(raw);
    } catch {
      // Try stripping trailing commas before closing braces/brackets
      try {
        const cleaned = raw.replace(/,\s*([}\]])/g, '$1');
        parsed = JSON.parse(cleaned);
      } catch {
        this.feedback = { type:'error', msg:'Invalid JSON — check syntax and try again.' };
        return;
      }
    }

    if (typeof parsed !== 'object' || Array.isArray(parsed)) {
      this.feedback = { type:'error', msg:'Expected a JSON object { ... }' };
      return;
    }

    const result = this.svc.submitCapture(parsed);

    switch (result) {
      case 'added':
        this.feedback = { type:'success', msg:`Added "${parsed['id']}" — green highlight active.` };
        this.jsonInput = '';
        this.captureConfirmed.emit();
        break;
      case 'replaced':
        this.feedback = { type:'success', msg:`Replaced "${parsed['id']}" — highlight updated.` };
        this.jsonInput = '';
        this.captureConfirmed.emit();
        break;
      case 'deleted':
        this.feedback = { type:'deleted', msg:`Deleted "${parsed['id']}" — removed from captures.` };
        this.jsonInput = '';
        this.captureConfirmed.emit();
        break;
      case 'rejected':
        const hasId    = String(parsed['id']    ?? '').trim();
        const hasLabel = String(parsed['label'] ?? '').trim();
        if (!hasId || !hasLabel) {
          this.feedback = { type:'error', msg:'id and label are both required — not captured.' };
        } else {
          this.feedback = { type:'error', msg:'No matching id found to delete.' };
        }
        break;
    }
  }

  // ── Card interactions ─────────────────────────────────────────────────────
  onDelete(id: string, e: MouseEvent): void {
    e.stopPropagation();
    this.svc.deleteCapture(id);
    this.feedback = { type:'', msg:'' };
  }

  onCardClick(item: CaptureItem): void {
    this.svc.setActiveField(item.id);
    this.goToWord.emit(item);
  }

  onClearAll(): void {
    this.svc.fields().slice().forEach((f: CaptureItem) => this.svc.deleteCapture(f.id));
    this.feedback = { type:'', msg:'' };
  }
}