// Sidecar JSON loading hook.
// Called once when a document opens. Silently loads:
//   {base}_word_index.json
//   {base}_captured_fields.json
//   {base}_categories.json
// No error shown to user if absent.

import { useEffect } from 'react';
import { useAppStore } from '../store/appStore';
import { extractRawCoords, normaliseBatch } from '../utils/coords';
import type { WordEntry, Category, CaptureItem } from '../adapters/types';
import { PALETTE_COLORS } from '../adapters/types';
import type { ViewerAdapter } from '../adapters/types';

// ── Word index normalisation ──────────────────────────────────────────────────

function parseWordIndex(
  json: unknown,
  adapter: ViewerAdapter | null
): Map<number, WordEntry[]> {
  const result = new Map<number, WordEntry[]>();

  if (!json || typeof json !== 'object') return result;

  // Format A: { version, pages: { "1": [...] } }
  if ('pages' in (json as object)) {
    const pages = (json as Record<string, unknown>).pages as Record<string, unknown[]>;
    for (const [pageStr, entries] of Object.entries(pages)) {
      const page = parseInt(pageStr);
      const items: WordEntry[] = [];
      for (const e of entries as Record<string, unknown>[]) {
        const raw = extractRawCoords(e);
        if (!raw) continue;
        const coords = normaliseOne(raw, e, page, adapter);
        items.push({
          text: (e.t ?? e.text ?? e.label ?? '') as string,
          page,
          x: coords[0], y: coords[1], width: coords[2], height: coords[3],
        });
      }
      result.set(page, items);
    }
    return result;
  }

  // Format B: flat array
  if (Array.isArray(json)) {
    const getPage = (item: Record<string, unknown>) =>
      typeof item.page === 'number' ? item.page : 1;

    // Two-pass: pass1 done inside normaliseBatch
    const normalised = normaliseBatch(json as Record<string, unknown>[], getPage, adapter as any);
    for (const { raw, coords } of normalised) {
      if (!coords) continue;
      const page = getPage(raw);
      if (!result.has(page)) result.set(page, []);
      result.get(page)!.push({
        text: (raw.text ?? raw.t ?? raw.label ?? '') as string,
        page,
        x: coords[0], y: coords[1], width: coords[2], height: coords[3],
      });
    }
    return result;
  }

  return result;
}

// ── Captured fields normalisation ─────────────────────────────────────────────

function parseCapturedFields(
  json: unknown,
  adapter: ViewerAdapter | null
): CaptureItem[] {
  if (!Array.isArray(json)) return [];

  // Build page size cache once O(pages)
  const pageSizeCache = new Map<number, { width: number; height: number } | null>();
  const getPageDims = (page: number) => {
    if (!pageSizeCache.has(page)) {
      pageSizeCache.set(page, adapter ? adapter.getPageDimensions(page) : null);
    }
    return pageSizeCache.get(page) ?? null;
  };

  return (json as Record<string, unknown>[]).map(item => {
    const raw = extractRawCoords(item);
    const page = typeof item.page === 'number' ? item.page : 1;
    let x = 0, y = 0, w = 0, h = 0;

    if (raw) {
      const [rx, ry, rw, rh] = raw;
      const isAbs = rx > 1 || ry > 1 || rw > 1 || rh > 1;
      if (isAbs) {
        let pw: number | undefined, ph: number | undefined;
        if (typeof item.pageWidth === 'number') pw = item.pageWidth as number;
        if (typeof item.pageHeight === 'number') ph = item.pageHeight as number;
        if (!pw || !ph) {
          const dims = getPageDims(page);
          if (dims) { pw = dims.width; ph = dims.height; }
        }
        if (pw && ph) {
          x = Math.max(0, Math.min(1, rx / pw));
          y = Math.max(0, Math.min(1, ry / ph));
          w = Math.max(0, Math.min(1, rw / pw));
          h = Math.max(0, Math.min(1, rh / ph));
        }
      } else {
        [x, y, w, h] = [rx, ry, rw, rh];
      }
    }

    let sourceFormat: CaptureItem['sourceFormat'] = 'flat';
    if ('bbox' in item) sourceFormat = 'bbox';
    else if ('rectangle' in item) sourceFormat = 'rectangle';
    else if ('coordinates' in item) sourceFormat = 'coordinates';

    return {
      id: String(item.id ?? Math.random().toString(36).slice(2)),
      label: String(item.label ?? ''),
      value: String(item.value ?? ''),
      page,
      x, y, width: w, height: h,
      sourceFormat,
      fromJson: true,
      color: typeof item.color === 'string' ? resolveColor(item.color) : undefined,
    } satisfies CaptureItem;
  });
}

// ── Categories ────────────────────────────────────────────────────────────────

function parseCategories(json: unknown): Category[] {
  if (!Array.isArray(json)) return [];
  let paletteIdx = 0;
  return (json as Record<string, unknown>[]).map(item => {
    const color = typeof item.color === 'string'
      ? item.color
      : PALETTE_COLORS[paletteIdx++ % PALETTE_COLORS.length];
    return {
      pages: Array.isArray(item.pages) ? (item.pages as number[]) : [],
      label: String(item.label ?? ''),
      color,
    };
  });
}

// ── Color resolution ──────────────────────────────────────────────────────────

function resolveColor(raw: string): string {
  if (!raw) return '';
  // Bare hex without #
  if (/^[0-9a-fA-F]{6}$/.test(raw)) return '#' + raw;
  if (/^[0-9a-fA-F]{3}$/.test(raw)) return '#' + raw;
  return raw; // already CSS color
}

// ── Normalise one item (helper) ───────────────────────────────────────────────

function normaliseOne(
  raw: [number, number, number, number],
  item: Record<string, unknown>,
  page: number,
  adapter: ViewerAdapter | null
): [number, number, number, number] {
  const [x, y, w, h] = raw;
  if (x <= 1 && y <= 1 && w <= 1 && h <= 1) return [x, y, w, h];
  const dims = adapter?.getPageDimensions(page) ?? null;
  if (dims) {
    return [
      Math.max(0, Math.min(1, x / dims.width)),
      Math.max(0, Math.min(1, y / dims.height)),
      Math.max(0, Math.min(1, w / dims.width)),
      Math.max(0, Math.min(1, h / dims.height)),
    ];
  }
  return [x, y, w, h];
}

// ── Hook ──────────────────────────────────────────────────────────────────────

export function useSidecarLoader() {
  const file = useAppStore(s => s.file);
  const adapter = useAppStore(s => s.adapter);
  const setWordIndex = useAppStore(s => s.setWordIndex);
  const setCategories = useAppStore(s => s.setCategories);
  const addCapture = useAppStore(s => s.addCapture);
  const replaceCapture = useAppStore(s => s.replaceCapture);

  useEffect(() => {
    if (!file || !adapter) return;

    // We need to wait for the adapter to be ready before normalising
    let cancelled = false;

    const tryLoad = async () => {
      const base = file.name.replace(/\.[^.]+$/, '');
      const fileDir = ''; // same directory as the document (for file: protocol, use dirname)

      // Attempt to load sidecar files from the same directory.
      // In a browser context without a server, we look for files in a sibling input.
      // The hook exposes a helper so the UI can also inject sidecar data.
      // For now: silently skip (would need server or stored files).
      // The store exposes setWordIndex/setCategories for external injection.
    };

    adapter.onReady(() => {
      if (!cancelled) tryLoad();
    });

    return () => { cancelled = true; };
  }, [file, adapter]);
}

// ── Manual sidecar injection (called from UI when user provides sidecar files) ──

export function injectWordIndex(
  json: unknown,
  adapter: ViewerAdapter | null
): Map<number, WordEntry[]> {
  return parseWordIndex(json, adapter);
}

export function injectCapturedFields(
  json: unknown,
  adapter: ViewerAdapter | null
): CaptureItem[] {
  return parseCapturedFields(json, adapter);
}

export function injectCategories(json: unknown): Category[] {
  return parseCategories(json);
}
