// ─────────────────────────────────────────────────────────────────────────────
// ImageAdapter — tiff.js for TIF/TIFF, native browser for BMP/JPEG/PNG
// Multi-frame TIFF = multi-page. Single images = 1 page.
// ─────────────────────────────────────────────────────────────────────────────

import type { ViewerAdapter } from './types';

export interface ImageFrame {
  canvas: HTMLCanvasElement;
  width: number;
  height: number;
}

export class ImageAdapter implements ViewerAdapter {
  pageCount = 0;

  private _frames: ImageFrame[] = [];
  private _readyCallbacks: Array<() => void> = [];
  private _pageRenderedCallbacks: Array<(page: number) => void> = [];
  private _pageElements = new Map<number, HTMLElement>();
  private _renderedPages = new Set<number>();
  private _isReady = false;

  // ── Loading ────────────────────────────────────────────────────────────────

  async loadFile(file: File): Promise<void> {
    const isTiff = /\.(tif|tiff)$/i.test(file.name);
    if (isTiff) {
      await this._loadTiff(file);
    } else {
      await this._loadNativeImage(file);
    }
    this._isReady = true;
    this.pageCount = this._frames.length;
    this._readyCallbacks.forEach(cb => cb());
    this._readyCallbacks = [];
  }

  private async _loadTiff(file: File): Promise<void> {
    // tiff package: decode() returns IFD array with data/width/height per page
    const tiffLib = await import('tiff');
    const buffer = await file.arrayBuffer();
    const ifds = tiffLib.decode(buffer);
    this._frames = [];
    for (const ifd of ifds) {
      const { data, width, height } = ifd as {
        data: Uint8Array | Uint16Array;
        width: number;
        height: number;
      };
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d')!;
      const imgData = ctx.createImageData(width, height);
      // tiff data is RGBA uint8 or grayscale — normalise to RGBA uint8
      const src = new Uint8Array(data.buffer ?? (data as Uint8Array).buffer);
      if (src.length === width * height * 4) {
        imgData.data.set(src);
      } else if (src.length === width * height) {
        // Grayscale
        for (let i = 0; i < width * height; i++) {
          imgData.data[i * 4] = src[i];
          imgData.data[i * 4 + 1] = src[i];
          imgData.data[i * 4 + 2] = src[i];
          imgData.data[i * 4 + 3] = 255;
        }
      } else if (src.length === width * height * 3) {
        // RGB
        for (let i = 0; i < width * height; i++) {
          imgData.data[i * 4] = src[i * 3];
          imgData.data[i * 4 + 1] = src[i * 3 + 1];
          imgData.data[i * 4 + 2] = src[i * 3 + 2];
          imgData.data[i * 4 + 3] = 255;
        }
      } else {
        imgData.data.set(src.slice(0, width * height * 4));
      }
      ctx.putImageData(imgData, 0, 0);
      this._frames.push({ canvas, width, height });
    }
  }

  private async _loadNativeImage(file: File): Promise<void> {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.naturalWidth;
        canvas.height = img.naturalHeight;
        const ctx = canvas.getContext('2d')!;
        ctx.drawImage(img, 0, 0);
        this._frames = [{
          canvas,
          width: img.naturalWidth,
          height: img.naturalHeight,
        }];
        URL.revokeObjectURL(url);
        resolve();
      };
      img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('Image decode failed')); };
      img.src = url;
    });
  }

  // Called by the ImageViewer component when a page is rendered to DOM
  notifyPageRendered(page: number) {
    this._renderedPages.add(page);
    this._pageRenderedCallbacks.forEach(cb => cb(page));
  }

  registerPageElement(page: number, el: HTMLElement | null) {
    if (el) this._pageElements.set(page, el);
    else this._pageElements.delete(page);
  }

  getFrame(page: number): ImageFrame | null {
    return this._frames[page - 1] ?? null;
  }

  getAllFrames(): ImageFrame[] {
    return this._frames;
  }

  // ── ViewerAdapter implementation ──────────────────────────────────────────

  navigateToPage(page: number): void {
    const el = this._pageElements.get(page);
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  getPageDimensions(page: number): { width: number; height: number } | null {
    const frame = this._frames[page - 1];
    if (!frame) return null;
    return { width: frame.width, height: frame.height };
  }

  getPageCanvas(page: number): HTMLCanvasElement | null {
    // The canvas might be inside the page element
    const el = this._pageElements.get(page);
    if (el) return el.querySelector('canvas') ?? null;
    return this._frames[page - 1]?.canvas ?? null;
  }

  getPageElement(page: number): HTMLElement | null {
    return this._pageElements.get(page) ?? null;
  }

  getRenderedPages(): Set<number> {
    return new Set(this._renderedPages);
  }

  onReady(cb: () => void): void {
    if (this._isReady) cb();
    else this._readyCallbacks.push(cb);
  }

  onPageRendered(cb: (page: number) => void): void {
    this._pageRenderedCallbacks.push(cb);
  }

  dispose() {
    this._frames = [];
    this._readyCallbacks = [];
    this._pageRenderedCallbacks = [];
    this._pageElements.clear();
    this._renderedPages.clear();
    this._isReady = false;
    this.pageCount = 0;
  }
}
