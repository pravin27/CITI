import React, { useEffect } from 'react';
import { useAppStore } from './store/appStore';
import { FileUpload } from './components/FileUpload';
import { TopBar } from './components/TopBar';
import { ResizablePanes } from './components/ResizablePanes';
import { ViewerPane } from './components/ViewerPane';
import { FieldsPanel } from './components/FieldsPanel';
import { ThumbnailSidebar } from './components/ThumbnailSidebar';
import { useSidecarLoader } from './hooks/useSidecarLoader';

function useGlobalShortcuts() {
  const setSearchOpen = useAppStore(s => s.setSearchOpen);
  const searchIsOpen  = useAppStore(s => s.search.isOpen);
  const file          = useAppStore(s => s.file);

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'f' && file) {
        e.preventDefault();
        setSearchOpen(!searchIsOpen);
      }
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [setSearchOpen, searchIsOpen, file]);
}

function AppShell() {
  const file        = useAppStore(s => s.file);
  const format      = useAppStore(s => s.format);
  const isLoading   = useAppStore(s => s.isLoading);
  const loadError   = useAppStore(s => s.loadError);
  const sidebarOpen = useAppStore(s => s.sidebarOpen);

  useSidecarLoader();
  useGlobalShortcuts();

  if (!file && !isLoading) {
    return (
      <div className="flex flex-col h-screen bg-[#060d1a]">
        <TopBar />
        <FileUpload />
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex flex-col h-screen bg-[#060d1a]">
        <TopBar />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="w-10 h-10 border-2 border-[#0a84ff] border-t-transparent rounded-full animate-spin mx-auto mb-3" />
            <p className="text-[#8899aa] text-sm">Loading document…</p>
          </div>
        </div>
      </div>
    );
  }

  if (loadError) {
    return (
      <div className="flex flex-col h-screen bg-[#060d1a]">
        <TopBar />
        <div className="flex-1 flex items-center justify-center">
          <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-6 max-w-md text-center">
            <div className="text-red-400 text-2xl mb-2">⚠️</div>
            <div className="text-white font-semibold mb-1">Failed to open document</div>
            <div className="text-red-400 text-sm">{loadError}</div>
          </div>
        </div>
      </div>
    );
  }

  if (format === 'unknown') {
    return (
      <div className="flex flex-col h-screen bg-[#060d1a]">
        <TopBar />
        <div className="flex-1 flex items-center justify-center">
          <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-6 max-w-md text-center">
            <div className="text-amber-400 text-2xl mb-2">📄</div>
            <div className="text-white font-semibold mb-1">Unsupported format</div>
            <div className="text-amber-400 text-sm">Supported: PDF, TIF/TIFF, BMP, JPEG, PNG, XLS, XLSX, CSV</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-[#060d1a] overflow-hidden">
      <TopBar />
      <ResizablePanes
        left={
          <div className="flex flex-1 overflow-hidden">
            {sidebarOpen && <ThumbnailSidebar />}
            <ViewerPane />
          </div>
        }
        right={<FieldsPanel />}
        defaultSplit={0.62}
        minLeft={320}
        minRight={280}
      />
    </div>
  );
}

export default function App() {
  return <AppShell />;
}
