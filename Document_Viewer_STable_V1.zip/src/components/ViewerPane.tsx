import React, { useRef, useCallback } from 'react';
import { useAppStore } from '../store/appStore';
import { PDFViewer } from './PDFViewer';
import { ImageViewer } from './ImageViewer';
import { SpreadsheetViewer } from './SpreadsheetViewer';
import { ViewerToolbar } from './ViewerToolbar';
import { useBoxCapture } from '../hooks/useBoxCapture';
import { useHighlightCanvas } from '../hooks/useHighlightCanvas';
import { useWordSpanInjector } from '../hooks/useWordSpanInjector';
import type { PDFAdapter } from '../adapters/PDFAdapter';
import type { ImageAdapter } from '../adapters/ImageAdapter';
import type { SpreadsheetAdapter } from '../adapters/SpreadsheetAdapter';
import type { CaptureResult } from '../hooks/useBoxCapture';

export function ViewerPane() {
  const file             = useAppStore(s => s.file);
  const format           = useAppStore(s => s.format);
  const adapter          = useAppStore(s => s.adapter);
  const zoom             = useAppStore(s => s.zoom);
  const setPendingCapture = useAppStore(s => s.setPendingCapture);
  const setPreviewRect    = useAppStore(s => s.setPreviewRect);

  const containerRef = useRef<HTMLDivElement>(null);

  // When box is drawn or word double-clicked:
  // → store as pendingCapture (shown as editable JSON in right panel)
  // → set previewRect so canvas draws the cyan highlight
  const handleCapture = useCallback((result: CaptureResult) => {
    setPendingCapture({
      text: result.text,
      page: result.page,
      x: result.x, y: result.y,
      width: result.width, height: result.height,
    });
    setPreviewRect({
      page: result.page,
      x: result.x, y: result.y,
      width: result.width, height: result.height,
    });
  }, [setPendingCapture, setPreviewRect]);

  useBoxCapture(containerRef as React.RefObject<HTMLElement>, handleCapture);
  useHighlightCanvas(containerRef as React.RefObject<HTMLElement>);
  useWordSpanInjector(containerRef as React.RefObject<HTMLElement>);

  return (
    <div className="flex flex-col flex-1 overflow-hidden">
      <ViewerToolbar />
      <div ref={containerRef} className="flex-1 flex flex-col overflow-hidden relative">
        {file && format === 'pdf' && adapter && (
          <PDFViewer file={file} adapter={adapter as PDFAdapter} zoom={zoom} />
        )}
        {file && format === 'image' && adapter && (
          <ImageViewer adapter={adapter as ImageAdapter} zoom={zoom} />
        )}
        {file && format === 'spreadsheet' && adapter && (
          <SpreadsheetViewer adapter={adapter as SpreadsheetAdapter} />
        )}
      </div>
    </div>
  );
}
