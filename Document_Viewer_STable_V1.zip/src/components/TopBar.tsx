import React from 'react';
import { useAppStore } from '../store/appStore';
import type { CaptureItem } from '../adapters/types';

export function TopBar() {
  const fileName    = useAppStore(s => s.fileName);
  const format      = useAppStore(s => s.format);
  const captures    = useAppStore(s => s.captures);
  const closeFile   = useAppStore(s => s.closeFile);
  const currentPage = useAppStore(s => s.currentPage);
  const adapter     = useAppStore(s => s.adapter);

  const FORMAT_LABELS: Record<string, string> = { pdf: 'PDF', image: 'Image', spreadsheet: 'Sheet' };
  const FORMAT_COLORS: Record<string, string> = {
    pdf:         'bg-red-500/20 text-red-400 border-red-500/30',
    image:       'bg-green-500/20 text-green-400 border-green-500/30',
    spreadsheet: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  };

  const pageCount = adapter?.pageCount ?? 0;

  const exportJson = () => {
    if (!captures.length) return;
    const data = captures.map((c: CaptureItem) => {
      const base: Record<string, unknown> = { id: c.id, label: c.label, value: c.value, page: c.page };
      const round = (n: number) => parseFloat(n.toFixed(6));
      if (c.sourceFormat === 'bbox')        base.bbox        = [round(c.x), round(c.y), round(c.width), round(c.height)];
      else if (c.sourceFormat === 'rectangle')  base.rectangle   = [round(c.x), round(c.y), round(c.width), round(c.height)];
      else if (c.sourceFormat === 'coordinates') base.coordinates = [round(c.y), round(c.x), round(c.y + c.height), round(c.x + c.width)];
      else { base.x = round(c.x); base.y = round(c.y); base.width = round(c.width); base.height = round(c.height); }
      if (c.color) base.color = c.color;
      return base;
    });
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${fileName.replace(/\.[^.]+$/, '')}_captured_fields.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <header className="h-11 bg-[#080f1a] border-b border-[#1a2740] flex items-center px-4 gap-3 shrink-0">
      <div className="flex items-center gap-2 text-white font-semibold text-sm">
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
          <rect width="20" height="20" rx="4" fill="#0a84ff" fillOpacity="0.2"/>
          <path d="M5 4h7l4 4v8a1 1 0 01-1 1H5a1 1 0 01-1-1V5a1 1 0 011-1z" stroke="#0a84ff" strokeWidth="1.2" fill="none"/>
          <path d="M12 4v4h4" stroke="#0a84ff" strokeWidth="1.2" fill="none"/>
        </svg>
        Document Viewer
      </div>

      {fileName && <div className="w-px h-4 bg-[#1e2d45]" />}

      {fileName && (
        <>
          <span className="text-[#8899aa] text-xs truncate max-w-xs">{fileName}</span>
          {format !== 'unknown' && (
            <span className={`text-xs px-2 py-0.5 rounded border font-medium ${FORMAT_COLORS[format] ?? 'bg-gray-500/20 text-gray-400 border-gray-500/30'}`}>
              {FORMAT_LABELS[format] ?? format}
            </span>
          )}
        </>
      )}

      {pageCount > 0 && (
        <span className="text-[#607080] text-xs ml-1">{currentPage} / {pageCount}</span>
      )}

      <div className="ml-auto flex items-center gap-2">
        {captures.length > 0 && (
          <button onClick={exportJson}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs bg-[#0a84ff]/15 text-[#0a84ff] border border-[#0a84ff]/30 hover:bg-[#0a84ff]/25 transition-colors">
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
              <path d="M6 1v7M3 5l3 3 3-3M1 10h10" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/>
            </svg>
            Export JSON ({captures.length})
          </button>
        )}
        {fileName && (
          <button onClick={closeFile}
            className="text-[#607080] hover:text-white text-xs px-2 py-1 rounded hover:bg-[#1e2d45] transition-colors">
            Close
          </button>
        )}
      </div>
    </header>
  );
}
