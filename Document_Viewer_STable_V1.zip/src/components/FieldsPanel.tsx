import React, { useState, useCallback, useEffect } from 'react';
import { useAppStore } from '../store/appStore';
import { extractRawCoords, normaliseCoords } from '../utils/coords';
import type { CaptureItem } from '../adapters/types';
import { SidecarLoader } from './SidecarLoader';

// ── JSON helpers ──────────────────────────────────────────────────────────────

function cleanJson(raw: string): string {
  return raw.replace(/,(\s*[}\]])/g, '$1').trim();
}

interface ParsedSubmit {
  id?: string; label?: string; value?: string; page?: number; color?: string;
  coords?: [number,number,number,number] | null;
  sourceFormat?: CaptureItem['sourceFormat'];
}

function parseJson(raw: string): ParsedSubmit | { error: string } {
  try {
    const json = JSON.parse(cleanJson(raw));
    if (!json || typeof json !== 'object') return { error: 'JSON must be an object' };
    if (!json.id) return { error: 'Add an "id" field then click Confirm' };
    let coords: [number,number,number,number] | null = null;
    let sourceFormat: CaptureItem['sourceFormat'] = 'flat';
    const rc = extractRawCoords(json as Record<string, unknown>);
    if (rc) {
      const [x, y, w, h] = rc;
      if (x !== 0 || y !== 0 || w !== 0 || h !== 0) {
        coords = rc;
        if ('bbox' in json) sourceFormat = 'bbox';
        else if ('rectangle' in json) sourceFormat = 'rectangle';
        else if ('coordinates' in json) sourceFormat = 'coordinates';
      }
    }
    return {
      id: String(json.id),
      label: json.label ? String(json.label) : undefined,
      value: json.value !== undefined ? String(json.value) : undefined,
      page: typeof json.page === 'number' ? json.page : undefined,
      color: json.color ? String(json.color) : undefined,
      coords, sourceFormat,
    };
  } catch { return { error: 'Invalid JSON' }; }
}

// ── Pending capture preview panel ─────────────────────────────────────────────

function PendingCapturePanel() {
  const pending           = useAppStore(s => s.pendingCapture);
  const clearPending      = useAppStore(s => s.clearPendingCapture);
  const clearPreviewRect  = useAppStore(s => s.clearPreviewRect);
  const addCapture        = useAppStore(s => s.addCapture);
  const replaceCapture    = useAppStore(s => s.replaceCapture);
  const captures          = useAppStore(s => s.captures);
  const adapter           = useAppStore(s => s.adapter);

  const [editJson, setEditJson] = useState('');
  const [error, setError]       = useState('');

  // When a new capture comes in, populate editJson with a template
  useEffect(() => {
    if (!pending) { setEditJson(''); setError(''); return; }
    const draft = {
      id: '',          // user must fill this in
      label: '',
      value: pending.text,
      page:  pending.page,
      x:     parseFloat(pending.x.toFixed(6)),
      y:     parseFloat(pending.y.toFixed(6)),
      width: parseFloat(pending.width.toFixed(6)),
      height:parseFloat(pending.height.toFixed(6)),
    };
    setEditJson(JSON.stringify(draft, null, 2));
    setError('');
  }, [pending]);

  const handleConfirm = useCallback(() => {
    setError('');
    const parsed = parseJson(editJson);
    if ('error' in parsed) { setError(parsed.error); return; }
    const { id, label, value, page, color, coords, sourceFormat } = parsed;

    // Coords come from the JSON (user may have edited them)
    if (!coords) { setError('No coordinates found in JSON'); return; }
    const pg = page ?? pending?.page ?? 1;
    let [x, y, w, h] = coords;
    if (x > 1 || y > 1 || w > 1 || h > 1) {
      [x, y, w, h] = normaliseCoords(coords, {} as Record<string, unknown>, pg, adapter as any, null);
    }

    const item: CaptureItem = {
      id: id!, label: label || id!, value: value ?? '',
      page: pg, x, y, width: w, height: h,
      sourceFormat, color,
    };

    if (captures.some(c => c.id === id)) replaceCapture(item);
    else addCapture(item);

    clearPending();
    clearPreviewRect();
  }, [editJson, pending, captures, adapter, addCapture, replaceCapture, clearPending, clearPreviewRect]);

  const handleDiscard = useCallback(() => {
    clearPending();
    clearPreviewRect();
    setError('');
  }, [clearPending, clearPreviewRect]);

  if (!pending) return null;

  return (
    <div className="mx-3 mt-3 rounded-xl border border-[#0a84ff]/40 bg-[#0a84ff]/05 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 bg-[#0a84ff]/10 border-b border-[#0a84ff]/20">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-[#0a84ff] animate-pulse" />
          <span className="text-xs font-semibold text-[#0a84ff]">Captured — add ID &amp; confirm</span>
        </div>
        <button onClick={handleDiscard}
          className="text-[#607080] hover:text-red-400 transition-colors" title="Discard">
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
            <path d="M2 2l8 8M10 2l-8 8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
          </svg>
        </button>
      </div>

      {/* Captured text preview */}
      {pending.text && (
        <div className="px-3 pt-2 pb-1">
          <span className="text-[10px] text-[#607080] uppercase tracking-wide">Text</span>
          <p className="text-xs text-white mt-0.5 truncate" title={pending.text}>
            {pending.text}
          </p>
        </div>
      )}

      {/* Editable JSON */}
      <div className="px-3 pt-1 pb-2">
        <span className="text-[10px] text-[#607080] uppercase tracking-wide">Edit JSON</span>
        <textarea
          value={editJson}
          onChange={e => { setEditJson(e.target.value); setError(''); }}
          onKeyDown={e => { if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') handleConfirm(); }}
          className="w-full mt-1 bg-[#060d16] border border-[#1e2d45] rounded-lg p-2
            text-[11px] text-[#6aff9b] font-mono resize-none
            focus:outline-none focus:border-[#0a84ff]/60"
          style={{ height: 160 }}
          spellCheck={false}
        />
        {error && (
          <div className="mt-1 text-[10px] text-amber-400 bg-amber-500/10 rounded px-2 py-1 border border-amber-500/20">
            ⚠ {error}
          </div>
        )}
        <div className="flex gap-2 mt-2">
          <button onClick={handleDiscard}
            className="flex-1 py-1.5 rounded-lg text-xs text-[#607080] border border-[#1e2d45] hover:bg-[#1e2d45] transition-colors">
            Discard
          </button>
          <button onClick={handleConfirm}
            className="flex-2 flex-grow-[2] py-1.5 rounded-lg text-xs font-semibold
              bg-[#0a84ff] text-white hover:bg-[#0a84ff]/80 transition-colors">
            Confirm (Ctrl+Enter)
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Capture card ──────────────────────────────────────────────────────────────

function CaptureCard({ item }: { item: CaptureItem }) {
  const activeFieldId  = useAppStore(s => s.activeFieldId);
  const setActiveField = useAppStore(s => s.setActiveField);
  const deleteCapture  = useAppStore(s => s.deleteCapture);
  const adapter        = useAppStore(s => s.adapter);
  const isActive = item.id === activeFieldId;

  return (
    <div
      onClick={() => { setActiveField(item.id); adapter?.navigateToPage(item.page); }}
      className={`rounded-lg p-2.5 cursor-pointer transition-all border select-none ${
        isActive
          ? 'border-yellow-500/50 bg-yellow-500/10'
          : 'border-[#1e2d45] bg-[#0d1829] hover:border-[#2a3f60] hover:bg-[#111c30]'
      }`}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 mb-0.5">
            {item.color && <span className="w-2 h-2 rounded-full shrink-0" style={{ background: item.color }} />}
            <span className="text-[#8899aa] text-xs truncate">{item.label || item.id}</span>
            <span className="text-[#607080] text-[10px] ml-auto shrink-0">p{item.page}</span>
          </div>
          <div className="text-white text-xs font-medium truncate">{item.value || '—'}</div>
          <div className="text-[#607080] text-[10px] mt-0.5 font-mono">
            x:{item.x.toFixed(3)} y:{item.y.toFixed(3)} w:{item.width.toFixed(3)} h:{item.height.toFixed(3)}
          </div>
        </div>
        <button
          onClick={e => { e.stopPropagation(); deleteCapture(item.id); }}
          className="text-[#607080] hover:text-red-400 shrink-0 transition-colors mt-0.5"
          title="Delete"
        >
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
            <path d="M2 2l8 8M10 2l-8 8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
          </svg>
        </button>
      </div>
    </div>
  );
}

// ── Main fields panel ─────────────────────────────────────────────────────────

export function FieldsPanel() {
  const captures       = useAppStore(s => s.captures);
  const activeFieldId  = useAppStore(s => s.activeFieldId);
  const adapter        = useAppStore(s => s.adapter);
  const addCapture     = useAppStore(s => s.addCapture);
  const replaceCapture = useAppStore(s => s.replaceCapture);
  const deleteCapture  = useAppStore(s => s.deleteCapture);
  const setActiveField = useAppStore(s => s.setActiveField);
  const wordIndex      = useAppStore(s => s.wordIndex);

  const [submitJson, setSubmitJson]       = useState('');
  const [submitError, setSubmitError]     = useState('');
  const [submitSuccess, setSubmitSuccess] = useState('');
  const [findJson, setFindJson]           = useState('');
  const [findError, setFindError]         = useState('');
  const [rawExpanded, setRawExpanded]     = useState(false);

  const activeCapture = captures.find(c => c.id === activeFieldId) ?? null;

  // Submit JSON (manual add/replace/delete)
  const handleSubmit = useCallback(() => {
    setSubmitError(''); setSubmitSuccess('');
    if (!submitJson.trim()) return;
    const parsed = parseJson(submitJson);
    if ('error' in parsed) { setSubmitError(parsed.error); return; }
    const { id, label, value, page, color, coords, sourceFormat } = parsed;

    if (!coords) {
      if (captures.some(c => c.id === id!)) { deleteCapture(id!); setSubmitSuccess(`Deleted "${id}"`); }
      else setSubmitError(`No capture with id "${id}" found`);
      return;
    }

    const pg = page ?? activeCapture?.page ?? 1;
    let [x, y, w, h] = coords;
    if (x > 1 || y > 1 || w > 1 || h > 1) {
      [x, y, w, h] = normaliseCoords(coords, {} as Record<string, unknown>, pg, adapter as any, null);
    }
    const item: CaptureItem = { id: id!, label: label ?? id!, value: value ?? '', page: pg, x, y, width: w, height: h, sourceFormat, color };
    if (captures.some(c => c.id === id)) { replaceCapture(item); setSubmitSuccess(`Replaced "${id}"`); }
    else { addCapture(item); setSubmitSuccess(`Added "${id}"`); }
    adapter?.navigateToPage(pg);
  }, [submitJson, captures, activeCapture, adapter, addCapture, replaceCapture, deleteCapture]);

  // Find / Add & Go
  const handleFind = useCallback(() => {
    setFindError('');
    if (!findJson.trim()) return;
    const parsed = parseJson(findJson);
    if ('error' in parsed) { setFindError(parsed.error); return; }
    const { id, coords } = parsed;
    const existing = captures.find(c => c.id === id);
    if (existing) { setActiveField(existing.id); adapter?.navigateToPage(existing.page); return; }
    if (coords) {
      const pg = parsed.page ?? 1;
      let [x, y, w, h] = coords;
      if (x > 1 || y > 1 || w > 1 || h > 1) {
        [x, y, w, h] = normaliseCoords(coords, {} as Record<string, unknown>, pg, adapter as any, null);
      }
      addCapture({ id: id!, label: parsed.label ?? id!, value: parsed.value ?? '', page: pg, x, y, width: w, height: h, sourceFormat: parsed.sourceFormat, color: parsed.color });
      adapter?.navigateToPage(pg);
      return;
    }
    setFindError('Not found. Provide coords to add.');
  }, [findJson, captures, adapter, setActiveField, addCapture]);

  const rawJson = activeCapture
    ? JSON.stringify(activeCapture, null, 2)
    : captures.length > 0 ? JSON.stringify(captures, null, 2) : null;

  return (
    <div className="flex flex-col h-full bg-[#080f1a] text-white overflow-hidden">

      {/* Header */}
      <div className="px-4 py-3 border-b border-[#1a2740] shrink-0">
        <div className="flex items-center justify-between">
          <span className="text-sm font-semibold text-white">Captures</span>
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#607080]">{captures.length} field{captures.length !== 1 ? 's' : ''}</span>
            {wordIndex.size > 0 && (
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-400 border border-blue-500/30">
                Word index
              </span>
            )}
          </div>
        </div>
        {/* Usage hint */}
        <p className="text-[10px] text-[#3a4a5a] mt-1">
          Box mode: <strong className="text-[#607080]">draw</strong> to capture area · <strong className="text-[#607080]">double-click</strong> a word
        </p>
      </div>

      <div className="flex-1 overflow-y-auto">

        {/* ── Pending capture (live drawn box result) ── */}
        <PendingCapturePanel />

        {/* Active field status */}
        {activeCapture && (
          <div className="mx-3 mt-3 p-2 rounded-lg bg-[#0d1829] border border-[#1e2d45]">
            <div className="text-[10px] text-[#607080] mb-0.5">Active</div>
            <div className="text-sm text-yellow-400 font-medium truncate">{activeCapture.label || activeCapture.id}</div>
            <div className="text-xs text-[#8899aa] truncate">{activeCapture.value}</div>
          </div>
        )}

        {/* Raw JSON preview */}
        {rawJson && (
          <div className="mx-3 mt-3">
            <button onClick={() => setRawExpanded(v => !v)}
              className="flex items-center gap-1.5 text-[10px] text-[#607080] hover:text-[#8899aa] mb-1">
              <span>{rawExpanded ? '▼' : '▶'}</span>
              <span>Raw JSON {activeCapture ? '(active)' : '(all)'}</span>
            </button>
            {rawExpanded && (
              <pre className="text-[10px] text-[#6aff9b] bg-[#060d16] rounded p-2 overflow-x-auto max-h-40 border border-[#1e2d45]">
                {rawJson}
              </pre>
            )}
          </div>
        )}

        {/* Sidecar loader */}
        <SidecarLoader />

        {/* Manual submit JSON */}
        <div className="mx-3 mt-4 pb-1">
          <div className="text-[10px] text-[#607080] mb-1.5 uppercase tracking-wide">Submit JSON</div>
          <textarea
            value={submitJson}
            onChange={e => { setSubmitJson(e.target.value); setSubmitError(''); setSubmitSuccess(''); }}
            onKeyDown={e => { if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') handleSubmit(); }}
            placeholder={'{\n  "id": "field1",\n  "label": "Invoice No",\n  "value": "INV-001",\n  "x": 0.17, "y": 0.12,\n  "width": 0.04, "height": 0.015\n}'}
            className="w-full h-28 bg-[#0d1829] border border-[#1e2d45] rounded-lg p-2 text-[11px] text-[#8899aa] font-mono resize-none focus:outline-none focus:border-[#0a84ff]/60 placeholder-[#3a4a5a]"
            spellCheck={false}
          />
          <button onClick={handleSubmit}
            className="mt-1.5 w-full py-1.5 rounded-lg text-xs font-medium bg-[#0a84ff]/15 text-[#0a84ff] border border-[#0a84ff]/30 hover:bg-[#0a84ff]/25 transition-colors">
            Submit (Ctrl+Enter)
          </button>
          {submitError   && <div className="mt-1.5 text-xs text-red-400 bg-red-500/10 rounded p-2 border border-red-500/20">{submitError}</div>}
          {submitSuccess && <div className="mt-1.5 text-xs text-green-400 bg-green-500/10 rounded p-2 border border-green-500/20">✓ {submitSuccess}</div>}
        </div>

        {/* Find / Add & Go */}
        <div className="mx-3 mt-4">
          <div className="text-[10px] text-[#607080] mb-1.5 uppercase tracking-wide">Find / Add & Go</div>
          <textarea
            value={findJson}
            onChange={e => { setFindJson(e.target.value); setFindError(''); }}
            placeholder={'{ "id": "field1" }'}
            className="w-full h-14 bg-[#0d1829] border border-[#1e2d45] rounded-lg p-2 text-[11px] text-[#8899aa] font-mono resize-none focus:outline-none focus:border-[#0a84ff]/60 placeholder-[#3a4a5a]"
            spellCheck={false}
          />
          <button onClick={handleFind}
            className="mt-1.5 w-full py-1.5 rounded-lg text-xs font-medium bg-[#1e2d45] text-[#8899aa] border border-[#1e2d45] hover:bg-[#263d5a] hover:text-white transition-colors">
            Find / Add & Go
          </button>
          {findError && <div className="mt-1.5 text-xs text-red-400 bg-red-500/10 rounded p-2 border border-red-500/20">{findError}</div>}
        </div>

        {/* Confirmed captures list */}
        {captures.length > 0 && (
          <div className="mx-3 mt-4 flex flex-col gap-1.5 pb-4">
            <div className="text-[10px] text-[#607080] mb-0.5 uppercase tracking-wide">Confirmed ({captures.length})</div>
            {captures.map(item => <CaptureCard key={item.id} item={item} />)}
          </div>
        )}
        {captures.length === 0 && (
          <div className="mx-3 mt-6 text-center text-[#3a4a5a] text-xs py-8">
            No captures yet.<br/>Enable Box Mode, then draw a box or double-click a word.
          </div>
        )}
      </div>

      {/* Legend */}
      <div className="px-3 py-3 border-t border-[#1a2740] shrink-0">
        <div className="text-[10px] text-[#607080] mb-2 uppercase tracking-wide">Legend</div>
        <div className="flex flex-wrap gap-x-3 gap-y-1">
          {[
            { color: 'rgba(255,230,0,0.5)',   label: 'Active'    },
            { color: 'rgba(255,182,193,0.6)', label: 'Duplicate' },
            { color: 'rgba(150,150,150,0.4)', label: 'Captured'  },
            { color: 'rgba(6,182,212,0.5)',   label: 'Pending'   },
          ].map(({ color, label }) => (
            <div key={label} className="flex items-center gap-1">
              <span className="w-3 h-2.5 rounded-sm border"
                style={{ background: color, borderColor: color.replace(/[\d.]+\)$/, '0.8)') }} />
              <span className="text-[10px] text-[#607080]">{label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
