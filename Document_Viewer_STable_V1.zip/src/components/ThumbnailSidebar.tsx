import React, { useEffect, useRef, useMemo } from 'react';
import { useAppStore } from '../store/appStore';
import { PALETTE_MAP } from '../adapters/types';
import type { PaletteColor, Category } from '../adapters/types';
import type { AdapterInstance } from '../store/appStore';

export function ThumbnailSidebar() {
  const adapter    = useAppStore(s => s.adapter);
  const categories = useAppStore(s => s.categories);
  const sidebarTab = useAppStore(s => s.sidebarTab);
  const setCurrentPage = useAppStore(s => s.setCurrentPage);

  // local filter state — not in store, so fine as useState
  const [activeFilter, setActiveFilter] = React.useState<string | null>(null);

  const pageCount = adapter?.pageCount ?? 0;

  const pageCategoryMap = useMemo(() => {
    const map = new Map<number, Category | null>();
    for (let p = 1; p <= pageCount; p++) {
      map.set(p, categories.find(c => c.pages.includes(p)) ?? null);
    }
    return map;
  }, [categories, pageCount]);

  const uncategorisedPages = useMemo(() => {
    const cat = new Set(categories.flatMap(c => c.pages));
    let n = 0;
    for (let p = 1; p <= pageCount; p++) if (!cat.has(p)) n++;
    return n;
  }, [categories, pageCount]);

  if (sidebarTab !== 'thumbnails') return null;

  const resolvePalette = (color?: string) =>
    color && color in PALETTE_MAP ? PALETTE_MAP[color as PaletteColor] : null;

  const getVisible = (page: number) => {
    if (!activeFilter) return true;
    if (activeFilter === '__other__') return !pageCategoryMap.get(page);
    return pageCategoryMap.get(page)?.label === activeFilter;
  };

  return (
    <div className="flex flex-col h-full overflow-hidden bg-[#0d1829] border-r border-[#1a2740]" style={{ width: 160 }}>
      {categories.length > 0 && (
        <div className="px-2 pt-2 pb-1.5 border-b border-[#1a2740] flex flex-col gap-1 shrink-0">
          <button onClick={() => setActiveFilter(null)}
            className={`text-[10px] px-2 py-1 rounded-md text-left transition-colors ${
              !activeFilter ? 'bg-blue-100 text-blue-800 border border-blue-300 font-semibold' : 'text-[#8899aa] hover:bg-[#1e2d45]'
            }`}>
            All {pageCount}
          </button>
          {categories.map(cat => {
            const pal = resolvePalette(cat.color);
            const isActive = activeFilter === cat.label;
            return (
              <button key={cat.label} onClick={() => setActiveFilter(isActive ? null : cat.label)}
                className="text-[10px] px-2 py-1 rounded-md text-left transition-colors"
                style={isActive && pal ? { background: pal.bg, color: pal.text, fontWeight: 700 }
                  : pal ? { background: pal.divBg, color: pal.divText } : { color: '#8899aa' }}>
                {cat.label} {cat.pages.length}
              </button>
            );
          })}
          {uncategorisedPages > 0 && (
            <button onClick={() => setActiveFilter(activeFilter === '__other__' ? null : '__other__')}
              className={`text-[10px] px-2 py-1 rounded-md text-left transition-colors ${
                activeFilter === '__other__' ? 'bg-[#5F5E5A] text-[#F1EFE8] font-semibold' : 'text-[#8899aa] hover:bg-[#1e2d45]'
              }`}>
              Other {uncategorisedPages}
            </button>
          )}
        </div>
      )}

      <div className="flex-1 overflow-y-auto py-2 flex flex-col gap-2 px-2">
        {Array.from({ length: pageCount }, (_, i) => i + 1).map(page => {
          if (!getVisible(page)) return null;
          const cat = pageCategoryMap.get(page) ?? null;
          const pal = resolvePalette(cat?.color);
          return (
            <ThumbnailItem key={page} page={page} adapter={adapter} category={cat} palette={pal}
              hasCategories={categories.length > 0}
              onClick={() => { setCurrentPage(page); adapter?.navigateToPage(page); }} />
          );
        })}
        {pageCount === 0 && (
          <div className="text-center text-[#3a4a5a] text-[10px] pt-8">No pages</div>
        )}
      </div>
    </div>
  );
}

interface ThumbnailItemProps {
  page: number;
  adapter: AdapterInstance | null;
  category: Category | null;
  palette: typeof PALETTE_MAP[PaletteColor] | null;
  hasCategories: boolean;
  onClick: () => void;
}

function ThumbnailItem({ page, adapter, category, palette, hasCategories, onClick }: ThumbnailItemProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const currentPage = useAppStore(s => s.currentPage);
  const isActive = currentPage === page;

  useEffect(() => {
    if (!adapter || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const draw = () => {
      const src = adapter.getPageCanvas(page);
      if (!src) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      const W = 128;
      const aspect = src.height / Math.max(src.width, 1);
      canvas.width = W;
      canvas.height = Math.round(W * aspect);
      ctx.drawImage(src, 0, 0, canvas.width, canvas.height);
    };
    draw();
    adapter.onPageRendered((p: number) => { if (p === page) draw(); });
  }, [adapter, page]);

  return (
    <button onClick={onClick}
      className={`relative rounded overflow-hidden shrink-0 text-left transition-all ${
        isActive ? 'ring-2 ring-[#0a84ff] ring-offset-1 ring-offset-[#0d1829]' : 'hover:ring-1 hover:ring-[#2a3f60]'
      }`}
      style={category && palette ? { borderLeft: `3px solid ${palette.bg}` } : {}}>
      <canvas ref={canvasRef} className="w-full bg-white" style={{ display: 'block' }} />
      <div className="absolute top-0.5 left-0.5 bg-black/60 text-white text-[9px] px-1 rounded">{page}</div>
      {category && palette ? (
        <div className="absolute bottom-0 left-0 right-0 text-[9px] px-1 py-0.5 text-center truncate"
          style={{ background: palette.bg, color: palette.text }}>
          {category.label}
        </div>
      ) : hasCategories && (
        <div className="absolute bottom-0 left-0 right-0 text-[9px] px-1 py-0.5 text-center truncate"
          style={{ background: '#3a3a37', color: '#c4c0b8' }}>
          Others
        </div>
      )}
    </button>
  );
}
