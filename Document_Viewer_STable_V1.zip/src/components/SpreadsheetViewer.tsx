// ─────────────────────────────────────────────────────────────────────────────
// SpreadsheetViewer — fixed coordinate system, zoom, search, click2pick
//
// COORDINATE FIX:
//   All fractional coords (x,y,w,h) are computed from the TABLE element's
//   own bounding rect — NOT the wrapper div. The wrapper div includes sticky
//   header and row-number offsets that cause the wrong cell to be captured.
//   We store a ref to the <table> element and use that for all math.
//
// ZOOM:
//   CSS transform scale() on the table, wrapped in an overflow container.
//   The wrapper is sized to the natural (unscaled) table dimensions so the
//   scroll container gets correct scrollbar range.
//
// SEARCH:
//   Scans <td data-cell-text> attributes for exact/contains match.
//   Results land in the store's search.results array, navigated by the
//   standard Next/Prev toolbar buttons.
//
// CLICK2PICK (box mode):
//   onClick on each <td> → coords from table.getBoundingClientRect()
//   Fractional: (cell.left - table.left) / table.width, etc.
//   Double-click → same capture but via dblclick event.
// ─────────────────────────────────────────────────────────────────────────────

import React, { useEffect, useRef, useCallback, useState, useMemo } from 'react';
import { useAppStore } from '../store/appStore';
import type { SpreadsheetAdapter } from '../adapters/SpreadsheetAdapter';

const COL_WIDTH  = 96;   // px per column (natural, pre-zoom)
const ROW_HEIGHT = 22;   // px per row
const ROW_NUM_W  = 44;   // px for the row-number column
const HEADER_H   = 26;   // px for the column-header row

interface SpreadsheetViewerProps { adapter: SpreadsheetAdapter; }

// ── Helper: column index → letter (A, B, … Z, AA, …) ─────────────────────────
function colLetter(i: number): string {
  let r = '';
  while (i >= 0) { r = String.fromCharCode(65 + (i % 26)) + r; i = Math.floor(i / 26) - 1; }
  return r;
}

// ── Helper: cell address string ───────────────────────────────────────────────
function cellAddr(row: number, col: number) { return `${colLetter(col)}${row + 1}`; }

// ── Main component ────────────────────────────────────────────────────────────
export function SpreadsheetViewer({ adapter }: SpreadsheetViewerProps) {
  const currentPage    = useAppStore(s => s.currentPage);
  const setCurrentPage = useAppStore(s => s.setCurrentPage);
  const sheets = adapter.getAllSheets();

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-[#1a1f2e]">
      {/* Sheet tabs */}
      {sheets.length > 1 && (
        <div className="flex items-center gap-1 px-3 py-2 bg-[#0d1829] border-b border-[#1e2d45] overflow-x-auto shrink-0">
          {sheets.map((sheet, i) => {
            const pageNum = i + 1;
            return (
              <button key={i} onClick={() => setCurrentPage(pageNum)}
                className={`px-3 py-1.5 text-xs rounded-md font-medium whitespace-nowrap transition-colors ${
                  currentPage === pageNum
                    ? 'bg-[#0a84ff] text-white'
                    : 'text-[#8899aa] hover:text-white hover:bg-[#1e2d45]'
                }`}>
                {sheet.name || `Sheet ${pageNum}`}
              </button>
            );
          })}
        </div>
      )}

      {/* Sheet tables */}
      <div className="flex-1 overflow-hidden relative">
        {sheets.map((sheet, i) => (
          <SheetTable
            key={i}
            pageNum={i + 1}
            sheet={sheet}
            adapter={adapter}
            visible={currentPage === i + 1}
          />
        ))}
      </div>
    </div>
  );
}

// ── Sheet table ───────────────────────────────────────────────────────────────
interface SheetTableProps {
  pageNum: number;
  sheet: { name: string; rows: string[][]; colCount: number; rowCount: number };
  adapter: SpreadsheetAdapter;
  visible: boolean;
}

function SheetTable({ pageNum, sheet, adapter, visible }: SheetTableProps) {
  const boxMode          = useAppStore(s => s.boxMode);
  const zoom             = useAppStore(s => s.zoom);
  const setPendingCapture = useAppStore(s => s.setPendingCapture);
  const setPreviewRect   = useAppStore(s => s.setPreviewRect);
  const search           = useAppStore(s => s.search);
  const setSearchResults = useAppStore(s => s.runSearch); // we'll trigger from effect

  // Refs for DOM elements
  const scrollRef = useRef<HTMLDivElement>(null);    // outer scroll container
  const tableRef  = useRef<HTMLTableElement>(null);  // the actual <table>
  const wrapperRef = useRef<HTMLDivElement>(null);   // data-page-number div

  const { rows, colCount, rowCount } = sheet;

  // Register page element with adapter (use scrollRef for highlight canvas)
  useEffect(() => {
    adapter.registerPageElement(pageNum, wrapperRef.current);
    if (visible) adapter.notifyPageRendered(pageNum);
    return () => adapter.registerPageElement(pageNum, null);
  }, [adapter, pageNum, visible]);

  // ── Coordinate helpers ────────────────────────────────────────────────────
  // ALL coords relative to the TABLE element (not wrapper, not scrollRef).
  // This avoids sticky header / row-number column offset bugs.

  const getCellFrac = useCallback((
    cellEl: HTMLElement
  ): { x: number; y: number; width: number; height: number } | null => {
    const table = tableRef.current;
    if (!table) return null;

    const tRect = table.getBoundingClientRect();
    const cRect = cellEl.getBoundingClientRect();

    // Natural (pre-zoom) table dimensions
    const naturalW = tRect.width  / zoom;
    const naturalH = tRect.height / zoom;

    // Cell position relative to table, divided by zoom to get natural coords
    const relLeft = (cRect.left - tRect.left) / zoom;
    const relTop  = (cRect.top  - tRect.top)  / zoom;
    const cellW   = cRect.width  / zoom;
    const cellH   = cRect.height / zoom;

    return {
      x:      relLeft / naturalW,
      y:      relTop  / naturalH,
      width:  cellW   / naturalW,
      height: cellH   / naturalH,
    };
  }, [zoom]);

  // ── Click2Pick handler ────────────────────────────────────────────────────
  const handleCellClick = useCallback((
    e: React.MouseEvent<HTMLTableCellElement>,
    row: number, col: number, cellValue: string
  ) => {
    if (!boxMode) return;

    const frac = getCellFrac(e.currentTarget);
    if (!frac) return;

    const addr = cellAddr(row, col);
    setPendingCapture({
      text: cellValue || addr,
      page: pageNum,
      x: frac.x, y: frac.y,
      width: frac.width, height: frac.height,
    });
    setPreviewRect({ page: pageNum, ...frac });
  }, [boxMode, pageNum, getCellFrac, setPendingCapture, setPreviewRect]);

  // Double-click → immediate capture (same coords, same handler)
  const handleCellDblClick = useCallback((
    e: React.MouseEvent<HTMLTableCellElement>,
    row: number, col: number, cellValue: string
  ) => {
    if (!boxMode) return;
    e.preventDefault();
    handleCellClick(e, row, col, cellValue);
  }, [boxMode, handleCellClick]);

  // ── In-table search ───────────────────────────────────────────────────────
  // Runs whenever the search query/options change, for this visible sheet
  useEffect(() => {
    if (!visible || !search.query.trim()) return;

    const q = search.matchCase ? search.query : search.query.toLowerCase();
    const results: Array<{ page: number; x: number; y: number; width: number; height: number; text: string }> = [];

    const table = tableRef.current;
    if (!table) return;
    const tRect = table.getBoundingClientRect();
    const naturalW = tRect.width  / zoom;
    const naturalH = tRect.height / zoom;

    const cells = table.querySelectorAll<HTMLTableCellElement>('td[data-cell-text]');
    for (const cell of cells) {
      const txt = cell.dataset.cellText ?? '';
      if (!txt) continue;
      const t = search.matchCase ? txt : txt.toLowerCase();
      const match = search.matchType === 'exact' ? t === q : t.includes(q);
      if (!match) continue;

      const cRect = cell.getBoundingClientRect();
      const relLeft = (cRect.left - tRect.left) / zoom;
      const relTop  = (cRect.top  - tRect.top)  / zoom;
      const cellW   = cRect.width  / zoom;
      const cellH   = cRect.height / zoom;

      results.push({
        page: pageNum,
        x:      relLeft / naturalW,
        y:      relTop  / naturalH,
        width:  cellW   / naturalW,
        height: cellH   / naturalH,
        text: txt,
      });
    }

    // Push results into store (merge with existing results from other pages)
    if (results.length > 0) {
      useAppStore.setState(s => {
        const filtered = s.search.results.filter(r => r.page !== pageNum);
        const merged   = [...filtered, ...results].sort(
          (a, b) => a.page !== b.page ? a.page - b.page : a.y !== b.y ? a.y - b.y : a.x - b.x
        );
        const currentIndex = merged.length > 0 ? 0 : -1;
        return { search: { ...s.search, results: merged, currentIndex } };
      });
    }
  }, [search.query, search.matchCase, search.matchType, visible, pageNum, zoom]);

  // ── Search result highlight ───────────────────────────────────────────────
  // Which cells are search results on this page?
  const searchHitCells = useMemo(() => {
    const set = new Set<string>(); // "row,col"
    if (!search.query.trim()) return set;
    const q = search.matchCase ? search.query : search.query.toLowerCase();
    rows.forEach((row, ri) => {
      row.forEach((cell, ci) => {
        if (!cell) return;
        const t = search.matchCase ? cell : cell.toLowerCase();
        const match = search.matchType === 'exact' ? t === q : t.includes(q);
        if (match) set.add(`${ri},${ci}`);
      });
    });
    return set;
  }, [rows, search.query, search.matchCase, search.matchType]);

  // Which result index is "current" for this page?
  const currentResultKey = useMemo(() => {
    const r = search.results[search.currentIndex];
    if (!r || r.page !== pageNum) return null;
    // Find the cell at this fractional position
    if (!tableRef.current) return null;
    const tRect = tableRef.current.getBoundingClientRect();
    const naturalW = tRect.width  / zoom;
    const naturalH = tRect.height / zoom;
    // Reverse-engineer row/col from fractions
    const col = Math.round(r.x * naturalW / COL_WIDTH) - 1; // approx
    const row = Math.round(r.y * naturalH / ROW_HEIGHT) - 1;
    return `${row},${col}`;
  }, [search.results, search.currentIndex, pageNum, zoom]);

  if (!visible) return null;

  // Natural dimensions (pre-zoom)
  const naturalTableW = ROW_NUM_W + colCount * COL_WIDTH;
  const naturalTableH = HEADER_H  + rowCount * ROW_HEIGHT;

  return (
    // Outer scroll container — sized to natural dimensions, zoom is on inner
    <div
      ref={scrollRef}
      data-viewer-scroll="1"
      className="w-full h-full overflow-auto bg-[#111827]"
    >
      {/* Size placeholder so scrollbars reflect zoomed size */}
      <div
        style={{
          width:  naturalTableW * zoom,
          height: naturalTableH * zoom,
          position: 'relative',
        }}
      >
        {/* Zoomed table */}
        <div
          ref={wrapperRef}
          data-page-number={pageNum}
          style={{
            position: 'absolute',
            top: 0, left: 0,
            transform: `scale(${zoom})`,
            transformOrigin: 'top left',
            width: naturalTableW,
            height: naturalTableH,
          }}
        >
          <table
            ref={tableRef}
            className="border-collapse select-none"
            style={{ tableLayout: 'fixed', width: naturalTableW, fontSize: 12 }}
          >
            {/* Column header row */}
            <colgroup>
              <col style={{ width: ROW_NUM_W }} />
              {Array.from({ length: colCount }, (_, ci) => (
                <col key={ci} style={{ width: COL_WIDTH }} />
              ))}
            </colgroup>
            <thead>
              <tr style={{ height: HEADER_H }}>
                {/* Corner cell */}
                <th className="bg-[#0d1829] border border-[#1e2d45] text-[#607080]
                  font-normal text-center sticky top-0 left-0 z-20"
                  style={{ width: ROW_NUM_W, height: HEADER_H }} />
                {Array.from({ length: colCount }, (_, ci) => (
                  <th key={ci}
                    className="bg-[#0d1829] border border-[#1e2d45] text-[#607080]
                      font-normal text-center px-1"
                    style={{ width: COL_WIDTH, height: HEADER_H }}>
                    {colLetter(ci)}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((row, ri) => (
                <tr key={ri} style={{ height: ROW_HEIGHT }}>
                  {/* Row number */}
                  <td
                    className="bg-[#0d1829] border border-[#1e2d45] text-[#607080]
                      text-center text-xs sticky left-0 z-10"
                    style={{ width: ROW_NUM_W, height: ROW_HEIGHT, fontSize: 11 }}>
                    {ri + 1}
                  </td>
                  {Array.from({ length: colCount }, (_, ci) => {
                    const cellVal = row[ci] ?? '';
                    const key = `${ri},${ci}`;
                    const isSearchHit    = searchHitCells.has(key);
                    const isCurrentResult = currentResultKey === key;

                    return (
                      <td
                        key={ci}
                        data-row={ri}
                        data-col={ci}
                        data-cell-text={cellVal}
                        title={cellVal}
                        onClick={e => handleCellClick(e, ri, ci, cellVal)}
                        onDoubleClick={e => handleCellDblClick(e, ri, ci, cellVal)}
                        className={`border border-[#1e2d45] px-1.5 text-xs
                          whitespace-nowrap overflow-hidden transition-colors
                          ${boxMode ? 'cursor-crosshair' : 'cursor-default'}
                          ${isCurrentResult
                            ? 'bg-orange-500/40 text-white'
                            : isSearchHit
                              ? 'bg-yellow-500/25 text-[#ffe066]'
                              : 'bg-[#111827] text-[#d0dae8]'
                          }
                          ${boxMode && !isSearchHit && !isCurrentResult ? 'hover:bg-[#1a2a40]' : ''}
                        `}
                        style={{ width: COL_WIDTH, height: ROW_HEIGHT, maxWidth: COL_WIDTH }}
                      >
                        {cellVal}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
