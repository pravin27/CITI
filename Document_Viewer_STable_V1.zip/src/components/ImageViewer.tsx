import React, { useEffect, useRef } from 'react';
import { useAppStore } from '../store/appStore';
import type { ImageAdapter } from '../adapters/ImageAdapter';

const PAGE_GAP = 12;

interface ImageViewerProps { adapter: ImageAdapter; zoom: number; }

export function ImageViewer({ adapter, zoom }: ImageViewerProps) {
  const setCurrentPage = useAppStore(s => s.setCurrentPage);
  const rotation       = useAppStore(s => s.rotation);
  const frames = adapter.getAllFrames();
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (containerRef.current) containerRef.current.setAttribute('data-viewer-scroll', '1');
  }, []);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    const observer = new IntersectionObserver(
      entries => {
        let best: { page: number; ratio: number } | null = null;
        for (const e of entries) {
          if (!e.isIntersecting) continue;
          const page = Number((e.target as HTMLElement).dataset.pageNumber);
          if (!best || e.intersectionRatio > best.ratio) best = { page, ratio: e.intersectionRatio };
        }
        if (best) setCurrentPage(best.page);
      },
      { root: container, threshold: [0, 0.5] },
    );
    container.querySelectorAll<HTMLElement>('[data-page-number]').forEach(el => observer.observe(el));
    return () => observer.disconnect();
  }, [frames.length, setCurrentPage]);

  return (
    <div ref={containerRef} className="flex-1 overflow-y-auto overflow-x-auto bg-[#1a1f2e]">
      <div className="flex flex-col items-center py-4">
        {frames.map((frame, i) => (
          <ImagePageCanvas key={i} pageNum={i + 1} frame={frame} zoom={zoom} rotation={rotation} adapter={adapter} />
        ))}
      </div>
    </div>
  );
}

interface ImagePageCanvasProps {
  pageNum: number;
  frame: { canvas: HTMLCanvasElement; width: number; height: number };
  zoom: number;
  rotation: number;
  adapter: ImageAdapter;
}

function ImagePageCanvas({ pageNum, frame, zoom, rotation, adapter }: ImagePageCanvasProps) {
  const wrapperRef = useRef<HTMLDivElement>(null);
  const canvasRef  = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    adapter.registerPageElement(pageNum, wrapperRef.current);
    return () => adapter.registerPageElement(pageNum, null);
  }, [adapter, pageNum]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const isFlipped = rotation === 90 || rotation === 270;
    const displayW = Math.round((isFlipped ? frame.height : frame.width)  * zoom);
    const displayH = Math.round((isFlipped ? frame.width  : frame.height) * zoom);
    canvas.width  = displayW;
    canvas.height = displayH;
    const ctx = canvas.getContext('2d')!;
    ctx.clearRect(0, 0, displayW, displayH);
    ctx.save();
    ctx.translate(displayW / 2, displayH / 2);
    ctx.rotate((rotation * Math.PI) / 180);
    const drawW = frame.width  * zoom;
    const drawH = frame.height * zoom;
    ctx.drawImage(frame.canvas, -drawW / 2, -drawH / 2, drawW, drawH);
    ctx.restore();
    adapter.notifyPageRendered(pageNum);
  }, [frame, zoom, rotation, adapter, pageNum]);

  const isFlipped = rotation === 90 || rotation === 270;
  const displayW = Math.round((isFlipped ? frame.height : frame.width)  * zoom);
  const displayH = Math.round((isFlipped ? frame.width  : frame.height) * zoom);

  return (
    <div ref={wrapperRef} data-page-number={pageNum} className="relative shadow-2xl"
      style={{ marginBottom: PAGE_GAP }}>
      <canvas ref={canvasRef} style={{ width: displayW, height: displayH, display: 'block' }} />
    </div>
  );
}
