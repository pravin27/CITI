import { create } from 'zustand';
import type { CaptureItem, Category, WordEntry } from '../adapters/types';
import { PDFAdapter } from '../adapters/PDFAdapter';
import { ImageAdapter } from '../adapters/ImageAdapter';
import { SpreadsheetAdapter } from '../adapters/SpreadsheetAdapter';
import { detectFormat } from '../adapters/types';

export type AdapterInstance = PDFAdapter | ImageAdapter | SpreadsheetAdapter;

interface HighlightRect {
  x: number; y: number; width: number; height: number;
  id: string; color?: string; type?: 'external';
}

export interface PendingCapture {
  text: string; page: number;
  x: number; y: number; width: number; height: number;
}

export interface SearchState {
  query: string;
  matchCase: boolean;
  matchType: 'exact' | 'contains';
  highlightAll: boolean;
  results: Array<{ page: number; x: number; y: number; width: number; height: number; text: string }>;
  currentIndex: number; // -1 = none
  isOpen: boolean;
}

interface AppState {
  // ── Document ──
  file: File | null;
  fileName: string;
  format: ReturnType<typeof detectFormat>;
  adapter: AdapterInstance | null;
  isLoading: boolean;
  loadError: string | null;

  // ── Box Mode ──
  boxMode: boolean;

  // ── Sidebar ──
  sidebarOpen: boolean;
  sidebarTab: 'thumbnails' | 'outline';

  // ── Current page ──
  currentPage: number;

  // ── Rotation (degrees: 0 | 90 | 180 | 270) ──
  rotation: 0 | 90 | 180 | 270;

  // ── Zoom ──
  zoom: number;
  zoomMode: 'custom' | 'page-fit' | 'page-width' | 'actual';

  // ── Search ──
  search: SearchState;

  // ── Captures ──
  captures: CaptureItem[];
  activeFieldId: string | null;
  pendingCapture: PendingCapture | null;

  // ── JSON sidecar data ──
  wordIndex: Map<number, WordEntry[]>;
  categories: Category[];
  highlightIndex: Map<number, HighlightRect[]>;

  // ── Preview pulse ──
  previewRect: { page: number; x: number; y: number; width: number; height: number } | null;

  // ── Actions ──
  openFile(file: File): Promise<void>;
  closeFile(): void;
  setBoxMode(on: boolean): void;
  setSidebarOpen(open: boolean): void;
  setSidebarTab(tab: 'thumbnails' | 'outline'): void;
  setCurrentPage(page: number): void;
  setZoom(z: number): void;
  setZoomMode(mode: AppState['zoomMode'], containerW?: number, containerH?: number, pageW?: number, pageH?: number): void;
  rotateCW(): void;
  rotateCCW(): void;
  downloadFile(): void;

  // Search
  setSearchOpen(open: boolean): void;
  setSearchQuery(q: string): void;
  setSearchOption(key: keyof Pick<SearchState,'matchCase'|'matchType'|'highlightAll'>, value: boolean | 'exact' | 'contains'): void;
  runSearch(): void;
  searchNext(): void;
  searchPrev(): void;
  clearSearch(): void;

  addCapture(item: CaptureItem): void;
  replaceCapture(item: CaptureItem): void;
  deleteCapture(id: string): void;
  setActiveField(id: string | null): void;
  setPendingCapture(p: PendingCapture | null): void;
  clearPendingCapture(): void;
  setWordIndex(map: Map<number, WordEntry[]>): void;
  setCategories(cats: Category[]): void;
  setPreviewRect(rect: AppState['previewRect']): void;
  clearPreviewRect(): void;
  _rebuildHighlightIndex(): void;
}

const defaultSearch: SearchState = {
  query: '', matchCase: false, matchType: 'contains',
  highlightAll: true, results: [], currentIndex: -1, isOpen: false,
};

export const useAppStore = create<AppState>((set, get) => ({
  file: null, fileName: '', format: 'unknown', adapter: null,
  isLoading: false, loadError: null,
  boxMode: false, sidebarOpen: false, sidebarTab: 'thumbnails',
  currentPage: 1, rotation: 0, zoom: 1.0, zoomMode: 'custom',
  search: defaultSearch,
  captures: [], activeFieldId: null, pendingCapture: null,
  wordIndex: new Map(), categories: [], highlightIndex: new Map(),
  previewRect: null,

  async openFile(file: File) {
    const { adapter: old } = get();
    if (old && 'dispose' in old) (old as any).dispose();
    const format = detectFormat(file.name);
    set({
      file, fileName: file.name, format, isLoading: true, loadError: null,
      captures: [], activeFieldId: null, pendingCapture: null,
      wordIndex: new Map(), categories: [], highlightIndex: new Map(),
      currentPage: 1, adapter: null, previewRect: null,
      rotation: 0, zoomMode: 'custom', zoom: 1.0,
      search: defaultSearch,
    });
    try {
      let adapter: AdapterInstance;
      if (format === 'pdf') {
        adapter = new PDFAdapter();
      } else if (format === 'image') {
        const ia = new ImageAdapter(); await ia.loadFile(file); adapter = ia;
      } else if (format === 'spreadsheet') {
        const sa = new SpreadsheetAdapter(); await sa.loadFile(file); adapter = sa;
      } else {
        set({ isLoading: false, loadError: `Unsupported format: ${file.name.split('.').pop()}` });
        return;
      }
      set({ adapter, isLoading: false });
    } catch (err) { set({ isLoading: false, loadError: String(err) }); }
  },

  closeFile() {
    const { adapter } = get();
    if (adapter && 'dispose' in adapter) (adapter as any).dispose();
    set({
      file: null, fileName: '', format: 'unknown', adapter: null,
      isLoading: false, loadError: null, captures: [], activeFieldId: null,
      pendingCapture: null, wordIndex: new Map(), categories: [],
      highlightIndex: new Map(), currentPage: 1, previewRect: null,
      rotation: 0, zoom: 1.0, zoomMode: 'custom', search: defaultSearch,
    });
  },

  setBoxMode(on)       { set({ boxMode: on }); },
  setSidebarOpen(open) { set({ sidebarOpen: open }); },
  setSidebarTab(tab)   { set({ sidebarTab: tab }); },
  setCurrentPage(page) { set({ currentPage: page }); },

  setZoom(z) { set({ zoom: Math.max(0.1, Math.min(5, z)), zoomMode: 'custom' }); },

  setZoomMode(mode, containerW, containerH, pageW, pageH) {
    if (mode === 'actual') {
      set({ zoom: 1.0, zoomMode: 'actual' });
    } else if (mode === 'page-fit' && containerW && containerH && pageW && pageH) {
      const z = Math.min(containerW / pageW, containerH / pageH) * 0.95;
      set({ zoom: Math.max(0.1, z), zoomMode: 'page-fit' });
    } else if (mode === 'page-width' && containerW && pageW) {
      const z = (containerW / pageW) * 0.97;
      set({ zoom: Math.max(0.1, z), zoomMode: 'page-width' });
    } else {
      set({ zoomMode: mode });
    }
  },

  rotateCW() {
    set(s => ({ rotation: ((s.rotation + 90) % 360) as 0|90|180|270 }));
  },
  rotateCCW() {
    set(s => ({ rotation: ((s.rotation + 270) % 360) as 0|90|180|270 }));
  },

  downloadFile() {
    const { file } = get();
    if (!file) return;
    const url = URL.createObjectURL(file);
    const a = document.createElement('a');
    a.href = url; a.download = file.name; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  },

  // ── Search ──────────────────────────────────────────────────────────────────
  setSearchOpen(open) { set(s => ({ search: { ...s.search, isOpen: open } })); },
  setSearchQuery(q)   { set(s => ({ search: { ...s.search, query: q } })); },
  setSearchOption(key, value) {
    set(s => ({ search: { ...s.search, [key]: value } }));
  },

  runSearch() {
    const { search, wordIndex, adapter, format, zoom } = get();
    const q = search.matchCase ? search.query : search.query.toLowerCase();
    if (!q.trim()) { set(s => ({ search: { ...s.search, results: [], currentIndex: -1 } })); return; }

    const results: SearchState['results'] = [];

    // ── For spreadsheets: scan td[data-cell-text] ────────────────────────────
    if (format === 'spreadsheet') {
      const pageEls = document.querySelectorAll<HTMLElement>('[data-page-number]');
      for (const pageEl of pageEls) {
        const page = Number(pageEl.dataset.pageNumber);
        const table = pageEl.querySelector<HTMLTableElement>('table');
        if (!table) continue;
        const tRect = table.getBoundingClientRect();
        const naturalW = tRect.width  / zoom;
        const naturalH = tRect.height / zoom;
        const cells = table.querySelectorAll<HTMLTableCellElement>('td[data-cell-text]');
        for (const cell of cells) {
          const txt = cell.dataset.cellText ?? '';
          if (!txt) continue;
          const t = search.matchCase ? txt : txt.toLowerCase();
          const match = search.matchType === 'exact' ? t === q : t.includes(q);
          if (!match) continue;
          const cRect = cell.getBoundingClientRect();
          results.push({
            page,
            x:      ((cRect.left - tRect.left) / zoom) / naturalW,
            y:      ((cRect.top  - tRect.top)  / zoom) / naturalH,
            width:  (cRect.width  / zoom) / naturalW,
            height: (cRect.height / zoom) / naturalH,
            text: txt,
          });
        }
      }
      results.sort((a, b) => a.page !== b.page ? a.page - b.page : a.y !== b.y ? a.y - b.y : a.x - b.x);
      const currentIndex = results.length > 0 ? 0 : -1;
      set(s => ({ search: { ...s.search, results, currentIndex } }));
      if (results.length > 0) {
        const first = results[0];
        get().adapter?.navigateToPage(first.page);
        get().setPreviewRect({ page: first.page, x: first.x, y: first.y, width: first.width, height: first.height });
      }
      return;
    }

    // ── PDF / Image: word index then DOM spans ────────────────────────────────
    for (const [page, entries] of wordIndex) {
      for (const e of entries) {
        const t = search.matchCase ? e.text : e.text.toLowerCase();
        const match = search.matchType === 'exact' ? t === q : t.includes(q);
        if (match) results.push({ page, x: e.x, y: e.y, width: e.width, height: e.height, text: e.text });
      }
    }

    if (!results.length && adapter) {
      const pageEls = document.querySelectorAll<HTMLElement>('[data-page-number]');
      for (const pageEl of pageEls) {
        const page = Number(pageEl.dataset.pageNumber);
        const inner = pageEl.querySelector('canvas:not([data-hl-canvas])') as HTMLElement ?? pageEl;
        const rect  = inner.getBoundingClientRect();
        const spans = pageEl.querySelectorAll<HTMLElement>('span, [data-json-word]');
        for (const sp of spans) {
          const txt = (sp.dataset.jsonWord ?? sp.textContent ?? '').trim();
          if (!txt) continue;
          const t = search.matchCase ? txt : txt.toLowerCase();
          const match = search.matchType === 'exact' ? t === q : t.includes(q);
          if (match) {
            const r = sp.getBoundingClientRect();
            results.push({
              page,
              x: (r.left - rect.left) / rect.width,
              y: (r.top  - rect.top)  / rect.height,
              width:  r.width  / rect.width,
              height: r.height / rect.height,
              text: txt,
            });
          }
        }
      }
    }

    results.sort((a, b) => a.page !== b.page ? a.page - b.page : a.y !== b.y ? a.y - b.y : a.x - b.x);
    const currentIndex = results.length > 0 ? 0 : -1;
    set(s => ({ search: { ...s.search, results, currentIndex } }));
    if (results.length > 0) {
      const first = results[0];
      get().adapter?.navigateToPage(first.page);
      get().setPreviewRect({ page: first.page, x: first.x, y: first.y, width: first.width, height: first.height });
    }
  },

  searchNext() {
    const { search, format, zoom } = get();
    if (!search.results.length) return;
    const idx = (search.currentIndex + 1) % search.results.length;
    const r = search.results[idx];
    set(s => ({ search: { ...s.search, currentIndex: idx } }));
    get().adapter?.navigateToPage(r.page);
    get().setPreviewRect({ page: r.page, x: r.x, y: r.y, width: r.width, height: r.height });
    // For spreadsheets: scroll the matched cell into view
    if (format === 'spreadsheet') {
      setTimeout(() => {
        const el = document.querySelector<HTMLElement>(`[data-page-number="${r.page}"] td[data-cell-text="${CSS.escape(r.text)}"]`);
        el?.scrollIntoView({ block: 'center', inline: 'center', behavior: 'smooth' });
      }, 50);
    }
  },

  searchPrev() {
    const { search, format, zoom } = get();
    if (!search.results.length) return;
    const idx = (search.currentIndex - 1 + search.results.length) % search.results.length;
    const r = search.results[idx];
    set(s => ({ search: { ...s.search, currentIndex: idx } }));
    get().adapter?.navigateToPage(r.page);
    get().setPreviewRect({ page: r.page, x: r.x, y: r.y, width: r.width, height: r.height });
    if (format === 'spreadsheet') {
      setTimeout(() => {
        const el = document.querySelector<HTMLElement>(`[data-page-number="${r.page}"] td[data-cell-text="${CSS.escape(r.text)}"]`);
        el?.scrollIntoView({ block: 'center', inline: 'center', behavior: 'smooth' });
      }, 50);
    }
  },

  clearSearch() {
    set(s => ({ search: { ...s.search, query: '', results: [], currentIndex: -1 } }));
    get().clearPreviewRect();
  },

  // ── Captures ────────────────────────────────────────────────────────────────
  addCapture(item) {
    set(s => ({ captures: [...s.captures, item], activeFieldId: item.id }));
    get()._rebuildHighlightIndex();
  },
  replaceCapture(item) {
    set(s => {
      const captures = s.captures.map(c => c.id === item.id ? item : c);
      if (!captures.some(c => c.id === item.id)) captures.push(item);
      return { captures, activeFieldId: item.id };
    });
    get()._rebuildHighlightIndex();
  },
  deleteCapture(id) {
    set(s => ({
      captures: s.captures.filter(c => c.id !== id),
      activeFieldId: s.activeFieldId === id ? null : s.activeFieldId,
    }));
    get()._rebuildHighlightIndex();
  },
  setActiveField(id)     { set({ activeFieldId: id }); },
  setPendingCapture(p)   { set({ pendingCapture: p }); },
  clearPendingCapture()  { set({ pendingCapture: null }); },
  setWordIndex(map)      { set({ wordIndex: map }); },
  setCategories(cats)    { set({ categories: cats }); },
  setPreviewRect(rect)   { set({ previewRect: rect }); },
  clearPreviewRect()     { set({ previewRect: null }); },

  _rebuildHighlightIndex() {
    const { captures } = get();
    const index = new Map<number, HighlightRect[]>();
    for (const c of captures) {
      if (!index.has(c.page)) index.set(c.page, []);
      index.get(c.page)!.push({ x: c.x, y: c.y, width: c.width, height: c.height, id: c.id, color: c.color, type: c.type });
    }
    set({ highlightIndex: index });
  },
}));
