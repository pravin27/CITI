/**
 * ViewerToolbar.component.test.tsx
 *
 * Component tests for ViewerToolbar.
 * Tests pagination buttons, showSplitMerge icon, zoom controls, Reset button.
 * Strategy: set store state → render → interact → assert.
 */

import React from 'react';
import { describe, it, expect, beforeEach, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { ViewerToolbar } from '../../components/ViewerToolbar';
import { useAppStore } from '../../store/appStore';

// ── Mock heavy imports that ViewerToolbar doesn't need for these tests ────────
vi.mock('../../components/PDFViewer', () => ({
  navigatePdfPage: vi.fn(),
}));

vi.mock('../../hooks/useThumbnailRenderer', () => ({
  useThumbnailRenderer: () => ({ registerThumb: vi.fn(), unregisterThumb: vi.fn(), pauseRendering: vi.fn() }),
}));

// ── Minimal mock adapter ──────────────────────────────────────────────────────
const mockAdapter = {
  navigateToPage: vi.fn(),
  pageCount: 10,
  getPageDimensions: vi.fn(() => ({ width: 816, height: 1056 })),
  constructor: { name: 'PDFAdapter' },
};

// ── Reset store to clean state before each test ───────────────────────────────
beforeEach(() => {
  useAppStore.setState({
    adapter:       null,
    file:          null,
    currentPage:   1,
    pageCount:     0,
    zoom:          1,
    zoomMode:      'page-fit',
    showSplitMerge: false,
    isSplitScreen: false,
    annotateMode:  false,
    search:        { isOpen: false, query: '', results: [], currentIndex: 0, highlightAll: false },
  });
  vi.clearAllMocks();
});

// ── Helper — set up store for a loaded document ───────────────────────────────
function setLoadedDoc(overrides: Record<string, unknown> = {}) {
  useAppStore.setState({
    adapter:     mockAdapter as any,
    file:        new File([''], 'test.pdf', { type: 'application/pdf' }),
    currentPage: 1,
    pageCount:   10,
    ...overrides,
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// Rendering
// ─────────────────────────────────────────────────────────────────────────────
describe('ViewerToolbar — rendering', () => {

  it('renders without crashing', () => {
    expect(() => render(<ViewerToolbar />)).not.toThrow();
  });

  it('renders page counter when document loaded', () => {
    setLoadedDoc({ currentPage: 3, pageCount: 10 });
    render(<ViewerToolbar />);
    expect(screen.getByText(/3/)).toBeTruthy();
    expect(screen.getByText(/10/)).toBeTruthy();
  });

  it('renders previous page button', () => {
    setLoadedDoc();
    render(<ViewerToolbar />);
    const prevBtn = screen.getByTitle(/previous page/i);
    expect(prevBtn).toBeTruthy();
  });

  it('renders next page button', () => {
    setLoadedDoc();
    render(<ViewerToolbar />);
    const nextBtn = screen.getByTitle(/next page/i);
    expect(nextBtn).toBeTruthy();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Pagination — previous/next buttons
// ─────────────────────────────────────────────────────────────────────────────
describe('ViewerToolbar — pagination', () => {

  it('prev button disabled on page 1', () => {
    setLoadedDoc({ currentPage: 1, pageCount: 10 });
    render(<ViewerToolbar />);
    const prevBtn = screen.getByTitle(/previous page/i);
    expect(prevBtn).toBeDisabled();
  });

  it('prev button enabled on page > 1', () => {
    setLoadedDoc({ currentPage: 5, pageCount: 10 });
    render(<ViewerToolbar />);
    const prevBtn = screen.getByTitle(/previous page/i);
    expect(prevBtn).not.toBeDisabled();
  });

  it('next button disabled on last page', () => {
    setLoadedDoc({ currentPage: 10, pageCount: 10 });
    render(<ViewerToolbar />);
    const nextBtn = screen.getByTitle(/next page/i);
    expect(nextBtn).toBeDisabled();
  });

  it('next button enabled when not on last page', () => {
    setLoadedDoc({ currentPage: 5, pageCount: 10 });
    render(<ViewerToolbar />);
    const nextBtn = screen.getByTitle(/next page/i);
    expect(nextBtn).not.toBeDisabled();
  });

  it('clicking next updates currentPage in store', () => {
    setLoadedDoc({ currentPage: 3, pageCount: 10 });
    render(<ViewerToolbar />);
    fireEvent.click(screen.getByTitle(/next page/i));
    expect(useAppStore.getState().currentPage).toBe(4);
  });

  it('clicking prev updates currentPage in store', () => {
    setLoadedDoc({ currentPage: 5, pageCount: 10 });
    render(<ViewerToolbar />);
    fireEvent.click(screen.getByTitle(/previous page/i));
    expect(useAppStore.getState().currentPage).toBe(4);
  });

  it('clicking next calls adapter.navigateToPage', () => {
    setLoadedDoc({ currentPage: 3, pageCount: 10 });
    render(<ViewerToolbar />);
    fireEvent.click(screen.getByTitle(/next page/i));
    expect(mockAdapter.navigateToPage).toHaveBeenCalledWith(4);
  });

  it('clicking prev calls adapter.navigateToPage', () => {
    setLoadedDoc({ currentPage: 5, pageCount: 10 });
    render(<ViewerToolbar />);
    fireEvent.click(screen.getByTitle(/previous page/i));
    expect(mockAdapter.navigateToPage).toHaveBeenCalledWith(4);
  });

  it('next at last page does not call navigateToPage', () => {
    setLoadedDoc({ currentPage: 10, pageCount: 10 });
    render(<ViewerToolbar />);
    fireEvent.click(screen.getByTitle(/next page/i));
    expect(mockAdapter.navigateToPage).not.toHaveBeenCalled();
  });

  it('prev at page 1 does not call navigateToPage', () => {
    setLoadedDoc({ currentPage: 1, pageCount: 10 });
    render(<ViewerToolbar />);
    fireEvent.click(screen.getByTitle(/previous page/i));
    expect(mockAdapter.navigateToPage).not.toHaveBeenCalled();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Split & Merge icon
// ─────────────────────────────────────────────────────────────────────────────
describe('ViewerToolbar — Split & Merge icon', () => {

  it('scissors icon hidden when showSplitMerge=false', () => {
    setLoadedDoc();
    useAppStore.setState({ showSplitMerge: false });
    render(<ViewerToolbar />);
    expect(screen.queryByTitle(/split/i)).toBeNull();
  });

  it('scissors icon visible when showSplitMerge=true', () => {
    setLoadedDoc();
    useAppStore.setState({ showSplitMerge: true });
    render(<ViewerToolbar />);
    // The scissors button should be present
    const splitBtn = screen.queryByTitle(/split/i) || screen.queryByRole('button', { name: /split/i });
    expect(splitBtn).toBeTruthy();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Zoom
// ─────────────────────────────────────────────────────────────────────────────
describe('ViewerToolbar — zoom controls', () => {

  it('renders zoom mode selector', () => {
    setLoadedDoc();
    render(<ViewerToolbar />);
    // Zoom control should have Page Fit or similar
    expect(screen.getByText(/page fit/i) || screen.getByText(/fit/i)).toBeTruthy();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Empty state (no document)
// ─────────────────────────────────────────────────────────────────────────────
describe('ViewerToolbar — no document', () => {

  it('renders without error when no file loaded', () => {
    expect(() => render(<ViewerToolbar />)).not.toThrow();
  });

  it('both page buttons disabled when no document', () => {
    render(<ViewerToolbar />);
    const prev = screen.queryByTitle(/previous page/i);
    const next = screen.queryByTitle(/next page/i);
    if (prev) expect(prev).toBeDisabled();
    if (next) expect(next).toBeDisabled();
  });
});
