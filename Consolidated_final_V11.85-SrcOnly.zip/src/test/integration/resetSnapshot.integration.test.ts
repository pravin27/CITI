/**
 * resetSnapshot.integration.test.ts
 *
 * Tests the snapshot save → SM reclassify → Reset restore flow.
 * This is the most critical stateful flow in the app.
 *
 * Flow:
 *   1. LOAD_SINGLEDOC/MANIFEST → originalCategories/originalDocuments saved
 *   2. SM_RECLASSIFY → categories updated (snapshot NOT touched)
 *   3. Reset → Yes → restored from snapshot, DISCARD_CLICKED fired
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';
import { useAppStore } from '../../store/appStore';

// ── Reset store before each test ──────────────────────────────────────────────
beforeEach(() => {
  useAppStore.setState({
    captures:            [],
    categories:          [],
    originalCategories:  null,
    originalDocuments:   null,
    hasReclassification: false,
    isSplitScreen:       false,
    activeFieldId:       null,
    previewRect:         null,
    highlightIndex:      new Map(),
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Snapshot save on LOAD_SINGLEDOC
// ─────────────────────────────────────────────────────────────────────────────
describe('snapshot save — LOAD_SINGLEDOC', () => {
  const originalCats = [
    { id: 'inv', label: 'Invoice', color: 'blue', pages: [1, 2] },
    { id: 'ann', label: 'Annexure', color: 'teal', pages: [3] },
  ];

  it('setOriginalCategories saves the snapshot', () => {
    useAppStore.getState().setOriginalCategories(originalCats as any);
    expect(useAppStore.getState().originalCategories).toHaveLength(2);
    expect(useAppStore.getState().originalCategories![0].label).toBe('Invoice');
  });

  it('snapshot survives a setCategories call', () => {
    useAppStore.getState().setOriginalCategories(originalCats as any);
    useAppStore.getState().setCategories([{ id: 'other', label: 'Other', pages: [] }] as any);

    // Snapshot untouched
    expect(useAppStore.getState().originalCategories![0].label).toBe('Invoice');
    // Active categories updated
    expect(useAppStore.getState().categories[0].label).toBe('Other');
  });

  it('snapshot survives multiple setCategories calls', () => {
    useAppStore.getState().setOriginalCategories(originalCats as any);
    for (let i = 0; i < 5; i++) {
      useAppStore.getState().setCategories([{ id: `cat-${i}`, label: `Cat ${i}`, pages: [] }] as any);
    }
    expect(useAppStore.getState().originalCategories).toHaveLength(2);
  });

  it('second LOAD clears and resets snapshot', () => {
    useAppStore.getState().setOriginalCategories(originalCats as any);
    // Simulate new LOAD resetting snapshot
    const newCats = [{ id: 'newcat', label: 'New Category', color: 'purple', pages: [1] }];
    useAppStore.getState().setOriginalCategories(newCats as any);
    expect(useAppStore.getState().originalCategories).toHaveLength(1);
    expect(useAppStore.getState().originalCategories![0].id).toBe('newcat');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// SM_RECLASSIFY — does NOT overwrite snapshot
// ─────────────────────────────────────────────────────────────────────────────
describe('SM_RECLASSIFY — snapshot protection', () => {
  const originalCats = [
    { id: 'inv', label: 'Invoice', color: 'blue', pages: [1, 2] },
    { id: 'ann', label: 'Annexure', color: 'teal', pages: [3] },
  ];

  it('setCategories (SM update) does not overwrite originalCategories', () => {
    // 1. Save snapshot on load
    useAppStore.getState().setOriginalCategories(originalCats as any);

    // 2. SM_RECLASSIFY updates categories
    const smUpdated = [{ id: 'inv', label: 'Invoice', color: 'blue', pages: [1] }]; // reduced pages
    useAppStore.getState().setCategories(smUpdated as any);
    useAppStore.getState().setHasReclassification(true);

    // 3. Snapshot must still show original 2 pages for Invoice
    const snap = useAppStore.getState().originalCategories;
    expect(snap).not.toBeNull();
    expect(snap!.find((c: any) => c.id === 'inv')?.pages).toEqual([1, 2]);
  });

  it('setHasReclassification(true) marks state for Reset visibility', () => {
    useAppStore.getState().setHasReclassification(true);
    expect(useAppStore.getState().hasReclassification).toBe(true);
  });

  it('categories show SM changes while snapshot holds original', () => {
    useAppStore.getState().setOriginalCategories(originalCats as any);
    useAppStore.getState().setCategories([
      { id: 'inv', label: 'Invoice Modified', color: 'blue', pages: [1] },
    ] as any);

    expect(useAppStore.getState().categories[0].label).toBe('Invoice Modified');
    expect(useAppStore.getState().originalCategories![0].label).toBe('Invoice');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Reset flow — restores from snapshot
// ─────────────────────────────────────────────────────────────────────────────
describe('Reset flow — restore from snapshot', () => {
  const originalCats = [
    { id: 'inv', label: 'Invoice', color: 'blue', pages: [1, 2] },
    { id: 'ann', label: 'Annexure', color: 'teal', pages: [3] },
  ];

  function simulateReset() {
    const st = useAppStore.getState();
    const origCats = st.originalCategories;
    if (origCats?.length) {
      useAppStore.setState({ categories: origCats as any });
    }
    st.setHasReclassification(false);
    st.setIsSplitScreen(false);
  }

  it('restores categories from originalCategories', () => {
    useAppStore.getState().setOriginalCategories(originalCats as any);
    useAppStore.getState().setCategories([{ id: 'inv', label: 'Invoice Modified', pages: [1] }] as any);
    useAppStore.getState().setHasReclassification(true);

    simulateReset();

    expect(useAppStore.getState().categories).toHaveLength(2);
    expect(useAppStore.getState().categories[0].label).toBe('Invoice');
    expect(useAppStore.getState().categories[0].pages).toEqual([1, 2]);
  });

  it('sets hasReclassification to false after reset', () => {
    useAppStore.getState().setHasReclassification(true);
    simulateReset();
    expect(useAppStore.getState().hasReclassification).toBe(false);
  });

  it('sets isSplitScreen to false after reset', () => {
    useAppStore.getState().setIsSplitScreen(true);
    simulateReset();
    expect(useAppStore.getState().isSplitScreen).toBe(false);
  });

  it('snapshot is not null after reset (can reset again)', () => {
    useAppStore.getState().setOriginalCategories(originalCats as any);
    simulateReset();
    // Snapshot remains available for subsequent resets
    expect(useAppStore.getState().originalCategories).not.toBeNull();
  });

  it('reset with no snapshot is a no-op for categories', () => {
    useAppStore.setState({ originalCategories: null });
    useAppStore.getState().setCategories([{ id: 'sm-cat', label: 'SM Cat', pages: [] }] as any);

    simulateReset();

    // No snapshot → categories unchanged
    expect(useAppStore.getState().categories[0].id).toBe('sm-cat');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// originalDocuments — MultiDoc snapshot
// ─────────────────────────────────────────────────────────────────────────────
describe('originalDocuments — MultiDoc snapshot', () => {
  const originalDocs = [
    { id: 'doc1', name: 'invoice.pdf', category: 'invoice' },
    { id: 'doc2', name: 'annexure.pdf', category: 'annexure' },
  ];

  it('setOriginalDocuments saves MultiDoc snapshot', () => {
    useAppStore.getState().setOriginalDocuments(originalDocs as any);
    expect(useAppStore.getState().originalDocuments).toHaveLength(2);
    expect(useAppStore.getState().originalDocuments![0].category).toBe('invoice');
  });

  it('LOAD_SINGLEDOC sets originalDocuments to null', () => {
    useAppStore.getState().setOriginalDocuments(originalDocs as any);
    // Simulating LOAD_SINGLEDOC which clears MultiDoc snapshot
    useAppStore.getState().setOriginalDocuments(null);
    expect(useAppStore.getState().originalDocuments).toBeNull();
  });

  it('originalDocuments survives category changes', () => {
    useAppStore.getState().setOriginalDocuments(originalDocs as any);
    useAppStore.getState().setCategories([{ id: 'x', label: 'X', pages: [] }] as any);
    expect(useAppStore.getState().originalDocuments).toHaveLength(2);
  });

  it('originalDocuments holds category field for restore', () => {
    useAppStore.getState().setOriginalDocuments(originalDocs as any);
    const snap = useAppStore.getState().originalDocuments!;
    expect(snap[0].category).toBe('invoice');
    expect(snap[1].category).toBe('annexure');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Full round-trip — load → SM change → reset
// ─────────────────────────────────────────────────────────────────────────────
describe('full round-trip: load → SM reclassify → reset', () => {

  it('restores exact original state after SM modification', () => {
    const original = [
      { id: 'a', label: 'Form 15CA', color: 'blue', pages: [1, 2] },
      { id: 'b', label: 'Annexure', color: 'teal', pages: [3, 4] },
    ];

    // Step 1: Load saves snapshot
    useAppStore.getState().setCategories(original as any);
    useAppStore.getState().setOriginalCategories(original as any);

    // Step 2: SM sends 1 page instead of 2 for Form 15CA
    const smVersion = [
      { id: 'a', label: 'Form 15CA', color: 'blue', pages: [1] }, // reduced
      { id: 'b', label: 'Annexure', color: 'teal', pages: [3, 4] },
    ];
    useAppStore.getState().setCategories(smVersion as any);
    useAppStore.getState().setHasReclassification(true);

    // Verify SM change is visible
    expect(useAppStore.getState().categories.find((c: any) => c.id === 'a')?.pages).toEqual([1]);

    // Step 3: Reset
    const origCats = useAppStore.getState().originalCategories;
    useAppStore.setState({ categories: origCats as any });
    useAppStore.getState().setHasReclassification(false);

    // Verify restoration
    const restoredA = useAppStore.getState().categories.find((c: any) => c.id === 'a');
    expect(restoredA?.pages).toEqual([1, 2]);
    expect(useAppStore.getState().hasReclassification).toBe(false);
  });
});
