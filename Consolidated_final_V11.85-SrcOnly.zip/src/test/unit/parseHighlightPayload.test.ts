/**
 * parseHighlightPayload.test.ts
 * Unit tests for the HIGHLIGHT event payload parser.
 * Critical path — maps parent messages to CaptureItems for the store.
 */

import { describe, it, expect } from 'vitest';
import { parseHighlightPayload } from '../../utils/parseHighlightPayload';
import type { HighlightPayload } from '../../hooks/useEventBridge';

// Mock adapter with page dimensions
const mockAdapter = {
  getPageDimensions: () => ({ width: 816, height: 1056 }),
  pageCount: 5,
};

// Helper — build a minimal valid flat payload
const flatPayload = (overrides: Partial<HighlightPayload> = {}): HighlightPayload => ({
  id:     'field-1',
  page:   1,
  x:      0.1,
  y:      0.2,
  width:  0.3,
  height: 0.05,
  ...overrides,
});

// ─────────────────────────────────────────────────────────────────────────────
// Valid flat format
// ─────────────────────────────────────────────────────────────────────────────
describe('parseHighlightPayload — flat format', () => {
  it('returns item for valid payload', () => {
    const result = parseHighlightPayload(flatPayload(), mockAdapter as any);
    expect('item' in result).toBe(true);
    if (!('item' in result)) return;
    expect(result.item.id).toBe('field-1');
    expect(result.item.page).toBe(1);
    expect(result.item.x).toBeCloseTo(0.1);
    expect(result.item.y).toBeCloseTo(0.2);
    expect(result.item.width).toBeCloseTo(0.3);
    expect(result.item.height).toBeCloseTo(0.05);
  });

  it('uses id as label when label not provided', () => {
    const result = parseHighlightPayload(flatPayload(), mockAdapter as any);
    if (!('item' in result)) return;
    expect(result.item.label).toBe('field-1');
  });

  it('uses provided label when present', () => {
    const result = parseHighlightPayload(
      flatPayload({ label: 'Invoice Number' }),
      mockAdapter as any,
    );
    if (!('item' in result)) return;
    expect(result.item.label).toBe('Invoice Number');
  });

  it('preserves value field', () => {
    const result = parseHighlightPayload(
      flatPayload({ value: 'INV-2024-001' }),
      mockAdapter as any,
    );
    if (!('item' in result)) return;
    expect(result.item.value).toBe('INV-2024-001');
  });

  it('preserves color field', () => {
    const result = parseHighlightPayload(
      flatPayload({ color: 'blue' }),
      mockAdapter as any,
    );
    if (!('item' in result)) return;
    expect(result.item.color).toBe('blue');
  });

  it('sets sourceFormat to flat', () => {
    const result = parseHighlightPayload(flatPayload(), mockAdapter as any);
    if (!('item' in result)) return;
    expect(result.item.sourceFormat).toBe('flat');
  });

  it('works with page 2', () => {
    const result = parseHighlightPayload(flatPayload({ page: 2 }), mockAdapter as any);
    if (!('item' in result)) return;
    expect(result.item.page).toBe(2);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Error cases
// ─────────────────────────────────────────────────────────────────────────────
describe('parseHighlightPayload — error cases', () => {
  it('returns error when id is missing', () => {
    const payload = { page: 1, x: 0.1, y: 0.2, width: 0.3, height: 0.05 } as any;
    const result = parseHighlightPayload(payload, mockAdapter as any);
    expect('error' in result).toBe(true);
    if (!('error' in result)) return;
    expect(result.error).toMatch(/id/i);
  });

  it('returns error when id is empty string', () => {
    const payload = flatPayload({ id: '' });
    const result = parseHighlightPayload(payload, mockAdapter as any);
    expect('error' in result).toBe(true);
  });

  it('returns error when page is 0', () => {
    const payload = flatPayload({ page: 0 });
    const result = parseHighlightPayload(payload, mockAdapter as any);
    expect('error' in result).toBe(true);
    if (!('error' in result)) return;
    expect(result.error).toMatch(/page/i);
  });

  it('returns error when page is negative', () => {
    const result = parseHighlightPayload(flatPayload({ page: -1 }), mockAdapter as any);
    expect('error' in result).toBe(true);
  });

  it('returns error when no coordinates found', () => {
    const payload = { id: 'f1', page: 1 } as any;
    const result = parseHighlightPayload(payload, mockAdapter as any);
    expect('error' in result).toBe(true);
    if (!('error' in result)) return;
    expect(result.error).toMatch(/coord/i);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// bbox_relative format
// ─────────────────────────────────────────────────────────────────────────────
describe('parseHighlightPayload — bbox_relative format', () => {
  it('parses bbox_relative payload', () => {
    const payload = {
      id: 'f1', page: 1,
      bbox_relative: [0.1, 0.2, 0.3, 0.05],
    } as any;
    const result = parseHighlightPayload(payload, mockAdapter as any);
    expect('item' in result).toBe(true);
    if (!('item' in result)) return;
    expect(result.item.x).toBeCloseTo(0.1);
    expect(result.item.sourceFormat).toBe('bbox_relative');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// xmin/ymin/xmax/ymax (FORMAT 6)
// ─────────────────────────────────────────────────────────────────────────────
describe('parseHighlightPayload — FORMAT 6 (xmin/ymin/xmax/ymax)', () => {
  it('parses corner coords and converts to x/y/w/h', () => {
    const payload = {
      id: 'f1', page: 1,
      xmin: 0.1, ymin: 0.2, xmax: 0.4, ymax: 0.25,
    } as any;
    const result = parseHighlightPayload(payload, mockAdapter as any);
    expect('item' in result).toBe(true);
    if (!('item' in result)) return;
    expect(result.item.x).toBeCloseTo(0.1);
    expect(result.item.y).toBeCloseTo(0.2);
    expect(result.item.width).toBeCloseTo(0.3);
    expect(result.item.height).toBeCloseTo(0.05);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Null adapter
// ─────────────────────────────────────────────────────────────────────────────
describe('parseHighlightPayload — null adapter', () => {
  it('works with 0-1 coords even without adapter', () => {
    const result = parseHighlightPayload(flatPayload(), null);
    expect('item' in result).toBe(true);
  });

  it('fails gracefully for pixel coords without adapter', () => {
    // Pixel coords need adapter to normalise — may return error or clamp
    const payload = flatPayload({ x: 100, y: 200, width: 150, height: 30 });
    // Should not throw regardless of outcome
    expect(() => parseHighlightPayload(payload, null)).not.toThrow();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Return type narrowing
// ─────────────────────────────────────────────────────────────────────────────
describe('parseHighlightPayload — return type', () => {
  it('successful result has item and no error', () => {
    const result = parseHighlightPayload(flatPayload(), mockAdapter as any);
    if ('error' in result) throw new Error('Expected item');
    expect(result.item).toBeDefined();
    expect((result as any).error).toBeUndefined();
  });

  it('error result has error string and no item', () => {
    const result = parseHighlightPayload({ id: '' } as any, null);
    if ('item' in result) throw new Error('Expected error');
    expect(typeof result.error).toBe('string');
    expect(result.error.length).toBeGreaterThan(0);
  });
});
