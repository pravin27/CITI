// ─────────────────────────────────────────────────────────────────────────────
// VIEWER ADAPTER INTERFACE
// ─────────────────────────────────────────────────────────────────────────────

export interface ViewerAdapter {
  /** Total page / sheet count (1-based) */
  pageCount: number;

  /** Navigate to a 1-based page number */
  navigateToPage(page: number): void;

  /** Real page dimensions in points/pixels for coord normalisation */
  getPageDimensions(page: number): { width: number; height: number } | null;

  /** The rendered canvas element for a page (for overlay positioning) */
  getPageCanvas(page: number): HTMLCanvasElement | null;

  /** The wrapper element for a page (for overlay attachment) */
  getPageElement(page: number): HTMLElement | null;

  /** Currently visible / rendered page numbers */
  getRenderedPages(): Set<number>;

  /** Fire cb once when the document is fully loaded */
  onReady(cb: () => void): void;

  /** Fire cb each time a page finishes rendering */
  onPageRendered(cb: (page: number) => void): void;

  /** Remove a previously registered page-rendered callback */
  offPageRendered?(cb: (page: number) => void): void;
}

// ─────────────────────────────────────────────────────────────────────────────
// FILE FORMAT DETECTION
// ─────────────────────────────────────────────────────────────────────────────

export type FormatGroup = 'pdf' | 'image' | 'spreadsheet' | 'document' | 'unknown';

export function detectFormat(filename: string): FormatGroup {
  const ext = filename.split('.').pop()?.toLowerCase() ?? '';
  if (ext === 'pdf') return 'pdf';
  if (['tif', 'tiff', 'bmp', 'jpeg', 'jpg', 'png'].includes(ext)) return 'image';
  if (['xls', 'xlsx', 'csv'].includes(ext)) return 'spreadsheet';
  if (['docx', 'doc', 'txt'].includes(ext)) return 'document';
  return 'unknown';
}

export function isTiff(filename: string): boolean {
  const ext = filename.split('.').pop()?.toLowerCase() ?? '';
  return ext === 'tif' || ext === 'tiff';
}

export function isCsv(filename: string): boolean {
  return filename.split('.').pop()?.toLowerCase() === 'csv';
}

// ─────────────────────────────────────────────────────────────────────────────
// CAPTURE ITEM DATA MODEL
// ─────────────────────────────────────────────────────────────────────────────

export type CoordSourceFormat = 'flat' | 'bbox' | 'rectangle' | 'coordinates' | 'bbox_relative';

export interface CaptureItem {
  id: string;
  label: string;
  value: string;
  page: number;
  x: number;       // 0–1 fraction of page width
  y: number;       // 0–1 fraction of page height
  width: number;
  height: number;
  sourceFormat?: CoordSourceFormat;
  fromJson?: boolean;
  color?: string;  // resolved CSS color
  type?: 'external';
  // Which JSON key was used for the text field in the source (text/label/value).
  // Used to round-trip submit JSON with the same key name.
  _textField?: 'text' | 'label' | 'value';
  // Original raw coords from parent before normalisation — used to send
  // CAPTURE_PREVIEW back to parent in the same unit as received.
  _rawX?:      number;
  _rawY?:      number;
  _rawWidth?:  number;
  _rawHeight?: number;
  _rawUnit?:   'px' | 'pt' | 'norm';
}

// ─────────────────────────────────────────────────────────────────────────────
// WORD INDEX ENTRY
// ─────────────────────────────────────────────────────────────────────────────

export interface WordEntry {
  text: string;
  page: number;
  x: number;   // always 0-1 normalised internally
  y: number;
  width: number;
  height: number;
  // Which JSON key held the text in the source (text/label/value).
  _textField?: 'text' | 'label' | 'value';
  // Which coord format was used in the source JSON — preserved for export round-trip
  sourceFormat?: CoordSourceFormat;
  // Original raw coords from parent (before normalisation) — used to send
  // CAPTURE_PREVIEW back to parent in the same unit as received.
  _rawX?:      number;
  _rawY?:      number;
  _rawWidth?:  number;
  _rawHeight?: number;
  _rawUnit?:   'px' | 'pt' | 'norm';
}

// ─────────────────────────────────────────────────────────────────────────────
// CATEGORY
// ─────────────────────────────────────────────────────────────────────────────

export interface Category {
  pages: number[];
  label: string;
  color?: string;   // resolved palette key or CSS color
}

export const PALETTE_COLORS = ['blue','teal','amber','gray','purple','coral','green','red'] as const;
export type PaletteColor = typeof PALETTE_COLORS[number];

// ─── PALETTE OPACITY ────────────────────────────────────────────────────────
// Controls how light/heavy category color badges and headers appear in the UI.
//
//   PALETTE_BG_OPACITY   — opacity of category header backgrounds and page pills
//                          Range: 0.05 (very light) → 1.0 (full saturated color)
//                          Default: 0.30 (30%) — light enough to not overpower content
//
//   PALETTE_CHIP_OPACITY — opacity for small badge/chip backgrounds (divBg)
//                          Automatically set to 40% of PALETTE_BG_OPACITY.
//                          Override here if you want chip opacity independent of header.
//
// To change: update PALETTE_BG_OPACITY below. All 8 colors update automatically.
// ────────────────────────────────────────────────────────────────────────────
export const PALETTE_BG_OPACITY   = 0.30;  // ← change this (0.05 – 1.0)
export const PALETTE_CHIP_OPACITY = Math.max(0.08, PALETTE_BG_OPACITY * 0.40);

// Build rgba() strings from a hex color + opacity
function hexToRgba(hex: string, alpha: number): string {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgba(${r},${g},${b},${alpha.toFixed(2)})`;
}

// Base hex values — the saturated full-strength color for each palette key.
// divText always uses the full hex so chip text stays vivid even at low opacity.
const PALETTE_BASE: Record<PaletteColor, string> = {
  blue:   '#185FA5',
  teal:   '#0F6E56',
  amber:  '#854F0B',
  gray:   '#5F5E5A',
  purple: '#3C3489',
  coral:  '#993C1D',
  green:  '#3B6D11',
  red:    '#A32D2D',
};

/**
 * Derive a stable palette colour from a category label string.
 * Uses djb2 hash — same label always maps to the same colour regardless
 * of position in the array or order of arrival.
 * Only used when no explicit color is provided.
 */
export function categoryColor(label: string): PaletteColor {
  let hash = 5381;
  for (let i = 0; i < label.length; i++) {
    hash = Math.imul(hash, 33) ^ label.charCodeAt(i);
  }
  return PALETTE_COLORS[Math.abs(hash) % PALETTE_COLORS.length];
}

export const PALETTE_MAP: Record<PaletteColor, {
  bg: string; text: string; divBg: string; divText: string
}> = Object.fromEntries(
  (Object.entries(PALETTE_BASE) as [PaletteColor, string][]).map(([key, hex]) => [
    key,
    {
      bg:      hexToRgba(hex, PALETTE_BG_OPACITY),
      text:    '#111111',          // dark text always readable on lightened background
      divBg:   hexToRgba(hex, PALETTE_CHIP_OPACITY),
      divText: hex,                // full saturated color for chip/badge text
    },
  ])
) as Record<PaletteColor, { bg: string; text: string; divBg: string; divText: string }>;

