import React, { useCallback, useRef, useState } from 'react';
import { useAppStore } from '../store/appStore';
import { injectWordIndex, injectCapturedFields, injectCategories } from '../hooks/useSidecarLoader';
import type { ViewerAdapter } from '../adapters/types';
import type { DocumentManifest } from '../types/multiDoc';

type SidecarType = 'word_index' | 'captured_fields' | 'categories' | 'manifest';

function detectSidecarType(filename: string, json: unknown): SidecarType | null {
  const lower = filename.toLowerCase();

  // Manifest structure check comes FIRST — takes priority over filename.
  // A file can be named "xxx_categories.json" but contain a manifest object.
  if (json && typeof json === 'object' && !Array.isArray(json)) {
    const j = json as Record<string, unknown>;
    if ((j.mode === 'single' || j.mode === 'multi') && Array.isArray(j.documents)) {
      return 'manifest';
    }
  }

  // Filename shortcuts — only reached for non-manifest JSON
  if (lower.includes('word_index')) return 'word_index';
  if (lower.includes('captured_field')) return 'captured_fields';
  if (lower.includes('categories')) return 'categories';

  if (Array.isArray(json)) {
    const first = (json as Record<string, unknown>[])[0];
    if (!first) return null;
    if ('pages' in first && 'label' in first) return 'categories';

    const hasId     = 'id'          in first;
    const hasLabel  = 'label'       in first;
    // page_width / page_height per item = exclusive signal for captured_fields
    // word_index entries never carry per-item page dimensions
    const hasPgDim  = 'page_width'  in first || 'pageWidth'  in first ||
                      'page_height' in first || 'pageHeight' in first;
    const hasCoord  = 'x'           in first || 'bbox'       in first ||
                      'bbox_relative' in first || 'rectangle' in first ||
                      'coordinates' in first  || 'xmin'      in first;
    const hasText   = 'text' in first || 't' in first;

    // captured_fields: has id/label/pageDims alongside coordinates
    if ((hasId || hasLabel || hasPgDim) && hasCoord) return 'captured_fields';
    // captured_fields: has id but no coords (text-only field)
    if (hasId && !hasCoord) return 'captured_fields';
    // word_index: text + coords, no per-item page metadata
    if (hasText && hasCoord && !hasPgDim) return 'word_index';
    if (hasText) return 'word_index';
    return 'captured_fields';
  }
  // Format A word_index: {pages: {...}}
  if (json && typeof json === 'object' && 'pages' in (json as object)) return 'word_index';
  return null;
}

export interface SidecarLoaderProps {
  /** Called when a manifest JSON (mode:single|multi) is detected */
  onManifest?: (manifest: DocumentManifest) => void;
}

export function SidecarLoader({ onManifest }: SidecarLoaderProps = {}) {
  const fileName      = useAppStore(s => s.fileName);
  const adapter       = useAppStore(s => s.adapter);
  const setWordIndex  = useAppStore(s => s.setWordIndex);
  const setCategories = useAppStore(s => s.setCategories);
  const replaceCapture = useAppStore(s => s.replaceCapture);

  const [status, setStatus] = useState('');
  const [error, setError]   = useState('');
  const [isDragging, setIsDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const processFile = useCallback(async (file: File) => {
    setError(''); setStatus('');
    try {
      const json = JSON.parse(await file.text());
      const type = detectSidecarType(file.name, json);
      if (!type) { setError('Could not detect sidecar type.'); return; }
      const va = adapter as unknown as ViewerAdapter | null;

      // Wait for adapter to be fully ready (all page dimensions loaded).
      // This is critical: PDF page dims are loaded via Promise.all in PDFViewer,
      // but if the user drops the sidecar JSON immediately after the PDF loads,
      // the adapter might not have getPageDimensions() data yet.
      // onReady() fires after all dims are stored, ensuring correct unit detection.
      // Manifest is handled immediately — no adapter wait needed
      if (type === 'manifest') {
        const manifest = json as DocumentManifest;
        // Priority 1: prop
        const handler = onManifest
          // Priority 2: store-registered handler (set by App via registerManifestHandler)
          ?? useAppStore.getState()._manifestHandler
          // Priority 3: legacy window bridge (kept for backwards compat)
          ?? (typeof (window as any).__onManifest === 'function' ? (window as any).__onManifest : null);
        if (handler) {
          handler(manifest);
          setStatus(`✓ Manifest: mode=${manifest.mode}, ${manifest.documents.length} docs, ${manifest.categories.length} categories`);
        } else {
          setError('Manifest detected but no handler registered.');
        }
        return;
      }

      const run = () => {
        if (type === 'word_index') {
          const map = injectWordIndex(json, va);
          setWordIndex(map);
          const total = Array.from(map.values()).reduce((s, a) => s + a.length, 0);
          setStatus(`✓ Word index: ${map.size} page(s), ${total} words`);
        } else if (type === 'captured_fields') {
          const fields = injectCapturedFields(json, va);
          fields.forEach(f => replaceCapture(f));
          setStatus(`✓ Captured fields: ${fields.length} loaded`);
        } else {
          const cats = injectCategories(json);
          setCategories(cats);
          setStatus(`✓ Categories: ${cats.length} loaded`);
        }
      };

      // If adapter has onReady (PDF/Image/Doc adapters), wait for it.
      // For adapters without onReady (or already ready), run immediately.
      if (va && typeof (va as any).onReady === 'function') {
        (va as any).onReady(run);
      } else {
        run();
      }
    } catch (e) { setError(`Failed to parse: ${e}`); }
  }, [adapter, setWordIndex, setCategories, replaceCapture]);

  const handleFiles = useCallback((files: FileList | null) => {
    if (!files?.length) return;
    Array.from(files).forEach(f => processFile(f));
  }, [processFile]);

  if (!fileName) return null;

  return (
    <div className="mx-3 mt-4">
      <div className="text-[10px] text-[#607080] mb-1.5 uppercase tracking-wide">Load Sidecar JSON</div>
      <div
        onDrop={e => { e.preventDefault(); setIsDragging(false); handleFiles(e.dataTransfer.files); }}
        onDragOver={e => { e.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onClick={() => inputRef.current?.click()}
        className={`border border-dashed rounded-lg p-3 cursor-pointer transition-all text-center ${
          isDragging ? 'border-[#0a84ff] bg-[#0a84ff]/10' : 'border-[#1e2d45] hover:border-[#2a3f60] bg-[#0d1829]'
        }`}>
        <input ref={inputRef} type="file" accept=".json" multiple className="hidden"
          onChange={e => handleFiles(e.target.files)} />
        <div className="text-[#607080] text-[10px]">
          Drop or click to load<br/>
          <span className="text-[#3a4a5a]">word_index · captured_fields · categories · manifest</span>
        </div>
      </div>
      {status && <div className="mt-1.5 text-[10px] text-green-400 bg-green-500/10 rounded p-1.5 border border-green-500/20">{status}</div>}
      {error  && <div className="mt-1.5 text-[10px] text-red-400 bg-red-500/10 rounded p-1.5 border border-red-500/20">{error}</div>}
    </div>
  );
}
