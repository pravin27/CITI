// ─────────────────────────────────────────────────────────────────────────────
// useThumbnailRenderer — scroll-aware background thumbnail rendering
//
// KEY DESIGN: pixel cache lives at MODULE SCOPE
//   • Survives sidebar open/close/accordion collapse
//   • On remount: drawImage from cached ImageBitmap in <1ms — no re-render
//   • Cache keyed by adapter identity string (filename+pageCount)
//   • Old adapter's cache cleared when a new document loads
//
// Fixes vs previous version:
//   [1] Module-scope ImageBitmap cache — survives sidebar unmount
//   [2] unregisterThumb does NOT clear rendered flag or pixel cache
//   [3] Priority queue uses two arrays (high[], low[]) — no O(n log n) sort
//   [4] scheduleNext batches: single RAF for all pending work
//   [5] Stable function refs via useRef — no useCallback dependency churn
//   [6] IntersectionObserver created once per adapter, not per render
//   [7] Initial load: deferred queue start (after first observer fires)
// ─────────────────────────────────────────────────────────────────────────────

import { useEffect, useRef } from 'react';
import { useAppStore } from '../store/appStore';
import type { AdapterInstance } from '../store/appStore';
import type { ImageAdapter } from '../adapters/ImageAdapter';

const THUMB_W       = 140;   // render width px
const PRELOAD_AHEAD = 10;    // pages to preload beyond visible viewport
const FRAME_BUDGET  = 12;    // ms per RAF frame — leaves room for React/pdfjs

// ── Module-scope pixel cache ───────────────────────────────────────────────────
// Key: adapterKey (filename+pageCount string, stable for the lifetime of a document)
// Value: Map<pageNumber, ImageBitmap>
// Survives sidebar close/reopen. Cleared when a new document loads.

const thumbCache = new Map<string, Map<number, ImageBitmap>>();
let   currentAdapterKey = '';

function getAdapterKey(adapter: AdapterInstance | null): string {
  if (!adapter) return '';
  // Include fileName + file size so multi-doc mode never collides across documents
  // e.g. two 50-page TIFs get different keys: 'ImageAdapter:inv_jan.tif:2048576:50'
  const pc   = adapter.pageCount ?? 0;
  const s    = useAppStore.getState();
  const name = s.fileName || '';
  const size = s.file?.size ?? 0;
  return `${adapter.constructor.name}:${name}:${size}:${pc}`;
}

function getPageCache(key: string): Map<number, ImageBitmap> {
  if (!thumbCache.has(key)) thumbCache.set(key, new Map());
  return thumbCache.get(key)!;
}

function clearOldCache(newKey: string) {
  for (const [key, bitmaps] of thumbCache) {
    if (key !== newKey) {
      bitmaps.forEach(bm => { try { bm.close(); } catch (_) {} });
      thumbCache.delete(key);
    }
  }
}

// pdfjs document proxy set by PDFViewer
function getPdfDoc(): any | null { return (window as any).__tovPdfDoc ?? null; }

// ── Hook ──────────────────────────────────────────────────────────────────────

export function useThumbnailRenderer(adapter: AdapterInstance | null) {
  // Live canvas elements: page → HTMLCanvasElement (updated on each mount)
  const canvasMap     = useRef<Map<number, HTMLCanvasElement>>(new Map());
  // Pages currently being rendered (in-flight async tasks)
  const inFlight      = useRef<Set<number>>(new Set());
  // Two-array priority queue — avoids O(n log n) sort
  const qHigh         = useRef<number[]>([]);
  const qLow          = useRef<number[]>([]);
  // RAF handle
  const rafHandle     = useRef(0);
  // IntersectionObserver
  const observer      = useRef<IntersectionObserver | null>(null);
  // Visible page range (updated by IO)
  const visibleRange  = useRef<[number, number]>([1, 1]);
  // Stable adapter key (set when adapter changes)
  const adapterKeyRef = useRef('');
  // Whether the scheduler is already running
  const running       = useRef(false);

  // ── Pixel cache helpers ────────────────────────────────────────────────────

  function isRendered(page: number): boolean {
    return thumbCache.get(adapterKeyRef.current)?.has(page) ?? false;
  }

  function getCachedBitmap(page: number): ImageBitmap | undefined {
    return thumbCache.get(adapterKeyRef.current)?.get(page);
  }

  function storeBitmap(page: number, bm: ImageBitmap) {
    getPageCache(adapterKeyRef.current).set(page, bm);
  }

  // ── Paint cached bitmap onto a canvas (instant) ────────────────────────────

  function paintFromCache(page: number, canvas: HTMLCanvasElement): boolean {
    const bm = getCachedBitmap(page);
    if (!bm) return false;
    canvas.width  = bm.width;
    canvas.height = bm.height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return false;
    ctx.drawImage(bm, 0, 0);
    return true;
  }

  // ── Queue management ───────────────────────────────────────────────────────

  function enqueue(page: number, priority: 'high' | 'low') {
    if (isRendered(page)) return;
    if (inFlight.current.has(page)) return;
    if (!canvasMap.current.has(page)) return;
    const arr = priority === 'high' ? qHigh.current : qLow.current;
    if (!arr.includes(page)) arr.push(page);
    startScheduler();
  }

  function enqueueRange(first: number, last: number, priority: 'high' | 'low') {
    for (let p = first; p <= last; p++) enqueue(p, priority);
  }

  // ── Scheduler ─────────────────────────────────────────────────────────────
  // Drains high[] first, then low[], respecting frame budget.
  // Single RAF per batch — no per-page cancel+request.

  function startScheduler() {
    if (running.current) return;
    running.current = true;
    rafHandle.current = requestAnimationFrame(runBatch);
  }

  async function runBatch() {
    const deadline = performance.now() + FRAME_BUDGET;

    while (performance.now() < deadline) {
      // Pick next page — high priority first
      let page: number | undefined;
      if (qHigh.current.length) {
        page = qHigh.current.shift();
      } else if (qLow.current.length) {
        page = qLow.current.shift();
      } else {
        break;
      }
      if (page === undefined) break;
      if (isRendered(page) || inFlight.current.has(page)) continue;
      const canvas = canvasMap.current.get(page);
      if (!canvas) continue;

      inFlight.current.add(page);
      try {
        const bm = await renderToBitmap(page, adapter);
        if (bm) {
          storeBitmap(page, bm);
          // Paint onto the live canvas if still mounted
          const liveCanvas = canvasMap.current.get(page);
          if (liveCanvas) {
            liveCanvas.width  = bm.width;
            liveCanvas.height = bm.height;
            liveCanvas.getContext('2d')?.drawImage(bm, 0, 0);
          }
        }
      } catch (_) {
        // canvas-not-ready: will retry via onPageRendered subscription
      } finally {
        inFlight.current.delete(page);
      }
    }

    const hasMore = qHigh.current.length > 0 || qLow.current.length > 0;
    if (hasMore) {
      rafHandle.current = requestAnimationFrame(runBatch);
    } else {
      running.current = false;
    }
  }

  // ── IntersectionObserver ───────────────────────────────────────────────────

  function setupObserver(scrollRoot: Element) {
    observer.current?.disconnect();
    const pageCount = adapter?.pageCount ?? 0;

    observer.current = new IntersectionObserver(entries => {
      const visible: number[] = [];
      for (const e of entries) {
        const page = Number((e.target as HTMLElement).dataset.thumbPage);
        if (!page) continue;
        if (e.isIntersecting) {
          visible.push(page);
          enqueue(page, 'high');
        }
      }
      if (!visible.length) return;

      const sorted = visible.sort((a, b) => a - b);
      const first = sorted[0], last = sorted[sorted.length - 1];
      visibleRange.current = [first, last];

      enqueueRange(
        Math.max(1, first - PRELOAD_AHEAD),
        Math.min(pageCount, last + PRELOAD_AHEAD),
        'low'
      );
    }, { root: scrollRoot, threshold: 0.01 });

    // Observe all registered thumb wrappers
    canvasMap.current.forEach((canvas) => {
      const wrapper = canvas.closest('[data-thumb-page]') as HTMLElement | null;
      if (wrapper) observer.current!.observe(wrapper);
    });
  }

  // ── Public API ─────────────────────────────────────────────────────────────

  const registerThumb = (
    page: number,
    canvas: HTMLCanvasElement | null,
    scrollRoot?: Element | null,
  ) => {
    if (!canvas) return;

    // Update live canvas ref (DOM node changes on remount)
    canvasMap.current.set(page, canvas);

    // If already cached, paint immediately — no queue, no wait
    if (paintFromCache(page, canvas)) return;

    // Set up observer lazily on first registration
    if (scrollRoot && !observer.current) {
      setupObserver(scrollRoot);
    }

    // Observe this wrapper
    const wrapper = canvas.closest('[data-thumb-page]') as HTMLElement | null;
    if (wrapper && observer.current) {
      observer.current.observe(wrapper);
    }

    // Queue if within or near the initial visible range
    const [vFirst, vLast] = visibleRange.current;
    if (page >= vFirst - 2 && page <= vLast + 2) {
      enqueue(page, 'high');
    }
  };

  const unregisterThumb = (page: number, canvas: HTMLCanvasElement | null) => {
    // Remove canvas ref — but DO NOT clear rendered/cache state.
    // The cached ImageBitmap survives. On remount, paintFromCache() fires instantly.
    canvasMap.current.delete(page);
    if (canvas) {
      const wrapper = canvas.closest('[data-thumb-page]') as HTMLElement | null;
      if (wrapper && observer.current) observer.current.unobserve(wrapper);
    }
  };

  // ── Lifecycle effects ──────────────────────────────────────────────────────

  // Adapter change: clear old cache, set new key, reset queues
  useEffect(() => {
    if (!adapter) return;
    const newKey = getAdapterKey(adapter);
    if (newKey === currentAdapterKey && newKey === adapterKeyRef.current) return;

    // New document loaded — clear all other caches
    clearOldCache(newKey);
    currentAdapterKey = newKey;
    adapterKeyRef.current = newKey;

    // Reset in-flight and queues (rendered state is now in thumbCache)
    inFlight.current.clear();
    qHigh.current = [];
    qLow.current  = [];
    running.current = false;
    cancelAnimationFrame(rafHandle.current);

    // Disconnect observer so it reconnects on next registerThumb
    observer.current?.disconnect();
    observer.current = null;
    canvasMap.current.clear();

  }, [adapter]);

  // Subscribe to adapter.onPageRendered — re-queue when new data available
  useEffect(() => {
    if (!adapter || typeof (adapter as any).onPageRendered !== 'function') return;
    const cb = (page: number) => {
      if (!canvasMap.current.has(page)) return;
      // Clear cached bitmap so it gets re-rendered with fresh data
      thumbCache.get(adapterKeyRef.current)?.delete(page);
      inFlight.current.delete(page);
      enqueue(page, 'high');
    };
    (adapter as any).onPageRendered(cb);
    return () => { (adapter as any).offPageRendered?.(cb); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [adapter]);

  // Cleanup on full unmount
  useEffect(() => {
    return () => {
      observer.current?.disconnect();
      cancelAnimationFrame(rafHandle.current);
      running.current = false;
    };
  }, []);

  return { registerThumb, unregisterThumb };
}

// ── Render one page to an ImageBitmap (off-screen, never touches DOM canvas) ──

async function renderToBitmap(
  page: number,
  adapter: AdapterInstance | null,
): Promise<ImageBitmap | null> {
  if (!adapter) return null;

  // ── PDF ────────────────────────────────────────────────────────────────────
  if (adapter.constructor.name === 'PDFAdapter') {
    const pdfDoc = getPdfDoc();
    if (!pdfDoc) return null;

    const pdfPage  = await pdfDoc.getPage(page);
    const viewport = pdfPage.getViewport({ scale: 1 });
    const scale    = THUMB_W / viewport.width;
    const scaledVP = pdfPage.getViewport({ scale });

    const offscreen = new OffscreenCanvas(
      Math.round(scaledVP.width),
      Math.round(scaledVP.height)
    );
    const ctx = offscreen.getContext('2d') as OffscreenCanvasRenderingContext2D;

    // 'print' intent: independent of main viewer's 'display' queue
    await pdfPage.render({ canvasContext: ctx, viewport: scaledVP, intent: 'print' }).promise;

    // Convert to ImageBitmap — GPU-resident, instant to draw
    return offscreen.transferToImageBitmap();
  }

  // ── TIF / Image ────────────────────────────────────────────────────────────
  if (adapter.constructor.name === 'ImageAdapter') {
    const frame = await (adapter as ImageAdapter).getFrameAsync(page);
    if (!frame) return null;

    const scale = THUMB_W / frame.width;
    const w = THUMB_W;
    const h = Math.round(frame.height * scale);

    const offscreen = new OffscreenCanvas(w, h);
    const ctx = offscreen.getContext('2d') as OffscreenCanvasRenderingContext2D;
    ctx.drawImage(frame.bitmap, 0, 0, w, h);
    return offscreen.transferToImageBitmap();
  }

  // ── Doc / Spreadsheet — getPageCanvas fallback ─────────────────────────────
  const src = adapter.getPageCanvas?.(page);
  if (!src || src.width === 0 || src.height === 0) {
    throw new Error(`canvas-not-ready:${page}`);
  }
  const scale = THUMB_W / src.width;
  const w = THUMB_W;
  const h = Math.round(src.height * scale);

  const offscreen = new OffscreenCanvas(w, h);
  const ctx = offscreen.getContext('2d') as OffscreenCanvasRenderingContext2D;
  ctx.drawImage(src, 0, 0, w, h);
  return offscreen.transferToImageBitmap();
}
