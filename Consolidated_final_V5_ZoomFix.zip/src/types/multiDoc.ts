// ─────────────────────────────────────────────────────────────────────────────
// Multi-document types
// ─────────────────────────────────────────────────────────────────────────────

export interface ManifestCategory {
  id: string;
  label: string;
  color: string;
}

/**
 * Category-first page mapping for mode:"multi".
 * Each category lists the page numbers that belong to it.
 * Mirrors the existing single-doc categories JSON format.
 *
 * Example:
 *   { "category": "invoice",     "pages": [1,2,3,4,5] }
 *   { "category": "declaration", "pages": [6,7,8] }
 *   { "category": "permit",      "pages": [9,10] }
 *
 * Total pages in the document = union of all pages arrays.
 * Page order in the viewer follows page number, not array order.
 */
export interface DocPageCategory {
  category: string;   // ManifestCategory.id
  pages: number[];    // 1-based page numbers belonging to this category
}

export interface ManifestDocument {
  id: string;
  name: string;
  // Data source — pick exactly one OR omit and rely on loadDocumentData() callback
  src?: string;       // URL: relative path, absolute http, or blob:
  dataUrl?: string;   // "data:application/pdf;base64,..."
  base64?: string;    // raw base64 string, no prefix

  // ── mode:"single" ─────────────────────────────────────────────────────────
  category?: string;  // ManifestCategory.id  (one category per doc)

  // ── mode:"multi" ──────────────────────────────────────────────────────────
  pageCategories?: DocPageCategory[];  // category-first, pages array per entry
}

export type ManifestMode = 'single' | 'multi';

export interface DocumentManifest {
  mode: ManifestMode;
  categories: ManifestCategory[];
  documents: ManifestDocument[];
}

// ── Runtime ───────────────────────────────────────────────────────────────────

export interface ResolvedCategory {
  id: string;
  label: string;
  color: string;
}

/** Runtime doc item — pageCategories kept as-is from manifest */
export interface DocSetItem {
  id: string;
  name: string;
  categoryId?: string;              // mode:single
  pageCategories?: DocPageCategory[]; // mode:multi
  /** Total page count — derived once from union of all pages arrays */
  totalPages?: number;
}

export interface MultiDocState {
  mode: ManifestMode;
  categories: ResolvedCategory[];
  documents: DocSetItem[];
  activeDocId: string | null;
  activePage: number;
}

export interface MultiDocConfig {
  /**
   * Called when a document has no inline src/data.
   * Return: ArrayBuffer | Uint8Array  → used directly as binary
   *         string starting "data:"   → decoded as dataUrl
   *         string starting "blob:" or "http" → used as URL
   *         string (plain)            → treated as raw base64
   */
  loadDocumentData?: (docId: string) => Promise<ArrayBuffer | Uint8Array | string>;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

/**
 * Build a Map<pageNumber, categoryId> for a document.
 * Used by sidebar and outline to look up which category a page belongs to.
 */
export function buildPageCatMap(pageCategories: DocPageCategory[]): Map<number, string> {
  const map = new Map<number, string>();
  pageCategories.forEach(({ category, pages }) => {
    pages.forEach(pg => map.set(pg, category));
  });
  return map;
}

/**
 * Compute total page count from pageCategories.
 * Returns the highest page number across all category arrays.
 */
export function totalPagesFromCategories(pageCategories: DocPageCategory[]): number {
  let max = 0;
  pageCategories.forEach(({ pages }) => {
    pages.forEach(pg => { if (pg > max) max = pg; });
  });
  return max;
}

/**
 * Get sorted page numbers for a specific category in a document.
 */
export function pagesForCategory(pageCategories: DocPageCategory[], categoryId: string): number[] {
  const entry = pageCategories.find(pc => pc.category === categoryId);
  return entry ? [...entry.pages].sort((a, b) => a - b) : [];
}
