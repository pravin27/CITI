// ─────────────────────────────────────────────────────────────────────────────
// PDFViewer — native pdfjs-dist engine
//
// HIGHLIGHT STRATEGY (final, correct approach):
//   Highlights are drawn INSIDE the pdfjs 'pagerendered' event handler.
//   At that moment we have:
//     • pv.div       — the page DOM element (guaranteed live)
//     • pv.viewport  — real CSS pixel dimensions (no clientWidth needed)
//     • pv.canvas    — the rendered pdfjs canvas (guaranteed painted)
//   We create one overlay <canvas> per page div and draw into it immediately.
//   When pdfjs re-renders a page (zoom, scroll-back), pagerendered fires again
//   and we re-draw — highlights always match the current page state.
//
//   Store changes (new capture, active field change) → drawAllVisible()
//   which re-draws all currently rendered pages by iterating pdfjs page views.
// ─────────────────────────────────────────────────────────────────────────────

import React, { useEffect, useRef } from 'react';
import * as pdfjsLib from 'pdfjs-dist';
import {
  EventBus, PDFViewer as PdfjsPDFViewer,
  PDFLinkService, PDFFindController,
  GenericL10n,
} from 'pdfjs-dist/web/pdf_viewer.mjs';
import { useAppStore } from '../store/appStore';
import type { PDFAdapter } from '../adapters/PDFAdapter';
import { colorToRgba, stripPunct } from '../utils/color';
import { clearPdfTextCache } from '../hooks/useBoxCapture';
import { InMemoryCMapReaderFactory, InMemoryStandardFontDataFactory } from '../utils/pdfResourceCache';
import type { CaptureItem, WordEntry } from '../adapters/types';

// ── pdfjs setup ───────────────────────────────────────────────────────────────
if (typeof document !== 'undefined' && !document.getElementById('pdfjs-viewer-css')) {
  const link = document.createElement('link');
  link.id = 'pdfjs-viewer-css'; link.rel = 'stylesheet'; link.href = '/pdf_viewer.css';
  document.head.appendChild(link);
}
// ── PDF worker setup ─────────────────────────────────────────────────────────
// ECS/OpenShift blocks ES-module dynamic import() inside blob: URLs.
// Fix: fetch the worker script once, wrap as a classic-script blob,
// set workerSrc synchronously so the first getDocument() call can use it.
// Falls back to the direct URL if fetch fails.
const _workerSrc = '/pdf.worker.min.mjs';

// Set workerSrc to the direct absolute URL.
// The "fake worker" warning in ECS is cosmetic — pdfjs still creates the worker
// correctly because the file returns 200. The warning occurs because pdfjs
// tries module worker creation which may log a warning in strict CSP, but
// falls back successfully to the working URL.
const _workerAbsUrl = new URL(_workerSrc, document.baseURI).href;
pdfjsLib.GlobalWorkerOptions.workerSrc = _workerAbsUrl;

export const workerReadyPromise: Promise<void> = Promise.resolve();
// Canvas pixel cap — balance between quality and render speed.
// At DPR=2, page-fit A4 ≈ 0.9MP, page-width ≈ 3.6MP, 150% zoom ≈ 5.5MP.
// ─── CHANGE THIS to tune quality vs render speed ─────────────────────────────
//   16_777_216 = 16MP — maximum quality, slowest on heavy image pages
//   10_485_760 = 10MP — high quality, can cause lag on 10MB+ PDFs
//    8_388_608 =  8MP — balanced (recommended for heavy PDFs) ← default
//    4_194_304 =  4MP — fast, slightly softer on retina displays
// ─────────────────────────────────────────────────────────────────────────────
const MAX_CANVAS_PIXELS = 3_670_016; // 3.5MP — fast decode for image-heavy PDFs (sharp at 150% A4)

// Cap devicePixelRatio at 2 to avoid 4x render cost on high-DPI displays.
// DPR=3 gives marginal sharpness improvement but 2.25x more pixels to render.
if (typeof window !== 'undefined' && window.devicePixelRatio > 2) {
  try { Object.defineProperty(window, 'devicePixelRatio', { value: 2, configurable: true }); } catch (_) {}
}

// ── CSS pulse animation ───────────────────────────────────────────────────────
let _cssInjected = false;
function injectPulseCSS() {
  if (_cssInjected || typeof document === 'undefined') return;
  _cssInjected = true;
  const s = document.createElement('style');
  s.textContent = `
    .tov-pulse-box{position:absolute;border-radius:3px;pointer-events:none;z-index:20;
      border:1.5px solid rgba(0,0,0,0.75);background:rgba(0,0,0,0.04);}
    .pdfViewer { min-width: max-content; }
    .pdfViewer .page { margin-left: auto !important; margin-right: auto !important; }
  `;
  document.head.appendChild(s);
}

// ── Core drawing ──────────────────────────────────────────────────────────────
const RADIUS = 2.5;
type Ctx2D = CanvasRenderingContext2D;

function rr(ctx: Ctx2D, x: number, y: number, w: number, h: number, r: number) {
  if (w < 1 || h < 1) return;
  r = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x+r,y); ctx.lineTo(x+w-r,y); ctx.arcTo(x+w,y,x+w,y+r,r);
  ctx.lineTo(x+w,y+h-r); ctx.arcTo(x+w,y+h,x+w-r,y+h,r);
  ctx.lineTo(x+r,y+h); ctx.arcTo(x,y+h,x,y+h-r,r);
  ctx.lineTo(x,y+r); ctx.arcTo(x,y,x+r,y,r); ctx.closePath();
}

// Proportional padding constants — no static pixel values.
const PAD_TOP  = 0.10;  // 10% of h added above text
const PAD_BOT  = 0.14;  // 14% of h added below text — more space so text never touches bottom border
const PAD_W    = 0.12;  // 12% of h added left + right

/**
 * drawBox — highlight box with proportional padding.
 * PDF/canvas y coordinates point to the TOP of the text line, not the baseline.
 * We add slightly more padding on top than bottom so the box feels centered
 * around the visible glyph without overrunning the line below.
 */
function drawBox(ctx: Ctx2D, x: number, y: number, w: number, h: number) {
  const pt = h * PAD_TOP;
  const pb = h * PAD_BOT;
  const pw = h * PAD_W;
  rr(ctx, x - pw, y - pt, w + pw * 2, h + pt + pb, RADIUS);
}

interface DrawState {
  captures:       CaptureItem[];
  activeFieldId:  string | null;
  highlightIndex: Map<number, Array<{x:number;y:number;width:number;height:number;id:string;color?:string;type?:'external'}>>;
  wordIndex:      Map<number, WordEntry[]>;
  previewRect:    {page:number;x:number;y:number;width:number;height:number} | null;
  searchResults:  Array<{page:number;x:number;y:number;width:number;height:number}>;
  searchCurrent:  number;
  searchHighAll:  boolean;
}

interface DrawCaches {
  fwc:    Map<string,string>;          // fieldId → stripped word
  cgc:    Array<{fill:string;stroke:string;ids:string[]}>;
  l3c:    Map<number,Map<string,Array<{x:number;y:number;w:number;h:number}>>>;
  awt:    string;                      // active field word text
  l3Key:  string;
}

function rebuildCaches(ds: DrawState, caches: DrawCaches) {
  const capturesRef = ds.captures.map(c=>`${c.id}:${c.value}`).join(',')
                    + '|wi:' + ds.wordIndex.size;
  if (capturesRef !== caches.l3Key) {
    caches.l3Key = capturesRef;
    caches.fwc.clear();
    for (const c of ds.captures) caches.fwc.set(c.id, c.value.toLowerCase().trim());
    caches.l3c.clear();
    if (ds.wordIndex.size > 0) {
      // watch = exact lowercase capture values — same form used in all matching
      const watch = new Set<string>();
      for (const wt of caches.fwc.values()) if (wt) watch.add(wt);
      for (const [pg, entries] of ds.wordIndex) {
        const pm = new Map<string,Array<{x:number;y:number;w:number;h:number}>>();
        if (!Array.isArray(entries)) {
          console.error('[rebuildCaches] wordIndex page', pg, 'has non-array entries:', typeof entries, entries);
          continue;
        }
        for (const e of entries) {
          // Match exact word first (wordIndex entries are usually single words)
          const wt = e.text.toLowerCase().trim();
          if (watch.has(wt)) {
            if (!pm.has(wt)) pm.set(wt, []);
            pm.get(wt)!.push({x:e.x, y:e.y, w:e.width, h:e.height});
            continue;
          }
          // If entry is a multi-word run, split and match individual words
          if (wt.includes(' ')) {
            const words = wt.split(/\s+/);
            let xOff = 0;
            for (const word of words) {
              if (watch.has(word)) {
                const frac = words.slice(0, words.indexOf(word)).join(' ').length / Math.max(wt.length, 1);
                const wFrac = word.length / Math.max(wt.length, 1);
                const wx = e.x + frac * e.width;
                const ww = wFrac * e.width;
                if (!pm.has(word)) pm.set(word, []);
                pm.get(word)!.push({x:wx, y:e.y, w:ww, h:e.height});
              }
              xOff += word.length + 1;
            }
          }
        }
        if (pm.size) caches.l3c.set(pg, pm);
      }
    }
  }
  // Always rebuild color groups (active field changes need this)
  const groups = new Map<string,{fill:string;stroke:string;ids:string[]}>();
  for (const c of ds.captures) {
    if (c.id === ds.activeFieldId) continue;
    const key = c.color ?? '__default__';
    if (!groups.has(key)) groups.set(key, {
      fill:   c.color ? colorToRgba(c.color, .10) : 'rgba(150,150,150,.10)',
      stroke: c.color ? colorToRgba(c.color, .90) : 'rgba(100,100,100,.85)', ids: [],
    });
    groups.get(key)!.ids.push(c.id);
  }
  caches.cgc = Array.from(groups.values());
  // awt: exact lowercase — same form as fwc values so PATH B text matching is consistent
  caches.awt = ds.activeFieldId ? (caches.fwc.get(ds.activeFieldId) ?? '') : '';
}

// Draw highlights onto a canvas.
// W, H = CSS display pixels (from pdfjs viewport — correct coordinate space)
// pageDiv: the page DOM element — used to scan text layer for word occurrences
//          when no word_index is loaded (PDF with native text layer).
function paintPage(ctx: Ctx2D, W: number, H: number, page: number,
  ds: DrawState, caches: DrawCaches, pageDiv?: HTMLElement) {
  ctx.clearRect(0, 0, W, H);

  const rects  = ds.highlightIndex.get(page) ?? [];
  const aid    = ds.activeFieldId;
  const aTxt   = aid ? (caches.fwc.get(aid) ?? '') : '';
  const hasWI  = ds.wordIndex.size > 0;

  // Search highlights
  const sr = ds.searchResults.filter(r => r.page === page);
  for (let i = 0; i < sr.length; i++) {
    const r = sr[i];
    const isCur = ds.searchResults.indexOf(r) === ds.searchCurrent;
    ctx.save();
    if (isCur) {
      ctx.fillStyle='rgba(255,140,0,.45)'; ctx.strokeStyle='rgba(255,100,0,.95)';
      ctx.lineWidth=2; ctx.shadowColor='rgba(255,140,0,.5)'; ctx.shadowBlur=6;
    } else if (ds.searchHighAll) {
      ctx.fillStyle='rgba(255,220,50,.28)'; ctx.strokeStyle='rgba(200,160,0,.65)'; ctx.lineWidth=1;
    } else { ctx.restore(); continue; }
    drawBox(ctx, r.x*W, r.y*H, r.width*W, r.height*H);
    ctx.fill(); ctx.stroke(); ctx.restore();
  }

  // Captured boxes — colour rules (confirmed):
  //   active                     → YELLOW
  //   same text as active (isDup)→ PINK strong — these are duplicate captured boxes
  //   type==='external'          → PURPLE — added via HIGHLIGHT event (not a capture)
  //   all other captures         → GREY — regardless of whether any field is active
  for (const rect of rects) {
    const isAct = rect.id === aid;
    const isDup = !isAct && !!aTxt && (caches.fwc.get(rect.id)??'') === aTxt;
    ctx.save();
    if (isAct) {
      ctx.shadowColor='rgba(220,180,0,.5)'; ctx.shadowBlur=8;
      ctx.fillStyle='rgba(255,230,0,.35)'; ctx.strokeStyle='rgb(200,160,0)'; ctx.lineWidth=2.5;
    } else if (rect.type==='external') {
      ctx.fillStyle='rgba(139,92,246,.22)'; ctx.strokeStyle='rgba(139,92,246,.85)'; ctx.lineWidth=1.5;
    } else if (isDup) {
      // Same text as active — PINK strong
      ctx.fillStyle='rgba(255,182,193,.5)'; ctx.strokeStyle='rgba(220,80,120,.95)'; ctx.lineWidth=2.5;
    } else if (rect.color) {
      ctx.fillStyle=colorToRgba(rect.color,.07); ctx.strokeStyle=colorToRgba(rect.color,.95); ctx.lineWidth=2.5;
    } else {
      // All other captures: GREY — not focused, not duplicate
      ctx.fillStyle='rgba(150,150,150,.10)'; ctx.strokeStyle='rgba(80,80,80,.90)'; ctx.lineWidth=2.0;
    }
    drawBox(ctx, rect.x*W, rect.y*H, rect.width*W, rect.height*H);
    ctx.fill(); ctx.stroke(); ctx.restore();
  }

  // ── Word occurrences ──────────────────────────────────────────────────────
  // Show word occurrence highlights for ALL captures (grey when inactive, pink for active word)
  // Skip set — prevents word occurrences from drawing over already-drawn capture boxes.
  // Uses a tolerance grid: snap coords to 8-unit grid so small positional differences
  // (pdfjs text layer vs normalised capture coords) still match.
  const SNAP = 8;  // grid size in normalised*1000 space (~0.008 fraction)
  const skip = new Set<number>();
  const snapKey = (x: number, y: number) =>
    Math.round(x*1000/SNAP)*SNAP*10000 + Math.round(y*1000/SNAP)*SNAP;
  for (const r of rects) {
    // Mark the capture box position and a small neighbourhood around it
    for (let dx = -1; dx <= 1; dx++) for (let dy = -1; dy <= 1; dy++) {
      skip.add(Math.round(r.x*1000/SNAP+dx)*SNAP*10000
             + Math.round(r.y*1000/SNAP+dy)*SNAP);
    }
  }

  // PATH A: wordIndex loaded AND this page has entries in l3c
  const pl3 = hasWI ? caches.l3c.get(page) : undefined;
  if (hasWI && pl3?.size) {
    // Fast path — pre-built position cache, zero DOM access
    const occ = (wt:string, fill:string, stroke:string, lw:number) => {
      const es = pl3.get(wt); if (!es?.length) return;
      ctx.fillStyle=fill; ctx.strokeStyle=stroke; ctx.lineWidth=lw;
      for (const e of es) {
        const k = snapKey(e.x, e.y);
        if (skip.has(k)) continue; skip.add(k);
        drawBox(ctx, e.x*W, e.y*H, e.w*W, e.h*H); ctx.fill(); ctx.stroke();
      }
    };
    for (const g of caches.cgc) for (const id of g.ids) {
      const wt = caches.fwc.get(id) ?? ''; if (wt) occ(wt, g.fill, g.stroke, 1.2);
    }
    if (caches.awt) occ(caches.awt,'rgba(255,182,193,.4)','rgba(220,80,120,.8)',1.5);

  } else if (pageDiv) {
    // PATH B: page not in l3c — scan the pdfjs text layer spans that are
    // currently in the DOM (works for the visible/near-visible pages).
    // For pages not yet rendered (text layer absent), the caller (drawPageOverlay)
    // will trigger a lazy pdfjs getTextContent() fetch to extend l3c.
    const textLayer = pageDiv.querySelector<HTMLElement>('.textLayer');
    if (!textLayer) return;
    const pageRect = pageDiv.getBoundingClientRect();
    const pW = pageRect.width  || W;
    const pH = pageRect.height || H;
    const spans = textLayer.querySelectorAll<HTMLElement>('span');

    // Build lookup: exact-lowercase word → {fill, stroke, lw}
    // Matching rule: exact lowercase only — "invoice." ≠ "invoice" (different words).
    const needles = new Map<string, {fill:string; stroke:string; lw:number}>();
    for (const g of caches.cgc) {
      for (const id of g.ids) {
        const wt = caches.fwc.get(id) ?? '';
        if (!wt) continue;
        if (!needles.has(wt)) needles.set(wt, {fill:g.fill, stroke:g.stroke, lw:1.2});
      }
    }
    if (caches.awt) needles.set(caches.awt, {fill:'rgba(255,182,193,.35)', stroke:'rgba(220,80,120,.75)', lw:1.5});

    if (!needles.size) return;

    for (const span of spans) {
      const txt = span.textContent?.trim().toLowerCase() ?? '';
      if (!txt) continue;
      const sr2 = span.getBoundingClientRect();
      if (sr2.width < 1 || sr2.height < 1) continue;

      // Try exact span text first
      const exactMatch = needles.get(txt);
      if (exactMatch) {
        const fx = (sr2.left - pageRect.left) / pW;
        const fy = (sr2.top  - pageRect.top)  / pH;
        const fw = sr2.width  / pW; const fh = sr2.height / pH;
        const k = snapKey(fx, fy);
        if (!skip.has(k)) {
          skip.add(k);
          ctx.fillStyle=exactMatch.fill; ctx.strokeStyle=exactMatch.stroke; ctx.lineWidth=exactMatch.lw;
          drawBox(ctx, fx*W, fy*H, fw*W, fh*H); ctx.fill(); ctx.stroke();
        }
        continue;
      }
      // Span is a multi-word run — split and match individual words
      // Estimate per-word position by character proportion within the span
      if (txt.includes(' ')) {
        const words = txt.split(/\s+/);
        let charsSoFar = 0;
        for (const word of words) {
          const wMatch = needles.get(word);
          if (wMatch) {
            const startFrac = charsSoFar / Math.max(txt.length, 1);
            const widthFrac = word.length / Math.max(txt.length, 1);
            const fx = (sr2.left - pageRect.left) / pW + startFrac * sr2.width / pW;
            const fw = widthFrac * sr2.width / pW;
            const fy = (sr2.top - pageRect.top) / pH;
            const fh = sr2.height / pH;
            const k = snapKey(fx, fy);
            if (!skip.has(k)) {
              skip.add(k);
              ctx.fillStyle=wMatch.fill; ctx.strokeStyle=wMatch.stroke; ctx.lineWidth=wMatch.lw;
              drawBox(ctx, fx*W, fy*H, fw*W, fh*H); ctx.fill(); ctx.stroke();
            }
          }
          charsSoFar += word.length + 1;
        }
      }
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────

export // Module-level stable navigation function.
// Written by PDFViewer when pdfViewer is ready, read by navigatePage() below.
// Survives adapter instance changes and component re-renders without remounting.
let _pdfNavigateFn: ((page: number) => void) | null = null;

/** Call this from anywhere to navigate the PDF viewer to a page. */
export function navigatePdfPage(page: number) {
  if (_pdfNavigateFn) {
    _pdfNavigateFn(page);
  } else {
    _pdfPendingPage = page;
  }
}
let _pdfPendingPage = 1;

export function PDFViewer({
  file, adapter, zoom,
}: { file: File; adapter: PDFAdapter; zoom: number }) {
  injectPulseCSS();

  const setCurrentPage = useAppStore(s => s.setCurrentPage);
  const rotation       = useAppStore(s => s.rotation);
  const wordIndex      = useAppStore(s => s.wordIndex);
  const hasWordIndex   = wordIndex.size > 0;

  const containerRef      = useRef<HTMLDivElement>(null);
  const viewerDivRef      = useRef<HTMLDivElement>(null);
  const viewerRef         = useRef<PdfjsPDFViewer | null>(null);
  const eventBusRef       = useRef<EventBus | null>(null);
  const blobUrlRef        = useRef<string | null>(null);
  const didInit           = useRef(false);
  const zoomRef           = useRef(zoom);
  // Pages whose text content has been fetched from pdfjs worker and merged into l3c.
  // Prevents duplicate fetches. Cleared when document changes.
  const textFetchedPages  = useRef<Set<number>>(new Set());
  // Shared draw debounce timer — used by both subscription and lazy text fetch
  const drawTimerRef      = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Highlight state — kept in a ref so the pagerendered handler always has latest
  const dsRef     = useRef<DrawState>({
    captures: [], activeFieldId: null,
    highlightIndex: new Map(), wordIndex: new Map(),
    previewRect: null, searchResults: [], searchCurrent: 0, searchHighAll: false,
  });
  const cachesRef = useRef<DrawCaches>({
    fwc: new Map(), cgc: [], l3c: new Map(), awt: '', l3Key: '',
  });
  // Overlay canvases keyed by page number
  const overlayMap = useRef(new Map<number, HTMLCanvasElement>());
  // Pulse div
  const pulseRef   = useRef<HTMLDivElement | null>(null);
  // Stable refs for draw functions — ensures subscription always calls latest
  const drawAllRef  = useRef<() => void>(() => {});
  const snapRef     = useRef<() => void>(() => {});

  // ── Snap store → dsRef ────────────────────────────────────────────────────
  function snapStore() {
    const s = useAppStore.getState();
    const prev = dsRef.current;
    const capturesChanged  = s.captures    !== prev.captures;
    const wordIndexChanged = s.wordIndex   !== prev.wordIndex;

    dsRef.current = {
      captures:      s.captures,
      activeFieldId: s.activeFieldId,
      highlightIndex:s.highlightIndex,
      wordIndex:     s.wordIndex,
      previewRect:   s.previewRect,
      searchResults: s.search.results,
      searchCurrent: s.search.currentIndex,
      searchHighAll: s.search.highlightAll,
    };
    // rebuildCaches does expensive l3c iteration over all wordIndex pages.
    // Only call it when captures or wordIndex actually changed.
    if (capturesChanged || wordIndexChanged) {
      rebuildCaches(dsRef.current, cachesRef.current);
      // Clear lazy-fetch cache when captures change — new capture text may need
      // matching on pages that were already fetched with the old watch set.
      // This ensures those pages re-fetch and pick up the new word.
      if (capturesChanged) textFetchedPages.current.clear();
    } else {
      // Fast path: just update awt (active word text) for highlight colour changes
      const aid = s.activeFieldId;
      cachesRef.current.awt = aid ? (cachesRef.current.fwc.get(aid) ?? '') : '';
    }
  }

  // ── Draw one page overlay ─────────────────────────────────────────────────
  // pageDiv: the pdfjs .page div
  // W, H:   CSS display pixels from pdfjs viewport (accurate, no clientWidth)
  function drawPageOverlay(pageNum: number, pageDiv: HTMLElement, W: number, H: number) {
    const ds = dsRef.current;
    const hasCap  = (ds.highlightIndex.get(pageNum)?.length ?? 0) > 0;
    const hasSrch = ds.searchResults.some(r => r.page === pageNum);
    const hasWI   = ds.wordIndex.size > 0;
    // hasCgcOrAwt: captures exist whose text needs matching via word occurrences.
    // Even when wordIndex is absent, PATH B scans the DOM text layer — but only
    // if we enter drawPageOverlay at all. Without this check, pages with no
    // captures of their own are skipped early → PATH B never runs → no duplicates shown.
    const hasCgcOrAwt = cachesRef.current.cgc.some(g => g.ids.length > 0)
                     || !!cachesRef.current.awt;

    // Remove overlay only when there is genuinely nothing to draw on this page
    if (!hasCap && !hasSrch && !hasWI && !hasCgcOrAwt) {
      const ex = overlayMap.current.get(pageNum);
      if (ex) { ex.remove(); overlayMap.current.delete(pageNum); }
      updatePulse();
      return;
    }

    // Get or create overlay canvas
    let oc = overlayMap.current.get(pageNum);
    if (oc && !oc.isConnected) {
      // pdfjs destroyed and re-created the page div — our canvas is orphaned
      oc.remove();
      overlayMap.current.delete(pageNum);
      oc = undefined;
    }
    if (!oc) {
      oc = document.createElement('canvas');
      oc.dataset.hlCanvas = '1';
      oc.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:11;';
      pageDiv.style.position = 'relative';
      pageDiv.appendChild(oc);
      overlayMap.current.set(pageNum, oc);
    }

    // Use div's actual rendered CSS pixels — canvas CSS stretches to clientWidth/Height.
    // If canvas pixels match clientWidth exactly, rects are 1:1 with display (no scaling).
    // This makes canvas rects pixel-perfect with the pulse div (which also uses clientWidth).
    const iW = pageDiv.clientWidth  || Math.round(W);
    const iH = pageDiv.clientHeight || Math.round(H);
    if (oc.width !== iW || oc.height !== iH) {
      oc.width = iW; oc.height = iH;
    }

    const ctx2d = oc.getContext('2d')!;
    paintPage(ctx2d, iW, iH, pageNum, ds, cachesRef.current, pageDiv);
    updatePulse();

    // ── Lazy text-content fetch for pages beyond wordIndex coverage ───────────
    // If this page has no l3c entry AND its text layer isn't in the DOM yet
    // (page is not fully rendered — common for pages just outside the viewport),
    // fetch text content from the pdfjs worker and extend l3c.
    // This covers the case: wordIndex has pages 1-250, user scrolls to page 700.
    // Performance: each page fetched at most once (textFetchedPages guard).
    // Only runs when there are captures with text to match (needles.size > 0).
    const hasCgc = cachesRef.current.cgc.some(g => g.ids.length > 0);
    const hasAwt = !!cachesRef.current.awt;
    const needsWo = hasCgc || hasAwt;  // any word-occurrence highlighting needed?

    if (needsWo && !cachesRef.current.l3c.get(pageNum)?.size &&
        !textFetchedPages.current.has(pageNum)) {
      const pdfjsDoc = (window as any).__tovPdfDoc;
      if (pdfjsDoc) {
        textFetchedPages.current.add(pageNum);   // mark immediately — prevent duplicate fetches
        pdfjsDoc.getPage(pageNum).then((pdfjsPage: any) => {
          return pdfjsPage.getTextContent({ includeMarkedContent: false });
        }).then((tc: any) => {
          if (!tc?.items?.length) return;
          // Build l3c entry for this page using exact lowercase matching
          const watch = new Set<string>();
          const fwc = cachesRef.current.fwc;
          for (const wt of fwc.values()) if (wt) watch.add(wt);
          if (!watch.size) return;

          const adp = useAppStore.getState().adapter;
          const dims = adp?.getPageDimensions?.(pageNum);
          if (!dims || !dims.width || !dims.height) return;
          const pw = dims.width;   // pts
          const ph = dims.height;  // pts

          const pm = new Map<string, Array<{x:number;y:number;w:number;h:number}>>();
          for (const item of tc.items) {
            if (!item.str?.trim()) continue;
            const tx  = item.transform?.[4] ?? 0;
            const ty  = item.transform?.[5] ?? 0;
            // item.height is the actual rendered glyph height (ascent only, no descender gap).
            // transform[3] is the full em-square height which overshoots visible text.
            // Prefer item.height; fall back to transform[3] only if height is 0 or absent.
            const rawH = (item.height && item.height > 0) ? item.height : Math.abs(item.transform?.[3] ?? 10);
            const fh  = rawH / ph;
            const fy0 = 1 - (ty / ph) - fh;
            const runW = (item.width ?? 0);

            // pdfjs returns text RUNS (e.g. "PRODUCT CODE"), not individual words.
            // Split each run into words and estimate per-word x position proportionally.
            const runStr   = item.str;
            const runWords = runStr.split(/\s+/);
            const runLower = runStr.toLowerCase();
            let charOffset = 0;

            for (const word of runWords) {
              if (!word) { charOffset += 1; continue; }
              const wt = word.toLowerCase().trim();
              if (watch.has(wt)) {
                // Estimate word x-position: charOffset/total chars × run width
                const wordStartFrac = runLower.indexOf(wt, charOffset) / Math.max(runStr.length, 1);
                const wordWidthFrac = wt.length / Math.max(runStr.length, 1);
                const fx = (tx + wordStartFrac * runW) / pw;
                const fw = wordWidthFrac * runW / pw;
                const fy = fy0;

                if (fx < 0 || fy < 0 || fw <= 0 || fh <= 0) { charOffset += word.length + 1; continue; }
                if (!pm.has(wt)) pm.set(wt, []);
                pm.get(wt)!.push({x:fx, y:fy, w:fw, h:fh});
              }
              charOffset += word.length + 1;
            }
            // Also try the full run as-is for exact multi-word captures
            {
              const wt = item.str.toLowerCase().trim();
              if (watch.has(wt)) {
                const fx = tx / pw;
                const fw = runW / pw;
                const fy = fy0;
                if (fx >= 0 && fy >= 0 && fw > 0 && fh > 0) {
                  if (!pm.has(wt)) pm.set(wt, []);
                  pm.get(wt)!.push({ x: fx, y: fy, w: fw, h: fh });
                }
              }
            }
          } // end for (const item of tc.items)

          if (pm.size) {
            cachesRef.current.l3c.set(pageNum, pm);
            if (drawTimerRef.current) clearTimeout(drawTimerRef.current);
            drawTimerRef.current = setTimeout(() => { drawTimerRef.current = null; drawAllRef.current(); }, 16);
          }
        }).catch(() => {
          // Fetch failed — remove from fetched set so it can retry on next render
          textFetchedPages.current.delete(pageNum);
        });
      }
    }
  }

  // ── Redraw all currently rendered pages ───────────────────────────────────
  // Iterates ALL pdfjs page views that have a div in the DOM.
  // pv.canvas can be null for virtualized pages (pdfjs evicts it when off-screen).
  // We use pv.div + pv.viewport — div persists, viewport always has dimensions.
  function drawAllVisible() {
    const viewer = viewerRef.current;
    if (!viewer) return;
    const n = viewer.pagesCount || 0;
    for (let i = 0; i < n; i++) {
      const pv = viewer.getPageView(i);
      // pv.div exists for all pages; pv.canvas only for rendered ones.
      // We can draw on any page that has a div — the overlay canvas persists
      // independently of the pdfjs canvas.
      if (!pv?.div || !pv.viewport) continue;
      const vp = pv.viewport;
      drawPageOverlay(i + 1, pv.div, vp.width, vp.height);
    }
    updatePulse();
  }

  // ── CSS pulse overlay ─────────────────────────────────────────────────────
  function updatePulse() {
    const pr = dsRef.current.previewRect;
    if (!pr) { pulseRef.current?.remove(); pulseRef.current = null; return; }

    const viewer = viewerRef.current;
    if (!viewer) return;
    const pv = viewer.getPageView(pr.page - 1);
    if (!pv?.div) return;
    const vp = pv.viewport;
    const W = vp.width, H = vp.height;

    if (!pulseRef.current) {
      pulseRef.current = document.createElement('div');
      pulseRef.current.className = 'tov-pulse-box';
    }
    if (pulseRef.current.parentElement !== pv.div) {
      pv.div.style.position = 'relative';
      pv.div.appendChild(pulseRef.current);
    }
    const d = pulseRef.current;
    // Use pageDiv.clientWidth/Height — same reference as drawPageOverlay iW/iH.
    // Math.round(W) fallback mirrors the canvas fallback exactly.
    const cW = pv.div.clientWidth  || Math.round(W);
    const cH = pv.div.clientHeight || Math.round(H);
    // Use the same PAD_* constants as drawBox — single source of truth.
    const rH  = pr.height * cH;
    const pt  = rH * PAD_TOP;
    const pb  = rH * PAD_BOT;
    const pw  = rH * PAD_W;
    d.style.left   = ((pr.x      * cW) - pw    ).toFixed(1) + 'px';
    d.style.top    = ((pr.y      * cH) - pt     ).toFixed(1) + 'px';
    d.style.width  = ((pr.width  * cW) + pw * 2 ).toFixed(1) + 'px';
    d.style.height = (rH               + pt + pb).toFixed(1) + 'px';
  }

  // ── pdfjs init (runs once per file) ──────────────────────────────────────
  useEffect(() => {
    if (didInit.current) return;
    const container = containerRef.current;
    const viewerDiv = viewerDivRef.current;
    if (!container || !viewerDiv) return;
    didInit.current = true;

    const eventBus = new EventBus();
    eventBusRef.current = eventBus;
    const linkService = new PDFLinkService({ eventBus, externalLinkTarget: 2 });
    const findController = new PDFFindController({ linkService, eventBus });

    // Read zoomMode at viewer creation time to set pdfjs default
    const initialZoomMode = useAppStore.getState().zoomMode;
    const defaultZoomValue =
      initialZoomMode === 'page-fit'   ? 'page-fit'   :
      initialZoomMode === 'page-width' ? 'page-width' :
      initialZoomMode === 'actual'     ? 'page-actual':
      String(useAppStore.getState().zoom);

    const pdfViewer = new PdfjsPDFViewer({
      container, viewer: viewerDiv, eventBus, linkService, findController,
      textLayerMode:     0,                // disabled — box capture uses pdfjs getTextContent directly
                                            // text layer adds 40-80% render overhead per page
      annotationMode:    0,                // disabled — saves memory + no annotation parse cost
      removePageBorders: true,
      enableHWA:         true,  // GPU-accelerated image rendering
      maxCanvasPixels:   MAX_CANVAS_PIXELS,
      // Render only the visible page range — pdfjs default renders ±2 pages
      // which for heavy image PDFs means 5 pages worth of GPU allocation at once.
      // ─── CHANGE THIS to tune render lookahead ───────────────────────────────
      //   1 = minimum (render only current page + immediate neighbours)
      //   2 = default pdfjs
      // ─────────────────────────────────────────────────────────────────────────
      ...({ renderingQueue: undefined } as any), // use pdfjs default queue
      l10n:              new (GenericL10n as any)('en'),
      ...({ defaultZoomValue } as any),  // pdfjs runtime option, not in TS types
    });
    // Page rendering cache — more slots = fewer white-screen re-renders.
    // Each slot holds one rendered page canvas (GPU texture).
    // For heavy image-heavy PDFs each page can be 2–4 MB on canvas.
    // 120 slots gives ~240 MB headroom — covers most back-navigation distances.
    // ─── CHANGE THIS to tune memory vs re-render tradeoff ───────────────────
    //   120 = default (recommended for heavy PDFs)
    //   200 = maximum — almost no re-renders, higher RAM
    //    60 = low-memory mode
    // ─────────────────────────────────────────────────────────────────────────
    const PDF_PAGE_CACHE_SIZE = 120;
    try { (pdfViewer as any)._buffer?.resize(PDF_PAGE_CACHE_SIZE); } catch {}
    viewerRef.current = pdfViewer;
    linkService.setViewer(pdfViewer);

    // ── Wire navigateToPage IMMEDIATELY — before any async getDocument() call ─
    // CRITICAL: must be synchronous. On heavy docs, thumbnail/toolbar clicks
    // fire while getDocument() is still pending. If set inside .then(), those
    // early clicks hit the no-op PDFAdapter stub and are silently dropped.
    // Write to module-level fn — survives adapter instance swaps
    _pdfNavigateFn = (page: number) => {
      const pageNum = Math.round(Number(page));
      if (!Number.isFinite(pageNum) || pageNum < 1) return;
      _pdfPendingPage = pageNum;
      (window as any).__doccapture_pauseThumbRender?.();
      const v = viewerRef.current;
      if (!v || !v.pagesCount) return;  // pagesloaded will pick up _pdfPendingPage
      const clamped = Math.max(1, Math.min(pageNum, v.pagesCount));
      v.currentPageNumber = clamped;
      setCurrentPage(clamped);
      // Immediately flush the render queue so pdfjs prioritises the new page.
      // This eliminates the delay between navigation and render start.
      requestAnimationFrame(() => {
        try { v.update(); } catch (_) {}
      });
    };
    // Also patch adapter so existing callers work
    adapter.navigateToPage = _pdfNavigateFn;

    // pagechanging fires during setDocument init and during user navigation.
    // We suppress spinner during initial load (before pagesloaded fires) using
    // a flag — only user-initiated navigation after load should trigger spinner.
    let docFullyLoaded = false;

    eventBus.on('pagechanging', (evt: any) => {
      if (!viewerRef.current?.pagesCount) return;
      const newPage = evt.pageNumber;
      // Ensure pdfjs prioritises rendering the page the user navigated to.
      // Without this, the render queue processes pages sequentially from page 1
      // which delays the target page on heavy documents.
      try {
        const buf = (viewerRef.current as any)._buffer;
        if (buf?.has && !buf.has(newPage - 1) && viewerRef.current.currentPageNumber !== newPage) {
          (viewerRef.current as any).currentPageNumber = newPage;
        }
      } catch (_) {}
      // Always update the page counter
      setCurrentPage(newPage);
      // Re-apply fit/width scale per page so pages with different dimensions
      // (landscape vs portrait, mixed sizes) each scale correctly.
      // pdfjs keeps a fixed numeric scale after first-page fit — this corrects it.
      if (docFullyLoaded) {
        const zm = useAppStore.getState().zoomMode;
        if (zm === 'page-fit' || zm === 'page-width') {
          setTimeout(() => {
            const pv = viewerRef.current;
            if (!pv) return;
            pv.currentScaleValue = zm === 'page-fit' ? 'page-fit' : 'page-width';
          }, 0);
        }
      }
      // Only show/hide spinner after initial load is complete
      if (!docFullyLoaded) return;
      if (!renderedPages.has(newPage)) {
        useAppStore.getState().setRenderProgress(1);
      } else {
        // Already rendered — clear spinner immediately
        useAppStore.getState().setRenderProgress(0);
      }
    });

    // ── PAGE RENDERED — draw highlights immediately ────────────────────────
    // renderedPages tracks which pages have been rendered in the CURRENT load.
    // Declared here (outside getDocument promise) so pagechanging handler
    // can read it before the promise resolves.
    const renderedPages = new Set<number>();

    eventBus.on('pagerendered', (evt: any) => {
      const pageNum = evt.pageNumber as number;
      renderedPages.add(pageNum);
      // Only clear spinner if THIS is the current page being waited on
      const state = useAppStore.getState();
      if (pageNum === state.currentPage && state.renderProgress > 0) {
        useAppStore.getState().setRenderProgress(100);
        setTimeout(() => useAppStore.getState().setRenderProgress(0), 500);
      }
      const pv = pdfViewer.getPageView(pageNum - 1);
      if (!pv?.div) return;

      // Tag the page div for box capture and adapter
      pv.div.dataset.pageNumber = String(pageNum);
      adapter.registerPageElement(pageNum, pv.div);
      adapter.onPageRenderSuccess(pageNum);

      // Hide text layer when word_index is loaded
      if (hasWordIndex) {
        const tl = pv.div.querySelector('.textLayer') as HTMLElement | null;
        if (tl) { tl.style.pointerEvents = 'none'; tl.style.opacity = '0'; }
      }

      // Draw highlights — deferred 1 rAF so pdfjs finishes painting first
      const vp = pv.viewport;
      snapStore(); // ensure latest state (fast path — no l3c rebuild if unchanged)
      // requestAnimationFrame defers overlay drawing until pdfjs canvas paint completes
      requestAnimationFrame(() => {
        drawPageOverlay(pageNum, pv.div, vp.width, vp.height);
      });

      // Pre-warm worker with next pages during idle — runs in Web Worker,
      // cannot block main thread. No timeout = only runs when truly idle.
      // Uses __tovPdfDoc (set inside .then()) because this handler is outside
      // the getDocument().promise.then() scope where doc is defined.
      if ('requestIdleCallback' in window) {
        (window as any).requestIdleCallback((idleDeadline: any) => {
          // Only pre-warm if we have at least 10ms of idle time remaining
          if (idleDeadline.timeRemaining() < 10) return;
          const pdfjsDoc = (window as any).__tovPdfDoc;
          if (!pdfjsDoc) return;
          [pageNum + 1, pageNum + 2].forEach(pg => {
            if (pg >= 1 && pg <= pdfjsDoc.numPages) {
              pdfjsDoc.getPage(pg).then((p: any) => p.getOperatorList()).catch(() => {});
            }
          });
        });
        // No timeout — if browser never idles, skip pre-warm entirely
      }
    });

    // pdfjs find controller is always kept closed (findbarclose dispatched above).
    // updatefindmatchescount will not fire. Search is handled entirely by
    // runSearch() via wordIndex or getTextContent — results have real coords.
    eventBus.on('updatefindmatchescount', (_evt: any) => { /* no-op — pdfjs find disabled */ });

    eventBus.on('updatefindcontrolstate', (evt: any) => {
      if (useAppStore.getState().wordIndex.size > 0) return;
      if (evt.state === 1) {
        useAppStore.setState(s => ({ search: { ...s.search, results: [], currentIndex: -1 } }));
      }
    });

    // Load document
    // If file has __rawBuffer (loaded via openFileBuffer from parent postMessage),
    // pass the ArrayBuffer directly to pdfjs — avoids blob URL creation and
    // an extra file read. Falls back to blob URL for normally opened files.
    const rawBuf = (file as any).__rawBuffer as ArrayBuffer | undefined;
    let url: string | null = null;
    let loadCancelled = false;

    // pdfjs transfers the ArrayBuffer to its worker (detaches it).
    // We must slice() before passing so __rawBuffer stays intact for re-opens.
    // slice() is a shallow copy of the bytes — fast (~1ms per 10MB) and
    // still faster than blob URL creation + file read on every open.
    const pdfjsSource = rawBuf && rawBuf.byteLength > 0
      ? { data: rawBuf.slice(0),  // slice preserves __rawBuffer for re-open
          // Custom in-memory factories — serve fonts/cmaps from RAM, zero network fetches
          CMapReaderFactory:        InMemoryCMapReaderFactory,
          StandardFontDataFactory:  InMemoryStandardFontDataFactory,
          cMapPacked: true,
          // PDF data is fully in memory — disable all network fetching
          disableAutoFetch: true,
          disableStream:    true,
          isEvalSupported:  true,      // JIT font programs — faster rendering
          useSystemFonts:   false,     // embedded fonts only — no system font mixing
          stopAtErrors:     false,
          // Offload image decoding to worker — prevents main thread jank
          // on pages with heavy images (photos, scanned pages, etc.)
          useWorkerFetch:   false,     // data already in memory, no worker fetch needed
          // Enable operator list caching — re-renders the SAME page much faster
          // by replaying cached drawing commands instead of re-parsing PDF operators.
          // Critical for back-navigation on image-heavy pages.
          enableXfa:        false,     // skip XFA (rarely used, significant parse cost)
          disableRange:     true,      // all data in memory — no range requests needed
          disableFontFace:  false,     // keep font rendering for text clarity
          verbosity:        0,         // suppress worker log messages (reduces IPC overhead)
          // Range requests: disabled — data is already in memory
          rangeChunkSize:   65536,
        }
      : (() => {
          url = URL.createObjectURL(file);
          blobUrlRef.current = url;
          return {
            url,
            CMapReaderFactory:       InMemoryCMapReaderFactory,
            StandardFontDataFactory: InMemoryStandardFontDataFactory,
            cMapPacked:    true,
            disableAutoFetch: false,   // blob URL — streaming OK
            isEvalSupported:  true,
            useSystemFonts:   false,
            stopAtErrors:     false,
            enableXfa:        false,
          };
        })();

    // Wait for worker blob to be ready before opening any document
    workerReadyPromise.then(() => {
    pdfjsLib.getDocument(pdfjsSource)
      .promise.then(async doc => {
        if (loadCancelled) { doc.destroy(); return; }
        // Set pageCount immediately so toolbar shows correct page count.
        // Do NOT call adapter.onDocumentLoad() here — that sets _isReady=true
        // and fires readyCallbacks, but page dimensions aren't loaded yet.
        // We call onDocumentLoad AFTER await Promise.all below.
        useAppStore.getState().setPageCount(doc.numPages);
        renderedPages.clear(); // fresh render tracking for this document
        adapter.pageCount = doc.numPages;

        // Wire navigateToPage BEFORE setDocument so it's available immediately
        // pendingNavPage: if navigateToPage is called before pdfjs is ready
        // (pagesCount=0 or pagesloaded not fired yet), store the page here
        // so onPagesLoaded can honour it after layout is complete.
        // navigateToPage override set earlier (before getDocument) — see above

        // pagesloaded is the ONLY reliable place to set scale and navigate.
        // It fires after pdfjs has fully laid out all page placeholders with
        // the correct container dimensions — so scale and scroll are accurate.
        const onPagesLoaded = () => {
          eventBus.off('pagesloaded', onPagesLoaded);

          // 1. Reset store page to 1 BEFORE applying scale so no spurious
          //    pagechanging events fire for in-between pages
          setCurrentPage(1);

          // 2. Apply scale now — container is fully laid out, dimensions are stable
          const zm2 = useAppStore.getState().zoomMode;
          if (zm2 === 'page-fit')        pdfViewer.currentScaleValue = 'page-fit';
          else if (zm2 === 'page-width') pdfViewer.currentScaleValue = 'page-width';
          else if (zm2 === 'actual')     pdfViewer.currentScaleValue = 'page-actual';
          else                           pdfViewer.currentScaleValue = String(zoomRef.current);

          // 3. Always start at page 1 for correct layout
          pdfViewer.currentPageNumber = 1;

          // 4. Spinner: only show if page 1 hasn't rendered yet
          if (!renderedPages.has(1)) {
            useAppStore.getState().setRenderProgress(1);
          }

          // 5. Mark load complete — pagechanging can now trigger spinners
          docFullyLoaded = true;
    
          // 6. If user clicked a page BEFORE pdfjs was ready, honour it now.
          if (_pdfPendingPage > 1) {
            const v = viewerRef.current;
            if (v && v.pagesCount) {
              const clamped = Math.max(1, Math.min(_pdfPendingPage, v.pagesCount));
              v.currentPageNumber = clamped;
              setCurrentPage(clamped);
            }
          }

          // 6. Notify parent once page 1 is rendered (canvas painted — user can see it).
          // We listen for `pagerendered` rather than firing here at `pagesloaded`,
          // because pagesloaded fires as soon as pdfjs parses the structure — before
          // any canvas is actually drawn. DOC_LOADED should mean "user can see content".
          const onFirstPageRendered = (evt: { pageNumber: number }) => {
            if (evt.pageNumber !== 1) return;
            eventBus.off('pagerendered', onFirstPageRendered);
            const bridgeEmit = (window as any).__doccapture_bridge?.emitPdfLoaded;
            if (bridgeEmit) {
              const st = useAppStore.getState();
              bridgeEmit({ fileName: st.fileName, pageCount: st.pageCount, docId: (st.file as any)?.__docId ?? null });
            }
          };
          eventBus.on('pagerendered', onFirstPageRendered);
        };
        eventBus.on('pagesloaded', onPagesLoaded);

        pdfViewer.setDocument(doc);
        linkService.setDocument(doc);
  
        // Expose pdfjs doc globally for getTextContent fallback in box capture
        (window as any).__tovPdfDoc = doc;
        (window as any).__tovPdfViewer = pdfViewer;
        // Notify all waiting thumbnail renderers that PDF doc is ready
        const v = ((window as any).__doccapture_pdfDocVersion ?? 0) + 1;
        (window as any).__doccapture_pdfDocVersion = v;
        const listeners = (window as any).__doccapture_pdfDocListeners as Set<()=>void> | undefined;
        listeners?.forEach(fn => { try { fn(); } catch(_) {} });

        // Open a second lightweight document for thumbnail rendering.
        // Thumbnails use a separate pdfjs doc so their render tasks don't
        // compete with the main viewer's render queue (fixes pages 3+ showing blank).
        clearPdfTextCache(); // invalidate per-page text item cache

        // Load ALL page dimensions BEFORE marking document ready.
        // This is critical: if we load dims lazily (one page at a time), the
        // adapter returns null for getPageDimensions() when the word_index JSON
        // is dropped immediately after the PDF loads — causing wrong normalisation.
        // We use Promise.all so every page's pts dimensions are stored synchronously
        // before the adapter fires _readyCallbacks and before the sidecar loader runs.
        //
        // page.view = [x0, y0, x1, y1] in PDF user units (pts for standard PDFs)
        // page.userUnit = points per user unit (1.0 for nearly all real-world PDFs)
        // width_pts = (x1 - x0) * userUnit  — the authoritative page width in points
        // Load page dimensions in batches of 4 — smaller batches reduce
        // pdfjs worker memory pressure during initial parse of large PDFs.
        // Sequential batching is faster than Promise.all for large docs because
        // the pdfjs worker processes one request at a time anyway.
        // For smaller docs (≤20 pages) fetch all page dims in one batch.
        // For larger docs batch by 8 to balance memory vs speed.
        const BATCH = doc.numPages <= 20 ? doc.numPages : 8;
        for (let start = 1; start <= doc.numPages; start += BATCH) {
          const end = Math.min(start + BATCH - 1, doc.numPages);
          await Promise.all(
            Array.from({ length: end - start + 1 }, (_, i) => {
              const pg = start + i;
              return doc.getPage(pg).then((page: any) => {
                const v = page.view as [number, number, number, number];
                const u = (page.userUnit as number) ?? 1;
                adapter.onPageLoad(pg, {
                  width:  (v[2] - v[0]) * u,
                  height: (v[3] - v[1]) * u,
                });
              }).catch(() => {});
            })
          );
        }
        // NOW the adapter is truly ready: page dims + page count both loaded.
        // onDocumentLoad sets _isReady=true and fires all queued callbacks.
        adapter.onDocumentLoad(doc.numPages);
        // Clear lazy text-fetch cache — new document, new text content
        textFetchedPages.current.clear();
      }).catch(err => {
        if (loadCancelled) return;
        console.error('[PDFViewer] PDF load failed:', err);
        const bridge = (window as any).__doccapture_bridge;
        if (bridge?.emitDocLoadError) {
          const msg = String(err?.message ?? err);
          const code = msg.includes('Invalid PDF') || msg.includes('corrupt')
            ? 'CORRUPT_FILE'
            : msg.includes('buffer') || msg.includes('empty')
            ? 'INVALID_BUFFER'
            : 'UNKNOWN';
          bridge.emitDocLoadError({
            code,
            reason: `PDF failed to load: ${msg}`,
            fileName: useAppStore.getState().fileName ?? undefined,
            docId: (useAppStore.getState().file as any)?.__docId ?? null,
          });
        }
      });
    }); // end workerReadyPromise.then

    return () => {
      _pdfNavigateFn = null;  // clear so navigatePdfPage queues via _pdfPendingPage
      _pdfPendingPage = 1;    // reset so next document always starts at page 1
      (window as any).__tovPdfDoc   = null;
      (window as any).__tovThumbDoc = null;
      (window as any).__tovPdfViewer = null;

      loadCancelled = true;
      viewerRef.current = null; eventBusRef.current = null;
      // Delay revoke so any in-flight pdfjs fetch can complete
      if (url) setTimeout(() => URL.revokeObjectURL(url!), 1000);
      blobUrlRef.current = null;
      overlayMap.current.forEach(c => c.remove()); overlayMap.current.clear();
      pulseRef.current?.remove(); pulseRef.current = null;
      didInit.current = false;
    };
  }, [file]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Zoom ──────────────────────────────────────────────────────────────────
  const zoomMode = useAppStore(s => s.zoomMode);
  const isLoading = useAppStore(s => s.isLoading);
  useEffect(() => {
    zoomRef.current = zoom;
    // Skip during file load — pagesloaded handler applies the correct scale
    // once pdfjs has finished layout. Pushing scale here before pagesloaded
    // is a no-op and causes confusion.
    if (isLoading) return;
    if (!viewerRef.current) return;
    const zm = useAppStore.getState().zoomMode;
    if (zm === 'page-fit')        viewerRef.current.currentScaleValue = 'page-fit';
    else if (zm === 'page-width') viewerRef.current.currentScaleValue = 'page-width';
    else if (zm === 'actual')     viewerRef.current.currentScaleValue = 'page-actual';
    else                          viewerRef.current.currentScaleValue = String(zoom);
  }, [zoom, zoomMode]);

  // ── Rotation ──────────────────────────────────────────────────────────────
  useEffect(() => {
    if (viewerRef.current) viewerRef.current.pagesRotation = rotation;
  }, [rotation]);

  // ── Keep draw function refs current every render ─────────────────────────
  // Plain functions defined in the component body are recreated each render.
  // The subscription effect runs once with [] and would capture stale closures.
  // Using refs avoids this — the subscription always calls the current function.
  useEffect(() => {
    drawAllRef.current = drawAllVisible;
    snapRef.current    = snapStore;
  });

  // ── Store subscription → redraw all visible pages ─────────────────────────
  useEffect(() => {
    snapRef.current();  // seed with initial state
    const unsub = useAppStore.subscribe((n, p) => {
      const changed =
        n.captures       !== p.captures       ||
        n.activeFieldId  !== p.activeFieldId  ||
        n.highlightIndex !== p.highlightIndex ||
        n.wordIndex      !== p.wordIndex      ||
        n.previewRect    !== p.previewRect    ||
        n.search.results !== p.search.results ||
        n.search.currentIndex !== p.search.currentIndex ||
        n.search.highlightAll !== p.search.highlightAll;
      if (!changed) return;
      // Snap immediately so dsRef is always current
      snapRef.current();
      // Use requestAnimationFrame to batch redraws — paints at most once per frame
      // regardless of how many state fields change simultaneously.
      // This is critical with 400-800 captured fields: without batching, each
      // setState (activeFieldId + previewRect + captures) triggers 3 separate paints.
      if (drawTimerRef.current) cancelAnimationFrame(drawTimerRef.current as any);
      drawTimerRef.current = requestAnimationFrame(() => {
        drawTimerRef.current = null;
        drawAllRef.current();
      }) as any;
    });
    return unsub;
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Search ────────────────────────────────────────────────────────────────
  // STRATEGY:
  //   • word_index loaded  → use our own runSearch() (fractional coords from
  //     word_index Map). pdfjs find controller is DISABLED — it uses the PDF
  //     text layer which may differ from word_index content and draws its own
  //     conflicting highlights on .textLayer .highlight elements.
  //   • no word_index      → delegate to pdfjs PDFFindController (searches
  //     all pages via worker, works across virtual-scroll pages).
  const search = useAppStore(s => s.search);

  useEffect(() => {
    const eb = eventBusRef.current; if (!eb) return;
    // Always close pdfjs find controller — we handle search ourselves:
    //   • wordIndex loaded  → runSearch() from the index
    //   • no wordIndex (PDF)→ runSearch() via getTextContent (same result, no text layer needed)
    // pdfjs find must stay closed in both cases to prevent updatefindmatchescount
    // from overwriting our real results with NaN sentinels.
    eb.dispatch('findbarclose', { source: window });
  }, [search.query, search.matchCase, search.matchType, search.highlightAll, search.isOpen, hasWordIndex]);

  // Bridge searchNext/searchPrev toolbar buttons
  useEffect(() => {
    const wi = useAppStore.getState().wordIndex;

    if (wi.size > 0) {
      // word_index mode: next/prev work correctly in appStore — nothing to override.
      return;
    }
    // No word_index: runSearch() uses pdfjs getTextContent → real 0-1 coords in
    // results[]. appStore searchNext/searchPrev increment currentIndex and call
    // navigateToPage + setPreviewRect — same as word_index mode. No override needed.
  }, [hasWordIndex]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Text layer + pdfjs find highlight visibility ─────────────────────────
  // When word_index is loaded:
  //   - text layer: hidden (we use word_index for hit-test, not DOM spans)
  //   - .textLayer .highlight: hidden (pdfjs find controller highlights — we
  //     draw our own search highlights on the overlay canvas)
  // Inject a style tag to suppress pdfjs highlights globally when word_index active.
  useEffect(() => {
    const styleId = 'tov-suppress-pdfjs-find';
    let styleEl = document.getElementById(styleId) as HTMLStyleElement | null;
    if (hasWordIndex) {
      if (!styleEl) {
        styleEl = document.createElement('style');
        styleEl.id = styleId;
        document.head.appendChild(styleEl);
      }
      // Hide pdfjs find highlights AND selection highlights
      styleEl.textContent = `.textLayer .highlight,.textLayer .selected{display:none!important;}`;
    } else {
      styleEl?.remove();
    }
  }, [hasWordIndex]);

  useEffect(() => {
    const c = containerRef.current; if (!c) return;
    c.querySelectorAll<HTMLElement>('.textLayer').forEach(el => {
      // word_index mode: hide text layer entirely (we use word_index for hit-test)
      // no word_index:   text layer visible and hittable for box capture DOM fallback
      el.style.pointerEvents = hasWordIndex ? 'none' : 'auto';
      el.style.opacity       = hasWordIndex ? '0'    : '';
      // Ensure spans are individually hittable for elementsFromPoint
      if (!hasWordIndex) {
        el.querySelectorAll<HTMLElement>('span').forEach(sp => {
          sp.style.pointerEvents = 'auto';
        });
      }
    });
  }, [hasWordIndex]);

  // Also re-apply on every page render (new pages mount after effect runs)
  // by hooking into the pagerendered event
  useEffect(() => {
    if (!eventBusRef.current) return;
    const eb = eventBusRef.current;
    const handler = () => {
      const c = containerRef.current; if (!c) return;
      c.querySelectorAll<HTMLElement>('.textLayer').forEach(el => {
        el.style.pointerEvents = hasWordIndex ? 'none' : 'auto';
        el.style.opacity       = hasWordIndex ? '0' : '';
        if (!hasWordIndex) {
          el.querySelectorAll<HTMLElement>('span').forEach(sp => {
            sp.style.pointerEvents = 'auto';
          });
        }
      });
    };
    eb.on('pagerendered', handler);
    return () => eb.off('pagerendered', handler);
  }, [hasWordIndex]);

  return (
    <div ref={containerRef} data-viewer-scroll="1"
      className="flex-1 bg-[#e8e8e8]"
      style={{ position: 'absolute', inset: 0, overflowY: 'auto', overflowX: 'auto' }}>
      <div ref={viewerDivRef} className="pdfViewer"
        style={{ minWidth: 'min-content', margin: '0 auto' }} />
    </div>
  );
}
