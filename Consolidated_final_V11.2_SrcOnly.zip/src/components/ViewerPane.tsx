import React, { useRef, useCallback } from 'react';
import { useAppStore } from '../store/appStore';
import { PDFViewer } from './PDFViewer';
import { ImageViewer } from './ImageViewer';
import { SpreadsheetViewer } from './SpreadsheetViewer';
import { useBoxCapture } from '../hooks/useBoxCapture';
import { useAnnotation } from '../hooks/useAnnotation';
import { AnnotationPanel } from './AnnotationPanel';
import { RenderLoader } from './RenderLoader';
import type { AnnotationSettings } from '../hooks/useAnnotation';
import { useHighlightCanvas } from '../hooks/useHighlightCanvas';
import { useWordSpanInjector } from '../hooks/useWordSpanInjector';
import type { PDFAdapter } from '../adapters/PDFAdapter';
import type { ImageAdapter } from '../adapters/ImageAdapter';
import type { SpreadsheetAdapter } from '../adapters/SpreadsheetAdapter';
import type { DocAdapter } from '../adapters/DocAdapter';
import type { CaptureResult } from '../hooks/useBoxCapture';

// ── No-file placeholder ───────────────────────────────────────────────────────
function NoPreview() {
  const isLoading = useAppStore(s => s.isLoading);
  const loadError = useAppStore(s => s.loadError);




  if (isLoading) return (
    <div className="flex-1 flex items-center justify-center bg-[#e8e8e8]">
      <div className="text-center">
        <div className="w-10 h-10 border-2 border-[#0a84ff] border-t-transparent rounded-full animate-spin mx-auto mb-3" />
        <p className="text-[#8899aa] text-sm">Loading document…</p>
      </div>
    </div>
  );

  if (loadError) return (
    <div className="flex-1 flex items-center justify-center bg-[#e8e8e8]">
      <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-6 max-w-sm text-center">
        <div className="text-red-400 text-xl mb-2">⚠</div>
        <div className="text-white font-semibold mb-1 text-sm">Failed to open</div>
        <div className="text-red-400 text-xs">{loadError}</div>
      </div>
    </div>
  );

  return (
    <div className="flex-1 select-none" style={{ position: 'relative', overflow: 'hidden', background: '#e8e9eb' }}>

      {/* Dot-grid background */}
      <svg style={{ position:'absolute', inset:0, width:'100%', height:'100%', opacity:.22 }}
        xmlns="http://www.w3.org/2000/svg">
        <defs>
          <pattern id="np-dots" x="0" y="0" width="24" height="24" patternUnits="userSpaceOnUse">
            <circle cx="1" cy="1" r="1" fill="#94a3b8"/>
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#np-dots)"/>
      </svg>

      {/* Centred content */}
      <div style={{
        position: 'absolute', inset: 0,
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center', gap: 20,
      }}>
        {/* Stacked pages illustration */}
        <div style={{ position: 'relative', width: 96, height: 118 }}>
          {/* Back page */}
          <div style={{
            position: 'absolute', left: 0, top: 14, width: 72, height: 92,
            background: '#d1dae4', borderRadius: 4, transform: 'rotate(-6deg)',
          }}/>
          {/* Mid page */}
          <div style={{
            position: 'absolute', left: 8, top: 7, width: 72, height: 92,
            background: '#dde5ed', borderRadius: 4, transform: 'rotate(-2deg)',
          }}/>
          {/* Front page */}
          <div style={{
            position: 'absolute', left: 16, top: 0, width: 72, height: 92,
            background: '#fff', borderRadius: 4,
            border: '0.5px solid #c8d4e0',
            display: 'flex', flexDirection: 'column',
            padding: '10px 9px', gap: 5,
          }}>
            <div style={{ height: 8, background: '#d0dce8', borderRadius: 2, width: '80%' }}/>
            <div style={{ height: 6, background: '#eaeff5', borderRadius: 2 }}/>
            <div style={{ height: 6, background: '#eaeff5', borderRadius: 2, width: '90%' }}/>
            <div style={{ height: 6, background: '#eaeff5', borderRadius: 2, width: '70%' }}/>
            <div style={{ height: 6, background: '#eaeff5', borderRadius: 2, width: '85%' }}/>
          </div>
        </div>

        {/* Heading only — no subtext */}
        <p style={{ fontSize: 16, fontWeight: 700, color: '#1e293b', letterSpacing: '-.01em' }}>
          No preview available
        </p>
      </div>
    </div>
  );
}

// ── Main pane ─────────────────────────────────────────────────────────────────
export function ViewerPane({ multiDocLoading = false }: { multiDocLoading?: boolean }) {
  const file             = useAppStore(s => s.file);
  const format           = useAppStore(s => s.format);
  const adapter          = useAppStore(s => s.adapter);
  const zoom             = useAppStore(s => s.zoom);
  const setPendingCapture = useAppStore(s => s.setPendingCapture);
  const annotateMode = useAppStore(s => s.annotateMode);
  const currentPage  = useAppStore(s => s.currentPage);
  const setPreviewRect    = useAppStore(s => s.setPreviewRect);

  const containerRef = useRef<HTMLDivElement>(null);
  const annotationSettings = useRef<AnnotationSettings>({
    tool: 'pencil', color: '#e74c3c', size: 2, opacity: 100,
  });
  const { undo, clear } = useAnnotation(
    containerRef as React.RefObject<HTMLElement>,
    annotationSettings
  );

  const handleCapture = useCallback((result: CaptureResult) => {
    setPendingCapture({ text: result.text, page: result.page,
      x: result.x, y: result.y, width: result.width, height: result.height,
      _textField: result._textField,
      sourceFormat: result.sourceFormat });
    setPreviewRect({ page: result.page, x: result.x, y: result.y,
      width: result.width, height: result.height });
  }, [setPendingCapture, setPreviewRect]);

  useBoxCapture(containerRef as React.RefObject<HTMLElement>, handleCapture);
  useHighlightCanvas(containerRef as React.RefObject<HTMLElement>);
  useWordSpanInjector(containerRef as React.RefObject<HTMLElement>);

  const hasFile = !!file && !!adapter;

  return (
    <div className="flex flex-col flex-1 overflow-hidden">
      <div ref={containerRef} className="flex-1 flex flex-col overflow-hidden relative">
        {/* Multi-doc loading overlay — shown while fetching a document */}
        {multiDocLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-[#1e2d3d]/80 z-20">
            <div className="text-center">
              <div className="w-8 h-8 border-2 border-[#1a7fd4] border-t-transparent rounded-full animate-spin mx-auto mb-2" />
              <p className="text-[#8ab0c8] text-xs">Loading document…</p>
            </div>
          </div>
        )}
        {!hasFile && !multiDocLoading && <NoPreview />}
        {/* Render progress bar + skeleton — shown while PDF is rendering */}
        {hasFile && format === 'pdf' && <RenderLoader />}
        {hasFile && format === 'pdf' && (
          <PDFViewer file={file!} adapter={adapter as PDFAdapter} zoom={zoom} />
        )}
        {hasFile && (format === 'image' || format === 'document') && (
          <ImageViewer adapter={adapter as unknown as ImageAdapter} zoom={zoom} />
        )}
        {hasFile && format === 'spreadsheet' && (
          <SpreadsheetViewer adapter={adapter as SpreadsheetAdapter} />
        )}
        {/* Annotation floating panel — shown when annotateMode active */}
        {annotateMode && (
          <AnnotationPanel
            settings={annotationSettings}
            onSettingsChange={() => {}}
            onUndo={undo}
            onClear={clear}
          />
        )}
      </div>
    </div>
  );
}
