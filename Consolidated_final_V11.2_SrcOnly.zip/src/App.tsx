import React, { useEffect, useCallback } from 'react';
import { useAppStore } from './store/appStore';
import { TopBar } from './components/TopBar';
import { ResizablePanes } from './components/ResizablePanes';
import { ViewerToolbar } from './components/ViewerToolbar';
import { ViewerPane } from './components/ViewerPane';
import { FieldsPanel } from './components/FieldsPanel';
import { ThumbnailSidebar } from './components/ThumbnailSidebar';
import { useSidecarLoader } from './hooks/useSidecarLoader';
import { useMultiDoc } from './hooks/useMultiDoc';
import { MultiDocSidebar } from './components/MultiDocSidebar';
import type { DocumentManifest } from './types/multiDoc';
import { useEventBridge, isEmbedded, generateTempId } from './hooks/useEventBridge';
import { parseHighlightPayload } from './utils/parseHighlightPayload';

function useGlobalShortcuts() {
  const setSearchOpen = useAppStore(s => s.setSearchOpen);
  const searchIsOpen  = useAppStore(s => s.search.isOpen);
  const file          = useAppStore(s => s.file);
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'f' && file) {
        e.preventDefault(); setSearchOpen(!searchIsOpen);
      }
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [setSearchOpen, searchIsOpen, file]);
}

export default function App() {
  const sidebarOpen    = useAppStore(s => s.sidebarOpen);
  const openFile       = useAppStore(s => s.openFile);
  const setCurrentPage = useAppStore(s => s.setCurrentPage);
  const closeFile      = useAppStore(s => s.closeFile);
  const adapter               = useAppStore(s => s.adapter);
  const setWordIndex          = useAppStore(s => s.setWordIndex);
  const setCategories         = useAppStore(s => s.setCategories);
  const addCaptureWithId      = useAppStore(s => s.addCaptureWithId);
  const navigateAndHighlight  = useAppStore(s => s.navigateAndHighlight);
  const openFileBuffer        = useAppStore(s => s.openFileBuffer);

  useSidecarLoader();
  useGlobalShortcuts();

  // ── Multi-doc state ───────────────────────────────────────────────────────
  const multiDoc = useMultiDoc();

  // ── Event bridge (only active when running inside an iframe) ─────────────
  // Shared helper — apply optional meta (wordIndex/categories/captures) to store
  const applyDocMeta = useCallback((meta?: import('./hooks/useEventBridge').SingleDocMeta | import('./hooks/useEventBridge').DocResponseMeta) => {
    if (!meta) return;
    if (meta.wordIndex) {
      const map = new Map<number, import('./adapters/types').WordEntry[]>(
        Object.entries(meta.wordIndex).map(([k, v]) => [Number(k), v as any])
      );
      setWordIndex(map);
    }
    if (meta.categories) setCategories(meta.categories as any);
    if (meta.captures)   meta.captures.forEach((cap: any) => addCaptureWithId(cap));
  }, [setWordIndex, setCategories, addCaptureWithId]);

  const bridge = useEventBridge({
    onLoadSingleDoc: (buffer, fileName, meta) => {
      openFileBuffer(buffer, fileName);
      applyDocMeta(meta);
    },

    onLoadManifest: (manifest, activeDocId, activeBuffer, meta) => {
      multiDoc.loadManifest(manifest);
      if (activeBuffer && activeDocId) {
        const doc = (manifest.documents ?? []).find((d: any) => d.id === activeDocId);
        const name = (doc as any)?.name ?? `${activeDocId}.pdf`;
        openFileBuffer(activeBuffer, name);
        // Apply meta for the first/active doc
        applyDocMeta(meta);
      }
    },

    // Called after DOC_RESPONSE resolves — apply per-doc meta
    onDocMeta: (_docId, meta) => {
      applyDocMeta(meta);
    },

    onHighlight: async (payload) => {
      // If MultiDoc and different doc requested — fetch it first
      if (payload.docId && multiDoc.state &&
          payload.docId !== multiDoc.state.activeDocId) {
        await multiDoc.selectDoc(payload.docId);
      }

      // Try to navigate to existing capture
      const found = navigateAndHighlight(payload.id);
      if (found) return;

      // Not found — parse payload into a proper CaptureItem (handles all coord formats)
      const result = parseHighlightPayload(payload, adapter);
      if ('error' in result) {
        console.warn('[EventBridge] HIGHLIGHT parse error:', result.error);
        return;
      }
      addCaptureWithId(result.item);
    },

    onCaptureAck: (tempId, realId) => {
      bridge.resolveAck(tempId, realId);
    },
  });

  // Pass requestBuffer into multiDoc so selectDoc can fetch via postMessage
  useEffect(() => {
    if (!isEmbedded) return;
    multiDoc.setConfig({ requestBuffer: bridge.requestDocBuffer });
  }, [bridge.requestDocBuffer]); // eslint-disable-line

  // Register manifest handler in the store — synchronous, no timing race
  const handleManifest = useCallback((manifest: DocumentManifest) => {
    multiDoc.loadManifest(manifest);
  }, [multiDoc]);

  useEffect(() => {
    useAppStore.getState().registerManifestHandler(handleManifest);
    // Also set window bridge for ViewerPane drop zone (belt-and-suspenders)
    (window as any).__onManifest = handleManifest;
    return () => {
      (window as any).__onManifest = undefined;
    };
  }, [handleManifest]);

  // Exit multi-doc mode — clear state + reset viewer
  const handleClearMultiDoc = useCallback(() => {
    multiDoc.clearMultiDoc();
    closeFile();
  }, [multiDoc, closeFile]);

  // pendingPageRef: when selectDoc resolves a new file, navigate to requested page
  // after pdfjs adapter is ready (adapter.onReady fires after page dims loaded)
  const pendingPageRef = React.useRef<number>(1);

  const handleSelectDoc = useCallback(async (docId: string, page = 1) => {
    pendingPageRef.current = page;
    await multiDoc.selectDoc(docId, page);
  }, [multiDoc]);

  // Track last loaded file name to skip re-opening on cache hits (same File object)
  const lastLoadedFileRef = React.useRef<string>('');

  // When a new activeFile is resolved → load it into the viewer
  useEffect(() => {
    if (!multiDoc.activeFile) return;
    const fileKey = multiDoc.activeFile.name + multiDoc.activeFile.size;
    if (fileKey === lastLoadedFileRef.current) {
      // Cache hit — same File object, pdfjs already loaded.
      // Just navigate to the requested page.
      const pg = pendingPageRef.current;
      if (pg >= 1) {
        setCurrentPage(pg);
        useAppStore.getState().adapter?.navigateToPage?.(pg);
      }
      return;
    }
    lastLoadedFileRef.current = fileKey;
    // Preserve user zoom across multi-doc navigation.
    // If zoomMode is 'custom' (explicit %): restore immediately after the sync reset.
    // If zoomMode is 'page-fit'/'page-width': let ViewerToolbar auto-apply recalculate
    //   for the new document's dimensions — do not restore the old doc's pixel zoom.
    const { zoom: savedZoom, zoomMode: savedZoomMode } = useAppStore.getState();
    openFile(multiDoc.activeFile).then(() => {
      if (savedZoomMode === 'custom') {
        // Restore exact zoom — this also sets zoomMode='custom' which blocks auto-apply
        useAppStore.getState().setZoom(savedZoom);
      }
      // For page-fit/page-width: openFile already reset to zoomMode='page-fit',
      // and the ViewerToolbar useEffect fires when adapter+pageCount are ready,
      // recalculating the correct zoom for the new doc size automatically.
      const adapter = useAppStore.getState().adapter as any;
      if (adapter && typeof adapter.onReady === 'function') {
        adapter.onReady(() => {
          const pg = pendingPageRef.current;
          if (pg > 1) {
            setCurrentPage(pg);
            useAppStore.getState().adapter?.navigateToPage?.(pg);
          }
        });
      }
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [multiDoc.activeFile]);

  // Page selection within the current document
  const handleSelectPage = useCallback((page: number) => {
    multiDoc.selectPage(page);
    setCurrentPage(page);
    useAppStore.getState().adapter?.navigateToPage?.(page);
  }, [multiDoc, setCurrentPage]);

  const showMultiSidebar   = !!multiDoc.state && sidebarOpen;
  const showDefaultSidebar = !multiDoc.state && sidebarOpen;

  return (
    <div className="flex flex-col h-screen bg-[#060d1a] overflow-hidden">
      <TopBar />
      <ResizablePanes
        left={
          <div className="flex flex-col flex-1 overflow-hidden">
            {/* Toolbar spans full width above viewer+sidebar */}
            <ViewerToolbar />
            {/* Below toolbar: sidebar overlays the viewer body only */}
            <div className="flex flex-1 overflow-hidden relative">
              {showMultiSidebar && multiDoc.state && (
                <MultiDocSidebar
                  state={multiDoc.state}
                  isLoading={multiDoc.activeDocLoading}
                  loadError={multiDoc.activeDocError}
                  adapter={adapter}
                  onSelectDoc={handleSelectDoc}
                  onSelectPage={handleSelectPage}
                  onClose={handleClearMultiDoc}
                />
              )}
              {/* ThumbnailSidebar overlays viewer body — sits below toolbar, does not push viewer */}
              {showDefaultSidebar && (
                <div style={{
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  bottom: 0,
                  zIndex: 30,
                  display: 'flex',
                }}>
                  <ThumbnailSidebar />
                </div>
              )}
              <ViewerPane multiDocLoading={multiDoc.activeDocLoading && !multiDoc.activeFile} />
            </div>
          </div>
        }
        right={<FieldsPanel bridge={bridge} />}
        defaultSplit={0.80}
        minLeft={320}
        minRight={200}
      />
    </div>
  );
}
