// ─────────────────────────────────────────────────────────────────────────────
// ImageAdapter — UTIF for TIF/TIFF, browser native for BMP/JPEG/PNG
//
// UTIF advantages over the old 'tiff' library:
//   • Half the bundle size (62KB vs 135KB)
//   • Handles all real-world TIFF compression types:
//       G4 Fax (CCITT Group4) — most common for scanned docs
//       CCITT Group3, LZW, PackBits, Deflate, JPEG-in-TIFF, PixarLog
//   • Correct 16-bit/bilevel/palette output via toRGBA8()
//   • The old 'tiff' library silently produced wrong pixels on G4-compressed TIFs
// ─────────────────────────────────────────────────────────────────────────────

import type { ViewerAdapter } from './types';

export interface ImageFrame {
  canvas: HTMLCanvasElement;
  width:  number;
  height: number;
}

export class ImageAdapter implements ViewerAdapter {
  pageCount = 0;

  private _frames: ImageFrame[] = [];
  private _readyCallbacks:         Array<() => void> = [];
  private _pageRenderedCallbacks:  Array<(page: number) => void> = [];
  private _pageElements = new Map<number, HTMLElement>();
  private _renderedPages = new Set<number>();
  private _isReady = false;

  // ── File loading ───────────────────────────────────────────────────────────

  async loadFile(file: File): Promise<void> {
    const ext = file.name.split('.').pop()?.toLowerCase() ?? '';
    if (ext === 'tif' || ext === 'tiff') {
      await this._loadTiff(file);
    } else {
      await this._loadNativeImage(file);
    }
    this._isReady  = true;
    this.pageCount = this._frames.length;
    this._readyCallbacks.forEach(cb => cb());
    this._readyCallbacks = [];
  }

  // ── UTIF-based TIFF decoder ────────────────────────────────────────────────
  // Two-step UTIF API:
  //   1. UTIF.decode(buffer)          → array of IFD objects (metadata parsed)
  //   2. UTIF.decodeImage(buf, ifd)   → fills ifd.data with raw pixel bytes
  //   3. UTIF.toRGBA8(ifd)            → converts to standard RGBA Uint8Array
  // This handles every compression type including G4 Fax, CCITT, LZW, PackBits.

  private async _loadTiff(file: File): Promise<void> {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const UTIF   = ((await import('utif' as any)) as any).default ?? (await import('utif' as any));
    const buffer = await file.arrayBuffer();

    // Pass 1: parse all IFDs (pages) — fast, metadata only
    const ifds = UTIF.decode(buffer);
    this._frames = [];

    for (const ifd of ifds) {
      // Pass 2: decode this IFD's pixel data in-place
      UTIF.decodeImage(buffer, ifd);

      // Pass 3: convert to standard RGBA8 — handles 1-bit, 8-bit, 16-bit,
      // palette, RGB, CMYK, grayscale, and all compressed formats
      const rgba   = UTIF.toRGBA8(ifd);
      const width  = ifd.width  as number;
      const height = ifd.height as number;

      const canvas = document.createElement('canvas');
      canvas.width  = width;
      canvas.height = height;
      const ctx  = canvas.getContext('2d')!;
      const imgD = ctx.createImageData(width, height);
      imgD.data.set(rgba);
      ctx.putImageData(imgD, 0, 0);

      this._frames.push({ canvas, width, height });
    }
  }

  // ── Native browser decoder for PNG/JPEG/BMP ───────────────────────────────
  // Browser's own image decoder — fastest possible, zero overhead.

  private async _loadNativeImage(file: File): Promise<void> {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => {
        const canvas  = document.createElement('canvas');
        canvas.width  = img.naturalWidth;
        canvas.height = img.naturalHeight;
        const ctx = canvas.getContext('2d')!;
        ctx.drawImage(img, 0, 0);
        this._frames = [{ canvas, width: img.naturalWidth, height: img.naturalHeight }];
        URL.revokeObjectURL(url);
        resolve();
      };
      img.onerror = () => {
        URL.revokeObjectURL(url);
        reject(new Error('Image decode failed'));
      };
      img.src = url;
    });
  }

  // ── ViewerAdapter implementation ───────────────────────────────────────────

  navigateToPage(page: number): void {
    const el = this._pageElements.get(page);
    if (!el) return;
    const scrollContainer = el.closest('[data-viewer-scroll]') as HTMLElement | null;
    if (scrollContainer) {
      const containerRect = scrollContainer.getBoundingClientRect();
      const elRect        = el.getBoundingClientRect();
      const offset        = elRect.top - containerRect.top + scrollContainer.scrollTop - 8;
      scrollContainer.scrollTop = offset;
    } else {
      el.scrollIntoView({ behavior: 'instant' as ScrollBehavior, block: 'start' });
    }
  }

  notifyPageRendered(page: number) {
    this._renderedPages.add(page);
    this._pageRenderedCallbacks.forEach(cb => cb(page));
  }

  registerPageElement(page: number, el: HTMLElement | null) {
    if (el) this._pageElements.set(page, el);
    else    this._pageElements.delete(page);
  }

  getFrame(page: number):     ImageFrame | null { return this._frames[page - 1] ?? null; }
  getAllFrames():              ImageFrame[]      { return this._frames; }

  getPageDimensions(page: number) {
    const f = this._frames[page - 1];
    return f ? { width: f.width, height: f.height } : null;
  }

  getPageCanvas(page: number): HTMLCanvasElement | null {
    const el = this._pageElements.get(page);
    if (el) return el.querySelector('canvas') ?? null;
    return this._frames[page - 1]?.canvas ?? null;
  }

  getPageElement(page: number): HTMLElement | null {
    return this._pageElements.get(page) ?? null;
  }

  getRenderedPages(): Set<number> { return new Set(this._renderedPages); }

  onReady(cb: () => void) {
    if (this._isReady) cb();
    else this._readyCallbacks.push(cb);
  }

  onPageRendered(cb: (page: number) => void)  { this._pageRenderedCallbacks.push(cb); }
  offPageRendered(cb: (page: number) => void) {
    const idx = this._pageRenderedCallbacks.indexOf(cb);
    if (idx !== -1) this._pageRenderedCallbacks.splice(idx, 1);
  }

  dispose() {
    this._frames = [];
    this._readyCallbacks = [];
    this._pageRenderedCallbacks = [];
    this._pageElements.clear();
    this._renderedPages.clear();
    this._isReady  = false;
    this.pageCount = 0;
  }
}
