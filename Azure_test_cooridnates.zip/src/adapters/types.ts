// ─────────────────────────────────────────────────────────────────────────────
// VIEWER ADAPTER INTERFACE
// ─────────────────────────────────────────────────────────────────────────────

export interface ViewerAdapter {
  /** Total page / sheet count (1-based) */
  pageCount: number;

  /** Navigate to a 1-based page number */
  navigateToPage(page: number): void;

  /** Real page dimensions in points/pixels for coord normalisation */
  getPageDimensions(page: number): { width: number; height: number } | null;

  /** The rendered canvas element for a page (for overlay positioning) */
  getPageCanvas(page: number): HTMLCanvasElement | null;

  /** The wrapper element for a page (for overlay attachment) */
  getPageElement(page: number): HTMLElement | null;

  /** Currently visible / rendered page numbers */
  getRenderedPages(): Set<number>;

  /** Fire cb once when the document is fully loaded */
  onReady(cb: () => void): void;

  /** Fire cb each time a page finishes rendering */
  onPageRendered(cb: (page: number) => void): void;

  /** Remove a previously registered page-rendered callback */
  offPageRendered?(cb: (page: number) => void): void;
}

// ─────────────────────────────────────────────────────────────────────────────
// FILE FORMAT DETECTION
// ─────────────────────────────────────────────────────────────────────────────

export type FormatGroup = 'pdf' | 'image' | 'spreadsheet' | 'document' | 'unknown';

export function detectFormat(filename: string): FormatGroup {
  const ext = filename.split('.').pop()?.toLowerCase() ?? '';
  if (ext === 'pdf') return 'pdf';
  if (['tif', 'tiff', 'bmp', 'jpeg', 'jpg', 'png'].includes(ext)) return 'image';
  if (['xls', 'xlsx', 'csv'].includes(ext)) return 'spreadsheet';
  if (['docx', 'doc', 'txt'].includes(ext)) return 'document';
  return 'unknown';
}

export function isTiff(filename: string): boolean {
  const ext = filename.split('.').pop()?.toLowerCase() ?? '';
  return ext === 'tif' || ext === 'tiff';
}

export function isCsv(filename: string): boolean {
  return filename.split('.').pop()?.toLowerCase() === 'csv';
}

// ─────────────────────────────────────────────────────────────────────────────
// CAPTURE ITEM DATA MODEL
// ─────────────────────────────────────────────────────────────────────────────

export type CoordSourceFormat = 'flat' | 'bbox' | 'rectangle' | 'coordinates' | 'bbox_relative';

export interface CaptureItem {
  id: string;
  label: string;
  value: string;
  page: number;
  x: number;       // 0–1 fraction of page width
  y: number;       // 0–1 fraction of page height
  width: number;
  height: number;
  sourceFormat?: CoordSourceFormat;
  fromJson?: boolean;
  color?: string;  // resolved CSS color
  type?: 'external';
  // Which JSON key was used for the text field in the source (text/label/value).
  // Used to round-trip submit JSON with the same key name.
  _textField?: 'text' | 'label' | 'value';
}

// ─────────────────────────────────────────────────────────────────────────────
// WORD INDEX ENTRY
// ─────────────────────────────────────────────────────────────────────────────

export interface WordEntry {
  text: string;
  page: number;
  x: number;
  y: number;
  width: number;
  height: number;
  // Which JSON key held the text in the source (text/label/value).
  _textField?: 'text' | 'label' | 'value';
  // Which coord format was used in the source JSON — preserved for export round-trip
  sourceFormat?: CoordSourceFormat;
}

// ─────────────────────────────────────────────────────────────────────────────
// CATEGORY
// ─────────────────────────────────────────────────────────────────────────────

export interface Category {
  pages: number[];
  label: string;
  color?: string;   // resolved palette key or CSS color
}

export const PALETTE_COLORS = ['blue','teal','amber','gray','purple','coral','green','red'] as const;
export type PaletteColor = typeof PALETTE_COLORS[number];

export const PALETTE_MAP: Record<PaletteColor, {
  bg: string; text: string; divBg: string; divText: string
}> = {
  blue:   { bg:'#185FA5', text:'#E6F1FB', divBg:'#E6F1FB', divText:'#185FA5' },
  teal:   { bg:'#0F6E56', text:'#E1F5EE', divBg:'#E1F5EE', divText:'#0F6E56' },
  amber:  { bg:'#854F0B', text:'#FAEEDA', divBg:'#FAEEDA', divText:'#854F0B' },
  gray:   { bg:'#5F5E5A', text:'#F1EFE8', divBg:'#F1EFE8', divText:'#5F5E5A' },
  purple: { bg:'#3C3489', text:'#EEEDFE', divBg:'#EEEDFE', divText:'#3C3489' },
  coral:  { bg:'#993C1D', text:'#FAECE7', divBg:'#FAECE7', divText:'#993C1D' },
  green:  { bg:'#3B6D11', text:'#EAF3DE', divBg:'#EAF3DE', divText:'#3B6D11' },
  red:    { bg:'#A32D2D', text:'#FCEBEB', divBg:'#FCEBEB', divText:'#A32D2D' },
};
