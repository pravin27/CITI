import React, { useCallback, useRef, useState } from 'react';
import { useAppStore } from '../store/appStore';
import { injectWordIndex, injectCapturedFields, injectCategories } from '../hooks/useSidecarLoader';
import type { ViewerAdapter } from '../adapters/types';

type SidecarType = 'word_index' | 'captured_fields' | 'categories';

function detectSidecarType(filename: string, json: unknown): SidecarType | null {
  const lower = filename.toLowerCase();
  if (lower.includes('word_index')) return 'word_index';
  if (lower.includes('captured_fields')) return 'captured_fields';
  if (lower.includes('categories')) return 'categories';
  if (Array.isArray(json)) {
    const first = (json as Record<string, unknown>[])[0];
    if (!first) return null;
    if ('pages' in first && 'label' in first) return 'categories';
    if ('id' in first && ('x' in first || 'bbox' in first || 'rectangle' in first || 'coordinates' in first)) return 'captured_fields';
    if ('text' in first || 't' in first) return 'word_index';
    return 'captured_fields';
  }
  if (json && typeof json === 'object' && 'pages' in (json as object)) return 'word_index';
  return null;
}

export function SidecarLoader() {
  const fileName      = useAppStore(s => s.fileName);
  const adapter       = useAppStore(s => s.adapter);
  const setWordIndex  = useAppStore(s => s.setWordIndex);
  const setCategories = useAppStore(s => s.setCategories);
  const replaceCapture = useAppStore(s => s.replaceCapture);

  const [status, setStatus] = useState('');
  const [error, setError]   = useState('');
  const [isDragging, setIsDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const processFile = useCallback(async (file: File) => {
    setError(''); setStatus('');
    try {
      const json = JSON.parse(await file.text());
      const type = detectSidecarType(file.name, json);
      if (!type) { setError('Could not detect sidecar type.'); return; }
      const va = adapter as unknown as ViewerAdapter | null;
      if (type === 'word_index') {
        const map = injectWordIndex(json, va);
        setWordIndex(map);
        const total = Array.from(map.values()).reduce((s, a) => s + a.length, 0);
        setStatus(`✓ Word index: ${map.size} page(s), ${total} words`);
      } else if (type === 'captured_fields') {
        const fields = injectCapturedFields(json, va);
        fields.forEach(f => replaceCapture(f));
        setStatus(`✓ Captured fields: ${fields.length} loaded`);
      } else {
        const cats = injectCategories(json);
        setCategories(cats);
        setStatus(`✓ Categories: ${cats.length} loaded`);
      }
    } catch (e) { setError(`Failed to parse: ${e}`); }
  }, [adapter, setWordIndex, setCategories, replaceCapture]);

  const handleFiles = useCallback((files: FileList | null) => {
    if (!files?.length) return;
    Array.from(files).forEach(f => processFile(f));
  }, [processFile]);

  if (!fileName) return null;

  return (
    <div className="mx-3 mt-4">
      <div className="text-[10px] text-[#607080] mb-1.5 uppercase tracking-wide">Load Sidecar JSON</div>
      <div
        onDrop={e => { e.preventDefault(); setIsDragging(false); handleFiles(e.dataTransfer.files); }}
        onDragOver={e => { e.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onClick={() => inputRef.current?.click()}
        className={`border border-dashed rounded-lg p-3 cursor-pointer transition-all text-center ${
          isDragging ? 'border-[#0a84ff] bg-[#0a84ff]/10' : 'border-[#1e2d45] hover:border-[#2a3f60] bg-[#0d1829]'
        }`}>
        <input ref={inputRef} type="file" accept=".json" multiple className="hidden"
          onChange={e => handleFiles(e.target.files)} />
        <div className="text-[#607080] text-[10px]">
          Drop or click to load<br/>
          <span className="text-[#3a4a5a]">word_index · captured_fields · categories</span>
        </div>
      </div>
      {status && <div className="mt-1.5 text-[10px] text-green-400 bg-green-500/10 rounded p-1.5 border border-green-500/20">{status}</div>}
      {error  && <div className="mt-1.5 text-[10px] text-red-400 bg-red-500/10 rounded p-1.5 border border-red-500/20">{error}</div>}
    </div>
  );
}
