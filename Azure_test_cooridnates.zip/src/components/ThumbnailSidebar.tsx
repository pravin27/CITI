// ─────────────────────────────────────────────────────────────────────────────
// ThumbnailSidebar
//
// TWO MODES — decided by whether categories JSON was loaded:
//
//   NO CATEGORIES  → flat scrollable list, same as before. Zero overhead.
//
//   WITH CATEGORIES → collapsible accordion groups (Variant C style):
//       • thick left border (4px) in category colour
//       • light tinted header background matching colour
//       • each group collapses independently (local React state, no store)
//       • pages not assigned to any category → "Others" group at bottom
//       • badge shows page count per group
//
// PERFORMANCE:
//   • pageCategoryMap built once with useMemo — O(pages)
//   • groups array built once with useMemo — O(categories + pages)
//   • ThumbnailItem canvas drawn lazily on first render via useEffect
//   • onPageRendered callback registered once per item, never re-registered
//   • No virtualization needed for typical doc sizes (<500 pages);
//     for very large docs the accordion collapse naturally hides DOM nodes.
// ─────────────────────────────────────────────────────────────────────────────

import React, { useEffect, useRef, useMemo, useState, useCallback, memo } from 'react';
import { useAppStore } from '../store/appStore';
import { PALETTE_MAP, PALETTE_COLORS } from '../adapters/types';
import type { PaletteColor, Category } from '../adapters/types';
import type { AdapterInstance } from '../store/appStore';

// ── Colour helpers ─────────────────────────────────────────────────────────────

// Light tint + dark text for header background (Variant C style)
// Returns { headerBg, borderColor, textColor, badgeBg, badgeText }
function resolveHeaderColors(color?: string): {
  headerBg: string; borderColor: string; textColor: string;
  badgeBg: string; badgeText: string;
} {
  // Others group — medium grey, readable on white sidebar
  const OTHERS = {
    headerBg:    '#6b7280',
    borderColor: '#4b5563',
    textColor:   '#ffffff',
    badgeBg:     '#4b5563',
    badgeText:   '#ffffff',
  };
  if (!color) return OTHERS;

  // Named palette key — use the full (saturated) bg color for a strong header
  if (color in PALETTE_MAP) {
    const p = PALETTE_MAP[color as PaletteColor];
    return {
      headerBg:    p.bg,       // full saturated color e.g. #185FA5
      borderColor: p.bg,
      textColor:   p.text,     // always white/near-white
      badgeBg:     'rgba(255,255,255,0.20)',
      badgeText:   '#ffffff',
    };
  }

  // Raw CSS hex color — use directly as header bg, white text
  return {
    headerBg:    color,
    borderColor: color,
    textColor:   '#ffffff',
    badgeBg:     'rgba(255,255,255,0.20)',
    badgeText:   '#ffffff',
  };
}

// Badge for the page thumbnail bottom strip (small, matches group colour)
function resolveBadgeColors(color?: string): { bg: string; text: string } | null {
  if (!color) return null;
  if (color in PALETTE_MAP) {
    const p = PALETTE_MAP[color as PaletteColor];
    return { bg: p.divBg, text: p.divText };
  }
  return { bg: color + '33', text: '#e0e8f0' };
}

// ── Types ──────────────────────────────────────────────────────────────────────

interface GroupDef {
  label:    string;
  color?:   string;
  pages:    number[];
  isOthers: boolean;
}

// ── Accordion group component ──────────────────────────────────────────────────

interface AccordionGroupProps {
  group:       GroupDef;
  adapter:     AdapterInstance | null;
  defaultOpen: boolean;
}

const AccordionGroup = memo(function AccordionGroup({
  group, adapter, defaultOpen,
}: AccordionGroupProps) {
  const [open, setOpen] = useState(defaultOpen);
  const colors = resolveHeaderColors(group.isOthers ? undefined : group.color);
  const setCurrentPage = useAppStore(s => s.setCurrentPage);

  const handlePageClick = useCallback((page: number) => {
    setCurrentPage(page);
    adapter?.navigateToPage(page);
  }, [adapter, setCurrentPage]);

  return (
    <div style={{ borderBottom: '0.5px solid #1a2740' }}>
      {/* Accordion header — Variant C: thick left border + light tint bg */}
      <button
        onClick={() => setOpen(v => !v)}
        style={{
          display:         'flex',
          alignItems:      'center',
          gap:             8,
          width:           '100%',
          padding:         '7px 10px 7px 8px',
          cursor:          'pointer',
          background:      colors.headerBg,
          borderLeft:      `4px solid ${colors.borderColor}`,
          border:          'none',
          borderBottom:    open ? `0.5px solid #1a2740` : 'none',
          textAlign:       'left',
          userSelect:      'none',
        }}
      >
        {/* Chevron */}
        <span style={{
          fontSize: 9,
          color:    colors.textColor,
          opacity:  0.7,
          display:  'inline-block',
          transform: open ? 'rotate(90deg)' : 'rotate(0deg)',
          transition: 'transform 0.15s',
          flexShrink: 0,
        }}>▶</span>

        {/* Label */}
        <span style={{
          flex:       1,
          fontSize:   11,
          fontWeight: 500,
          color:      colors.textColor,
          overflow:   'hidden',
          textOverflow: 'ellipsis',
          whiteSpace: 'nowrap',
        }}>
          {group.label}
        </span>

        {/* Page count badge */}
        <span style={{
          fontSize:     10,
          padding:      '1px 6px',
          borderRadius: 10,
          background:   colors.badgeBg,
          color:        colors.badgeText,
          fontWeight:   500,
          flexShrink:   0,
        }}>
          {group.pages.length}
        </span>
      </button>

      {/* Pages — only mounted when open, so canvas draw only runs when visible */}
      {open && (
        <div style={{ background: '#f0f2f4' }}>
          {group.pages.map(page => (
            <ThumbnailItem
              key={page}
              page={page}
              adapter={adapter}
              categoryLabel={group.isOthers ? 'Others' : group.label}
              color={group.isOthers ? undefined : group.color}
              onClick={() => handlePageClick(page)}
            />
          ))}
        </div>
      )}
    </div>
  );
});

// ── Main sidebar ───────────────────────────────────────────────────────────────

export function ThumbnailSidebar() {
  const adapter        = useAppStore(s => s.adapter);
  const categories     = useAppStore(s => s.categories);
  const sidebarTab     = useAppStore(s => s.sidebarTab);
  const setCurrentPage = useAppStore(s => s.setCurrentPage);
  const pageCount      = useAppStore(s => s.pageCount) || adapter?.pageCount || 0;

  const hasCategories = categories.length > 0;

  // Build page→category map — O(pages), memoised
  const pageCatMap = useMemo(() => {
    const map = new Map<number, Category | null>();
    for (let p = 1; p <= pageCount; p++) {
      map.set(p, categories.find(c => c.pages.includes(p)) ?? null);
    }
    return map;
  }, [categories, pageCount]);

  // Build ordered group list — memoised
  // Groups preserve category order from JSON; Others appended at end
  const groups = useMemo<GroupDef[]>(() => {
    if (!hasCategories) return [];
    const catSet = new Set(categories.flatMap(c => c.pages));
    const otherPages: number[] = [];
    for (let p = 1; p <= pageCount; p++) {
      if (!catSet.has(p)) otherPages.push(p);
    }
    const result: GroupDef[] = categories
      .filter(c => c.pages.length > 0)
      .map(c => ({ label: c.label, color: c.color, pages: [...c.pages].sort((a,b)=>a-b), isOthers: false }));
    if (otherPages.length > 0) {
      result.push({ label: 'Others', pages: otherPages, isOthers: true });
    }
    return result;
  }, [categories, pageCount, hasCategories]);

  if (sidebarTab !== 'thumbnails') return null;

  // ── WITH CATEGORIES: accordion mode ─────────────────────────────────────────
  if (hasCategories) {
    return (
      <div
        style={{ width: 172, display: 'flex', flexDirection: 'column',
          height: '100%', overflow: 'hidden',
          background: '#0d1829', borderRight: '1px solid #1a2740' }}
      >
        {/* Sidebar header */}
        <div style={{
          padding:      '7px 10px',
          borderBottom: '1px solid #1a2740',
          display:      'flex',
          alignItems:   'center',
          justifyContent: 'space-between',
          flexShrink:   0,
          background:   '#080f1a',
        }}>
          <span style={{ fontSize: 11, color: '#e8f0f6' }}>
            {pageCount} pages · {categories.length} types
          </span>
          <span style={{
            fontSize: 10, padding: '1px 7px', borderRadius: 10,
            background: 'rgba(255,255,255,0.15)', color: '#d8eaf6', fontWeight: 500,
          }}>{pageCount}</span>
        </div>

        {/* Accordion groups — scrollable */}
        <div style={{ flex: 1, overflowY: 'auto', background: '#f0f2f4' }}>
          {groups.map((group, idx) => (
            <AccordionGroup
              key={group.label}
              group={group}
              adapter={adapter}
              defaultOpen={idx === 0} // first group open by default
            />
          ))}
          {pageCount === 0 && (
            <div style={{ textAlign:'center', color:'#3a4a5a', fontSize:10, paddingTop:32 }}>
              No pages
            </div>
          )}
        </div>
      </div>
    );
  }

  // ── NO CATEGORIES: flat list (original UI, unchanged) ───────────────────────
  return (
    <div className="flex flex-col h-full overflow-hidden bg-[#f0f2f4] border-r border-[#dde3ea]"
      style={{ width: 160 }}>
      <div className="flex-1 overflow-y-auto py-2 flex flex-col gap-2 px-2 bg-[#f0f2f4]">
        {Array.from({ length: pageCount }, (_, i) => i + 1).map(page => (
          <ThumbnailItem
            key={page}
            page={page}
            adapter={adapter}
            categoryLabel={null}
            color={undefined}
            onClick={() => { setCurrentPage(page); adapter?.navigateToPage(page); }}
          />
        ))}
        {pageCount === 0 && (
          <div className="text-center text-[#3a4a5a] text-[10px] pt-8">No pages</div>
        )}
      </div>
    </div>
  );
}

// ── Thumbnail item ─────────────────────────────────────────────────────────────
// Memoized — only re-renders when page, currentPage, or adapter changes.
// Canvas draw runs once on mount and again whenever the adapter fires
// onPageRendered for this specific page. The callback is registered once
// and cleaned up on unmount to avoid accumulation over many renders.

interface ThumbnailItemProps {
  page:          number;
  adapter:       AdapterInstance | null;
  categoryLabel: string | null;
  color?:        string;
  onClick:       () => void;
}

const ThumbnailItem = memo(function ThumbnailItem({
  page, adapter, categoryLabel, color, onClick,
}: ThumbnailItemProps) {
  const canvasRef   = useRef<HTMLCanvasElement>(null);
  const buttonRef   = useRef<HTMLButtonElement>(null);

  // PERF: subscribe directly instead of useAppStore hook to avoid
  // re-rendering all 1000+ ThumbnailItems on every page navigation.
  // We imperatively update the button style when currentPage changes.
  useEffect(() => {
    const applyActive = (active: boolean) => {
      const btn = buttonRef.current;
      if (!btn) return;
      btn.style.background  = active ? '#dbeafe' : 'transparent';
      btn.style.borderLeft  = active ? '2px solid #2563eb' : '2px solid transparent';
      // Update canvas border
      const wrap = btn.querySelector<HTMLElement>('.thumb-wrap');
      if (wrap) wrap.style.borderColor = active ? '#2563eb' : '#dde3ea';
    };
    // Seed with current state
    applyActive(useAppStore.getState().currentPage === page);
    // Subscribe
    return useAppStore.subscribe(s => {
      applyActive(s.currentPage === page);
    });
  }, [page]);

  const badge = categoryLabel ? resolveBadgeColors(color) : null;

  // Draw canvas — registered once, cleaned up on unmount
  useEffect(() => {
    if (!adapter || !canvasRef.current) return;
    const canvas = canvasRef.current;

    const draw = () => {
      const src = adapter.getPageCanvas(page);
      if (!src || !canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      const W = 140;
      const aspect = src.height / Math.max(src.width, 1);
      canvas.width  = W;
      canvas.height = Math.round(W * aspect);
      ctx.drawImage(src, 0, 0, canvas.width, canvas.height);
    };

    draw();

    // Register page-rendered callback — redraw when adapter fires for this page
    const cb = (p: number) => { if (p === page) draw(); };
    adapter.onPageRendered(cb);
    return () => { (adapter as any).offPageRendered?.(cb); };
  }, [adapter, page]);

  const initActive = useAppStore.getState().currentPage === page;

  return (
    <button
      ref={buttonRef}
      onClick={onClick}
      style={{
        display:       'flex',
        flexDirection: 'column',
        width:         '100%',
        padding:       '6px 8px',
        background:    initActive ? '#dbeafe' : 'transparent',
        border:        'none',
        borderLeft:    initActive ? '2px solid #2563eb' : '2px solid transparent',
        cursor:        'pointer',
        textAlign:     'left',
        transition:    'background 0.1s',
        flexShrink:    0,
      }}
      onMouseEnter={e => { const el = e.currentTarget as HTMLElement; if (el.style.background !== 'rgb(219, 234, 254)') el.style.background = '#e8edf2'; }}
      onMouseLeave={e => { const el = e.currentTarget as HTMLElement; if (el.style.background !== 'rgb(219, 234, 254)') el.style.background = 'transparent'; }}
    >
      {/* Thumbnail canvas wrapper */}
      <div style={{
        width:        '100%',
        borderRadius: 4,
        overflow:     'hidden',
        border:       `1px solid ${initActive ? '#2563eb' : '#dde3ea'}`,
        background:   '#fff',
        marginBottom: 5,
        position:     'relative',
      }}>
        <canvas ref={canvasRef} style={{ width: '100%', display: 'block' }} />
        {/* Page number badge — top left */}
        <div style={{
          position:     'absolute',
          top:          3,
          left:         3,
          background:   'rgba(0,0,0,0.6)',
          color:        '#fff',
          fontSize:     9,
          padding:      '1px 5px',
          borderRadius: 3,
          lineHeight:   '14px',
        }}>{page}</div>
      </div>

      {/* Footer: category badge */}
      {categoryLabel && (
        <div style={{
          fontSize:     9,
          padding:      '2px 6px',
          borderRadius: 8,
          background:   badge?.bg ?? '#3a3a37',
          color:        badge?.text ?? '#c4c0b8',
          fontWeight:   500,
          textAlign:    'center',
          overflow:     'hidden',
          textOverflow: 'ellipsis',
          whiteSpace:   'nowrap',
          width:        '100%',
        }}>
          {categoryLabel}
        </div>
      )}
    </button>
  );
});
