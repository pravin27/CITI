// ─────────────────────────────────────────────────────────────────────────────
// ImageViewer — TIF / PNG / JPEG / DOC pages
//
// PERFORMANCE — critical for 1000+ page documents:
//
//  1. VIRTUAL SCROLL — only ±2 pages around the viewport are drawn to canvas.
//     Off-screen pages render as a blank placeholder div with the correct
//     height so scroll position is preserved. When a page enters the viewport
//     the IntersectionObserver fires and the canvas is drawn immediately.
//     Memory: O(visible_pages) canvases in the DOM at any time, not O(total).
//
//  2. SHARED HIGHLIGHT CACHE — fwc/flc Maps are built ONCE per captures change
//     in a module-level ref, not rebuilt inside every per-page drawHighlights.
//     400 captures * 1000 pages was rebuilding 400K Map entries per store event.
//     Now it rebuilds once regardless of page count.
//
//  3. SINGLE STORE SUBSCRIPTION per viewer (not per page).
//     The parent ImageViewer holds one subscription and calls into a per-page
//     draw function only for currently visible pages. Previously every
//     ImagePageCanvas had its own subscriber.
//
//  4. RAF-GATED REDRAWS — highlight redraws are batched through
//     requestAnimationFrame so rapid store changes (typing search query,
//     scrolling fast) only redraw once per frame.
// ─────────────────────────────────────────────────────────────────────────────

import React, { useEffect, useRef, useCallback, useState, memo } from 'react';
import { useAppStore } from '../store/appStore';
import type { ImageAdapter } from '../adapters/ImageAdapter';
import { colorToRgba } from '../utils/color';

const PAGE_GAP   = 12;
const RADIUS     = 2.5;
const OVERSCAN   = 2;   // pages to keep rendered beyond the visible viewport

interface ImageViewerProps { adapter: ImageAdapter; zoom: number; }

// ── Shared highlight cache ────────────────────────────────────────────────────
// Built once when captures change, reused by all page canvases.
interface HlCache {
  fwc:       Map<string, string>; // captureId → lowercase value
  flc:       Map<string, string>; // captureId → lowercase label
  version:   number;              // bumped on every rebuild
}
const hlCache: HlCache = { fwc: new Map(), flc: new Map(), version: 0 };

function rebuildHlCache(captures: ReturnType<typeof useAppStore.getState>['captures']) {
  hlCache.fwc.clear();
  hlCache.flc.clear();
  for (const cap of captures) {
    hlCache.fwc.set(cap.id, cap.value.toLowerCase().trim());
    hlCache.flc.set(cap.id, (cap.label || cap.id).toLowerCase().trim());
  }
  hlCache.version++;
}

// ── Rounded rect helper ───────────────────────────────────────────────────────
function rr(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  if (w < 1 || h < 1) return;
  r = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x+r,y); ctx.lineTo(x+w-r,y); ctx.arcTo(x+w,y,x+w,y+r,r);
  ctx.lineTo(x+w,y+h-r); ctx.arcTo(x+w,y+h,x+w-r,y+h,r);
  ctx.lineTo(x+r,y+h); ctx.arcTo(x,y+h,x,y+h-r,r);
  ctx.lineTo(x,y+r); ctx.arcTo(x,y,x+r,y,r); ctx.closePath();
}

// ── Per-page highlight draw ───────────────────────────────────────────────────
// Pure function — no hooks, no subscriptions. Called by the parent viewer.
function paintHighlights(
  canvas: HTMLCanvasElement,
  pageNum: number,
  W: number, H: number,
) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  ctx.clearRect(0, 0, W, H);

  const s           = useAppStore.getState();
  const rects       = s.highlightIndex.get(pageNum) ?? [];
  const aid         = s.activeFieldId;
  const previewRect = s.previewRect;
  const wi          = s.wordIndex;
  const hasWI       = wi.size > 0;

  const { fwc, flc } = hlCache;
  const activeTxt   = aid ? (fwc.get(aid) ?? '') : '';
  const activeLabel = aid ? (flc.get(aid) ?? '') : '';

  // ── Search highlights ────────────────────────────────────────────────────
  const sr = s.search.results.filter(r => r.page === pageNum);
  for (const r of sr) {
    const isCur = s.search.results.indexOf(r) === s.search.currentIndex;
    ctx.save();
    if (isCur) {
      ctx.fillStyle='rgba(255,140,0,.45)'; ctx.strokeStyle='rgba(255,100,0,.95)';
      ctx.lineWidth=2; ctx.shadowColor='rgba(255,140,0,.5)'; ctx.shadowBlur=6;
    } else if (s.search.highlightAll) {
      ctx.fillStyle='rgba(255,220,50,.28)'; ctx.strokeStyle='rgba(200,160,0,.65)'; ctx.lineWidth=1;
    } else { ctx.restore(); continue; }
    rr(ctx, r.x*W, r.y*H, r.width*W, r.height*H, RADIUS);
    ctx.fill(); ctx.stroke(); ctx.restore();
  }

  // ── Confirmed capture boxes ──────────────────────────────────────────────
  const capturedKeys = new Set<number>();
  for (const rect of rects) {
    capturedKeys.add(Math.round(rect.x*1000)*10000 + Math.round(rect.y*1000));
    const isAct   = rect.id === aid;
    const sameVal = !!activeTxt   && fwc.get(rect.id) === activeTxt;
    const sameLbl = !!activeLabel && flc.get(rect.id) === activeLabel;
    const isDup   = !isAct && (sameVal || sameLbl);
    ctx.save();
    if (isAct) {
      ctx.shadowColor='rgba(220,180,0,.5)'; ctx.shadowBlur=8;
      ctx.fillStyle='rgba(255,230,0,.35)'; ctx.strokeStyle='rgb(200,160,0)'; ctx.lineWidth=2.5;
    } else if (isDup) {
      ctx.fillStyle='rgba(255,182,193,.40)'; ctx.strokeStyle='rgba(220,80,120,.85)'; ctx.lineWidth=2;
    } else if (rect.color) {
      ctx.fillStyle=colorToRgba(rect.color,.20); ctx.strokeStyle=rect.color; ctx.lineWidth=1.5;
    } else {
      ctx.fillStyle='rgba(150,150,150,.18)'; ctx.strokeStyle='rgba(120,120,120,.70)'; ctx.lineWidth=1.5;
    }
    rr(ctx, rect.x*W, rect.y*H, rect.width*W, rect.height*H, RADIUS);
    ctx.fill(); ctx.stroke(); ctx.restore();
  }

  // ── Word-index occurrences ───────────────────────────────────────────────
  if (hasWI && aid) {
    const pageEntries = wi.get(pageNum) ?? [];
    for (const cap of s.captures) {
      if (cap.id === aid) continue;
      const wt = fwc.get(cap.id) ?? '';
      if (!wt) continue;
      const fill   = cap.color ? colorToRgba(cap.color, .18) : 'rgba(150,150,150,.18)';
      const stroke = cap.color ?? 'rgba(120,120,120,.70)';
      ctx.fillStyle=fill; ctx.strokeStyle=stroke; ctx.lineWidth=1.2;
      for (const e of pageEntries) {
        if (e.text.toLowerCase().trim() !== wt) continue;
        const k = Math.round(e.x*1000)*10000 + Math.round(e.y*1000);
        if (capturedKeys.has(k)) continue;
        rr(ctx, e.x*W, e.y*H, e.width*W, e.height*H, RADIUS);
        ctx.fill(); ctx.stroke();
      }
    }
    if (activeTxt) {
      ctx.fillStyle='rgba(255,182,193,.40)'; ctx.strokeStyle='rgba(220,80,120,.80)'; ctx.lineWidth=1.5;
      for (const e of wi.get(pageNum) ?? []) {
        if (e.text.toLowerCase().trim() !== activeTxt) continue;
        const k = Math.round(e.x*1000)*10000 + Math.round(e.y*1000);
        if (capturedKeys.has(k)) continue;
        rr(ctx, e.x*W, e.y*H, e.width*W, e.height*H, RADIUS);
        ctx.fill(); ctx.stroke();
      }
    }
  }

  // ── Preview rect ─────────────────────────────────────────────────────────
  if (previewRect?.page === pageNum) {
    ctx.save();
    ctx.fillStyle='rgba(6,182,212,.15)'; ctx.strokeStyle='rgba(6,182,212,.9)';
    ctx.lineWidth=2; ctx.shadowColor='rgba(6,182,212,.5)'; ctx.shadowBlur=6;
    rr(ctx, previewRect.x*W, previewRect.y*H, previewRect.width*W, previewRect.height*H, RADIUS);
    ctx.fill(); ctx.stroke(); ctx.restore();
  }
}

// ── Main viewer ───────────────────────────────────────────────────────────────
export function ImageViewer({ adapter, zoom }: ImageViewerProps) {
  const setCurrentPage = useAppStore(s => s.setCurrentPage);
  const rotation       = useAppStore(s => s.rotation);
  const frames         = adapter.getAllFrames();
  const containerRef   = useRef<HTMLDivElement>(null);

  // Track which pages are currently visible
  const [visiblePages, setVisiblePages] = useState<Set<number>>(() => new Set([1, 2]));
  const visibleRef = useRef<Set<number>>(new Set([1, 2]));

  // Per-page hl canvas refs — stored as a map so parent can call paintHighlights
  const hlRefs = useRef<Map<number, HTMLCanvasElement>>(new Map());

  useEffect(() => {
    if (containerRef.current) containerRef.current.setAttribute('data-viewer-scroll', '1');
  }, []);

  // ── IntersectionObserver: track visible pages + update currentPage ─────────
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const pageVisibility = new Map<number, number>(); // page → intersectionRatio

    const obs = new IntersectionObserver(entries => {
      for (const e of entries) {
        const page = Number((e.target as HTMLElement).dataset.pageNumber);
        if (e.isIntersecting) pageVisibility.set(page, e.intersectionRatio);
        else                  pageVisibility.delete(page);
      }

      // Update visible set with overscan
      const visible = new Set<number>();
      const sorted = [...pageVisibility.keys()].sort((a, b) => a - b);
      if (sorted.length) {
        const first = sorted[0], last = sorted[sorted.length - 1];
        for (let p = Math.max(1, first - OVERSCAN); p <= Math.min(frames.length, last + OVERSCAN); p++) {
          visible.add(p);
        }
        // Update current page (highest ratio)
        let best = sorted[0], bestR = 0;
        for (const [pg, r] of pageVisibility) if (r > bestR) { best = pg; bestR = r; }
        setCurrentPage(best);
      }

      // Only update React state if set actually changed
      const prev = visibleRef.current;
      if (visible.size !== prev.size || [...visible].some(p => !prev.has(p))) {
        visibleRef.current = visible;
        setVisiblePages(new Set(visible));
      }
    }, { root: container, threshold: [0, 0.1, 0.5] });

    container.querySelectorAll<HTMLElement>('[data-page-number]').forEach(el => obs.observe(el));
    return () => obs.disconnect();
  }, [frames.length, setCurrentPage]);

  // ── Single store subscription → RAF-gated redraws ────────────────────────
  // One subscription for the whole viewer. Redraws only visible pages.
  const rafRef = useRef(0);
  const redrawVisible = useCallback(() => {
    cancelAnimationFrame(rafRef.current);
    rafRef.current = requestAnimationFrame(() => {
      for (const page of visibleRef.current) {
        const hl = hlRefs.current.get(page);
        if (!hl || !hl.width || !hl.height) continue;
        paintHighlights(hl, page, hl.width, hl.height);
      }
    });
  }, []);

  useEffect(() => {
    // Rebuild shared cache when captures change, then redraw
    const unsub = useAppStore.subscribe((n, p) => {
      if (n.captures !== p.captures) {
        rebuildHlCache(n.captures);
      }
      if (n.captures        !== p.captures        ||
          n.activeFieldId   !== p.activeFieldId   ||
          n.highlightIndex  !== p.highlightIndex  ||
          n.wordIndex       !== p.wordIndex       ||
          n.previewRect     !== p.previewRect     ||
          n.search.results  !== p.search.results  ||
          n.search.currentIndex !== p.search.currentIndex ||
          n.search.highlightAll !== p.search.highlightAll) {
        redrawVisible();
      }
    });
    // Seed cache with current captures
    rebuildHlCache(useAppStore.getState().captures);
    return () => { unsub(); cancelAnimationFrame(rafRef.current); };
  }, [redrawVisible]);

  return (
    <div ref={containerRef} className="flex-1 overflow-y-auto overflow-x-auto bg-[#e8e8e8]">
      <div className="flex flex-col items-center py-4">
        {frames.map((frame, i) => {
          const page = i + 1;
          return (
            <ImagePageCanvas
              key={page}
              pageNum={page}
              frame={frame}
              zoom={zoom}
              rotation={rotation}
              adapter={adapter}
              visible={visiblePages.has(page)}
              hlRefs={hlRefs}
              onHlReady={redrawVisible}
            />
          );
        })}
      </div>
    </div>
  );
}

// ── Per-page canvas component ─────────────────────────────────────────────────
interface ImagePageCanvasProps {
  pageNum:    number;
  frame:      { canvas: HTMLCanvasElement; width: number; height: number };
  zoom:       number;
  rotation:   number;
  adapter:    ImageAdapter;
  visible:    boolean;  // controlled by parent's IntersectionObserver
  hlRefs:     React.MutableRefObject<Map<number, HTMLCanvasElement>>;
  onHlReady:  () => void;
}

const ImagePageCanvas = memo(function ImagePageCanvas({
  pageNum, frame, zoom, rotation, adapter, visible, hlRefs, onHlReady,
}: ImagePageCanvasProps) {
  const wrapperRef  = useRef<HTMLDivElement>(null);
  const canvasRef   = useRef<HTMLCanvasElement>(null);
  const hlCanvasRef = useRef<HTMLCanvasElement>(null);

  const isFlipped = rotation === 90 || rotation === 270;
  const displayW  = Math.round((isFlipped ? frame.height : frame.width)  * zoom);
  const displayH  = Math.round((isFlipped ? frame.width  : frame.height) * zoom);

  // Register with adapter (always — needed for box capture coordinate mapping)
  useEffect(() => {
    adapter.registerPageElement(pageNum, wrapperRef.current);
    return () => adapter.registerPageElement(pageNum, null);
  }, [adapter, pageNum]);

  // Register hl canvas with parent so it can call paintHighlights
  useEffect(() => {
    const hl = hlCanvasRef.current;
    if (hl) {
      hlRefs.current.set(pageNum, hl);
      return () => { hlRefs.current.delete(pageNum); };
    }
  }, [pageNum, hlRefs]);

  // Draw image canvas — only when visible
  useEffect(() => {
    if (!visible) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.width  = displayW;
    canvas.height = displayH;
    const ctx = canvas.getContext('2d')!;
    ctx.clearRect(0, 0, displayW, displayH);
    ctx.save();
    ctx.translate(displayW / 2, displayH / 2);
    ctx.rotate((rotation * Math.PI) / 180);
    ctx.drawImage(frame.canvas,
      -(frame.width * zoom) / 2, -(frame.height * zoom) / 2,
      frame.width * zoom, frame.height * zoom,
    );
    ctx.restore();
    adapter.notifyPageRendered(pageNum);
  }, [frame, zoom, rotation, adapter, pageNum, visible, displayW, displayH]);

  // Size hl canvas and trigger initial draw when it becomes visible
  useEffect(() => {
    const hl = hlCanvasRef.current;
    if (!hl || !visible) return;
    hl.width  = displayW;
    hl.height = displayH;
    onHlReady();
  }, [displayW, displayH, visible, onHlReady]);

  return (
    <div
      ref={wrapperRef}
      data-page-number={pageNum}
      className="relative shadow-md"
      style={{
        marginBottom: PAGE_GAP,
        width:  displayW,
        height: displayH,
        // Placeholder bg shown when page is not yet rendered
        background: visible ? 'transparent' : '#d8d8d8',
      }}
    >
      {visible && (
        <>
          <canvas ref={canvasRef} style={{ width: displayW, height: displayH, display: 'block' }} />
          <canvas
            ref={hlCanvasRef}
            width={displayW} height={displayH}
            style={{
              position: 'absolute', inset: 0,
              width: displayW, height: displayH,
              pointerEvents: 'none', zIndex: 11,
            }}
          />
        </>
      )}
    </div>
  );
});
