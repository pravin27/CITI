// ─────────────────────────────────────────────────────────────────────────────
// print.ts — Universal print utility for all viewer formats
//
// Strategy per format:
//
//  PDF:         Render each page to canvas at print resolution (2x device pixel),
//               convert to data URL, inject into hidden iframe as <img> tags,
//               call window.print(). Uses pdfjs page rendering directly.
//
//  TIF/Image:   Pages already decoded as HTMLCanvasElement in ImageAdapter/DocAdapter.
//               Convert to JPEG data URLs, print via iframe.
//
//  Spreadsheet: Render each sheet as a styled HTML <table> inside the iframe,
//               using actual cell values, fill colors, merges, col/row sizes.
//
// All formats use a hidden <iframe> + CSS @media print so the rest of the
// application UI is never printed.
// ─────────────────────────────────────────────────────────────────────────────

import type { AdapterInstance } from '../store/appStore';
import type { SpreadsheetAdapter } from '../adapters/SpreadsheetAdapter';
import type { ImageAdapter } from '../adapters/ImageAdapter';

// ── Shared iframe print helper ────────────────────────────────────────────────

function printHTML(html: string, title = 'Document'): void {
  const iframe = document.createElement('iframe');
  iframe.style.cssText = 'position:fixed;top:-9999px;left:-9999px;width:0;height:0;border:none;';
  document.body.appendChild(iframe);

  const doc = iframe.contentDocument!;
  doc.open();
  doc.write(`<!DOCTYPE html><html><head>
<title>${title}</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: white; }
  @media print {
    body { margin: 0; }
    .page-break { page-break-after: always; break-after: page; }
    .page-break:last-child { page-break-after: auto; break-after: auto; }
  }
  @media screen {
    body { padding: 20px; background: #f0f0f0; }
    .page-break { margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,.2); }
  }
</style>
</head><body>${html}</body></html>`);
  doc.close();

  iframe.onload = () => {
    iframe.contentWindow!.focus();
    iframe.contentWindow!.print();
    // Remove after print dialog closes
    setTimeout(() => document.body.removeChild(iframe), 2000);
  };
}

// ── PDF print ─────────────────────────────────────────────────────────────────
// Renders each page to canvas via pdfjs at 2× resolution for sharp print output.

export async function printPDF(fileName: string): Promise<void> {
  const pdfDoc = (window as any).__tovPdfDoc;
  if (!pdfDoc) {
    alert('PDF not loaded yet — please wait for the document to finish loading.');
    return;
  }

  const numPages = pdfDoc.numPages as number;
  const PRINT_SCALE = 2.0; // 2× = ~144dpi for standard monitor, sharp on printer

  const parts: string[] = [];

  for (let pageNum = 1; pageNum <= numPages; pageNum++) {
    const page = await pdfDoc.getPage(pageNum);
    const vp   = page.getViewport({ scale: PRINT_SCALE });

    const canvas = document.createElement('canvas');
    canvas.width  = Math.round(vp.width);
    canvas.height = Math.round(vp.height);
    const ctx = canvas.getContext('2d')!;

    await page.render({ canvasContext: ctx, viewport: vp }).promise;

    const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
    const isLast  = pageNum === numPages;

    parts.push(`
      <div class="${isLast ? '' : 'page-break'}"
           style="width:${canvas.width}px;max-width:100%;background:white;">
        <img src="${dataUrl}"
             style="width:100%;display:block;"
             alt="Page ${pageNum}" />
      </div>`);
  }

  printHTML(parts.join('\n'), fileName);
}

// ── Image / TIF / DOC print ───────────────────────────────────────────────────
// Converts each pre-decoded frame canvas to JPEG and prints.

export function printImages(
  adapter: ImageAdapter,
  fileName: string,
): void {
  const frames = adapter.getAllFrames();
  if (!frames.length) {
    alert('No pages to print.');
    return;
  }

  const parts = frames.map((frame, i) => {
    const dataUrl = frame.canvas.toDataURL('image/jpeg', 0.92);
    const isLast  = i === frames.length - 1;
    return `
      <div class="${isLast ? '' : 'page-break'}"
           style="width:${frame.width}px;max-width:100%;background:white;">
        <img src="${dataUrl}"
             style="width:100%;display:block;"
             alt="Page ${i + 1}" />
      </div>`;
  });

  printHTML(parts.join('\n'), fileName);
}

// ── Spreadsheet print ─────────────────────────────────────────────────────────
// Renders each sheet as a styled HTML table.

export function printSpreadsheet(
  adapter: SpreadsheetAdapter,
  fileName: string,
): void {
  const sheets = adapter.getAllSheets();
  if (!sheets.length) {
    alert('No sheets to print.');
    return;
  }

  const sheetHtml = sheets.map((sheet, si) => {
    const isLast = si === sheets.length - 1;
    const { rows, colCount, rowCount, merges = [], styles, colInfos, rowInfos } = sheet;

    // Build merge lookup: 'r,c' → {colSpan, rowSpan} or 'hidden'
    const mergeMap = new Map<string, { colSpan: number; rowSpan: number } | 'hidden'>();
    for (const m of merges) {
      const rs = m.e.r - m.s.r + 1, cs = m.e.c - m.s.c + 1;
      mergeMap.set(`${m.s.r},${m.s.c}`, { colSpan: cs, rowSpan: rs });
      for (let r = m.s.r; r <= m.e.r; r++) {
        for (let c = m.s.c; c <= m.e.c; c++) {
          if (r === m.s.r && c === m.s.c) continue;
          mergeMap.set(`${r},${c}`, 'hidden');
        }
      }
    }

    // Column widths
    const colWidths = Array.from({ length: colCount }, (_, ci) =>
      colInfos?.[ci]?.wpx ?? 96
    );

    // Header row
    const headerCells = colWidths.map((w, ci) =>
      `<th style="width:${w}px;min-width:${w}px;background:#f2f2f2;border:1px solid #d0d0d0;padding:3px 6px;font-weight:600;font-size:11px;text-align:center;">${colLetter(ci)}</th>`
    ).join('');

    // Data rows
    const dataRows = rows.map((row, ri) => {
      const rowH = rowInfos?.[ri]?.hpx ?? 22;
      if (rowInfos?.[ri]?.hidden) return '';

      const cells = Array.from({ length: colCount }, (_, ci) => {
        const key = `${ri},${ci}`;
        const mi  = mergeMap.get(key);
        if (mi === 'hidden') return '';

        const val      = row[ci] ?? '';
        const cellSty  = styles?.[ri]?.[ci];
        const span     = (mi as { colSpan: number; rowSpan: number } | undefined) ?? { colSpan: 1, rowSpan: 1 };
        const bg       = cellSty?.fillRgb ? `background:#${cellSty.fillRgb};` : '';
        const textColor = cellSty?.fillRgb && !isLightColorHex(cellSty.fillRgb) ? 'color:#fff;' : '';

        return `<td
          colspan="${span.colSpan}" rowspan="${span.rowSpan}"
          style="border:1px solid #d0d0d0;padding:2px 5px;font-size:11px;
                 height:${rowH}px;${bg}${textColor}overflow:hidden;white-space:nowrap;">
          ${escapeHtml(val)}
        </td>`;
      }).join('');

      return `<tr style="height:${rowH}px;">
        <td style="background:#f2f2f2;border:1px solid #d0d0d0;padding:2px 4px;
                   font-size:10px;color:#666;text-align:center;min-width:36px;">${ri + 1}</td>
        ${cells}
      </tr>`;
    }).join('');

    return `
      <div class="${isLast ? '' : 'page-break'}"
           style="background:white;padding:12px;">
        <div style="font-size:12px;font-weight:600;margin-bottom:8px;color:#333;">
          ${escapeHtml(sheet.name)}
        </div>
        <table style="border-collapse:collapse;font-family:Calibri,Arial,sans-serif;">
          <thead>
            <tr>
              <th style="width:36px;background:#f2f2f2;border:1px solid #d0d0d0;"></th>
              ${headerCells}
            </tr>
          </thead>
          <tbody>${dataRows}</tbody>
        </table>
      </div>`;
  }).join('\n');

  printHTML(sheetHtml, fileName);
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function colLetter(i: number): string {
  let r = '';
  while (i >= 0) { r = String.fromCharCode(65 + (i % 26)) + r; i = Math.floor(i / 26) - 1; }
  return r;
}

function escapeHtml(s: string): string {
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function isLightColorHex(hex: string): boolean {
  const r = parseInt(hex.slice(0,2),16);
  const g = parseInt(hex.slice(2,4),16);
  const b = parseInt(hex.slice(4,6),16);
  return (r*299 + g*587 + b*114) / 1000 > 140;
}

// ── Master print function ─────────────────────────────────────────────────────
// Called from the toolbar. Routes to the correct printer based on format.

export async function printCurrentDocument(
  format: string,
  adapter: AdapterInstance | null,
  fileName: string,
): Promise<void> {
  if (!adapter && format !== 'pdf') {
    alert('No document loaded.');
    return;
  }

  try {
    if (format === 'pdf') {
      await printPDF(fileName);
    } else if (format === 'image' || format === 'document') {
      printImages(adapter as ImageAdapter, fileName);
    } else if (format === 'spreadsheet') {
      printSpreadsheet(adapter as SpreadsheetAdapter, fileName);
    } else {
      alert('Print is not supported for this file format.');
    }
  } catch (err) {
    console.error('[Print] Error:', err);
    alert('Print failed: ' + String(err));
  }
}
