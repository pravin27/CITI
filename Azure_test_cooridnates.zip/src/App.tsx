import React, { useEffect, useRef } from 'react';
import { useAppStore } from './store/appStore';
import { TopBar } from './components/TopBar';
import { ResizablePanes } from './components/ResizablePanes';
import { ViewerPane } from './components/ViewerPane';
import { FieldsPanel } from './components/FieldsPanel';
import { ThumbnailSidebar } from './components/ThumbnailSidebar';
import { useSidecarLoader } from './hooks/useSidecarLoader';

function useGlobalShortcuts() {
  const setSearchOpen = useAppStore(s => s.setSearchOpen);
  const searchIsOpen  = useAppStore(s => s.search.isOpen);
  const file          = useAppStore(s => s.file);
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'f' && file) {
        e.preventDefault(); setSearchOpen(!searchIsOpen);
      }
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [setSearchOpen, searchIsOpen, file]);
}

export default function App() {
  const sidebarOpen = useAppStore(s => s.sidebarOpen);
  useSidecarLoader();
  useGlobalShortcuts();

  // Always render the full shell — ViewerPane shows "No Preview" when no file
  return (
    <div className="flex flex-col h-screen bg-[#060d1a] overflow-hidden">
      <TopBar />
      <ResizablePanes
        left={
          <div className="flex flex-1 overflow-hidden">
            {sidebarOpen && <ThumbnailSidebar />}
            <ViewerPane />
          </div>
        }
        right={<FieldsPanel />}
        defaultSplit={0.62}
        minLeft={320}
        minRight={280}
      />
    </div>
  );
}
