// xlsxWorkerBlob.ts
// Worker sends minimal data back to main thread to avoid postMessage freeze.
// Instead of sending 3MB of objects, sends compact arrays.

const WORKER_FN = `
// XLSX code is injected via postMessage — fetched on main thread, executed in worker
var XLSX = null;

self.onmessage = function(e) {
  if (e.data.type === 'init') {
    try {
      // Execute the xlsx library code in worker scope
      // The code is passed as a string from the main thread (already fetched)
      var fn = new Function(e.data.xlsxCode);
      fn();
      // After execution, XLSX global should be available
      XLSX = self.XLSX || (typeof XLSX !== 'undefined' ? XLSX : null);
      if (!XLSX) throw new Error('XLSX not defined after eval');
    } catch(err) {
      self.postMessage({ id:-1, error:'XLSX init failed: '+err });
      return;
    }
    self.postMessage({ type:'ready' });
    return;
  }

  var id = e.data.id, buffer = e.data.buffer, isLarge = e.data.isLarge;
  try {
    var wb = XLSX.read(new Uint8Array(buffer), {
      type:'array', cellStyles:!isLarge, cellDates:true
    });

    var sheets = wb.SheetNames.map(function(name) {
      var ws = wb.Sheets[name];
      var ref = ws['!ref'] || 'A1';
      var range = XLSX.utils.decode_range(ref);
      var R = range.e.r+1, C = range.e.c+1;

      // Pack all cell values into one flat string array (much smaller than objects)
      // cells[r*C + c] = cell display value
      var cells = new Array(R * C);
      for (var r=0; r<=range.e.r; r++) {
        for (var c=0; c<=range.e.c; c++) {
          var cell = ws[XLSX.utils.encode_cell({r:r,c:c})];
          cells[r*C+c] = cell ? (cell.w!=null ? String(cell.w) : cell.v!=null ? String(cell.v) : '') : '';
        }
      }

      // Column widths as compact Int16Array (Transferable - zero copy postMessage)
      var rawCols = ws['!cols'] || [];
      var colWidthsPx = new Int16Array(C);
      for (var ci=0; ci<C; ci++) {
        var col = rawCols[ci] || {};
        colWidthsPx[ci] = col.wpx || (col.width ? Math.round(col.width*7) : 96);
      }

      // Row heights as compact Int16Array (Transferable - zero copy postMessage)
      var rawRows = ws['!rows'] || [];
      var rowHeightsPx = new Int16Array(R);
      var rowHidden = new Uint8Array(R);
      for (var ri=0; ri<R; ri++) {
        var row = rawRows[ri] || {};
        rowHeightsPx[ri] = row.hpx || 22;
        rowHidden[ri] = row.hidden ? 1 : 0;
      }

      // Fill colors: only non-null ones, as index->rgb map (sparse)
      var fillColors = {};
      if (!isLarge) {
        for (var r2=0; r2<=range.e.r; r2++) {
          for (var c2=0; c2<=range.e.c; c2++) {
            var cell2 = ws[XLSX.utils.encode_cell({r:r2,c:c2})];
            if (!cell2 || !cell2.s) continue;
            var s = cell2.s;
            var rgb = (s.fgColor && s.fgColor.rgb) || (s.patternFg && s.patternFg.rgb) || null;
            if (rgb && s.patternType !== 'none' && rgb !== 'FFFFFF' && rgb !== 'ffffff') {
              fillColors[r2*C+c2] = rgb;
            }
          }
        }
      }

      var merges = (ws['!merges']||[]).map(function(m){
        return {s:{r:m.s.r,c:m.s.c},e:{r:m.e.r,c:m.e.c}};
      });

      return {
        name: name, rowCount: R, colCount: C,
        textBuf: textBuf,         // Uint8Array - Transferable, zero-copy
        rowOffsets: rowOffsets,   // Int32Array - Transferable, zero-copy
        colWidthsPx: colWidthsPx, // Int16Array - Transferable, zero-copy
        rowHeightsPx: rowHeightsPx, // Int16Array - Transferable, zero-copy
        rowHidden: rowHidden,     // Uint8Array - Transferable, zero-copy
        fillColors: fillColors,   // sparse object (small)
        merges: merges,
      };
    });

    // Transfer ALL TypedArrays (zero-copy postMessage - no main thread freeze)
    var transferables = [];
    sheets.forEach(function(s) {
      transferables.push(
        s.textBuf.buffer,       // cell data - zero copy
        s.rowOffsets.buffer,    // row offsets - zero copy
        s.colWidthsPx.buffer,
        s.rowHeightsPx.buffer,
        s.rowHidden.buffer
      );
    });

    self.postMessage({id:id, sheets:sheets}, transferables);
  } catch(err) {
    self.postMessage({id:id, error:String(err)});
  }
};
`;

export interface CompactSheet {
  name: string; rowCount: number; colCount: number;
  // Cell data encoded as UTF-8 bytes — rows separated by \n, cols by \t
  // Both are Transferable (zero-copy postMessage — no main thread freeze)
  textBuf: Uint8Array;
  rowOffsets: Int32Array; // rowOffsets[r] = byte offset of row r in textBuf
  colWidthsPx: Int16Array; rowHeightsPx: Int16Array; rowHidden: Uint8Array;
  fillColors: Record<number, string>;
  merges: Array<{s:{r:number;c:number};e:{r:number;c:number}}>;
}

let _worker:      Worker | null = null;
let _workerReady  = false;
const _pending    = new Map<number, { resolve: Function; reject: Function }>();
const _queue:     Array<() => void> = [];
let   _nextId     = 1;

// Cache the fetched xlsx code so we only download it once
let _xlsxCodePromise: Promise<string> | null = null;

function fetchXlsxCode(): Promise<string> {
  if (_xlsxCodePromise) return _xlsxCodePromise;
  const xlsxUrl = new URL('/xlsx.full.min.js', window.location.href).href;
  _xlsxCodePromise = fetch(xlsxUrl, { cache: 'force-cache' })
    .then(r => {
      if (!r.ok) throw new Error('Failed to fetch xlsx: ' + r.status);
      return r.text();
    });
  return _xlsxCodePromise;
}

function initWorker(): Worker {
  const blob   = new Blob([WORKER_FN], { type: 'application/javascript' });
  const blobUrl = URL.createObjectURL(blob);
  const w       = new Worker(blobUrl);

  w.onmessage = (e: MessageEvent) => {
    if (e.data.type === 'ready') {
      _workerReady = true;
      _queue.splice(0).forEach(fn => fn());
      return;
    }
    const { id, sheets, error } = e.data;
    const p = _pending.get(id);
    if (!p) return;
    _pending.delete(id);
    if (error) p.reject(new Error(error));
    else        p.resolve(sheets);
  };
  w.onerror = (err) => {
    console.error('[xlsxWorker]', err.message);
    _worker = null; _workerReady = false;
    _pending.forEach(p => p.reject(new Error(err.message)));
    _pending.clear(); _queue.length = 0;
  };

  // Fetch xlsx on main thread (no CORS issues) then send code to worker
  fetchXlsxCode()
    .then(xlsxCode => w.postMessage({ type: 'init', xlsxCode }))
    .catch(err => {
      console.error('[xlsxWorker] fetch failed:', err);
      _worker = null; _workerReady = false;
    });

  return w;
}

function getWorker(): Promise<Worker> {
  if (!_worker) _worker = initWorker();
  if (_workerReady) return Promise.resolve(_worker);
  return new Promise(resolve => { _queue.push(() => resolve(_worker!)); });
}

export function prewarmXlsxWorker(): void {
  getWorker().catch(() => {});
}

export async function parseXlsxInWorker(buffer: ArrayBuffer, isLarge: boolean): Promise<CompactSheet[]> {
  const id     = _nextId++;
  const worker = await getWorker();
  return new Promise((resolve, reject) => {
    _pending.set(id, { resolve, reject });
    worker.postMessage({ id, buffer, isLarge }, [buffer]);
  });
}

// Auto-prewarm on module load
if (typeof window !== 'undefined') {
  setTimeout(() => getWorker().catch(() => {}), 200);
}
