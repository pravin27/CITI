// ─────────────────────────────────────────────────────────────────────────────
// ImageViewer — virtual-scroll viewer for TIF/TIFF/PNG/JPEG/DOC pages
//
// Works with the new lazy-decode ImageAdapter:
//   • Placeholder divs (correct height, grey bg) for un-decoded pages
//   • IntersectionObserver fires → calls adapter.getFrameAsync(page)
//   • Frame arrives → drawImage(bitmap) onto canvas — no blocking
//   • onPageRendered callback re-triggers visible pages after decode
//   • highlight canvas overlay — single parent subscription, RAF-gated
// ─────────────────────────────────────────────────────────────────────────────

import React, { useEffect, useRef, useCallback, useState, memo } from 'react';
import { useAppStore } from '../store/appStore';
import type { ImageAdapter, ImageFrame } from '../adapters/ImageAdapter';
import { colorToRgba } from '../utils/color';

const PAGE_GAP = 12;
const RADIUS   = 2.5;
const OVERSCAN = 2;

interface ImageViewerProps { adapter: ImageAdapter; zoom: number; }

// ── Shared highlight cache ────────────────────────────────────────────────────
interface HlCache { fwc: Map<string,string>; version: number; }
const hlCache: HlCache = { fwc: new Map(), version: 0 };

function rebuildHlCache(captures: ReturnType<typeof useAppStore.getState>['captures']) {
  hlCache.fwc.clear();
  for (const cap of captures) {
    hlCache.fwc.set(cap.id, cap.value.toLowerCase().trim());
  }
  hlCache.version++;
}

function rr(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  if (w < 1 || h < 1) return;
  r = Math.min(r, w/2, h/2);
  ctx.beginPath();
  ctx.moveTo(x+r,y); ctx.lineTo(x+w-r,y); ctx.arcTo(x+w,y,x+w,y+r,r);
  ctx.lineTo(x+w,y+h-r); ctx.arcTo(x+w,y+h,x+w-r,y+h,r);
  ctx.lineTo(x+r,y+h); ctx.arcTo(x,y+h,x,y+h-r,r);
  ctx.lineTo(x,y+r); ctx.arcTo(x,y,x+r,y,r); ctx.closePath();
}

function paintHighlights(canvas: HTMLCanvasElement, pageNum: number, W: number, H: number) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  ctx.clearRect(0, 0, W, H);
  const s = useAppStore.getState();
  const rects = s.highlightIndex.get(pageNum) ?? [];
  const aid   = s.activeFieldId;
  const { fwc } = hlCache;
  const activeTxt = aid ? (fwc.get(aid) ?? '') : '';

  for (const r of s.search.results.filter(r => r.page === pageNum)) {
    const isCur = s.search.results.indexOf(r) === s.search.currentIndex;
    ctx.save();
    if (isCur) {
      ctx.fillStyle='rgba(255,140,0,.45)'; ctx.strokeStyle='rgba(255,100,0,.95)';
      ctx.lineWidth=2; ctx.shadowColor='rgba(255,140,0,.5)'; ctx.shadowBlur=6;
    } else if (s.search.highlightAll) {
      ctx.fillStyle='rgba(255,220,50,.28)'; ctx.strokeStyle='rgba(200,160,0,.65)'; ctx.lineWidth=1;
    } else { ctx.restore(); continue; }
    rr(ctx, r.x*W, r.y*H, r.width*W, r.height*H, RADIUS);
    ctx.fill(); ctx.stroke(); ctx.restore();
  }

  const capturedKeys = new Set<number>();
  for (const rect of rects) {
    capturedKeys.add(Math.round(rect.x*1000)*10000 + Math.round(rect.y*1000));
    const isAct=rect.id===aid;
    const isDup=!isAct&&!!activeTxt&&fwc.get(rect.id)===activeTxt;
    ctx.save();
    if (isAct) { ctx.shadowColor='rgba(220,180,0,.5)'; ctx.shadowBlur=8; ctx.fillStyle='rgba(255,230,0,.35)'; ctx.strokeStyle='rgb(200,160,0)'; ctx.lineWidth=2.5; }
    else if (isDup) { ctx.fillStyle='rgba(255,182,193,.40)'; ctx.strokeStyle='rgba(220,80,120,.85)'; ctx.lineWidth=2; }
    else if (rect.color) { ctx.fillStyle=colorToRgba(rect.color,.07); ctx.strokeStyle=colorToRgba(rect.color,.95); ctx.lineWidth=2.5; }
    else { ctx.fillStyle='rgba(150,150,150,.10)'; ctx.strokeStyle='rgba(80,80,80,.90)'; ctx.lineWidth=2.0; }
    const PAD = 0.002;
    const bx  = Math.max(0, rect.x - PAD),   by  = Math.max(0, rect.y - PAD);
    const bw  = Math.min(1 - bx, rect.width  + PAD*2), bh = Math.min(1 - by, rect.height + PAD*2);
    rr(ctx, bx*W, by*H, bw*W, bh*H, RADIUS);
    ctx.fill(); ctx.stroke(); ctx.restore();
  }

  // Duplicates from wordIndex — draw word occurrences matching captured values
  if (s.wordIndex.size > 0) {
    const pageEntries = s.wordIndex.get(pageNum) ?? [];
    if (aid) {
      // Non-active captures: show their word occurrences in grey/color
      for (const cap of s.captures) {
        if (cap.id === aid) continue;
        const wt = fwc.get(cap.id) ?? ''; if (!wt) continue;
        ctx.fillStyle=cap.color ? colorToRgba(cap.color,.07) : 'rgba(150,150,150,.10)';
        ctx.strokeStyle=cap.color ? colorToRgba(cap.color,.90) : 'rgba(80,80,80,.85)'; ctx.lineWidth=2.0;
        for (const e of pageEntries) {
          if (e.text.toLowerCase().trim() !== wt) continue;
          if (capturedKeys.has(Math.round(e.x*1000)*10000 + Math.round(e.y*1000))) continue;
          const wx=Math.max(0,e.x-0.0015), wy=Math.max(0,e.y-0.0015);
          const ww=Math.min(1-wx,e.width+0.003), wh=Math.min(1-wy,e.height+0.003);
          rr(ctx, wx*W, wy*H, ww*W, wh*H, RADIUS); ctx.fill(); ctx.stroke();
        }
      }
      // Active capture: show pink duplicates
      if (activeTxt) {
        ctx.fillStyle='rgba(255,182,193,.40)'; ctx.strokeStyle='rgba(220,80,120,.80)'; ctx.lineWidth=1.5;
        for (const e of pageEntries) {
          if (e.text.toLowerCase().trim() !== activeTxt) continue;
          if (capturedKeys.has(Math.round(e.x*1000)*10000 + Math.round(e.y*1000))) continue;
          const wx=Math.max(0,e.x-0.0015), wy=Math.max(0,e.y-0.0015);
          const ww=Math.min(1-wx,e.width+0.003), wh=Math.min(1-wy,e.height+0.003);
          rr(ctx, wx*W, wy*H, ww*W, wh*H, RADIUS); ctx.fill(); ctx.stroke();
        }
      }
    } else {
      // No active field — show all word occurrences in their group colour
      for (const cap of s.captures) {
        const wt = fwc.get(cap.id) ?? ''; if (!wt) continue;
        ctx.fillStyle=cap.color ? colorToRgba(cap.color,.07) : 'rgba(150,150,150,.10)';
        ctx.strokeStyle=cap.color ? colorToRgba(cap.color,.90) : 'rgba(80,80,80,.85)'; ctx.lineWidth=2.0;
        for (const e of pageEntries) {
          if (e.text.toLowerCase().trim() !== wt) continue;
          if (capturedKeys.has(Math.round(e.x*1000)*10000 + Math.round(e.y*1000))) continue;
          const wx=Math.max(0,e.x-0.0015), wy=Math.max(0,e.y-0.0015);
          const ww=Math.min(1-wx,e.width+0.003), wh=Math.min(1-wy,e.height+0.003);
          rr(ctx, wx*W, wy*H, ww*W, wh*H, RADIUS); ctx.fill(); ctx.stroke();
        }
      }
    }
  }

  if (s.previewRect?.page === pageNum) {
    ctx.save(); ctx.fillStyle='rgba(6,182,212,.15)'; ctx.strokeStyle='rgba(6,182,212,.9)';
    ctx.lineWidth=2; ctx.shadowColor='rgba(6,182,212,.5)'; ctx.shadowBlur=6;
    rr(ctx, s.previewRect.x*W, s.previewRect.y*H, s.previewRect.width*W, s.previewRect.height*H, RADIUS);
    ctx.fill(); ctx.stroke(); ctx.restore();
  }
}

// ── Main viewer ───────────────────────────────────────────────────────────────
export function ImageViewer({ adapter, zoom }: ImageViewerProps) {
  const setCurrentPage = useAppStore(s => s.setCurrentPage);
  const rotation       = useAppStore(s => s.rotation);
  const pageCount      = adapter.pageCount;
  const containerRef   = useRef<HTMLDivElement>(null);

  // Pages currently within viewport + overscan
  const [visiblePages, setVisiblePages] = useState<Set<number>>(() => new Set([1, 2]));
  const visibleRef = useRef<Set<number>>(new Set([1, 2]));

  // highlight canvas refs keyed by page
  const hlRefs = useRef<Map<number, HTMLCanvasElement>>(new Map());

  useEffect(() => {
    if (containerRef.current) containerRef.current.setAttribute('data-viewer-scroll', '1');
  }, []);

  // ── IntersectionObserver — track visible pages ─────────────────────────────
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    const pageVis = new Map<number, number>();

    const obs = new IntersectionObserver(entries => {
      for (const e of entries) {
        const page = Number((e.target as HTMLElement).dataset.pageNumber);
        if (e.isIntersecting) pageVis.set(page, e.intersectionRatio);
        else                  pageVis.delete(page);
      }
      const visible = new Set<number>();
      const sorted  = [...pageVis.keys()].sort((a, b) => a - b);
      if (sorted.length) {
        const first = sorted[0], last = sorted[sorted.length - 1];
        for (let p = Math.max(1, first - OVERSCAN); p <= Math.min(pageCount, last + OVERSCAN); p++) visible.add(p);
        let best = sorted[0], bestR = 0;
        for (const [pg, r] of pageVis) if (r > bestR) { best = pg; bestR = r; }
        setCurrentPage(best);
      }
      const prev = visibleRef.current;
      if (visible.size !== prev.size || [...visible].some(p => !prev.has(p))) {
        visibleRef.current = visible;
        setVisiblePages(new Set(visible));
      }
    }, { root: container, threshold: [0, 0.1, 0.5] });

    container.querySelectorAll<HTMLElement>('[data-page-number]').forEach(el => obs.observe(el));
    return () => obs.disconnect();
  }, [pageCount, setCurrentPage]);

  // ── RAF-gated highlight redraws ────────────────────────────────────────────
  const rafRef = useRef(0);
  const redrawVisible = useCallback(() => {
    cancelAnimationFrame(rafRef.current);
    rafRef.current = requestAnimationFrame(() => {
      for (const page of visibleRef.current) {
        const hl = hlRefs.current.get(page);
        if (hl && hl.width && hl.height) paintHighlights(hl, page, hl.width, hl.height);
      }
    });
  }, []);

  useEffect(() => {
    const unsub = useAppStore.subscribe((n, p) => {
      if (n.captures !== p.captures || n.highlightIndex !== p.highlightIndex)
        rebuildHlCache(n.captures);
      if (n.captures !== p.captures || n.activeFieldId !== p.activeFieldId ||
          n.highlightIndex !== p.highlightIndex || n.wordIndex !== p.wordIndex ||
          n.previewRect !== p.previewRect || n.search.results !== p.search.results ||
          n.search.currentIndex !== p.search.currentIndex || n.search.highlightAll !== p.search.highlightAll) {
        redrawVisible();
      }
    });
    rebuildHlCache(useAppStore.getState().captures);
    return () => { unsub(); cancelAnimationFrame(rafRef.current); };
  }, [redrawVisible]);

  // Re-render visible pages when a background decode completes
  useEffect(() => {
    const cb = (page: number) => {
      if (visibleRef.current.has(page)) {
        // Force React to re-render that specific page by updating visiblePages
        setVisiblePages(s => new Set(s));
      }
    };
    adapter.onPageRendered(cb);
    return () => adapter.offPageRendered(cb);
  }, [adapter]);

  return (
    <div ref={containerRef} className="flex-1 overflow-y-auto overflow-x-auto bg-[#e8e8e8]">
      <div className="flex flex-col items-center py-4">
        {Array.from({ length: pageCount }, (_, i) => i + 1).map(page => (
          <ImagePageCanvas
            key={page}
            pageNum={page}
            adapter={adapter}
            zoom={zoom}
            rotation={rotation}
            visible={visiblePages.has(page)}
            hlRefs={hlRefs}
            onHlReady={redrawVisible}
          />
        ))}
      </div>
    </div>
  );
}

// ── Per-page canvas ───────────────────────────────────────────────────────────
interface ImagePageCanvasProps {
  pageNum:   number;
  adapter:   ImageAdapter;
  zoom:      number;
  rotation:  number;
  visible:   boolean;
  hlRefs:    React.MutableRefObject<Map<number, HTMLCanvasElement>>;
  onHlReady: () => void;
}

const ImagePageCanvas = memo(function ImagePageCanvas({
  pageNum, adapter, zoom, rotation, visible, hlRefs, onHlReady,
}: ImagePageCanvasProps) {
  const wrapperRef  = useRef<HTMLDivElement>(null);
  const canvasRef   = useRef<HTMLCanvasElement>(null);
  const hlCanvasRef = useRef<HTMLCanvasElement>(null);

  // Frame may be null if not yet decoded — getFrame() kicks off async decode
  const [frame, setFrame] = useState<ImageFrame | null>(() =>
    visible ? adapter.getFrame(pageNum) : null
  );

  const dims   = adapter.getPageDimensions(pageNum);
  const isFlipped = rotation === 90 || rotation === 270;
  const baseW  = dims ? (isFlipped ? dims.height : dims.width)  : 0;
  const baseH  = dims ? (isFlipped ? dims.width  : dims.height) : 0;
  const displayW = Math.round(baseW * zoom);
  const displayH = Math.round(baseH * zoom);

  // Register with adapter for coordinate mapping
  useEffect(() => {
    adapter.registerPageElement(pageNum, wrapperRef.current);
    return () => adapter.registerPageElement(pageNum, null);
  }, [adapter, pageNum]);

  // Register hl canvas ref with parent
  useEffect(() => {
    const hl = hlCanvasRef.current;
    if (hl) { hlRefs.current.set(pageNum, hl); return () => { hlRefs.current.delete(pageNum); }; }
  }, [pageNum, hlRefs]);

  // When page becomes visible — request frame (may be instant cache hit or async)
  useEffect(() => {
    if (!visible) return;
    const cached = adapter.getFrame(pageNum);
    if (cached) { setFrame(cached); return; }
    // Not yet decoded — getFrame kicked off async decode; result arrives via onPageRendered
    adapter.getFrameAsync(pageNum).then(f => setFrame(f)).catch(() => {});
  }, [visible, adapter, pageNum]);

  // Draw image onto canvas when frame + visibility ready
  useEffect(() => {
    if (!visible || !frame) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.width  = displayW;
    canvas.height = displayH;
    const ctx = canvas.getContext('2d')!;
    ctx.clearRect(0, 0, displayW, displayH);
    ctx.save();
    ctx.translate(displayW / 2, displayH / 2);
    ctx.rotate((rotation * Math.PI) / 180);
    // drawImage(ImageBitmap) — GPU-accelerated, sub-millisecond
    ctx.drawImage(frame.bitmap,
      -(frame.width * zoom) / 2, -(frame.height * zoom) / 2,
      frame.width * zoom, frame.height * zoom,
    );
    ctx.restore();
    adapter.notifyPageRendered(pageNum);
  }, [frame, zoom, rotation, adapter, pageNum, visible, displayW, displayH]);

  // Size hl canvas and trigger redraw when visible
  useEffect(() => {
    const hl = hlCanvasRef.current;
    if (!hl || !visible) return;
    hl.width  = displayW;
    hl.height = displayH;
    onHlReady();
  }, [displayW, displayH, visible, onHlReady]);

  return (
    <div
      ref={wrapperRef}
      data-page-number={pageNum}
      className="relative shadow-md"
      style={{
        marginBottom: PAGE_GAP,
        width:   displayW || 800,
        height:  displayH || 1100,
        background: (visible && frame) ? 'transparent' : '#d0d0d0',
        flexShrink: 0,
      }}
    >
      {/* Loading indicator — shown while decode is in-flight */}
      {visible && !frame && displayW > 0 && (
        <div style={{
          position: 'absolute', inset: 0, display: 'flex',
          alignItems: 'center', justifyContent: 'center',
          color: '#888', fontSize: 11,
        }}>
          <div style={{
            width: 20, height: 20, border: '2px solid #bbb',
            borderTopColor: '#1a7fd4', borderRadius: '50%',
            animation: 'spin 0.7s linear infinite',
          }} />
        </div>
      )}
      {visible && frame && (
        <>
          <canvas ref={canvasRef} style={{ width: displayW, height: displayH, display: 'block' }} />
          <canvas
            ref={hlCanvasRef}
            width={displayW} height={displayH}
            style={{ position: 'absolute', inset: 0, width: displayW, height: displayH, pointerEvents: 'none', zIndex: 11 }}
          />
        </>
      )}
      {/* Placeholder when not visible — keeps scroll height correct */}
      {!visible && <canvas ref={canvasRef} style={{ display: 'none' }} />}
    </div>
  );
});
