// ─────────────────────────────────────────────────────────────────────────────
// PDFPerfToast.jsx
//
// A floating performance label that appears above the PDF viewer after each
// timed operation, showing how long it took. Auto-dismisses after 3 seconds.
// Shows a mini history bar of last 5 operations.
//
// Props:
//   latest      {PerfEntry|null}   — the most recent entry from usePDFPerf
//   entries     {PerfEntry[]}      — all entries from usePDFPerf
//   position    "top-left" | "top-right" | "top-center"  (default "top-center")
//   autoHideMs  {number}           — ms before toast hides (default 3000)
//
// Usage:
//   <PDFPerfToast latest={perf.latest} entries={perf.entries} />
// ─────────────────────────────────────────────────────────────────────────────

import { useState, useEffect, useRef } from "react";

// ─── Op metadata (label + colour) ────────────────────────────────────────────
const OP_META = {
  load:     { label: "PDF Loaded",       color: "#4ade80", bg: "rgba(74,222,128,0.12)",  icon: "📄" },
  navigate: { label: "Page Navigated",   color: "#4f8ef7", bg: "rgba(79,142,247,0.12)", icon: "↗" },
  jump:     { label: "Jumped to Page",   color: "#4f8ef7", bg: "rgba(79,142,247,0.12)", icon: "⤵" },
  prev:     { label: "Previous Page",    color: "#a78bfa", bg: "rgba(167,139,250,0.12)",icon: "‹" },
  next:     { label: "Next Page",        color: "#a78bfa", bg: "rgba(167,139,250,0.12)",icon: "›" },
  zoom:     { label: "Zoom Applied",     color: "#facc15", bg: "rgba(250,204,21,0.12)", icon: "⊕" },
};

const DEFAULT_META = { label: "Operation", color: "#8896b3", bg: "rgba(136,150,179,0.12)", icon: "⏱" };

function getMeta(op) { return OP_META[op] ?? DEFAULT_META; }

// ─── Format duration ─────────────────────────────────────────────────────────
function fmt(ms) {
  if (ms >= 1000) return `${(ms / 1000).toFixed(2)} s`;
  return `${Math.round(ms)} ms`;
}

// ─── Speed rating ─────────────────────────────────────────────────────────────
function rating(ms) {
  if (ms <  300) return { label: "Fast",   color: "#4ade80" };
  if (ms <  800) return { label: "Good",   color: "#facc15" };
  if (ms < 2000) return { label: "Slow",   color: "#fb923c" };
  return               { label: "Very slow", color: "#f87171" };
}

// ─── Mini sparkbar for history ────────────────────────────────────────────────
function SparkBar({ entries }) {
  const last5 = entries.slice(-5);
  if (last5.length < 2) return null;
  const max = Math.max(...last5.map(e => e.durationMs));
  return (
    <div style={{ display: "flex", alignItems: "flex-end", gap: 3, height: 20 }}>
      {last5.map((e, i) => {
        const h   = Math.max(3, Math.round((e.durationMs / max) * 20));
        const m   = getMeta(e.op);
        const isLast = i === last5.length - 1;
        return (
          <div
            key={e.id}
            title={`${getMeta(e.op).label}: ${fmt(e.durationMs)}`}
            style={{
              width: 8, height: h,
              borderRadius: 2,
              background: isLast ? m.color : "rgba(255,255,255,0.2)",
              transition: "height 0.3s ease",
              flexShrink: 0,
            }}
          />
        );
      })}
    </div>
  );
}

// ─── Main toast component ─────────────────────────────────────────────────────
export function PDFPerfToast({
  latest,
  entries    = [],
  position   = "top-center",
  autoHideMs = 3000,
}) {
  const [visible,  setVisible]  = useState(false);
  const [animIn,   setAnimIn]   = useState(false);
  const [displayed, setDisplayed] = useState(null);
  const hideTimer  = useRef(null);
  const prevId     = useRef(null);

  // Show toast whenever a new entry arrives
  useEffect(() => {
    if (!latest || latest.id === prevId.current) return;
    prevId.current = latest.id;

    // Clear any pending hide
    clearTimeout(hideTimer.current);

    setDisplayed(latest);
    setVisible(true);

    // Trigger enter animation on next tick
    requestAnimationFrame(() => setAnimIn(true));

    // Auto-hide after autoHideMs
    hideTimer.current = setTimeout(() => {
      setAnimIn(false);
      setTimeout(() => setVisible(false), 350); // wait for exit anim
    }, autoHideMs);

    return () => clearTimeout(hideTimer.current);
  }, [latest, autoHideMs]);

  if (!visible || !displayed) return null;

  const meta  = getMeta(displayed.op);
  const speed = rating(displayed.durationMs);

  // Position styles
  const posStyle = {
    "top-center": { top: 12, left: "50%", transform: animIn ? "translateX(-50%) translateY(0)" : "translateX(-50%) translateY(-20px)" },
    "top-left":   { top: 12, left: 12,    transform: animIn ? "translateY(0)" : "translateY(-20px)" },
    "top-right":  { top: 12, right: 12,   transform: animIn ? "translateY(0)" : "translateY(-20px)" },
  }[position] ?? {};

  return (
    <div
      style={{
        position:   "absolute",
        zIndex:     1000,
        pointerEvents: "none",
        ...posStyle,
        opacity:    animIn ? 1 : 0,
        transition: "opacity 0.3s ease, transform 0.3s cubic-bezier(0.34,1.56,0.64,1)",
      }}
    >
      <div style={{
        display:       "flex",
        alignItems:    "center",
        gap:           10,
        background:    "rgba(13,17,23,0.92)",
        border:        `1px solid ${meta.color}40`,
        borderLeft:    `3px solid ${meta.color}`,
        borderRadius:  8,
        padding:       "8px 14px 8px 10px",
        backdropFilter:"blur(12px)",
        boxShadow:     `0 4px 24px rgba(0,0,0,0.4), 0 0 0 1px ${meta.color}18`,
        fontFamily:    "'IBM Plex Mono', 'Fira Code', monospace",
        minWidth:      220,
        maxWidth:      340,
      }}>

        {/* Icon */}
        <span style={{ fontSize: 18, lineHeight: 1, flexShrink: 0 }}>
          {meta.icon}
        </span>

        {/* Main content */}
        <div style={{ flex: 1, minWidth: 0 }}>
          {/* Op label + speed rating */}
          <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 2 }}>
            <span style={{ fontSize: 11, color: "#8896b3", letterSpacing: 0.4 }}>
              {meta.label.toUpperCase()}
            </span>
            <span style={{
              fontSize: 9, fontWeight: 700,
              color: speed.color,
              background: `${speed.color}18`,
              border: `1px solid ${speed.color}40`,
              borderRadius: 3,
              padding: "1px 5px",
              letterSpacing: 0.3,
            }}>
              {speed.label.toUpperCase()}
            </span>
          </div>

          {/* Duration — big number */}
          <div style={{ display: "flex", alignItems: "baseline", gap: 6 }}>
            <span style={{
              fontSize: 22, fontWeight: 700,
              color: meta.color,
              lineHeight: 1,
              letterSpacing: -0.5,
            }}>
              {fmt(displayed.durationMs)}
            </span>

            {/* Page info if available */}
            {displayed.page && (
              <span style={{ fontSize: 11, color: "#505d7a" }}>
                p.{displayed.page}
                {displayed.numPages ? `/${displayed.numPages}` : ""}
              </span>
            )}
            {displayed.scale && displayed.op === "zoom" && (
              <span style={{ fontSize: 11, color: "#505d7a" }}>
                {Math.round(displayed.scale * 100)}%
              </span>
            )}
          </div>
        </div>

        {/* Sparkbar history */}
        <div style={{ flexShrink: 0 }}>
          <SparkBar entries={entries} />
        </div>
      </div>

      {/* Progress bar — shows countdown until hide */}
      <div style={{
        position: "absolute",
        bottom: 0, left: 3, right: 0,
        height: 2,
        borderRadius: "0 0 8px 8px",
        overflow: "hidden",
      }}>
        <div style={{
          height: "100%",
          background: meta.color,
          borderRadius: 2,
          animation: `perfToastProgress ${autoHideMs}ms linear forwards`,
        }} />
      </div>

      <style>{`
        @keyframes perfToastProgress {
          from { width: 100%; opacity: 1; }
          to   { width: 0%;   opacity: 0.4; }
        }
      `}</style>
    </div>
  );
}

export default PDFPerfToast;
