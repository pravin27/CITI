# PDF Performance Timing — Integration Guide

Two files to drop into your project:
- `usePDFPerf.js`    — the timing hook (pure logic, no UI)
- `PDFPerfToast.jsx` — the floating badge label (plug in anywhere)

---

## File structure

```
src/
  pdf-perf/
    usePDFPerf.js       ← timing hook
    PDFPerfToast.jsx    ← toast UI badge
  YourPDFViewer.jsx     ← your existing viewer
```

---

## Step-by-step integration

### STEP 1 — Import both files into your viewer component

```jsx
// YourPDFViewer.jsx
import { usePDFPerf }    from './pdf-perf/usePDFPerf';
import { PDFPerfToast }  from './pdf-perf/PDFPerfToast';
```

---

### STEP 2 — Initialise the hook inside your component

Add this near the top of your component, alongside your other state:

```jsx
export default function YourPDFViewer() {
  // ... your existing state ...

  const perf = usePDFPerf({
    logToConsole: true,   // ← remove in production
    autoHideMs:   3000,   // ← how long toast stays visible
  });

  // rest of component
}
```

---

### STEP 3 — Wrap the viewer container with position:relative

The toast positions itself absolutely, so its nearest positioned parent
must be the viewer container:

```jsx
{/* BEFORE */}
<div style={{ flex: 1, overflow: "hidden" }}>
  {/* PDF viewer */}
</div>

{/* AFTER */}
<div style={{ flex: 1, overflow: "hidden", position: "relative" }}>
  <PDFPerfToast
    latest={perf.latest}
    entries={perf.entries}
    position="top-center"   // "top-left" | "top-center" | "top-right"
    autoHideMs={3000}
  />
  {/* PDF viewer */}
</div>
```

---

### STEP 4 — Capture PDF LOAD time

Fire `startTiming("load")` when the user picks / drops a file.
Fire `endTiming("load", ...)` inside the page's render-complete callback.

**If you use react-pdf `<Document>` + `<Page>`:**
```jsx
// When file is selected
const handleFileChange = (file) => {
  perf.startTiming("load", { fileName: file.name });   // ← ADD THIS
  setPdfFile(URL.createObjectURL(file));
};

// Inside <Page> — fires when canvas is fully painted
<Page
  pageNumber={1}
  onRenderSuccess={() => {
    perf.endTiming("load", { page: 1, numPages });     // ← ADD THIS
  }}
/>
```

**If you use direct pdfjs (canvas rendering) like this project:**
```jsx
// When file is selected
const loadFile = (f) => {
  perf.startTiming("load", { fileName: f.name });      // ← ADD THIS
  setPdfFile(URL.createObjectURL(f));
};

// Inside PDFPage render effect, after await task.promise:
await task.promise;
// canvas is painted here ↓
perf.endTiming("load", { page: pageNum, numPages });   // ← ADD THIS
setStatus("ready");
```

---

### STEP 5 — Capture ZOOM change time

Fire `startTiming("zoom")` when scale changes.
Fire `endTiming("zoom")` when the page finishes re-rendering.

```jsx
// Where you handle zoom (zoomIn / zoomOut / dropdown change):
const zoomIn = () => {
  perf.startTiming("zoom", { scale: scale + 0.2 });    // ← ADD THIS
  setScale(s => Math.min(+(s + 0.2).toFixed(1), 4));
};

const zoomOut = () => {
  perf.startTiming("zoom", { scale: scale - 0.2 });    // ← ADD THIS
  setScale(s => Math.max(+(s - 0.2).toFixed(1), 0.4));
};

// Inside your zoom dropdown onChange:
const handleZoomChange = (newScale) => {
  perf.startTiming("zoom", { scale: newScale });       // ← ADD THIS
  setScale(newScale);
};

// In onRenderSuccess / after canvas render:
perf.endTiming("zoom", { page: pageNum, scale });      // ← ADD THIS
```

> NOTE: Because zoom re-renders the same page, the endTiming("zoom") call
> sits in the same place as endTiming("load"). Use a flag or check which
> timer is currently active:
>
> ```jsx
> // Simple guard — only end the timer that was started
> if (perf.isTimerActive("zoom")) {
>   perf.endTiming("zoom", { page: pageNum, scale });
> } else if (perf.isTimerActive("load")) {
>   perf.endTiming("load", { page: pageNum });
> } else {
>   perf.endTiming("navigate", { page: pageNum });
> }
> ```
>
> Or use the combined helper (see STEP 8).

---

### STEP 6 — Capture PREV / NEXT / JUMP navigation time

```jsx
// Prev page button
const handlePrev = () => {
  perf.startTiming("prev", { fromPage: currentPage });  // ← ADD THIS
  jump(currentPage - 1);
};

// Next page button
const handleNext = () => {
  perf.startTiming("next", { fromPage: currentPage });  // ← ADD THIS
  jump(currentPage + 1);
};

// Jump to page input
const handleJump = (pg) => {
  perf.startTiming("jump", { fromPage: currentPage, toPage: pg }); // ← ADD
  jump(pg);
};
```

Then in your page render-complete callback, end whichever navigate timer
is active:

```jsx
// After canvas render / onRenderSuccess:
perf.endTiming("prev",     { page: pageNum }) ||
perf.endTiming("next",     { page: pageNum }) ||
perf.endTiming("jump",     { page: pageNum }) ||
perf.endTiming("navigate", { page: pageNum });
// endTiming returns null when no timer is running, so only the active one fires
```

---

### STEP 7 — Combined render-complete handler (recommended pattern)

Instead of spreading endTiming calls everywhere, create one handler and
call it from every render-complete point:

```jsx
// Add this to your component:
const onPageRendered = useCallback((pageNum) => {
  // End whichever operation timer is currently running
  // endTiming() returns null if that op has no active timer → safe to chain
  const entry =
    perf.endTiming("load",     { page: pageNum, numPages }) ??
    perf.endTiming("zoom",     { page: pageNum, scale    }) ??
    perf.endTiming("jump",     { page: pageNum           }) ??
    perf.endTiming("prev",     { page: pageNum           }) ??
    perf.endTiming("next",     { page: pageNum           }) ??
    perf.endTiming("navigate", { page: pageNum           });

  // entry is null if no timer was running (e.g. page re-rendered due to
  // component update with no user action) — that's fine, just ignore it
}, [perf, numPages, scale]);
```

Wire it up:

```jsx
// react-pdf <Page>:
<Page
  pageNumber={pageNum}
  onRenderSuccess={() => onPageRendered(pageNum)}
/>

// Direct pdfjs (this project):
// Inside PDFPage useEffect, after await task.promise:
await task.promise;
onPageReady?.(pageNum);        // existing call
onPageRendered(pageNum);       // ← ADD THIS
```

---

### STEP 8 — isTimerActive helper

Add this utility to usePDFPerf.js or use inline:

```jsx
// Check if a specific timer is running right now:
const isTimerActive = (op) => !!timers.current[op];

// Or just check any timer:
const hasActiveTimer = Object.keys(timers.current).length > 0;
```

It's already exposed from the hook — just destructure it:
```jsx
const { startTiming, endTiming, isTimerActive, latest, entries } = usePDFPerf();
```

---

### STEP 9 — Full wiring example (minimal, complete)

```jsx
import { usePDFPerf }   from './pdf-perf/usePDFPerf';
import { PDFPerfToast } from './pdf-perf/PDFPerfToast';

export default function MyPDFViewer() {
  const [pdfFile, setPdfFile] = useState(null);
  const [scale,   setScale]   = useState(1.2);
  const [page,    setPage]    = useState(1);
  const [total,   setTotal]   = useState(0);

  const perf = usePDFPerf({ logToConsole: true });

  // STEP 4 — load
  const openFile = (file) => {
    perf.startTiming("load", { fileName: file.name });
    setPdfFile(URL.createObjectURL(file));
  };

  // STEP 5 — zoom
  const handleZoomIn = () => {
    perf.startTiming("zoom");
    setScale(s => Math.min(s + 0.2, 4));
  };

  // STEP 6 — navigation
  const handlePrev = () => { perf.startTiming("prev"); setPage(p => p - 1); };
  const handleNext = () => { perf.startTiming("next"); setPage(p => p + 1); };
  const handleJump = (n) => { perf.startTiming("jump"); setPage(n); };

  // STEP 7 — combined render-complete
  const onRendered = (pageNum) => {
    perf.endTiming("load",  { page: pageNum, numPages: total }) ??
    perf.endTiming("zoom",  { page: pageNum, scale           }) ??
    perf.endTiming("jump",  { page: pageNum                  }) ??
    perf.endTiming("prev",  { page: pageNum                  }) ??
    perf.endTiming("next",  { page: pageNum                  });
  };

  return (
    // STEP 3 — position:relative wrapper
    <div style={{ position: "relative", flex: 1 }}>
      <PDFPerfToast
        latest={perf.latest}
        entries={perf.entries}
        position="top-center"
      />

      {/* Your PDF viewer here */}
      <Document file={pdfFile} onLoadSuccess={d => setTotal(d.numPages)}>
        <Page
          pageNumber={page}
          scale={scale}
          onRenderSuccess={() => onRendered(page)}  // ← STEP 7
        />
      </Document>
    </div>
  );
}
```

---

## What the toast shows

```
┌─────────────────────────────────────────┐
│ 📄  PDF LOADED          ████ FAST       │
│     1.23 s    p.1/96          ▂▄▆█▆     │
│─────────────────────────────────────────│  ← progress bar (countdown)
└─────────────────────────────────────────┘
```

| Field | Source |
|---|---|
| Icon | Op type (📄 load, ↗ navigate, ⊕ zoom…) |
| Label | Op name uppercase |
| Speed badge | < 300ms = Fast · < 800ms = Good · < 2s = Slow |
| Big number | Duration in ms or seconds |
| `p.1/96` | Page and total pages |
| `%` | Scale (zoom ops only) |
| Sparkbars | Last 5 operation durations, scaled to tallest |
| Progress bar | Countdown to auto-dismiss |

---

## Accessing data programmatically

```jsx
// Latest single entry
perf.latest
// { op: "load", durationMs: 1230, page: 1, numPages: 96, isoTime: "..." }

// All entries
perf.entries
// Array of PerfEntry objects, newest last

// Aggregated stats per operation
perf.summary
// {
//   load:     { count:1, avgMs:1230, minMs:1230, maxMs:1230, p50Ms:1230, p90Ms:1230 },
//   navigate: { count:5, avgMs:280,  minMs:190,  maxMs:410,  p50Ms:265,  p90Ms:380  },
//   zoom:     { count:3, avgMs:340,  minMs:290,  maxMs:430,  p50Ms:300,  p90Ms:420  },
// }

// Send to analytics
perf.entries.forEach(e => analytics.track("pdf_perf", e));

// Export to JSON
const blob = new Blob([JSON.stringify(perf.entries, null, 2)]);
```
