// ─────────────────────────────────────────────────────────────────────────────
// usePDFPerf.js  —  Standalone PDF performance timing hook
//
// Captures render durations for:
//   • Initial PDF load  (file open → first page canvas painted)
//   • Page navigation   (jump / prev / next → target page painted)
//   • Zoom change       (scale change → page re-render complete)
//
// Works with: react-pdf <Page onRenderSuccess> OR direct pdfjs canvas rendering
//
// Usage:
//   import { usePDFPerf } from './usePDFPerf';
//
//   const perf = usePDFPerf({ onEntry: (entry) => console.log(entry) });
//
//   // When user opens a file:
//   perf.startTiming("load");
//
//   // When page finishes rendering (inside onRenderSuccess or after page.render()):
//   perf.endTiming("load", { page: 1, numPages: 100 });
//
//   // Access all entries:
//   perf.entries   // array of PerfEntry objects
//   perf.latest    // most recent entry
//   perf.summary   // aggregated stats per operation type
// ─────────────────────────────────────────────────────────────────────────────

import { useState, useRef, useCallback } from "react";

// ─── Types (JSDoc for IDE autocomplete without TypeScript) ───────────────────
/**
 * @typedef {"load" | "navigate" | "zoom" | "prev" | "next" | "jump"} PerfOp
 *
 * @typedef {Object} PerfEntry
 * @property {string}   id          - Unique entry id  (op-timestamp)
 * @property {PerfOp}   op          - Operation type
 * @property {number}   startMs     - performance.now() at operation start
 * @property {number}   endMs       - performance.now() at operation end
 * @property {number}   durationMs  - endMs - startMs  (rounded to 2dp)
 * @property {number}   [page]      - Target page number
 * @property {number}   [numPages]  - Total pages in document
 * @property {number}   [scale]     - Zoom scale at time of entry
 * @property {string}   [fileName]  - PDF file name if provided
 * @property {string}   isoTime     - ISO timestamp of entry completion
 * @property {Object}   [extra]     - Any extra metadata passed to endTiming()
 */

// ─── Helpers ─────────────────────────────────────────────────────────────────
const now = () =>
  typeof performance !== "undefined" ? performance.now() : Date.now();

const round2 = (n) => Math.round(n * 100) / 100;

function makeEntry(op, startMs, endMs, meta = {}) {
  return {
    id:         `${op}-${Date.now()}`,
    op,
    startMs:    round2(startMs),
    endMs:      round2(endMs),
    durationMs: round2(endMs - startMs),
    isoTime:    new Date().toISOString(),
    ...meta,
  };
}

// ─── Summary calculator ───────────────────────────────────────────────────────
export function calcPerfSummary(entries) {
  if (!entries.length) return {};

  const byOp = entries.reduce((acc, e) => {
    if (!acc[e.op]) acc[e.op] = [];
    acc[e.op].push(e.durationMs);
    return acc;
  }, {});

  const result = {};
  for (const [op, durations] of Object.entries(byOp)) {
    const sorted = [...durations].sort((a, b) => a - b);
    const sum    = durations.reduce((s, d) => s + d, 0);
    result[op] = {
      count:   durations.length,
      avgMs:   round2(sum / durations.length),
      minMs:   sorted[0],
      maxMs:   sorted[sorted.length - 1],
      p50Ms:   sorted[Math.floor(sorted.length * 0.5)],
      p90Ms:   sorted[Math.floor(sorted.length * 0.9)],
      totalMs: round2(sum),
    };
  }
  return result;
}

// ─── Main hook ────────────────────────────────────────────────────────────────
/**
 * @param {Object}   [options]
 * @param {function} [options.onEntry]     - Called with each PerfEntry when endTiming fires
 * @param {number}   [options.maxEntries]  - Max entries to keep in memory (default 200)
 * @param {boolean}  [options.logToConsole]- Log each entry to console (default false)
 */
export function usePDFPerf(options = {}) {
  const {
    onEntry       = null,
    maxEntries    = 200,
    logToConsole  = false,
  } = options;

  // Map of  op → startMs  (only one in-flight timer per op type at a time)
  const timers = useRef({});

  const [entries, setEntries]   = useState(/** @type {PerfEntry[]} */ ([]));
  const [latest,  setLatest]    = useState(/** @type {PerfEntry|null} */ (null));

  // ── startTiming(op, meta?) ──────────────────────────────────────────────
  /**
   * Call this BEFORE the operation begins.
   * @param {PerfOp}  op    - Operation identifier
   * @param {Object}  [meta]- Optional metadata stored on the future entry
   */
  const startTiming = useCallback((op, meta = {}) => {
    timers.current[op] = { t: now(), meta };
  }, []);

  // ── endTiming(op, meta?) ────────────────────────────────────────────────
  /**
   * Call this AFTER the operation completes (e.g. inside onRenderSuccess).
   * @param {PerfOp}  op    - Must match the op passed to startTiming
   * @param {Object}  [meta]- Additional metadata (page, scale, fileName…)
   * @returns {PerfEntry|null}
   */
  const endTiming = useCallback((op, meta = {}) => {
    const start = timers.current[op];
    if (!start) {
      if (logToConsole) console.warn(`[usePDFPerf] endTiming("${op}") called with no matching startTiming`);
      return null;
    }

    const entry = makeEntry(op, start.t, now(), { ...start.meta, ...meta });
    delete timers.current[op];

    if (logToConsole) {
      console.log(
        `%c[PDFPerf] ${entry.op.toUpperCase()} — ${entry.durationMs} ms`,
        "color:#4f8ef7;font-weight:600",
        entry
      );
    }

    onEntry?.(entry);

    setEntries(prev => {
      const next = [...prev, entry];
      return next.length > maxEntries ? next.slice(-maxEntries) : next;
    });
    setLatest(entry);

    return entry;
  }, [onEntry, maxEntries, logToConsole]);

  // ── cancelTiming(op) ────────────────────────────────────────────────────
  /**
   * Discard a timer without recording an entry (e.g. navigation cancelled).
   * @param {PerfOp} op
   */
  const cancelTiming = useCallback((op) => {
    delete timers.current[op];
  }, []);

  // ── isTimerActive(op) ────────────────────────────────────────────────────
  /**
   * Returns true if a startTiming(op) call is pending with no matching end.
   * Useful in render callbacks to decide which endTiming() to call.
   * @param {PerfOp} op
   * @returns {boolean}
   */
  const isTimerActive = useCallback((op) => {
    return !!timers.current[op];
  }, []);

  // ── hasActiveTimer ───────────────────────────────────────────────────────
  /** True if ANY timer is currently running */
  const hasActiveTimer = Object.keys(timers.current).length > 0;

  // ── clearEntries() ──────────────────────────────────────────────────────
  const clearEntries = useCallback(() => {
    setEntries([]);
    setLatest(null);
  }, []);

  // ── summary (derived) ───────────────────────────────────────────────────
  const summary = calcPerfSummary(entries);

  return {
    // Actions
    startTiming,
    endTiming,
    cancelTiming,
    isTimerActive,
    clearEntries,
    // State
    entries,
    latest,
    summary,
    hasActiveTimer,
  };
}

export default usePDFPerf;
