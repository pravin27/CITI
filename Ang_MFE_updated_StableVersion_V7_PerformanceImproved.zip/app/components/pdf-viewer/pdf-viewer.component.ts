import {
  Component,
  OnInit,
  AfterViewInit,
  OnDestroy,
  Input,
  Output,
  EventEmitter,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  NgZone,
  effect,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  NgxExtendedPdfViewerModule,
  PagesLoadedEvent,
  PageRenderedEvent,
} from 'ngx-extended-pdf-viewer';
import { PdfCaptureService } from '../../services/pdf-capture.service';
import { HighlightRect } from '../../models/pdf-capture.models';
import { Subject, fromEvent } from 'rxjs';
import { takeUntil, debounceTime } from 'rxjs/operators';

export interface CapturedWordPayload {
  text: string;
  page: number;
  x: number; y: number;
  width: number; height: number;
}

@Component({
  selector: 'app-pdf-viewer',
  standalone: true,
  imports: [CommonModule, FormsModule, NgxExtendedPdfViewerModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="viewer-host">

      <!-- The viewer — no [customToolbar], toolbar stays native and working -->
      <ngx-extended-pdf-viewer
        [src]="src"
        [height]="'100%'"
        [showToolbar]="true"
        [textLayer]="true"
        [showOpenFileButton]="true"
        [showPrintButton]="false"
        [showPresentationModeButton]="false"
        [showSidebarButton]="true"
        [showFindButton]="true"
        [zoom]="'page-width'"
        [sidebarVisible]="false"
        [(page)]="currentPage"
        (pagesLoaded)="onPagesLoaded($event)"
        (pageRendered)="onPageRendered($event)"
        (pdfLoaded)="onPdfLoaded()"
        (srcChange)="onSrcChange($event)"
        (thumbnailDrawn)="onThumbnailDrawn($event)"
      ></ngx-extended-pdf-viewer>

      <!-- SVG rubber-band overlay is injected directly into #viewerContainer
           by injectRubberbandOverlay() so it never covers the toolbar -->
    </div>
  `,
  styles: [`
    :host {
      display: flex;
      flex-direction: column;
      height: 100%;
    }

    .viewer-host {
      flex: 1;
      position: relative;
      overflow: hidden;
    }

    /* ── Single Capture Mode button ── */
    ::ng-deep #btn-capture-mode {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      height: 26px;
      padding: 0 10px;
      margin: 0 6px;
      border: 1.5px solid rgba(0,0,0,0.22);
      border-radius: 5px;
      background: var(--toolbar-bg, #f0f0f0);
      color: var(--toolbar-icon-fg-color, #404040);
      font-size: 11.5px;
      font-family: inherit;
      font-weight: 600;
      cursor: pointer;
      white-space: nowrap;
      vertical-align: middle;
      flex-shrink: 0;
      transition: background 0.15s, color 0.15s, border-color 0.15s;
      outline: none;
    }

    ::ng-deep #btn-capture-mode svg {
      width: 13px;
      height: 13px;
      flex-shrink: 0;
      opacity: 0.7;
      transition: opacity 0.15s;
    }

    ::ng-deep #btn-capture-mode:hover {
      background: rgba(0,0,0,0.08);
      border-color: rgba(0,0,0,0.35);
    }

    /* Active state — teal/green, clearly ON */
    ::ng-deep #btn-capture-mode.capture-active {
      background: #0a84ff;
      border-color: #0a84ff;
      color: #fff;
    }
    ::ng-deep #btn-capture-mode.capture-active svg { opacity: 1; }
    ::ng-deep #btn-capture-mode.capture-active:hover { background: #0070e0; }

    /* ── Capture mode cursor — content area only, not scrollbar ── */
    ::ng-deep #viewerContainer.box-mode-active { cursor: crosshair !important; }
    /* The scrollbar is outside clientWidth/Height so it gets the default cursor
       automatically — no extra CSS needed, the OS renders the scrollbar cursor */

    /* Live drag canvas — full-viewport fixed overlay, pointer-events:none */
    ::ng-deep #rband-canvas {
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      pointer-events: none !important;
      z-index: 99999 !important;
    }

    /* ── Text layer spans — hover highlight in capture mode ── */
    ::ng-deep .textLayer span:hover {
      background: rgba(0,0,0,0.05) !important;
      border-radius: 1px;
      cursor: pointer;
    }

    /* ── During box drag: disable pointer-events on ALL text spans ── */
    /* This prevents spans from stealing pointermove/pointerup during drag, */
    /* ensuring the rubber band draws smoothly and setPointerCapture works. */
    ::ng-deep body.tov-dragging .textLayer span {
      pointer-events: none !important;
      user-select: none !important;
    }

    /* ── JSON word spans injected from word index ── */
    ::ng-deep .textLayer span[data-json-word] {
      color: transparent !important;
      background: transparent !important;
      cursor: text;
      position: absolute;
      white-space: nowrap;
      overflow: hidden;
      user-select: text;
      -webkit-user-select: text;
      pointer-events: auto;
    }
    ::ng-deep .textLayer span[data-json-word]:hover {
      background: rgba(0,120,255,0.08) !important;
      cursor: pointer;
    }
  `],
})
export class PdfViewerComponent implements OnInit, AfterViewInit, OnDestroy {
  @Input() src: string | Uint8Array = '';
  /** When true, Box Mode activates automatically as soon as the viewer is ready.
   *  Set this before the PDF loads so JSON text layer injection fires on first render. */
  @Input() captureOnLoad = false;
  @Output() wordCaptured    = new EventEmitter<CapturedWordPayload>();
  @Output() boxCaptured     = new EventEmitter<CapturedWordPayload>();
  @Output() pdfNameChange   = new EventEmitter<string>();
  @Output() thumbnailDrawn  = new EventEmitter<{ pageNumber: number; thumbnail: HTMLElement }>();

  // ── Precision Word Index ─────────────────────────────────────────────────
  // Replaces caretRangeFromPoint with exact JSON coordinates for all capture
  // operations (click2pick, dblclick, box-select).
  //
  // PERFORMANCE DESIGN for 200-page × 2000-word documents (400K words):
  //
  // Problem: building a sorted Map for 400K words takes ~318ms synchronously
  //          and occupies ~46MB RAM for a file the user may never capture from.
  //
  // Solution — LAZY per-page sort:
  //   _wordIndexRaw:  Map<page, unsorted raw array>  ← stored on JSON load (0ms sort)
  //   _wordIndex:     Map<page, sorted array>         ← built on FIRST ACCESS to that page
  //
  // Cost per page sort: ~1.6ms for 2000 words — imperceptible.
  // Only pages the user actually visits get sorted. A 200-page document
  // where the user only works on pages 1-5 sorts 5 pages (8ms total), not 200 (318ms).
  //
  // Memory: raw arrays are plain objects ~120 bytes/word.
  // For 400K words: ~46MB. Acceptable (Chrome tab budget: 2-4GB).
  // If memory is a concern, use per-page JSON files instead (see docs).

  private _wordIndexRaw = new Map<number, Array<{t:string;x:number;y:number;w:number;h:number}>>();
  private _wordIndex    = new Map<number, Array<{t:string;x:number;y:number;w:number;h:number}>>();
  // No duplicate index cache — LAYER 3 queries getDuplicatesForPage() directly.
  // Simple, stateless, always correct. Cost: O(words/page) per draw, ~0.1ms.

  /** Called from app component when a word index JSON is available.
   *  Stores raw (unsorted) per-page arrays — O(1) per page, no sort cost.
   *  Sorting is deferred to first page access (lazy). */
  public loadWordIndex(data: {version:number; pages: Record<string,Array<{t:string;x:number;y:number;w:number;h:number}>>} | null): void {
    this._wordIndexRaw.clear();
    this._wordIndex.clear();
    this._layer3Cache.clear();
    // Refresh active field snapshot so PASS B always has current data
    this._activeFieldWt = this.captureService.activeWordText() ?? '';
    this._activeFieldId = this.captureService.activeFieldId()  ?? '';
    // Don't clear _rgbaCache — colors don't change between redraws,
    // keeping resolved rgba values across field changes is safe.
    this._pageElCache.clear();
    this._spansCache.clear();
    this._regexCache.clear();
    this._injectedPages.clear();
    if (!data?.pages) {
      // No word index data — if capture is active, ensure listeners are set up
      // for all rendered pages using library text layer (no JSON injection).
      if (this.captureActive) {
        for (const pageNum of this.renderedPages) {
          this.activatePageCapture(pageNum);
        }
      }
      return;
    }
    for (const [pageStr, words] of Object.entries(data.pages)) {
      this._wordIndexRaw.set(Number(pageStr), words);
    }
    this._rebuildLayer3Cache();

    if (this.captureActive) {
      const pages = Array.from(this.renderedPages);
      requestAnimationFrame(() => {
        for (const pageNum of pages) this.activatePageCapture(pageNum);
        this.scheduleRedraw();
      });
    }
    // captureActive=false case: spans will be injected when Box Mode turns ON
    // via activateCaptureMode → activatePageCapture → _injectWordIndexTextLayer
  }

  /** Get the sorted word array for a page — sorts lazily on first access. */
  private getPageWords(pageNum: number): Array<{t:string;x:number;y:number;w:number;h:number}> | null {
    // Return already-sorted if available
    if (this._wordIndex.has(pageNum)) return this._wordIndex.get(pageNum)!;
    // Sort the raw array for this page only — ~1.6ms for 2000 words
    const raw = this._wordIndexRaw.get(pageNum);
    if (!raw) return null;
    const sorted = raw.slice().sort((a, b) => a.y !== b.y ? a.y - b.y : a.x - b.x);
    this._wordIndex.set(pageNum, sorted);  // cache for subsequent accesses
    return sorted;
  }

  /**
   * Hit-test the word index for a given fractional point (fx, fy) on a page.
   * Returns the word whose bbox contains the point, or the nearest word
   * within a tolerance (handles small gaps between words).
   * O(n) per page — fast for 700-900 words per page.
   */
  /**
   * Hit-test the external coords index (PATH 0).
   * Returns exact JSON coordinate entry if click is WITHIN or NEAR a coord bbox.
   * Returns null if no coord is close — allows fallthrough to PATH A/B.
  /**
   * Hit-test the word index for a click at fractional coords (fx, fy).
   *
   * Three passes — ordered by precision:
   *   Pass 1: exact bbox containment (fx,fy inside word rect)
   *   Pass 2: expanded bbox (word height tolerance for gaps between lines)
   *   Pass 3: nearest word on the same line (for clicks between words)
   *
   * When the word index is loaded, this ALWAYS returns a word — it never
   * returns null for a click inside the text area. This prevents PATH B
   * (caretRangeFromPoint) from running and capturing wrong punctuation.
   */
  private hitTestWordIndex(fx: number, fy: number, pageNum: number): {t:string;x:number;y:number;w:number;h:number} | null {
    const words = this.getPageWords(pageNum);
    if (!words?.length) return null;

    // Pass 1: exact bbox hit
    for (const w of words) {
      if (fx >= w.x && fx <= w.x + w.w && fy >= w.y && fy <= w.y + w.h) return w;
    }

    // Pass 2: same line (within 1 line-height vertically), nearest horizontally
    // Typical line height ~0.02 of page. Expand Y by half line height each side.
    let best: typeof words[0] | null = null;
    let bestDx = Infinity;

    for (const w of words) {
      const wMidY = w.y + w.h / 2;
      const wMidX = w.x + w.w / 2;
      // Must be on same line: fy within [w.y - h, w.y + 2h]
      if (fy < w.y - w.h || fy > w.y + w.h * 2) continue;
      // Horizontal distance from click to word center
      const dx = Math.abs(fx - wMidX);
      if (dx < bestDx) { bestDx = dx; best = w; }
    }
    if (best) return best;

    // Pass 3: absolute nearest word anywhere on page (last resort for edge clicks)
    let bestDist = Infinity;
    for (const w of words) {
      const cx = w.x + w.w / 2;
      const cy = w.y + w.h / 2;
      const dist = (fx - cx) * (fx - cx) + (fy - cy) * (fy - cy);
      if (dist < bestDist) { bestDist = dist; best = w; }
    }
    return best;
  }

  /** Get or compile a word-boundary RegExp for a given word (cached). */
  private _getRegex(wordText: string): RegExp {
    let re = this._regexCache.get(wordText);
    if (!re) {
      const escaped = wordText.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      // Use \b word-boundary anchors — exact whole-word match only.
      // "the" will NOT match "them", "other", "together", "there".
      // \b works correctly for ASCII word chars (\w = [a-zA-Z0-9_]).
      re = new RegExp('\\b' + escaped + '\\b', 'gi');
      this._regexCache.set(wordText, re);
    }
    return re;
  }

  /** Get page element + canvas + fresh BCR (no cache — BCR changes on scroll). */
  private _getPageRef(pageNum: number): {pageEl:HTMLElement;canvas:HTMLCanvasElement;bcr:DOMRect} | null {
    // Cache pageEl and canvas element refs (DOM nodes don't move), but always
    // fetch BCR fresh — it changes on every scroll tick and must be accurate.
    const cached = this._pageElCache.get(pageNum);
    let pageEl: HTMLElement | null = cached?.pageEl ?? null;
    let canvas:  HTMLCanvasElement | null = cached?.canvas ?? null;

    if (!pageEl || !canvas) {
      pageEl = document.querySelector(`.page[data-page-number="${pageNum}"]`) as HTMLElement | null;
      canvas = pageEl?.querySelector('canvas') as HTMLCanvasElement | null;
      if (!pageEl || !canvas) return null;
      // Cache element refs only (not BCR)
      this._pageElCache.set(pageNum, { pageEl, canvas, bcr: new DOMRect(), bcrTs: 0 });
    }

    const bcr = canvas.getBoundingClientRect();
    if (bcr.width === 0) return null;
    return { pageEl, canvas, bcr };
  }

  /** Get cached text-layer spans for a page — invalidated on injection, not by TTL. */
  private _getSpans(pageNum: number, pageEl: HTMLElement): HTMLElement[] {
    const ver = this._spansCacheVer.get(pageNum) ?? -1;
    if (ver === this._spansCachePageVer && this._spansCache.has(pageNum)) {
      return this._spansCache.get(pageNum)!;
    }
    const spans = Array.from(pageEl.querySelectorAll('.textLayer span')) as HTMLElement[];
    this._spansCache.set(pageNum, spans);
    this._spansCacheVer.set(pageNum, this._spansCachePageVer);
    return spans;
  }

  /**
   * Rebuild the LAYER 3 result cache.
   * Called when fields change or word index loads — NOT per frame.
   * For word-index mode: O(pages × words). For DOM mode: deferred to draw time.
   * Uses a change-detection key to skip the O(pages×words) rebuild when only
   * the active field changes — making active field switching essentially free.
   */
  private _rebuildLayer3Cache(): void {
    const fields = this.captureService.fields();

    // Stable key: sorted id:value:color — detects adds/removes/recolors but NOT active change
    const newKey = fields.length === 0 ? '' : fields
      .filter(f => f.value)
      .map(f => `${f.id}:${f.value}:${f.color ?? ''}`)
      .sort().join('|');

    // Always refresh active field snapshot (cheap — signal reads are O(1))
    this._activeFieldWt = this.captureService.activeWordText() ?? '';
    this._activeFieldId = this.captureService.activeFieldId()  ?? '';

    if (newKey === this._layer3FieldsKey) {
      // Fields didn't change — only active field switched.
      // Re-derive color group cache (O(n) but cheap) to exclude new activeId.
      this._rebuildColorGroupCache(fields);
      return;
    }
    this._layer3FieldsKey = newKey;
    this._layer3Cache.clear();

    if (this._wordIndexRaw.size) {
      // Word-index mode: pre-compute all occurrence rects per page per word — O(pages×words)
      const capturedWords = new Set<string>();
      for (const f of fields) {
        if (f.value) capturedWords.add(f.value.toLowerCase().replace(/^[^\w]+|[^\w]+$/g, '').trim());
      }
      if (capturedWords.size) {
        for (const [pageNum, words] of this._wordIndexRaw) {
          const pageMap = new Map<string, Array<{x:number;y:number;w:number;h:number}>>();
          for (const w of words) {
            const lower = w.t.toLowerCase();
            if (!capturedWords.has(lower)) continue;
            let arr = pageMap.get(lower);
            if (!arr) { arr = []; pageMap.set(lower, arr); }
            arr.push({ x: w.x, y: w.y, w: w.w, h: w.h });
          }
          if (pageMap.size) this._layer3Cache.set(pageNum, pageMap);
        }
      }
    }

    // Rebuild per-field word text cache (cleaned, lowercased)
    this._fieldWordCache.clear();
    for (const f of fields) {
      if (!f.value) continue;
      const wt = f.value.toLowerCase().replace(/^[^\w]+|[^\w]+$/g, '').trim();
      if (wt) this._fieldWordCache.set(f.id, wt);
    }

    this._rebuildColorGroupCache(fields);
  }

  /** Rebuild color group cache only — O(n fields), called on active field switch */
  private _rebuildColorGroupCache(fields: ReturnType<typeof this.captureService.fields>): void {
    const cgMap = new Map<string, Array<{ id: string; wt: string }>>();
    for (const f of fields) {
      const wt = this._fieldWordCache.get(f.id);
      if (!wt) continue;
      const key = f.color || '__grey__';
      if (!cgMap.has(key)) cgMap.set(key, []);
      cgMap.get(key)!.push({ id: f.id, wt });
    }
    this._colorGroupCache = Array.from(cgMap.entries()).map(([colorKey, entries]) => ({ colorKey, entries }));
  }

  /**
   * Find all occurrences of wordText in the word index for a specific page.
   * Returns fractional rects {x,y,w,h} for every matching word.
   * Used by box-select and LAYER 3 draw loop.
   * Case-insensitive match. O(n) per page.
   */
  private getDuplicatesForPage(
    pageNum: number,
    wordText: string
  ): Array<{x:number;y:number;w:number;h:number}> {
    const words = this.getPageWords(pageNum);
    if (!words?.length || !wordText) return [];
    const lower = wordText.toLowerCase();
    return words
      .filter(w => w.t.toLowerCase() === lower)
      .map(w => ({ x: w.x, y: w.y, w: w.w, h: w.h }));
  }

  /**
   * Get all words from index that overlap a fractional bbox [x1,y1,x2,y2] on a page.
   * Used by box-select to collect all words inside the drawn rectangle.
   */
  private getWordsInBox(page:number, fx1:number,fy1:number,fx2:number,fy2:number): Array<{t:string;x:number;y:number;w:number;h:number}> {
    const words = this.getPageWords(page);
    if (!words?.length) return [];
    // Use a small tolerance (0.002 = ~0.2% of page = ~1px at normal zoom)
    // so that boxes touching word edges still capture those words.
    // Core condition: rectangles intersect when neither is fully outside the other.
    const TOL = 0.002;
    return words.filter(w =>
      w.x        < fx2 + TOL &&
      w.x + w.w  > fx1 - TOL &&
      w.y        < fy2 + TOL &&
      w.y + w.h  > fy1 - TOL
    );
  }


  currentPage = 1;
  totalPages  = 0;

  boxMode    = false;
  drawingBox = false;
  boxRect    = { x: 0, y: 0, w: 0, h: 0 };
  private boxStartClient = { x: 0, y: 0 };

  // ── Preview highlight ─────────────────────────────────────────────────────
  // Temporarily shows the last clicked/box-selected region in cyan so the user
  // can see exactly what they selected, even when no input field is active.
  // Cleared automatically after 2.5s or when a new selection is made.
  private previewHighlight: {
    page: number; x: number; y: number; width: number; height: number;
  } | null = null;
  private previewTimer: ReturnType<typeof setTimeout> | null = null;
  private previewRafId: number | null = null;
  private previewPulse  = 0;   // drives the pulse animation frame counter

  private destroy$           = new Subject<void>();
  private renderedPages      = new Set<number>();
  /** Real page dimensions in PDF points, fetched from PDF.js. Key = 1-based page number. */
  private _pageDimensions    = new Map<number, { widthPt: number; heightPt: number }>();
  private textLayerListeners = new Map<number, () => void>();
  private highlightCanvases  = new Map<number, HTMLCanvasElement>();
  private rafId: number | null = null;
  private pendingPage: number | null = null;

  /**
   * captureActive — master gate for ALL capture-related work.
   * When false: zero canvas, zero listeners, zero draw overhead.
   * When true: full capture system is live.
   */
  private captureActive = false;

  // Ref to the single injected capture-mode button
  private btnCapture: HTMLButtonElement | null = null;

  constructor(
    public captureService: PdfCaptureService,
    private cdr: ChangeDetectorRef,
    private ngZone: NgZone
  ) {
    // Effect 1: Rebuild LAYER 3 cache ONLY when fields (captures) change.
    // activeWordText changes don't affect the cache — only which field is active.
    effect(() => {
      captureService.highlightIndex();  // tracks field additions/removals/coords
      this.ngZone.runOutsideAngular(() => {
        this._rebuildLayer3Cache();
        if (this.captureActive) this.scheduleRedraw();
      });
    });

    // Effect 2: Redraw when active field changes (yellow↔grey swap) — no cache rebuild.
    effect(() => {
      const wt  = captureService.activeWordText();
      const id  = captureService.activeFieldId();
      this._activeFieldWt = wt ?? '';
      this._activeFieldId = id ?? '';
      this.ngZone.runOutsideAngular(() => {
        if (this.captureActive) this.scheduleRedraw();
      });
    });

    // Keep injected button label/state in sync when signal changes externally
    effect(() => {
      const c2p = captureService.click2pickMode();
      this.syncButtonStates(c2p, this.boxMode);
    });
  }

  ngOnInit(): void {}

  ngAfterViewInit(): void {
    // Toolbar may not exist yet — retry until it appears (max 3s)
    this.tryInjectToolbar(0);

    // Auto-activate Box Mode if captureOnLoad flag is set.
    // This runs BEFORE any page renders, so when pages come in they immediately
    // get JSON spans injected (no race with the word index HTTP fetch).
    if (this.captureOnLoad) {
      // Small delay to let the toolbar inject first so button states sync correctly
      setTimeout(() => {
        if (!this.captureActive) {
          this.captureService.setClick2PickMode(true);
          this.boxMode = true;
          this.activateCaptureMode();
          this.syncButtonStates(true, true);
          this.cdr.markForCheck();
        }
      }, 50);
    }
  }

  private tryInjectToolbar(attempt: number): void {
    const toolbar = document.querySelector('#toolbarViewerRight');
    if (toolbar) {
      this.injectToolbarControls();
      this.hookNativeFileInput();
      return;
    }
    if (attempt < 30) {
      setTimeout(() => this.tryInjectToolbar(attempt + 1), 100);
    }
  }

  private _pendingFileName = '';
  // Document-level capture listener — attached ONCE, catches all file input changes
  // regardless of when PDF.js creates the input element.
  private _docFileListener: ((e: Event) => void) | null = null;

  /**
   * Attach a SINGLE document-level capture-phase listener for file input changes.
   * This fires for any <input type="file"> on the page, no matter when it was created.
   * Called once at init — never needs re-hooking.
   */
  private hookNativeFileInput(): void {
    if (this._docFileListener) return; // already attached

    this._docFileListener = (e: Event) => {
      const input = e.target as HTMLInputElement;
      // Only care about file inputs that aren't our own custom ones
      if (input.type !== 'file') return;
      if (input.classList.contains('custom-injected') || input.id === 'pdf-upload') return;

      const file = input.files?.[0];
      if (!file?.name) return;

      // Store the filename — will be emitted by emitPdfName() when pdfLoaded fires.
      // Also emit immediately in case pdfLoaded already fired (re-open same file).
      this._pendingFileName = file.name;
      this.ngZone.run(() => this.pdfNameChange.emit(file.name));
    };

    // capture:true means we intercept BEFORE the element's own handlers
    document.addEventListener('change', this._docFileListener, true);
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
    if (this.rafId !== null) cancelAnimationFrame(this.rafId);
    this.textLayerListeners.forEach((fn) => fn());
    this.removeInjectedToolbarNodes();
    this.removeRubberbandOverlay();
    if (this._pageResizeObs) { this._pageResizeObs.disconnect(); this._pageResizeObs = null; }
    if (this._textLayerObs)  { this._textLayerObs.disconnect();  this._textLayerObs  = null; }
    this._pendingTextLayerCbs.clear();
    this._viewerContainer = null;
    this._rbandCanvas     = null;
    this._wordIndexRaw.clear();
    this._wordIndex.clear();
    this._layer3Cache.clear();
    this._pageElCache.clear();
    this._spansCache.clear();
    this._regexCache.clear();
    this._injectedPages.clear();
    this._layer3Cache.clear();
    this._layer3FieldsKey = '';
    this._pageElCache.clear();
    this._spansCache.clear();
    this._regexCache.clear();
    this._pendingFileName = '';
    if (this._docFileListener) {
      document.removeEventListener('change', this._docFileListener, true);
      this._docFileListener = null;
    }
  }

  // ── Mode Toggles ──────────────────────────────────────────────────────────

  /**
   * Single capture-mode toggle.
   * ON  → both Click2Pick AND Box-draw active simultaneously.
   *       SVG overlay injected into #viewerContainer (not over toolbar).
   * OFF → both disabled, overlay removed.
   */
  private toggleCaptureMode(): void {
    const isAnyOn = this.captureService.click2pickMode() || this.boxMode;
    const turnOn  = !isAnyOn;

    this.captureService.setClick2PickMode(turnOn);
    this.boxMode = turnOn;

    if (turnOn) {
      this.activateCaptureMode();
    } else {
      this.deactivateCaptureMode();
    }

    this.syncButtonStates(turnOn, turnOn);
    this.cdr.markForCheck();
  }

  // ── Activate: first time the button is pressed ────────────────────────────
  // Wires up ResizeObserver, creates canvases, attaches listeners, draws all
  // highlights for every page that already rendered while capture was off.
  private activateCaptureMode(): void {
    this.captureActive = true;
    this.injectRubberbandOverlay();

    // Rebuild LAYER 3 cache immediately with current field state
    this._rebuildLayer3Cache();

    // Start observing all currently rendered page elements for zoom changes
    if (this._pageResizeObs) {
      document.querySelectorAll('.page[data-page-number]')
        .forEach(el => this._pageResizeObs!.observe(el));
    }

    // Activate canvas + listeners + highlights for every already-rendered page.
    // activatePageCapture calls _injectWordIndexTextLayer which will use
    // _wordIndexRaw powers the precision text layer.
    for (const pageNum of this.renderedPages) {
      this.activatePageCapture(pageNum);
    }
  }

  // ── Deactivate: tear everything down to zero overhead ──────────────────
  private deactivateCaptureMode(): void {
    this.captureActive = false;
    if (this.previewHighlight) this.clearPreviewHighlight(this.previewHighlight.page);
    this.removeRubberbandOverlay();

    if (this._pageResizeObs) this._pageResizeObs.disconnect();

    this.highlightCanvases.forEach(c => c.remove());
    this.highlightCanvases.clear();

    this.textLayerListeners.forEach(fn => fn());
    this.textLayerListeners.clear();

    if (this.rafId !== null) { cancelAnimationFrame(this.rafId); this.rafId = null; }
  }

  /** Legacy helpers — both delegate to the unified toggleCaptureMode */
  toggleClick2Pick(): void { this.toggleCaptureMode(); }
  toggleBoxMode(): void { this.toggleCaptureMode(); }

  private syncButtonStates(c2pOn: boolean, boxOn: boolean): void {
    if (this.btnCapture) {
      const active = c2pOn || boxOn;
      this.btnCapture.classList.toggle('capture-active', active);
      // Update label to show current sub-mode
      const label = this.btnCapture.querySelector('span');
      if (label) label.textContent = active ? (boxOn ? 'Box Mode ON' : 'Capture ON') : 'Capture';
    }
  }

  // ── PDF Lifecycle ─────────────────────────────────────────────────────────
  onPdfLoaded(): void {
    // ── Reset page position FIRST ─────────────────────────────────────────────
    // [(page)] two-way binding retains the previous document's page number.
    // Without this reset, opening a 7-page doc while on page 5 of a 10-page doc
    // keeps currentPage=5 and scrolls the new document to page 5 immediately.
    this.currentPage = 1;
    this.totalPages  = 0;
    this.pendingPage = null;
    if (this.previewHighlight) { this.clearPreviewHighlight(this.previewHighlight.page); }
    this.previewHighlight = null;
    this.cdr.markForCheck();

    // ── Capture mode full reset ───────────────────────────────────────────────
    // Tear down everything from the previous document.
    this.captureActive = false;
    this.boxMode       = false;
    this.captureService.setClick2PickMode(false);

    this.renderedPages.clear();
    this._pageDimensions.clear();
    this.textLayerListeners.forEach((fn) => fn());
    this.textLayerListeners.clear();
    this.highlightCanvases.forEach(c => c.remove());
    this.highlightCanvases.clear();
    if (this._pageResizeObs) { this._pageResizeObs.disconnect(); this._pageResizeObs = null; }
    if (this._textLayerObs)  { this._textLayerObs.disconnect();  this._textLayerObs  = null; }
    this._pendingTextLayerCbs.clear();
    this._viewerContainer = null;
    this._rbandCanvas     = null;
    this._wordIndexRaw.clear();
    this._wordIndex.clear();
    this._layer3Cache.clear();
    this._pageElCache.clear();
    this._spansCache.clear();
    this._regexCache.clear();
    this._injectedPages.clear();
    if (this.rafId !== null)  { cancelAnimationFrame(this.rafId); this.rafId = null; }

    // ── Re-activate immediately if captureOnLoad is set ──────────────────────
    // captureOnLoad means capture mode survives PDF changes.
    // Set flags NOW so onPageRendered fires activatePageCapture on first page.
    if (this.captureOnLoad) {
      this.captureService.setClick2PickMode(true);
      this.boxMode       = true;
      this.captureActive = true;
    }

    // Single timeout: toolbar inject + emit filename
    // NOTE: _pendingFileName is cleared AFTER emitPdfName so it's available to read
    setTimeout(() => {
      this.tryInjectToolbar(0);
      // Sync button states — reflect captureOnLoad if active
      this.syncButtonStates(this.captureActive, this.boxMode);
      this.emitPdfName();
      // Clear only after emitting so emitPdfName can use it
      this._pendingFileName = '';
    }, 300);
  }

  private emitPdfName(): void {
    // Priority 1: _pendingFileName set by the file input change event (most accurate)
    if (this._pendingFileName) {
      this.ngZone.run(() => this.pdfNameChange.emit(this._pendingFileName));
      return;
    }
    // Priority 2: #title element set by PDF.js after load
    const titleEl = document.querySelector('#title') as HTMLInputElement | null;
    const titleName = (titleEl?.value || titleEl?.placeholder || '').trim();
    if (titleName && titleName !== 'PDF.js viewer' && titleName !== 'PDF.js Express') {
      this.ngZone.run(() => this.pdfNameChange.emit(titleName));
      return;
    }
    // Priority 3: poll title a bit longer (PDF.js may not have set it yet at 300ms)
    let polls = 0;
    const poll = setInterval(() => {
      polls++;
      const el = document.querySelector('#title') as HTMLInputElement | null;
      const name = (el?.value || el?.placeholder || '').trim();
      if ((name && name !== 'PDF.js viewer' && name !== 'PDF.js Express') || polls > 10) {
        clearInterval(poll);
        if (name && name !== 'PDF.js viewer' && name !== 'PDF.js Express') {
          this.ngZone.run(() => this.pdfNameChange.emit(name));
        }
      }
    }, 200);
  }

  onPagesLoaded(event: PagesLoadedEvent): void {
    this.totalPages = event.pagesCount;
    this.cdr.markForCheck();
    // Fetch real page dimensions from PDF.js for accurate absolute-coord normalisation.
    // Runs outside Angular zone — no CD cost. Fires async after PDF.js finishes rendering.
    this._fetchPageDimensions(event.pagesCount);

    this.ngZone.runOutsideAngular(() => {
      // Cache the container once here — used by scroll listener + overlay
      const container = (document.querySelector('#viewerContainer')
                      ?? document.querySelector('.pdfViewer')) as HTMLElement | null;
      this._viewerContainer = container;

      if (container) {
        // On scroll: immediately clear BCR cache (positions changed) then redraw.
        // Without clearing, _getPageRef returns stale screen coords → wrong highlight positions.
        fromEvent(container, 'scroll')
          .pipe(takeUntil(this.destroy$))
          .subscribe(() => {
            // Clear BCR cache immediately on every scroll tick — no debounce.
            // BCR is cheap to re-fetch (one call per page per draw); stale values cause wrong boxes.
            this._pageElCache.clear();
            // Debounce the expensive redraw itself
            if (this.captureActive) {
              if (this.rafId !== null) cancelAnimationFrame(this.rafId);
              this.rafId = requestAnimationFrame(() => {
                this.renderedPages.forEach(p => this.drawHighlightsForPage(p));
                this.rafId = null;
              });
            }
          });
      }

      // ResizeObserver: created immediately, but does NOT observe any pages yet.
      // Pages are added when capture mode turns ON (activateCaptureMode).
      // The observer callback runs OUTSIDE Angular zone — only enters zone when
      // there are actual canvas updates to avoid unnecessary CD cycles.
      if (this._pageResizeObs) this._pageResizeObs.disconnect();
      this._pageResizeObs = new ResizeObserver((entries) => {
        if (!this.captureActive) return;

        // Collect affected pages outside zone (no CD cost)
        const affectedPages: number[] = [];
        for (const entry of entries) {
          const page = parseInt(
            (entry.target as HTMLElement).getAttribute('data-page-number') ?? '0', 10
          );
          if (page > 0) affectedPages.push(page);
        }
        if (!affectedPages.length) return;

        // Enter zone only once for all affected pages (single CD cycle)
        this.ngZone.run(() => {
          for (const p of affectedPages) {
            const old = this.highlightCanvases.get(p);
            if (old) { old.remove(); this.highlightCanvases.delete(p); }
            this._pageElCache.delete(p);  // BCR is stale after resize
            this._spansCache.delete(p);   // spans cache stale
            // Re-inject JSON spans with fresh px coords for new zoom level
            this._clearInjectedSpans(p);
            this._injectWordIndexTextLayer(p);
          }
          for (const p of affectedPages) {
            if (this.renderedPages.has(p)) this.drawHighlightsForPage(p);
          }
        });
      });

      // Single shared MutationObserver for text-layer readiness (all pages)
      this.initTextLayerObserver();
    });
  }

  /**
   * Fetch real page dimensions (in PDF points) from PDF.js for all pages.
   * Stores in _pageDimensions for use by absolute-coord normalisation.
   * This is the ONLY accurate source — avoids hardcoded standard page sizes.
   */
  private _fetchPageDimensions(totalPages: number): void {
    this.ngZone.runOutsideAngular(async () => {
      try {
        // window.PDFViewerApplication is the global PDF.js application instance
        // exposed by ngx-extended-pdf-viewer
        const app = (window as any)['PDFViewerApplication'];
        const pdfDoc = app?.pdfDocument ?? app?.pdfViewer?.pdfDocument;
        if (!pdfDoc) return;

        for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
          try {
            const page     = await pdfDoc.getPage(pageNum);
            const viewport = page.getViewport({ scale: 1 });
            // viewport.width/height are in PDF points at scale=1
            this._pageDimensions.set(pageNum, {
              widthPt:  viewport.width,
              heightPt: viewport.height,
            });
          } catch { /* skip individual page errors */ }
        }
      } catch { /* PDF.js not ready yet — dimensions will fall back to inference */ }
    });
  }

  /**
   * Returns real page dimensions in PDF points for a given 1-based page number.
   * Returns null if not yet fetched (PDF still loading) — caller should fall back.
   * Public so app.component can use it when normalising incoming JSON coords.
   */
  public getPageDimensionsPt(pageNum: number): { widthPt: number; heightPt: number } | null {
    return this._pageDimensions.get(pageNum) ?? null;
  }

  onThumbnailDrawn(event: any): void {
    // Log full event shape ONCE so we can see ngx 25 structure
    console.log('[THUMB-EVENT] keys:', Object.keys(event ?? {}),
      '| pageNumber:', event?.pageNumber,
      '| source.id:', event?.source?.id,
      '| div tag:', event?.div?.tagName,
      '| source.div tag:', event?.source?.div?.tagName,
      '| thumb tag:', event?.thumbnail?.tagName,
      '| source.thumbnail tag:', event?.source?.thumbnail?.tagName
    );

    // Try every known property path for ngx versions
    const thumbEl: HTMLElement | null =
      event?.div             ??   // ngx <21
      event?.source?.div     ??   // ngx 21-24
      event?.thumbnail       ??   // ngx 25+
      event?.source?.thumbnail ?? // ngx 25+ via source
      null;

    const pageNum: number =
      event?.pageNumber      ??
      event?.source?.id      ??
      event?.source?.pageNumber ??
      0;

    if (thumbEl && pageNum) {
      this.thumbnailDrawn.emit({ pageNumber: pageNum, thumbnail: thumbEl });
    } else {
      console.warn('[THUMB-EVENT] Could not resolve thumbEl or pageNum from event');
    }
  }

  onPageRendered(event: PageRenderedEvent): void {
    const pageNum = event.pageNumber;
    this.renderedPages.add(pageNum);  // always track — needed when capture turns ON

    // ── PERFORMANCE GATE ─────────────────────────────────────────────────────
    // Nothing runs until capture mode is ON.
    // Canvas, text-layer listeners, highlights, ResizeObserver — all deferred.
    // For a 1096-page document this means zero overhead while just reading.
    if (!this.captureActive) return;

    this.activatePageCapture(pageNum);
  }

  // attachDblClick removed — dblclick handled by setupTextLayerListeners when capture is ON

  /** Attach canvas + listeners + draw for a single page. Called when: 
   *  (a) capture mode turns ON (activates all already-rendered pages), or
   *  (b) a new page renders while capture mode is already ON.           */
  private activatePageCapture(pageNum: number): void {
    const old = this.highlightCanvases.get(pageNum);
    if (old) { old.remove(); this.highlightCanvases.delete(pageNum); }
    this.waitForTextLayer(pageNum, () => {
      // Inject JSON word spans BEFORE setting up listeners.
      // This ensures caretRangeFromPoint hits our spans (with JSON coords)
      // rather than PDF.js spans (with library-derived coords).
      this._injectWordIndexTextLayer(pageNum);
      this.setupTextLayerListeners(pageNum);
      this.drawHighlightsForPage(pageNum);
      if (this.pendingPage === pageNum) this.pendingPage = null;

      if (this._pageResizeObs) {
        const pageEl = document.querySelector(`.page[data-page-number="${pageNum}"]`);
        if (pageEl) this._pageResizeObs.observe(pageEl);
      }
    });
  }

  // ── Shared text-layer readiness tracker ─────────────────────────────────
  // One Map per document load: pageNum → callback to run when textLayer ready.
  // A SINGLE MutationObserver watches the entire viewer for all pages at once,
  // instead of creating one observer per page (which scales poorly at 1000 pages).
  private _pendingTextLayerCbs = new Map<number, () => void>();
  private _textLayerObs: MutationObserver | null = null;
  // Pages where we've already injected JSON word spans into the text layer
  private _injectedPages = new Set<number>();
  // Reusable skip-keys set for LAYER 3 draw loop — cleared per frame, avoids allocation.
  private _l3SkipKeys  = new Set<number>();

  private initTextLayerObserver(): void {
    if (this._textLayerObs) { this._textLayerObs.disconnect(); this._textLayerObs = null; }
    this._pendingTextLayerCbs.clear();

    const viewer = this._viewerContainer
                ?? document.querySelector('#viewerContainer') as HTMLElement | null;
    if (!viewer) return;

    this._textLayerObs = new MutationObserver((mutations) => {
      if (!this._pendingTextLayerCbs.size) return;

      for (const mutation of mutations) {
        for (const node of Array.from(mutation.addedNodes)) {
          if (!(node instanceof HTMLElement)) continue;
          // Check if this node IS a textLayer or CONTAINS one
          const candidates = node.classList?.contains('textLayer')
            ? [node]
            : Array.from(node.querySelectorAll('.textLayer'));

          for (const tl of candidates) {
            const pageEl = (tl as HTMLElement).closest('[data-page-number]') as HTMLElement | null;
            if (!pageEl) continue;
            const page = parseInt(pageEl.getAttribute('data-page-number') ?? '0', 10);
            const cb = this._pendingTextLayerCbs.get(page);
            if (cb) {
              // Fire immediately when textLayer div appears.
              // If PDF.js hasn't populated spans yet, _injectWordIndexTextLayer
              // will wait for canvas layout via rAF and works correctly.
              this._pendingTextLayerCbs.delete(page);
              cb();
            }
          }
        }
      }
    });

    viewer.addEventListener('pdf-loaded-and-pages-initialized', () => {
      if (this._textLayerObs) {
        this._textLayerObs.disconnect();
        this._textLayerObs = null;
      }
    }, { once: true });

    this._textLayerObs.observe(viewer, { childList: true, subtree: true });
  }

  /**
   * Replace PDF.js text layer with JSON word spans for a page.
   *
   * Decision:
   *   _wordIndexRaw has page → use word_index.json (high precision spans)
   *   no word index        → leave PDF.js text layer untouched
   *
   * Positioning: canvas CSS px (NOT textLayer %) — canvas is always laid out
   * before the textLayer, giving reliable clientWidth/clientHeight values.
   * Spans are placed inside .textLayer but sized/positioned from the canvas.
   *
   * Called from:
   *   activatePageCapture()   — when Box Mode turns ON or a new page renders
   *   _reinjectAllPages()     — when JSON loads after pages already rendered
   *   ResizeObserver callback — on zoom, with fresh canvas dimensions
   */
  private _injectWordIndexTextLayer(pageNum: number): void {
    const hasIdx = this._wordIndexRaw.has(pageNum);
    if (!hasIdx) {
      return;
    }

    const pageEl    = document.querySelector(`.page[data-page-number="${pageNum}"]`) as HTMLElement | null;
    const textLayer = pageEl?.querySelector('.textLayer') as HTMLElement | null;
    const canvas    = pageEl?.querySelector('canvas')    as HTMLCanvasElement | null;
    if (!pageEl || !textLayer || !canvas) return;

    const cW = canvas.clientWidth;
    const cH = canvas.clientHeight;
    if (cW === 0 || cH === 0) {
      requestAnimationFrame(() => this._injectWordIndexTextLayer(pageNum));
      return;
    }

    // ALWAYS remove all existing JSON spans before injecting new ones.
    // Do NOT rely on _injectedPages — it may have been cleared by loadWordIndex
    // or loadWordIndex while spans were still in the DOM, causing
    // a second injection to append duplicates instead of replacing.
    textLayer.querySelectorAll('[data-json-word]').forEach(s => s.remove());
    this._injectedPages.delete(pageNum);

    type W = { text: string; x: number; y: number; w: number; h: number };
    const words: W[] = (this.getPageWords(pageNum) || []).map(e => ({ text: e.t, x: e.x, y: e.y, w: e.w, h: e.h }));
    if (!words.length) return;

    const pdfJsSpans = textLayer.querySelectorAll('span:not([data-json-word])');
    pdfJsSpans.forEach(s => s.remove());

    // Store JSON coords as data-attributes on each span.
    // payloadFromClick reads these directly — no index lookup needed at click time.
    const frag = document.createDocumentFragment();
    for (const w of words) {
      const span = document.createElement('span');
      span.setAttribute('data-json-word', '1');
      span.setAttribute('data-x', w.x.toFixed(6));
      span.setAttribute('data-y', w.y.toFixed(6));
      span.setAttribute('data-w', w.w.toFixed(6));
      span.setAttribute('data-h', w.h.toFixed(6));
      span.setAttribute('data-t', w.text);
      span.textContent = w.text;
      const h = Math.max(1, w.h * cH);
      span.style.cssText =
        `position:absolute;` +
        `left:${(w.x * cW).toFixed(2)}px;` +
        `top:${(w.y  * cH).toFixed(2)}px;` +
        `width:${(w.w * cW).toFixed(2)}px;` +
        `height:${h.toFixed(2)}px;` +
        `font-size:${h.toFixed(2)}px;` +
        `line-height:1;color:transparent;background:transparent;` +
        `white-space:nowrap;overflow:hidden;display:inline-block;` +
        `pointer-events:auto;user-select:text;-webkit-user-select:text;cursor:text;`;
      frag.appendChild(span);
    }
    textLayer.appendChild(frag);
    this._injectedPages.add(pageNum);
    // Invalidate spans cache for this page — spans changed
    this._spansCachePageVer++;
    this._spansCacheVer.set(pageNum, this._spansCachePageVer);
    this._spansCache.delete(pageNum); // will be rebuilt on next draw
  }

  /** Remove JSON spans from a page's textLayer (on zoom or PDF change). */
  private _clearInjectedSpans(pageNum: number): void {
    if (!this._injectedPages.has(pageNum)) return;
    const textLayer = document
      .querySelector(`.page[data-page-number="${pageNum}"] .textLayer`);
    textLayer?.querySelectorAll('[data-json-word]').forEach(s => s.remove());
    this._injectedPages.delete(pageNum);
    // Invalidate spans cache — spans changed
    this._spansCachePageVer++;
    this._spansCache.delete(pageNum);
  }

  /**
   * Re-inject all currently rendered pages.
   * Called when: JSON loads after pages already rendered, or zoom changes.
   * O(renderedPages) — typically 3-7 pages in viewport.
   */
  private _reinjectAllPages(): void {
    for (const pageNum of this._injectedPages) {
      this._clearInjectedSpans(pageNum);
    }
    this._injectedPages.clear();
    for (const pageNum of this.renderedPages) {
      this._injectWordIndexTextLayer(pageNum);
    }
  }

  private waitForTextLayer(pageNum: number, callback: () => void): void {
    const pageEl = document.querySelector(
      `.page[data-page-number="${pageNum}"]`
    ) as HTMLElement | null;

    // If textLayer div exists in DOM (even empty or with our injected spans),
    // run immediately. The canvas is what matters — text layer is always present
    // once the page div is in the DOM for rendered pages.
    if (pageEl) {
      const tl = pageEl.querySelector('.textLayer') as HTMLElement | null;
      if (tl) { callback(); return; }
    }

    // Queue callback — shared observer will fire it when textLayer appears
    this._pendingTextLayerCbs.set(pageNum, callback);

    // Fallback: if observer missed it, poll once after 2s
    setTimeout(() => {
      if (!this._pendingTextLayerCbs.has(pageNum)) return;
      this._pendingTextLayerCbs.delete(pageNum);
      callback();
    }, 2000);
  }

  // ── Toolbar DOM Injection ─────────────────────────────────────────────────
  /**
   * Inject Click2Pick, Box Select buttons and a Page-Jump input directly
   * into #toolbarViewerRight — the native PDF.js toolbar right section.
   * This avoids [customToolbar] which requires re-declaring all sub-components
   * and breaks PDF loading in v19.
   */
  private injectToolbarControls(): void {
    const right = document.querySelector('#toolbarViewerRight') as HTMLElement;
    if (!right) return;

    this.removeInjectedToolbarNodes();

    // ── "Capture" toggle button → into toolbarViewerRight (leftmost) ─────────
    const btnCapture = document.createElement('button');
    btnCapture.id        = 'btn-capture-mode';
    btnCapture.className = 'custom-injected';
    btnCapture.title     = 'Capture Mode: single-click OR drag a box to capture words';
    btnCapture.innerHTML = `
      <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M2 1.5L2 10.5L5 8L7 12L8.8 11.2L6.8 7.2L10.5 7.2L2 1.5Z"
              stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/>
        <rect x="8.5" y="1.5" width="6" height="6" rx="0.8"
              stroke="currentColor" stroke-width="1.1" stroke-dasharray="2 1.2"/>
      </svg>
      <span>Capture</span>`;
    btnCapture.addEventListener('click', () => this.ngZone.run(() => this.toggleCaptureMode()));
    this.btnCapture = btnCapture;
    right.insertBefore(btnCapture, right.firstChild);

    // Open PDF is handled by the native [showOpenFileButton]="true" binding

    this.syncButtonStates(this.captureService.click2pickMode(), this.boxMode);
  }



  // ── Rubber-band box-select — intercepts PDF.js pan at capture phase ──────────
  /**
   * PDF.js registers its scroll/pan handler on #viewerContainer with
   * addEventListener('mousedown', handler, true) — the CAPTURE phase.
   * The only way to beat it is to also register in the capture phase and call
   * stopImmediatePropagation() so PDF.js never sees the event.
   *
   * Strategy:
   *   1. On #viewerContainer, capture-phase mousedown → stopImmediatePropagation
   *      + preventDefault + start our drag. PDF.js pan never fires.
   *   2. mousemove / mouseup bound on document (capture phase) during drag.
   *      This way fast mouse movements that leave viewerContainer still work.
   *   3. On mouseup: release document listeners, collect words, done.
   *   4. SVG overlay is visual-only (pointer-events:none) — interaction is
   *      handled entirely by the #viewerContainer capture listener.
   */
  private _vcCaptureDown:     ((e: PointerEvent) => void) | null = null;
  private _docPointerMove:    ((e: PointerEvent) => void) | null = null;
  private _docPointerUp:      ((e: PointerEvent) => void) | null = null;
  private _pageResizeObs:     ResizeObserver | null = null;
  private _lastPointerDownMs: number = 0;
  // Cached DOM refs — set once, reused everywhere to avoid repeated querySelector
  private _viewerContainer:   HTMLElement | null = null;
  private _rbandCanvas:       HTMLCanvasElement | null = null;
  private _lastWordEmitMs:    number = 0;   // dedupe guard — prevents double-emit within 150ms

  // ── Performance caches for the draw loop ──────────────────────────────────
  // All rebuilt when field data changes — NEVER rebuilt per animation frame.

  // Per-page cached refs: Map<pageNum, {pageEl, canvas, bcr}>
  // Invalidated when zoom changes (ResizeObserver) or new page renders.
  private _pageElCache = new Map<number, {
    pageEl: HTMLElement;
    canvas: HTMLCanvasElement;
    bcr: DOMRect;
    bcrTs: number;        // timestamp of last BCR fetch — stale after 500ms
  }>();

  // Per-word compiled RegExp cache — compiled once, reused across all frames.
  // Key: lowercase word text. Value: RegExp with word-boundary lookbehind/ahead.
  private _regexCache = new Map<string, RegExp>();

  // Per-page span array cache — rebuilt after injection or text layer change.
  // Key: pageNum. Value: HTMLElement[] — invalidated on injection/zoom.
  private _spansCache = new Map<number, HTMLElement[]>();
  private _spansCacheVer = new Map<number, number>(); // version per page
  private _spansCachePageVer = 0; // global version bump on any injection

  // LAYER 3 result cache: Map<pageNum, Map<wordText, DupRect[]>>
  // Rebuilt only when word index or captured fields change — NOT per frame.
  // Key: pageNum → wordText → array of {x,y,w,h} fractional rects.
  private _layer3Cache    = new Map<number, Map<string, Array<{x:number;y:number;w:number;h:number}>>>();
  // Pre-computed per-field word text (lowercased, punctuation stripped) — rebuilt with layer3 cache
  private _fieldWordCache = new Map<string, string>();   // fieldId → cleaned word text
  // Pre-computed color groups for PASS A — rebuilt with layer3 cache, not per draw
  // colorKey → list of {fieldId, wt} pairs
  private _colorGroupCache: Array<{ colorKey: string; entries: Array<{ id: string; wt: string }> }> = [];
  // Color → rgba string cache for _colorToRgba — avoids offscreen canvas per draw
  private _rgbaCache = new Map<string, string>();        // 'color:alpha' → rgba string
  // Active field word text snapshot — updated when active field changes (not per draw)
  private _activeFieldWt: string = '';
  private _activeFieldId: string = '';
  private _layer3FieldsKey = '';  // tracks which fields are captured

  private injectRubberbandOverlay(): void {
    this.removeRubberbandOverlay();

    // Try both possible container selectors — ngx v25 may use a different id
    // Use cached ref from onPagesLoaded; fall back to querySelector once if needed
    const vc = (this._viewerContainer
             ?? document.querySelector('#viewerContainer')
             ?? document.querySelector('.pdfViewer')) as HTMLElement | null;
    if (!vc) return;
    this._viewerContainer = vc;  // cache for next time

    vc.classList.add('box-mode-active');

    // ── PDF.js 4.x (ngx v25) uses POINTER EVENTS for pan/scroll ─────────────
    // Intercepting 'mousedown' no longer beats PDF.js — it switched to
    // 'pointerdown'. We intercept 'pointerdown' in capture phase and call
    // setPointerCapture() so all subsequent move/up events are routed to us
    // exclusively, bypassing PDF.js entirely.
    this._vcCaptureDown = (e: PointerEvent) => {
      if (!this.captureActive || !this.boxMode) return;
      if (e.button !== 0 || e.pointerType === 'touch') return;

      // Scrollbar hit-test — let native scrollbar work
      const vcEl = e.currentTarget as HTMLElement;
      const vcRect = vcEl.getBoundingClientRect();
      if (e.clientX > vcRect.left + vcEl.clientWidth)  return;
      if (e.clientY > vcRect.top  + vcEl.clientHeight) return;

      // ── Double-click guard ──────────────────────────────────────────────────
      const now = Date.now();
      const msSinceLast = now - this._lastPointerDownMs;
      this._lastPointerDownMs = now;
      if (msSinceLast < 300) return;   // second tap of dblclick — let dblclick fire
      // ───────────────────────────────────────────────────────────────────────

      // Stop PDF.js from starting its pan/scroll on this pointerdown.
      // We always intercept — whether the user is about to click (click2pick)
      // or drag (box-select). We decide which at pointerup based on distance.
      e.preventDefault();
      e.stopImmediatePropagation();

      this.ngZone.run(() => this._startDrag(e, vcEl));
    };

    vc.addEventListener('pointerdown', this._vcCaptureDown, true);

    const rc = document.createElement('canvas');
    rc.id     = 'rband-canvas';
    rc.width  = window.innerWidth;
    rc.height = window.innerHeight;
    document.body.appendChild(rc);
    this._rbandCanvas = rc;

    const resizeHandler = () => {
      if (this._rbandCanvas) {
        this._rbandCanvas.width  = window.innerWidth;
        this._rbandCanvas.height = window.innerHeight;
      }
    };
    window.addEventListener('resize', resizeHandler);
    (this as any)._rbandResizeHandler = resizeHandler;
  }

  private _startDrag(e: PointerEvent | MouseEvent, vc: HTMLElement): void {
    if (!this.boxMode) return;
    this.drawingBox = true;

    this.boxStartClient = { x: e.clientX, y: e.clientY };
    this.boxRect = { x: e.clientX, y: e.clientY, w: 0, h: 0 };
    this.updateRubberbandRect();

    // setPointerCapture routes ALL pointer events to vc regardless of mouse position.
    // This keeps the rubber-band drawing even when mouse leaves the viewer area.
    try {
      vc.setPointerCapture((e as PointerEvent).pointerId);
      console.log('[BOX] setPointerCapture ok, pointerId=' + (e as PointerEvent).pointerId);
    } catch { /* ignore */ }

    // Disable text-layer pointer events during drag so spans don't intercept
    document.body.classList.add('tov-dragging');

    this._docPointerMove = (ev: PointerEvent) => {
      ev.preventDefault();
      ev.stopImmediatePropagation();
      const w = Math.abs(ev.clientX - this.boxStartClient.x);
      const h = Math.abs(ev.clientY - this.boxStartClient.y);
      this.boxRect = {
        x: Math.min(ev.clientX, this.boxStartClient.x),
        y: Math.min(ev.clientY, this.boxStartClient.y),
        w, h,
      };
      this.updateRubberbandRect();
    };

    this._docPointerUp = (ev: PointerEvent) => {
      ev.preventDefault();
      document.removeEventListener('pointermove', this._docPointerMove!, true);
      document.removeEventListener('pointerup',   this._docPointerUp!,   true);
      try { vc.releasePointerCapture((ev as PointerEvent).pointerId); } catch { /* ignore */ }
      this._docPointerMove = null;
      this._docPointerUp   = null;

      // Re-enable text-layer pointer events
      document.body.classList.remove('tov-dragging');

      this.ngZone.run(() => {
        this.drawingBox = false;
        const dx = this.boxRect.w;
        const dy = this.boxRect.h;

        if (dx > 5 && dy > 5) {
          // ── Real drag: box-select ────────────────────────────────────────
              const selL = this.boxRect.x;
          const selT = this.boxRect.y;
          this.collectWordsInBox(selL, selT, selL + dx, selT + dy);
          // Block the natural click that fires after pointerup on small movements
          this._lastWordEmitMs = Date.now();
        }
        // ── Small movement: do nothing ─────────────────────────────────────
        // The browser fires its own natural click event after pointerup.
        // stopImmediatePropagation on pointerdown only blocked other pointerdown
        // listeners (PDF.js scroll) — it does NOT cancel the browser's click.
        // So the natural click reaches textLayer → clickHandler → one capture.
        // No synthetic click needed — dispatching one would cause double-capture.

        this.boxRect = { x: 0, y: 0, w: 0, h: 0 };
        this.updateRubberbandRect();
      });
    };

    // Register on document — with setPointerCapture, all pointer events
    // bubble up from vc through document, so document capture phase fires.
    document.addEventListener('pointermove', this._docPointerMove!, true);
    document.addEventListener('pointerup',   this._docPointerUp!,   true);
  }

  private removeRubberbandOverlay(): void {
    // Always clean up drag state class when overlay is removed
    document.body.classList.remove('tov-dragging');
    if (this._docPointerMove) {
      document.removeEventListener('pointermove', this._docPointerMove, true);
      this._docPointerMove = null;
    }
    if (this._docPointerUp) {
      document.removeEventListener('pointerup', this._docPointerUp, true);
      this._docPointerUp = null;
    }

    const vc = (this._viewerContainer
             ?? document.querySelector('#viewerContainer')
             ?? document.querySelector('.pdfViewer')) as HTMLElement | null;
    if (vc) {
      if (this._vcCaptureDown) {
        vc.removeEventListener('pointerdown', this._vcCaptureDown as any, true);
        this._vcCaptureDown = null;
      }
      vc.classList.remove('box-mode-active');
    }

    if (this._rbandCanvas) { this._rbandCanvas.remove(); this._rbandCanvas = null; }
    else { const c = document.querySelector('#rband-canvas'); if (c) c.remove(); }

    const rh = (this as any)._rbandResizeHandler;
    if (rh) { window.removeEventListener('resize', rh); (this as any)._rbandResizeHandler = null; }
  }

  /** Draw (or clear) the live rubber-band rect on the full-viewport canvas */
  private updateRubberbandRect(): void {
    const canvas = this._rbandCanvas ?? document.querySelector('#rband-canvas') as HTMLCanvasElement | null;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Always clear first
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    if (!this.drawingBox || this.boxRect.w < 2 || this.boxRect.h < 2) return;

    const { x, y, w, h } = this.boxRect;

    // Fill
    ctx.fillStyle = 'rgba(10, 132, 255, 0.10)';
    ctx.fillRect(x, y, w, h);

    // Solid border
    ctx.strokeStyle = '#0a84ff';
    ctx.lineWidth = 2;
    ctx.setLineDash([]);
    ctx.strokeRect(x, y, w, h);

    // Dashed inner border for marching-ants effect
    ctx.strokeStyle = 'rgba(255,255,255,0.8)';
    ctx.lineWidth = 1;
    ctx.setLineDash([6, 4]);
    ctx.lineDashOffset = -(Date.now() / 60) % 10;  // animate
    ctx.strokeRect(x + 1, y + 1, w - 2, h - 2);
    ctx.setLineDash([]);

    // Corner handles for visual clarity
    ctx.fillStyle = '#0a84ff';
    const hs = 5;
    [[x,y],[x+w,y],[x,y+h],[x+w,y+h]].forEach(([cx,cy]) => {
      ctx.fillRect((cx as number)-hs/2, (cy as number)-hs/2, hs, hs);
    });

    // Schedule next frame while still drawing (marching ants animation)
    if (this.drawingBox) {
      requestAnimationFrame(() => this.updateRubberbandRect());
    }
  }

  private removeInjectedToolbarNodes(): void {
    document.querySelectorAll('.custom-injected').forEach((el) => el.remove());
    this.btnCapture = null;
  }

  // ── Public API ────────────────────────────────────────────────────────────
  public navigateToPage(page: number): void {
    this.currentPage = Math.max(1, Math.min(this.totalPages || 9999, page));
    this.pendingPage = this.currentPage;
    this.cdr.markForCheck();
  }

  public scrollToPage(page: number): void { this.navigateToPage(page); }

  /** Fired by [(srcChange)] when the user opens a file via the native toolbar button */
  onSrcChange(newSrc: string | Uint8Array): void {
    // Reset rendered-page tracking so highlights redraw correctly on the new doc
    this.renderedPages.clear();
    this.highlightCanvases.clear();
  }

  public clearBoxSelections(): void {
    this.scheduleRedraw();
  }

  // drawPreviewDirect removed — preview only runs when captureActive=true

  public scheduleRedraw(): void {
    if (!this.captureActive) return;
    if (this.rafId !== null) cancelAnimationFrame(this.rafId);
    this.rafId = requestAnimationFrame(() => {
      // Remove stale canvas refs for virtualised pages before drawing
      for (const [p, c] of this.highlightCanvases) {
        if (!c.isConnected) {
          this.highlightCanvases.delete(p);
          this._pageElCache.delete(p);
        }
      }
      this.renderedPages.forEach((p) => this.drawHighlightsForPage(p));
      this.rafId = null;
    });
  }

  /**
   * Show a temporary cyan preview highlight for the given payload rect.
   * Pulses for 2.5s then fades out automatically.
   * Called from click2pick and box-select BEFORE emitting to the parent,
   * so the highlight is visible even if no field is active to capture it.
   */
  private setPreviewHighlight(p: CapturedWordPayload): void {
    // Cancel previous timer + animation
    if (this.previewTimer)  { clearTimeout(this.previewTimer);     this.previewTimer  = null; }
    if (this.previewRafId)  { cancelAnimationFrame(this.previewRafId); this.previewRafId = null; }

    this.previewHighlight = { page: p.page, x: p.x, y: p.y, width: p.width, height: p.height };
    this.previewPulse     = 0;

    // Immediately draw on the correct page
    this.drawHighlightsForPage(p.page);

    // Start pulse animation loop
    const animate = () => {
      this.previewPulse++;
      this.drawHighlightsForPage(p.page);
      // Run for ~2.5s at 60fps = 150 frames, then clear
      if (this.previewPulse < 150) {
        this.previewRafId = requestAnimationFrame(animate);
      } else {
        this.clearPreviewHighlight(p.page);
      }
    };
    this.previewRafId = requestAnimationFrame(animate);

    // Auto-clear after 2.5s UNLESS a pending capture is staged for this page.
    // If pending: preview stays until user confirms or discards.
    this.previewTimer = setTimeout(() => {
      const pending = this.captureService.pendingCapture();
      if (pending) {
        // Pending capture exists — keep animation running, extend by another 2.5s
        this.previewTimer = setTimeout(() => this.clearPreviewHighlight(p.page), 2500);
      } else {
        this.clearPreviewHighlight(p.page);
      }
    }, 2500);
  }

  private clearPreviewHighlight(page: number): void {
    if (this.previewTimer)  { clearTimeout(this.previewTimer);         this.previewTimer  = null; }
    if (this.previewRafId)  { cancelAnimationFrame(this.previewRafId); this.previewRafId = null; }
    this.previewHighlight = null;
    this.previewPulse     = 0;
    // Redraw ALL pages — not just the preview page — so LAYER 3 duplicates
    // on other pages are drawn correctly after the animation ends.
    this.scheduleRedraw();
  }

  // ── Word Splitting — DISABLED ──────────────────────────────────────────────
  // PDF.js text spans often have CSS transforms (scaleX) applied for fonts with
  // matrix transforms (e.g. Identity-H CID fonts at 0.75 scale).
  // Pre-splitting spans into word sub-spans breaks because our injected elements
  // don't correctly inherit the transform, making getBoundingClientRect() return
  // wrong positions for the sub-spans.
  //
  // Instead we keep PDF.js's original spans intact and use caretRangeFromPoint()
  // at click/drag time to find the exact word under the cursor.
  // This delegates word boundary detection to the browser, which handles all
  // transforms correctly.
  private splitTextLayerIntoWords(_pageNum: number): void {
    // No-op — original spans preserved for transform-safe capture
  }

  private makeWordSpan(_text: string, _src: HTMLElement): HTMLElement {
    return document.createElement('span'); // unreachable
  }

  // ── Text Layer Event Listeners ────────────────────────────────────────────
  private setupTextLayerListeners(pageNum: number): void {
    const oldRemove = this.textLayerListeners.get(pageNum);
    if (oldRemove) oldRemove();

    const textLayer = document.querySelector(
      `.page[data-page-number="${pageNum}"] .textLayer`
    ) as HTMLElement;
    if (!textLayer) return;

    const clickHandler = (e: MouseEvent): void => {
      if (!this.captureActive) return;
      if (!this.captureService.click2pickMode() && !this.boxMode) return;
      if (e.detail >= 2) return;
      // Block click if a box-select just fired (box pointerup sets _lastWordEmitMs)
      if (Date.now() - this._lastWordEmitMs < 300) return;
      e.preventDefault(); e.stopPropagation();
      const p = this.payloadFromClick(e, pageNum);
      if (!p) return;
      this.setPreviewHighlight(p);
      this.ngZone.run(() => this.wordCaptured.emit(p));
    };

    const dblClickHandler = (e: MouseEvent): void => {
      e.preventDefault(); e.stopPropagation();
      window.getSelection()?.removeAllRanges();
      const p = this.payloadFromClick(e, pageNum);
      if (!p) return;
      this.setPreviewHighlight(p);
      this.ngZone.run(() => this.wordCaptured.emit(p));
    };

    // pointerdown is now intercepted at the viewerContainer level for ALL capture modes.
    // The textLayer mousedown does not need to preventDefault — it would block
    // the synthesized click event that _startDrag dispatches on small movements.
    const mousedownHandler = (_e: MouseEvent) => { /* intentionally empty */ };

    textLayer.addEventListener('mousedown', mousedownHandler, { passive: false } as EventListenerOptions);
    textLayer.addEventListener('click', clickHandler);
    textLayer.addEventListener('dblclick', dblClickHandler);
    this.textLayerListeners.set(pageNum, () => {
      textLayer.removeEventListener('mousedown', mousedownHandler);
      textLayer.removeEventListener('click', clickHandler);
      textLayer.removeEventListener('dblclick', dblClickHandler);
    });
  }

  /**
   * Extract the word under the cursor at click time using caretRangeFromPoint.
   *
   * This approach works correctly for ALL PDF fonts including those with CSS
   * transforms (scaleX, matrix) applied by PDF.js — because it uses the
   * browser's own hit-test and text layout engine rather than DOM measurements
   * on manually-injected sub-spans.
   *
   * Steps:
   * 1. caretRangeFromPoint → finds the text node + offset under the cursor
   * 2. Expand the Range to word boundaries using a word-boundary regex
   * 3. getClientRects() on the Range → accurate screen rect (transform-aware)
   * 4. Convert to fractional canvas coords via domRectToPayload
   */
  private payloadFromClick(e: MouseEvent, pageNum: number): CapturedWordPayload | null {
    // ── PATH 0 (HIGHEST): injected JSON span hit-test ─────────────────────────
    // caretRangeFromPoint finds the element under the cursor.
    // If it's one of our injected [data-json-word] spans, read coords directly
    // from the span's data-attributes. This is 100% accurate — no index lookup,
    // no BCR math, no race conditions. The span IS the JSON word.
    const elUnder = (document as any).caretRangeFromPoint?.(e.clientX, e.clientY)
                  ?? (document as any).caretPositionFromPoint?.(e.clientX, e.clientY);
    const nodeUnder = elUnder?.startContainer ?? elUnder?.offsetNode;
    const spanUnder = (nodeUnder?.nodeType === Node.TEXT_NODE
                        ? nodeUnder.parentElement
                        : nodeUnder) as HTMLElement | null;

    if (spanUnder?.getAttribute('data-json-word') === '1') {
      const x = parseFloat(spanUnder.getAttribute('data-x') || '0');
      const y = parseFloat(spanUnder.getAttribute('data-y') || '0');
      const w = parseFloat(spanUnder.getAttribute('data-w') || '0');
      const h = parseFloat(spanUnder.getAttribute('data-h') || '0');
      const t = spanUnder.getAttribute('data-t') || spanUnder.textContent || '';
      return { text: t, page: pageNum, x, y, width: w, height: h };
    }

    // ── PATH 1: Word index hit-test (precision JSON spans) ─────────────────────
    const ref = this._getPageRef(pageNum);
    const fx  = ref ? (e.clientX - ref.bcr.left) / ref.bcr.width  : -1;
    const fy  = ref ? (e.clientY - ref.bcr.top)  / ref.bcr.height : -1;

    if (this._wordIndexRaw.has(pageNum) && fx >= 0) {
      const hit = this.hitTestWordIndex(fx, fy, pageNum);
      return hit
        ? { text: hit.t, page: pageNum, x: hit.x, y: hit.y, width: hit.w, height: hit.h }
        : null;
    }

    // ── PATH 3: DOM caretRangeFromPoint — pure library fallback ──────────────
    // Only runs when no JSON index is loaded for this page.
    let range: Range | null = null;
    if ((document as any).caretRangeFromPoint) {
      range = (document as any).caretRangeFromPoint(e.clientX, e.clientY);
    } else if ((document as any).caretPositionFromPoint) {
      const pos = (document as any).caretPositionFromPoint(e.clientX, e.clientY);
      if (pos) {
        range = document.createRange();
        range.setStart(pos.offsetNode, pos.offset);
        range.setEnd(pos.offsetNode, pos.offset);
      }
    }
    if (!range) return null;

    const node = range.startContainer;
    if (node.nodeType !== Node.TEXT_NODE) return null;

    const textContent = node.textContent || '';
    if (!textContent.trim()) return null;

    let start = range.startOffset;
    let end   = range.startOffset;
    while (start > 0 && /\w/.test(textContent[start - 1])) start--;
    while (end < textContent.length && /\w/.test(textContent[end])) end++;
    if (start === end) {
      start = range.startOffset; end = range.startOffset;
      while (start > 0 && !/\s/.test(textContent[start - 1])) start--;
      while (end < textContent.length && !/\s/.test(textContent[end])) end++;
    }
    if (start === end) return null;

    const rawText  = textContent.slice(start, end);
    const wordText = rawText.replace(/^[^\w]+|[^\w]+$/g, '');
    if (!wordText) return null;

    start += rawText.length - rawText.replace(/^[^\w]+/, '').length;
    end   -= rawText.length - rawText.replace(/[^\w]+$/, '').length;

    const wordRange = document.createRange();
    wordRange.setStart(node, start);
    wordRange.setEnd(node, end);
    const rects = Array.from(wordRange.getClientRects());
    if (!rects.length) return null;
    const rect = rects.find(r => e.clientY >= r.top && e.clientY <= r.bottom) || rects[0];
    return this.domRectToPayload(
      { left: rect.left, top: rect.top, width: rect.width, height: rect.height },
      wordText, pageNum
    );
  }

  /**
   * Convert a DOM bounding rect to a CapturedWordPayload.
   *
   * IMPORTANT — coordinate alignment with pdfplumber/external JSON:
   * pdfplumber measures from the PDF canvas edge (no padding).
   * PDF.js wraps the canvas in a .page div that adds ~9px padding on each side.
   * Using pageEl.getBoundingClientRect() as the reference includes that padding,
   * causing a systematic ~10% offset vs external JSON coordinates.
   *
   * Fix: use the CANVAS element's bounding rect as the reference origin and scale.
   * canvas.getBoundingClientRect() matches exactly what pdfplumber sees.
   *
   * Coordinates stored as 0-1 fractions of canvas size — zoom-independent.
   */
  private domRectToPayload(
    domRect: { left: number; top: number; width: number; height: number },
    text: string,
    pageNum: number
  ): CapturedWordPayload | null {
    const pageEl = document.querySelector(`.page[data-page-number="${pageNum}"]`) as HTMLElement;
    if (!pageEl) return null;

    // Use the CANVAS rect — not the .page div rect — to exclude PDF.js padding
    const canvas = pageEl.querySelector('canvas') as HTMLCanvasElement | null;
    const ref    = canvas ? canvas.getBoundingClientRect() : pageEl.getBoundingClientRect();

    if (ref.width === 0 || ref.height === 0) return null;

    return {
      text, page: pageNum,
      x:      (domRect.left - ref.left) / ref.width,
      y:      (domRect.top  - ref.top)  / ref.height,
      width:  domRect.width  / ref.width,
      height: domRect.height / ref.height,
    };
  }

  // ── Box Select ────────────────────────────────────────────────────────────
  // onBoxMouse* are now handled entirely inside _startDrag / injectRubberbandOverlay
  // Keeping stubs for any legacy call sites
  onBoxMouseDown(_e: MouseEvent): void {}
  onBoxMouseMove(_e: MouseEvent): void {}
  onBoxMouseUp(_e: MouseEvent): void {}
  onBoxMouseLeave(_e: MouseEvent): void {}

  private collectWordsInBox(selL: number, selT: number, selR: number, selB: number): void {
    const captured: Array<{ payload: CapturedWordPayload; top: number; left: number }> = [];

    for (const pageNum of this.renderedPages) {
      const pageEl  = document.querySelector(`.page[data-page-number="${pageNum}"]`) as HTMLElement | null;
      if (!pageEl) continue;
      const canvasEl = pageEl.querySelector('canvas') as HTMLCanvasElement | null;
      const pr = (canvasEl ?? pageEl).getBoundingClientRect();
      if (pr.right < selL || pr.left > selR || pr.bottom < selT || pr.top > selB) continue;

      // ── PATH A: Word index — O(n) fractional bbox hit-test, no DOM needed ──
      if (this._wordIndexRaw.has(pageNum) && pr.width > 0) {
        const fx1 = (selL - pr.left) / pr.width;
        const fy1 = (selT - pr.top)  / pr.height;
        const fx2 = (selR - pr.left) / pr.width;
        const fy2 = (selB - pr.top)  / pr.height;

        const hits = this.getWordsInBox(pageNum, fx1, fy1, fx2, fy2);
        for (const hit of hits) {
          const screenY = hit.y * pr.height + pr.top;
          const screenX = hit.x * pr.width  + pr.left;
          captured.push({
            payload: { text: hit.t, page: pageNum, x: hit.x, y: hit.y, width: hit.w, height: hit.h },
            top: screenY, left: screenX
          });
        }
        continue; // skip DOM path for this page
      }

      // ── PATH B: DOM fallback — use data-attributes for JSON spans ────────────
      for (const span of Array.from(pageEl.querySelectorAll('.textLayer span')) as HTMLElement[]) {
        const sr = span.getBoundingClientRect();
        // Include word if ANY part of it intersects the selection box (touch = capture)
        if (sr.right < selL - 1 || sr.left > selR + 1 || sr.bottom < selT - 1 || sr.top > selB + 1) continue;
        const fullText = span.textContent || '';
        if (!fullText.trim()) continue;

        // JSON span: use exact data-attribute coords — no DOM Range needed
        if (span.getAttribute('data-json-word') === '1') {
          const x = parseFloat(span.getAttribute('data-x') || '0');
          const y = parseFloat(span.getAttribute('data-y') || '0');
          const w = parseFloat(span.getAttribute('data-w') || '0');
          const h = parseFloat(span.getAttribute('data-h') || '0');
          const t = span.getAttribute('data-t') || fullText;
          const screenX = x * pr.width  + pr.left;
          const screenY = y * pr.height + pr.top;
          captured.push({
            payload: { text: t, page: pageNum, x, y, width: w, height: h },
            top: screenY, left: screenX
          });
          continue;
        }

        // PDF.js span: use DOM Range + getClientRects()
        const textNode = Array.from(span.childNodes).find(n => n.nodeType === Node.TEXT_NODE) as Text | undefined;
        if (!textNode) continue;
        const wordRegex = /\S+/g;
        let match: RegExpExecArray | null;
        while ((match = wordRegex.exec(fullText)) !== null) {
          try {
            const wRange = document.createRange();
            wRange.setStart(textNode, match.index);
            wRange.setEnd(textNode, match.index + match[0].length);
            const wr = wRange.getClientRects()[0];
            if (!wr || wr.right < selL - 1 || wr.left > selR + 1 || wr.bottom < selT - 1 || wr.top > selB + 1) continue;
            const p = this.domRectToPayload({ left:wr.left, top:wr.top, width:wr.width, height:wr.height }, match[0], pageNum);
            if (p) captured.push({ payload: p, top: wr.top, left: wr.left });
          } catch { /* skip */ }
        }
      }
    }

    if (!captured.length) return;
    captured.sort((a, b) => Math.abs(a.top - b.top) < 8 ? a.left - b.left : a.top - b.top);

    this.ngZone.run(() => {
      const texts   = captured.map(c => c.payload.text).join(' ');
      const minX    = Math.min(...captured.map(c => c.payload.x));
      const minY    = Math.min(...captured.map(c => c.payload.y));
      const maxX    = Math.max(...captured.map(c => c.payload.x + c.payload.width));
      const maxY    = Math.max(...captured.map(c => c.payload.y + c.payload.height));
      const boxPage = captured[0].payload.page;
      const merged: CapturedWordPayload = {
        text: texts, page: boxPage,
        x: minX, y: minY,
        width: maxX - minX, height: maxY - minY,
      };
      // Show preview highlight for the merged box region
      this._lastWordEmitMs = Date.now();
      this.setPreviewHighlight(merged);
      this.boxCaptured.emit(merged);
    });
  }

  // ── Canvas Highlight Rendering ────────────────────────────────────────────
  private getOrCreateCanvas(pageNum: number): HTMLCanvasElement | null {
    // Verify cached canvas is still attached to the DOM — PDF.js may have
    // virtualised the page (removed + re-added the page div during fast scroll).
    if (this.highlightCanvases.has(pageNum)) {
      const cached = this.highlightCanvases.get(pageNum)!;
      if (cached.isConnected) return cached;  // still in DOM — use it
      // Detached: page was virtualised. Remove stale refs and recreate.
      this.highlightCanvases.delete(pageNum);
      this._pageElCache.delete(pageNum);
    }

    const pageEl    = document.querySelector(`.page[data-page-number="${pageNum}"]`) as HTMLElement;
    if (!pageEl) return null;
    const pdfCanvas = pageEl.querySelector('canvas') as HTMLCanvasElement;
    if (!pdfCanvas?.parentElement) return null;

    // Remove any existing detached highlight canvases to avoid duplicates
    pageEl.querySelectorAll('[data-highlight-canvas]').forEach(c => c.remove());

    const canvas = document.createElement('canvas');
    canvas.width  = pdfCanvas.width;
    canvas.height = pdfCanvas.height;
    canvas.style.cssText = 'position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:5;';
    canvas.setAttribute('data-highlight-canvas', String(pageNum));
    pdfCanvas.parentElement.style.position = 'relative';
    pdfCanvas.parentElement.appendChild(canvas);
    this.highlightCanvases.set(pageNum, canvas);
    return canvas;
  }

  private drawHighlightsForPage(pageNum: number): void {
    const canvas = this.getOrCreateCanvas(pageNum);
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // ── Snapshot computed values ONCE — all O(1) signal reads ─────────────────
    const activeId       = this.captureService.activeFieldId();
    const activeWordText = this.captureService.activeWordText();
    const fieldTextIdx   = this.captureService.fieldTextIndex();
    const highlights     = this.captureService.getHighlightsForPage(pageNum);
    const cw = canvas.width;
    const ch = canvas.height;

    // Early return — nothing to draw
    const fields      = this.captureService.fields();  // snapshot once — reused by LAYER 3
    const hasPreview  = this.previewHighlight?.page === pageNum;
    const hasL3       = this._layer3Cache.has(pageNum) || this._wordIndexRaw.size === 0;
    const hasCaptures = highlights.length > 0 || !!activeWordText;
    if (!hasCaptures && !hasPreview && !this._layer3Cache.has(pageNum)) return;

    // ── LAYER 0: Preview highlight — cyan pulse, drawn BELOW everything ────────
    // Shows the last clicked/box-selected region even when no field is active.
    // Fades in intensity with a sine wave on previewPulse for a living glow.
    if (hasPreview && this.previewHighlight) {
      const ph = this.previewHighlight;
      const pageEl  = document.querySelector(`.page[data-page-number="${pageNum}"]`) as HTMLElement | null;
      const pdfCvs  = pageEl?.querySelector('canvas') as HTMLCanvasElement | null;
      if (pageEl && pdfCvs) {
        const alpha   = 0.25 + 0.20 * Math.sin(this.previewPulse * 0.12); // 0.05–0.45 pulse
        const px = ph.x      * cw;
        const py = ph.y      * ch;
        const pw = ph.width  * cw;
        const phh= ph.height * ch;
        const r  = 3;

        ctx.save();
        ctx.fillStyle   = `rgba(6,182,212,${alpha})`;           // cyan fill
        ctx.strokeStyle = `rgba(6,182,212,${0.55 + alpha})`;    // cyan border
        ctx.lineWidth   = 2.5;
        ctx.shadowColor = 'rgba(6,182,212,0.6)';
        ctx.shadowBlur  = 8 + 4 * Math.sin(this.previewPulse * 0.12);

        ctx.beginPath();
        ctx.moveTo(px+r,py); ctx.lineTo(px+pw-r,py);
        ctx.quadraticCurveTo(px+pw,py,px+pw,py+r);
        ctx.lineTo(px+pw,py+phh-r); ctx.quadraticCurveTo(px+pw,py+phh,px+pw-r,py+phh);
        ctx.lineTo(px+r,py+phh); ctx.quadraticCurveTo(px,py+phh,px,py+phh-r);
        ctx.lineTo(px,py+r); ctx.quadraticCurveTo(px,py,px+r,py);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        ctx.restore();
      }
    }

    // ── LAYER 1: Yellow duplicate scan for active word ───────────────────────
    // For JSON spans (data-json-word=1): read exact coords from data-attributes.
    // For PDF.js spans: use getClientRects() on DOM Range (original behaviour).
    if (activeWordText) {
      const ref1 = this._getPageRef(pageNum);
      if (ref1) {
        const sx = cw / ref1.bcr.width;
        const sy = ch / ref1.bcr.height;
        ctx.fillStyle   = 'rgba(255,182,193,0.45)';   // light pink fill
        ctx.strokeStyle = 'rgba(220,80,120,0.85)';    // pink border
        ctx.lineWidth   = 1.5;

        const spans = this._getSpans(pageNum, ref1.pageEl);

        const drawBox = (dx: number, dy: number, dw: number, dh: number) => {
          const cr = 2;
          ctx.beginPath();
          ctx.moveTo(dx+cr,dy); ctx.lineTo(dx+dw-cr,dy);
          ctx.quadraticCurveTo(dx+dw,dy,dx+dw,dy+cr);
          ctx.lineTo(dx+dw,dy+dh-cr); ctx.quadraticCurveTo(dx+dw,dy+dh,dx+dw-cr,dy+dh);
          ctx.lineTo(dx+cr,dy+dh); ctx.quadraticCurveTo(dx,dy+dh,dx,dy+dh-cr);
          ctx.lineTo(dx,dy+cr); ctx.quadraticCurveTo(dx,dy,dx+cr,dy);
          ctx.closePath(); ctx.fill(); ctx.stroke();
        };

        for (let i = 0; i < spans.length; i++) {
          const span     = spans[i];
          const spanText = span.textContent || '';

          // ── JSON span: exact match on data-t attribute ────────────────────
          // "the" must NOT match "them", "other", "together" etc.
          if (span.getAttribute('data-json-word') === '1') {
            const spText = (span.getAttribute('data-t') || spanText).toLowerCase().trim();
            if (spText !== activeWordText) continue;
            const x = parseFloat(span.getAttribute('data-x') || '0');
            const y = parseFloat(span.getAttribute('data-y') || '0');
            const w = parseFloat(span.getAttribute('data-w') || '0');
            const h = parseFloat(span.getAttribute('data-h') || '0');
            drawBox(x * cw, y * ch, w * cw, h * ch);
            continue;
          }

          // ── PDF.js span: skip unless span contains an exact whole-word match ─
          // Use _getRegex which has \b word boundaries — "the" won't match "there"
          let textNode: Text | null = null;
          for (let c = 0; c < span.childNodes.length; c++) {
            if (span.childNodes[c].nodeType === Node.TEXT_NODE) {
              textNode = span.childNodes[c] as Text; break;
            }
          }
          if (!textNode) continue;

          const wordRe = this._getRegex(activeWordText);
          wordRe.lastIndex = 0;
          if (!wordRe.test(spanText)) continue;
          wordRe.lastIndex = 0;
          let match: RegExpExecArray | null;
          while ((match = wordRe.exec(spanText)) !== null) {
            try {
              const r = document.createRange();
              r.setStart(textNode, match.index);
              r.setEnd(textNode, match.index + match[0].length);
              const rects = r.getClientRects();
              for (let ri = 0; ri < rects.length; ri++) {
                const wr = rects[ri];
                if (wr.width === 0) continue;
                drawBox(
                  (wr.left - ref1.bcr.left) * sx,
                  (wr.top  - ref1.bcr.top)  * sy,
                  wr.width * sx, wr.height * sy
                );
              }
            } catch { /* skip */ }
          }
        }
      }
    }

    // ── LAYER 2: Grey field-capture highlights drawn on top ────────────────
    // highlights is already O(1) from the index.
    // fieldTextIdx lookup is O(1) — no fields.find() in the loop.
    for (let i = 0; i < highlights.length; i++) {
      const h        = highlights[i];
      const isActive = !!activeId && h.fieldId === activeId;
      const hText    = h.fieldId ? (fieldTextIdx.get(h.fieldId) ?? '') : '';
      const isDup    = !isActive && h.type === 'primary'
                       && !!activeWordText && hText === activeWordText;

      this.drawRect(ctx, {
        ...h,
        x:      h.x      * cw,
        y:      h.y      * ch,
        width:  h.width  * cw,
        height: h.height * ch,
      }, isActive, isDup);
    }

    // ── LAYER 3: Word-occurrence highlights for all confirmed captures ─────────
    //
    // Two sub-passes (grey drawn first, pink drawn on top):
    //
    //   PASS A — GREY: for every NON-ACTIVE confirmed field, draw grey at all
    //     other occurrences of that word (the captured coord is already grey
    //     from LAYER 2; this covers every other text-layer match).
    //
    //   PASS B — PINK: for the ACTIVE field only, draw pink at all other
    //     occurrences of its word (its captured coord is yellow from LAYER 2).
    //
    // skipKeys tracks all LAYER 2 positions so we never overdraw them.
    // After PASS A adds grey positions, PASS B's skipKeys includes them too,
    // so the same position won't be drawn twice.
    {
      const PREC     = 1000;
      const skipKeys = this._l3SkipKeys;
      skipKeys.clear();
      // Seed skipKeys with all LAYER 2 positions (captured coords)
      for (const h of highlights) {
        skipKeys.add(Math.round(h.x * PREC) * PREC + Math.round(h.y * PREC));
      }

      const l3Page = this._layer3Cache.get(pageNum);

      // Shared rounded-rect draw helper — uses current ctx fill/stroke
      const drawOccurrence = (dx: number, dy: number, dw: number, dh: number) => {
        const r = 2;
        ctx.beginPath();
        ctx.moveTo(dx+r,dy); ctx.lineTo(dx+dw-r,dy); ctx.quadraticCurveTo(dx+dw,dy,dx+dw,dy+r);
        ctx.lineTo(dx+dw,dy+dh-r); ctx.quadraticCurveTo(dx+dw,dy+dh,dx+dw-r,dy+dh);
        ctx.lineTo(dx+r,dy+dh); ctx.quadraticCurveTo(dx,dy+dh,dx,dy+dh-r);
        ctx.lineTo(dx,dy+r); ctx.quadraticCurveTo(dx,dy,dx+r,dy);
        ctx.closePath(); ctx.fill(); ctx.stroke();
      };

      // Shared scanner: finds all occurrences of wt not in skipKeys, calls onHit
      const scanWord = (wt: string, onHit: (dx:number,dy:number,dw:number,dh:number)=>void) => {
        if (l3Page) {
          const dups = l3Page.get(wt);
          if (dups) {
            for (const d of dups) {
              const key = Math.round(d.x * PREC) * PREC + Math.round(d.y * PREC);
              if (skipKeys.has(key)) continue;
              skipKeys.add(key);
              onHit(d.x*cw, d.y*ch, d.w*cw, d.h*ch);
            }
          }
        } else {
          const ref3 = this._getPageRef(pageNum);
          if (!ref3) return;
          const sx    = cw / ref3.bcr.width;
          const sy    = ch / ref3.bcr.height;
          const re3   = this._getRegex(wt);
          const spans = this._getSpans(pageNum, ref3.pageEl);
          for (let si = 0; si < spans.length; si++) {
            const span     = spans[si];
            const spanText = span.textContent || '';
            if (span.getAttribute('data-json-word') === '1') {
              const spText = (span.getAttribute('data-t') || spanText).toLowerCase().trim();
              if (spText !== wt) continue;
              const dx = parseFloat(span.getAttribute('data-x') || '0') * cw;
              const dy = parseFloat(span.getAttribute('data-y') || '0') * ch;
              const dw = parseFloat(span.getAttribute('data-w') || '0') * cw;
              const dh = parseFloat(span.getAttribute('data-h') || '0') * ch;
              const key = Math.round((dx/cw) * PREC) * PREC + Math.round((dy/ch) * PREC);
              if (!skipKeys.has(key)) { skipKeys.add(key); onHit(dx, dy, dw, dh); }
              continue;
            }
            let tn: Text | null = null;
            for (let c = 0; c < span.childNodes.length; c++) {
              if (span.childNodes[c].nodeType === Node.TEXT_NODE) { tn = span.childNodes[c] as Text; break; }
            }
            if (!tn) continue;
            re3.lastIndex = 0;
            let m: RegExpExecArray | null;
            while ((m = re3.exec(spanText)) !== null) {
              try {
                const rng = document.createRange();
                rng.setStart(tn, m.index); rng.setEnd(tn, m.index + m[0].length);
                const rcts = rng.getClientRects();
                for (let ri = 0; ri < rcts.length; ri++) {
                  const wr = rcts[ri];
                  if (wr.width === 0) continue;
                  const dx = (wr.left - ref3.bcr.left) * sx;
                  const dy = (wr.top  - ref3.bcr.top)  * sy;
                  const key = Math.round((dx/cw) * PREC) * PREC + Math.round((dy/ch) * PREC);
                  if (skipKeys.has(key)) continue;
                  skipKeys.add(key);
                  onHit(dx, dy, wr.width*sx, wr.height*sy);
                }
              } catch { /* skip */ }
            }
          }
        }
      };

      // ── PASS A: Grey/custom-color occurrences for all NON-ACTIVE fields ─────────
      // Uses pre-computed _colorGroupCache (built in _rebuildLayer3Cache, zero alloc here)
      // and _fieldWordCache (pre-cleaned word texts, no per-draw string ops)
      for (const grp of this._colorGroupCache) {
        const { colorKey, entries } = grp;
        // Skip entries — each entry's id will be checked against activeId below
        let drewAny = false;
        for (const { id, wt } of entries) {
          if (id === activeId) continue;   // active field handled in PASS B
          if (!drewAny) {
            // Lazy ctx.save — only if this group actually draws something
            ctx.save();
            if (colorKey === '__grey__') {
              ctx.fillStyle   = 'rgba(150,150,150,0.18)';
              ctx.strokeStyle = 'rgba(120,120,120,0.70)';
            } else {
              ctx.fillStyle   = this._colorToRgba(colorKey, 0.20);
              ctx.strokeStyle = colorKey;
            }
            ctx.lineWidth = 1.5;
            drewAny = true;
          }
          scanWord(wt, drawOccurrence);
        }
        if (drewAny) ctx.restore();
      }

      // ── PASS B: Pink — active field's word occurrences only ──────────────────
      // Use pre-computed _activeFieldWt (no find() or string ops per draw)
      const activeWt = this._activeFieldWt;
      if (activeId && activeWt) {
        ctx.save();
        ctx.fillStyle   = 'rgba(255,182,193,0.40)';
        ctx.strokeStyle = 'rgba(220,80,120,0.80)';
        ctx.lineWidth   = 1.5;
        scanWord(activeWt, drawOccurrence);
        ctx.restore();
      }
    } // end LAYER 3
  } // end drawHighlightsForPage

  /** Convert any CSS color string to rgba with given alpha for canvas fills.
   *  Works for: hex (#rgb / #rrggbb), named colors, rgb/hsl strings.
   *  For named/rgb/hsl we use a temporary canvas to resolve to rgb values. */
  private _colorToRgba(color: string, alpha: number): string {
    if (!color) return 'rgba(150,150,150,' + alpha + ')';
    const cacheKey = color + ':' + alpha;
    const cached = this._rgbaCache.get(cacheKey);
    if (cached) return cached;

    let result: string;
    // Hex 3-digit
    const h3 = color.match(/^#([0-9a-f]{3})$/i);
    if (h3) {
      const [r,g,b] = h3[1].split('').map(c => parseInt(c+c, 16));
      result = 'rgba(' + r + ',' + g + ',' + b + ',' + alpha + ')';
    } else {
      // Hex 6-digit
      const h6 = color.match(/^#([0-9a-f]{6})$/i);
      if (h6) {
        const n = parseInt(h6[1], 16);
        result = 'rgba(' + (n>>16&255) + ',' + (n>>8&255) + ',' + (n&255) + ',' + alpha + ')';
      } else {
        // Named colors / rgb() / hsl() — resolve once via offscreen canvas then cache
        try {
          const c2d = document.createElement('canvas').getContext('2d')!;
          c2d.fillStyle = color;
          const resolved = c2d.fillStyle;
          const h6r = resolved.match(/^#([0-9a-f]{6})$/i);
          if (h6r) {
            const n = parseInt(h6r[1], 16);
            result = 'rgba(' + (n>>16&255) + ',' + (n>>8&255) + ',' + (n&255) + ',' + alpha + ')';
          } else {
            result = 'rgba(150,150,150,' + alpha + ')';
          }
        } catch { result = 'rgba(150,150,150,' + alpha + ')'; }
      }
    }
    this._rgbaCache.set(cacheKey, result);
    return result;
  }

  private drawRect(ctx: CanvasRenderingContext2D, h: HighlightRect, isActive: boolean, isDup: boolean): void {
    const { x, y, width: w, height: hh } = h;
    ctx.save(); ctx.shadowBlur = 0;

    // ── Colour scheme ────────────────────────────────────────────────────────
    // ACTIVE (current selection)        → yellow
    // DUPLICATE (same text as active)   → light pink
    // PREVIOUS captures (other fields)  → grey
    // EXTERNAL coordinates              → purple
    if (h.type === 'external') {
      ctx.fillStyle   = 'rgba(139,92,246,0.22)';
      ctx.strokeStyle = 'rgba(139,92,246,0.85)';
      ctx.lineWidth   = 1.5;
    } else if (isActive) {
      // Yellow — current active selection
      ctx.fillStyle   = 'rgba(255,230,0,0.35)';
      ctx.strokeStyle = 'rgba(200,160,0,0.95)';
      ctx.lineWidth   = 2.5;
      ctx.shadowColor = 'rgba(220,180,0,0.50)';
      ctx.shadowBlur  = 8;
    } else if (isDup) {
      // Light pink — duplicate of current active word
      ctx.fillStyle   = 'rgba(255,182,193,0.40)';
      ctx.strokeStyle = 'rgba(220,80,120,0.85)';
      ctx.lineWidth   = 2;
    } else {
      // Custom colour or default grey — non-active confirmed capture
      if (h.color) {
        // User-specified colour: use it for both fill (low alpha) and border (full)
        ctx.fillStyle   = this._colorToRgba(h.color, 0.20);
        ctx.strokeStyle = h.color;
        ctx.lineWidth   = 1.5;
      } else {
        ctx.fillStyle   = 'rgba(150,150,150,0.18)';
        ctx.strokeStyle = 'rgba(120,120,120,0.70)';
        ctx.lineWidth   = 1.5;
      }
    }

    // Rounded rect
    const r = 3;
    ctx.beginPath();
    ctx.moveTo(x+r,y); ctx.lineTo(x+w-r,y); ctx.quadraticCurveTo(x+w,y,x+w,y+r);
    ctx.lineTo(x+w,y+hh-r); ctx.quadraticCurveTo(x+w,y+hh,x+w-r,y+hh);
    ctx.lineTo(x+r,y+hh); ctx.quadraticCurveTo(x,y+hh,x,y+hh-r);
    ctx.lineTo(x,y+r); ctx.quadraticCurveTo(x,y,x+r,y);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    ctx.restore();
  }
}