/**
 * All x, y, width, height values are stored as FRACTIONS (0–1) of the
 * page's rendered dimensions.  This makes them zoom-independent.
 */

export interface WordCoordinate {
  id: string;
  text: string;
  page: number;
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface InputField {
  id: string;
  label: string;
  value: string;
  capturedWord: CapturedWord | null;
  isFocused: boolean;
  /** True when this field's value + coords were pre-loaded from _captured_fields.json */
  fromJson?: boolean;
  /** Original coord format from the input JSON — preserved for round-trip export */
  sourceFormat?: CapturedFieldFormat;
}

export interface CapturedWord {
  text: string;
  page: number;
  x: number;
  y: number;
  width: number;
  height: number;
  fieldId: string;
}

/**
 * The JSON format for _captured_fields.json — both input and output.
 * Supports flat {x,y,width,height} OR bbox:[x,y,w,h].
 */
/**
 * All supported input formats for _captured_fields.json.
 * The format used in the input file is preserved and used on export.
 */
export interface CapturedFieldJson {
  id?: string;
  label?: string;
  value?: string;
  page?: number;
  // Format A: flat {x, y, width, height}
  x?: number;
  y?: number;
  width?: number;
  height?: number;
  // Format B: bbox array [x, y, w, h]
  bbox?: [number, number, number, number];
  // Format C: rectangle array [x, y, w, h]  ← new format
  rectangle?: [number, number, number, number];
  // Optional custom highlight colour (CSS colour string, e.g. '#e63946' or 'red')
  color?: string;
  // Optional page dimensions for absolute-coord normalisation
  pageWidth?: number;
  pageHeight?: number;
  pagewidth?: number;
  pageheight?: number;
}

/** Which coord key was present in the original input — preserved for round-trip export */
export type CapturedFieldFormat = 'flat' | 'bbox' | 'rectangle';

export interface HighlightRect {
  page: number;
  x: number;
  y: number;
  width: number;
  height: number;
  type: 'primary' | 'duplicate' | 'external';
  fieldId?: string;
  label?: string;
  /** Custom colour for this capture — overrides default grey when not active */
  color?: string;
}

export type HighlightMode = 'click2pick' | 'field-focus' | 'external';