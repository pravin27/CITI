/**
 * All x, y, width, height values are stored as FRACTIONS (0–1) of the
 * page's rendered dimensions.  This makes them zoom-independent.
 */

export interface WordCoordinate {
  id: string;
  text: string;
  page: number;
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface InputField {
  id: string;
  label: string;
  value: string;
  capturedWord: CapturedWord | null;
  isFocused: boolean;
  /** True when this field's value + coords were pre-loaded from _captured_fields.json */
  fromJson?: boolean;
}

export interface CapturedWord {
  text: string;
  page: number;
  x: number;
  y: number;
  width: number;
  height: number;
  fieldId: string;
}

/**
 * The JSON format for _captured_fields.json — both input and output.
 * Supports flat {x,y,width,height} OR bbox:[x,y,w,h].
 */
export interface CapturedFieldJson {
  id: string;
  label: string;
  value: string;
  page: number;
  x?: number;
  y?: number;
  width?: number;
  height?: number;
  bbox?: [number, number, number, number];
  /** Optional: page dimensions for absolute-coord normalisation */
  pageWidth?: number;
  pageHeight?: number;
}

export interface HighlightRect {
  page: number;
  x: number;
  y: number;
  width: number;
  height: number;
  type: 'primary' | 'duplicate' | 'external';
  fieldId?: string;
  label?: string;
}

export type HighlightMode = 'click2pick' | 'field-focus' | 'external';